<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function varify_admin_session(){
	$CI = &get_instance();
    
	$controller = $CI->router->class;
	
	if(($CI->session->userdata('admin_logged_in') != 1) && ($controller != "admin")){
		redirect('admin','refresh');
	}else{
		return true;
	}
}

function varify_user_session(){
	$CI = &get_instance();
    
	if(($CI->session->userdata('user_logged_in') != 1)){
		redirect('front','refresh');
	}else{
		return true;
	}
}
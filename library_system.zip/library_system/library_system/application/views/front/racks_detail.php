<div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
        	
            <?php if(($rack_details) && (count($rack_details) > 0)): ?>
            <p>Books in <b><?php if($rack_name): echo $rack_name->name; endif; ?></b> Rack</p>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <td><strong>Book Title</strong></td>
                        <td><strong>Book Author</strong></td>
                        <td><strong>Published Year</strong></td>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($rack_details as $book){
                          echo '<tr>';
                          echo '<td>'.$book->book_title."</td>";
                          echo '<td>'.$book->book_author."</td>";
                          echo '<td>'.$book->published_year."</td>";
                          echo '</tr>';
                      } ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>There is no Book in <b><?php if($rack_name): echo $rack_name->name; endif; ?></b> Rack.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
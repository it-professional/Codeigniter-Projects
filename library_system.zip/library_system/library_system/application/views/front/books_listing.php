<div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
        	<form class="form-inline my-2 my-lg-0" action="<?php echo site_url('front/search');?>" method="post">
				<input class="form-control mr-sm-2" name="search_word" type="search" placeholder="Search Book" value="<?php echo set_value('search_word'); ?>">
  				<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
  				<?php echo form_error('search_word'); ?>
			</form>
        	
            <?php if(($books) && (count($books) > 0)): ?>
            <p>All Books in Racks</p>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <td><strong>Book Title</strong></td>
                        <td><strong>Book Author</strong></td>
                        <td><strong>Published Year</strong></td>
                        <td><strong>Rack Name</strong></td>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($books as $book){
                          echo '<tr>';
                          echo '<td>'.$book->book_title."</td>";
                          echo '<td>'.$book->book_author."</td>";
                          echo '<td>'.$book->published_year."</td>";
						  echo '<td>'.$book->rack_name."</td>";
                          echo '</tr>';
                      } ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>There is no Book.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
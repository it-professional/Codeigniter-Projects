<div class="container">
    <div class="row">
        <div class="col-md-6 text-center">
        	<h2>Racks List</h2>
            
            <?php if(($racks) && (count($racks) > 0)): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <td><strong>Rack Name</strong></td>
                        <td><strong>No of Books</strong></td>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($racks as $rack){
                          echo '<tr>';
                          echo '<td><a href="'.site_url('front/rack_detail/'.$rack->id).'">'.$rack->name."</a></td>";
                          echo '<td>'.$rack->no_of_books."</td>";
                          echo '</tr>';
                      } ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>No Rack Found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
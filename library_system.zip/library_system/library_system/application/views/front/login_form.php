<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Library System</title>
        <link href="<?php echo base_url('includes/bootstrap-alpha/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css">
        <script src="<?php echo base_url('includes/bootstrap-alpha/js/bootstrap.js');?>"></script>
		<script src="<?php echo base_url('includes/bootstrap-alpha/js/bootstrap.min.js');?>" ></script>
    </head>
    <body>
        <div class="container">  
            <nav class="navbar navbar-toggleable-md">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('front/login'); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('front/register'); ?>">Register</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="container">
        	<div class="row">
            	<div class="col-md-4 text-center">
                	<h2>User Login</h2>
                </div>
            </div>
        	<div class="row">
            	<div class="col-md-12">
                	<?php if(isset($login_error)):  echo '<div class="row"><div class="col-md-4 text-center"><div class="form-control">'.$login_error.'</div></div></div>'; endif; ?>
                                      
                    <form action="<?php echo site_url('front/login');?>" method="post" >
                    	<div class="row">
                        	<div class="col-md-4">
                            	<div class="form-group">
                                	<label for="username">Username: </label>
                                	<input type="text" name="loginusername" id="username" class="form-control"  placeholder="User Name" value="<?php echo set_value('loginusername'); ?>" />
                                    <?php echo form_error('loginusername'); ?>
                                </div>
                        	</div>
                        </div>
                        
                        <div class="row">
                        	<div class="col-md-4">
                            	<div class="form-group">
                                	<label for="password">Password: </label>
                                	<input type="password" name="loginpassword" id="password" class="form-control"  placeholder="Password" value="<?php echo set_value('loginpassword'); ?>" />
                                    <?php echo form_error('loginpassword'); ?>
                                </div>
                        	</div>
                        </div>
                        
                        <div class="row">
                        	<div class="col-md-4">
                                <div class="text-center">
                                    <input type="submit" class="btn btn-primary" value="LOGIN">
                                </div>
                   			</div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
	</body>
</html>
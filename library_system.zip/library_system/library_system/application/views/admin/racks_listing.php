<div class="container">
    <div class="row">
        <div class="col-md-4 text-center">
        	<p><a href="<?php echo site_url('racks/add'); ?>">Add new Rack</a></p>
            
            <?php if(($racks) && count($racks)>0): ?>
            <h2>Racks Listing</h2>
            <ul class="list-group">
            	<?php foreach($racks as $rack): ?>
                	<li class="list-group-item"><?php echo $rack->name; ?></li>
                <?php endforeach; ?>
            </ul>
            <?php else: ?>
            	<h2>No Rack Found.</h2>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4 text-center">
            <h2>Add Rack</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php if(isset($db_error)):  echo '<div class="row"><div class="col-md-4 text-center"><div class="form-control text-danger">'.$db_error.'</div></div></div>'; endif; ?>
                              
            <form action="<?php echo site_url('racks/save');?>" method="post" >
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="rack_name">Name: </label>
                            <input type="text" name="rack_name" id="rack_name" class="form-control"  placeholder="Rack Name" value="<?php echo set_value('rack_name'); ?>" />
                            <?php echo form_error('rack_name'); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <input type="submit" class="btn btn-primary" value="Add Rack">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
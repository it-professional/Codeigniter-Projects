<div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
            <h2>Welcome to Library System</h2>
        </div>
    </div>
</div>
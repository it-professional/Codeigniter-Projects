<?php
$this->load->view('admin/header');
if(isset($content)): echo $content; endif;
$this->load->view('admin/footer');
?>
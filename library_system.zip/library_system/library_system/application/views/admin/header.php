<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Library System</title>
        <link href="<?php echo base_url('includes/bootstrap-alpha/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css">
        <script src="<?php echo base_url('includes/bootstrap-alpha/js/bootstrap.js');?>"></script>
		<script src="<?php echo base_url('includes/bootstrap-alpha/js/bootstrap.min.js');?>" ></script>
    </head>
    <body>
    <div class="container">  
		<nav class="navbar navbar-toggleable-md">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link" href="<?php echo site_url('admin/racks'); ?>">Manage Racks</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo site_url('admin/books'); ?>">Manage Books</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo site_url('admin/logout'); ?>">Logout</a>
				</li>
			</ul>
		</nav>
	</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
        	<p><a href="<?php echo site_url('books/add'); ?>">Add new Book</a></p>
            
            <?php if(($books) && (count($books) > 0)): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <td><strong>Book Title</strong></td>
                        <td><strong>Book Author</strong></td>
                        <td><strong>Published Year</strong></td>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($books as $book){
                          echo '<tr>';
                          echo '<td>'.$book->book_title."</td>";
                          echo '<td>'.$book->book_author."</td>";
                          echo '<td>'.$book->published_year."</td>";
                          echo '</tr>';
                      } ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>There is no Book.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4 text-center">
            <h2>Add New Book</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php if(isset($db_error)):  echo '<div class="row"><div class="col-md-4 text-center"><div class="form-control text-danger">'.$db_error.'</div></div></div>'; endif; ?>
                              
            <form action="<?php echo site_url('books/save');?>" method="post" >
            
                <?php if(isset($racks)): ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="rack_no">Rack: </label>
                            <select name="rack_no">
                                <option value="">--- Choose Rack ---</option>
                                <?php foreach($racks as $rack): ?>
                                    <option  value="<?php echo $rack->id; ?>" <?php echo set_select('rack_no', $rack->id); ?>><?php echo $rack->name; ?></option>
                                <?php endforeach; ?>
                            </select> 
                            <?php echo form_error('rack_no'); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="book_title">Book Title: </label>
                            <input type="text" name="book_title" id="book_title" class="form-control"  placeholder="Book Title" value="<?php echo set_value('book_title'); ?>" />
                            <?php echo form_error('book_title'); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="book_author">Book Author: </label>
                            <input type="text" name="book_author" id="book_author" class="form-control"  placeholder="Author Name" value="<?php echo set_value('book_author'); ?>" />
                            <?php echo form_error('book_author'); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="published_year">Published Year: </label>
                            <input type="text" name="published_year" id="published_year" class="form-control"  placeholder="Published Year" value="<?php echo set_value('published_year'); ?>" />
                            <?php echo form_error('published_year'); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <input type="submit" class="btn btn-primary" value="Add Book">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();	
		
		varify_admin_session(); 
		
		$this->load->library('form_validation');
		$this->load->model('login_model');
	}
	
	public function index()
	{
		if($this->session->userdata('admin_logged_in') == 1)
		{
			$data['content'] =  $this->load->view('admin/dashboard','',true);	
			$this->load->view('admin/template', $data);
		}
		else
		{
			$this->load->view('admin/login');
		}
	}
	
	public function login()
	{	
		$this->form_validation->set_rules('loginusername', 'Username', 'trim|required', array("required" => "User Name Required"));
		$this->form_validation->set_rules('loginpassword', 'Password', 'trim|required', array("required" => "Please Enter Password"));
		
		if($this->form_validation->run() == FALSE)
		{	
			$this->load->view('admin/login');
		}
		else
		{				
			$password = base64_encode($this->input->post('loginpassword')) ;
			$result = intval($this->login_model->validate_admin_login( $this->input->post('loginusername'), $password)) ;
			
			if($result == "0")
			{
				$data['login_error'] = 'Login failed, invalid user name or password';				
				$this->load->view('admin/login', $data);	
			}
			else
			{	
				$sessiondata = array('logged_in_username'=> $this->input->post('loginusername'),'admin_logged_in' => 1);
				$this->session->set_userdata($sessiondata);
				
				redirect(site_url('admin'));
			}
		}
	}
	
	function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url('admin'));
	}
}
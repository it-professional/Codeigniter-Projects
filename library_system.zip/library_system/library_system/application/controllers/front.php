<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('login_model');
		$this->load->model('rack');
		$this->load->model('book');
	}

	public function index()
	{
		if($this->session->userdata('user_logged_in'))
		{
			$data['content'] =  $this->load->view('front/dashboard','',true);	
			$this->load->view('front/template', $data);
		}
		else
		{
			$this->load->view('front/welcome_message');
		}
	}
	
	public function register()
	{	
		$this->form_validation->set_rules('username','User Name','required|trim|is_unique[tbl_users.strusername]');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('confirm_password','Confirm Password','required|matches[password]');
		
		if($this->form_validation->run() == FALSE)
		{	
			$this->load->view('front/register');
		}
		else
		{				
			$password = base64_encode($this->input->post('password')) ;
			$result = intval($this->login_model->register_user( $this->input->post('username'), $password)) ;
			
			if($result == "0")
			{
				$data['registration_error'] = 'Registration Failed.';				
				$this->load->view('front/register', $data);	
			}
			else
			{	
				$this->load->view('front/login_form');
			}
		}
	}
	
	public function login_form()
	{
		if($this->session->userdata('user_logged_in'))
		{
			$data['content'] =  $this->load->view('front/dashboard','',true);	
			$this->load->view('front/template', $data);	
		}
		else
		{
			$this->load->view('front/login_form');
		}
	}
	
	public function login()
	{	
		$this->form_validation->set_rules('loginusername', 'Username', 'trim|required', array("required" => "User Name Required"));
		$this->form_validation->set_rules('loginpassword', 'Password', 'trim|required', array("required" => "Please Enter Password"));
		
		if($this->form_validation->run() == FALSE)
		{	
			$this->load->view('front/login_form');
		}
		else
		{				
			$password = base64_encode($this->input->post('loginpassword')) ;
			$result = intval($this->login_model->validate_user_login( $this->input->post('loginusername'), $password)) ;
			
			if($result == "0")
			{
				$data['login_error'] = 'Login failed, invalid user name or password';				
				$this->load->view('front/login_form',$data);	
			}
			else
			{	
				$sessiondata = array('logged_in_username'=> $this->input->post('loginusername'),'user_logged_in' => 1);
				$this->session->set_userdata($sessiondata);
				
				redirect(site_url('front'));
			}
		}
	}
	
	public function racks(){
		varify_user_session();
		
		$data['racks'] = $this->rack->show_racks() ;
		$template_data['content'] =  $this->load->view('front/racks_listing',$data,true);	
		$this->load->view('front/template', $template_data);
	}
	
	public function rack_detail($rack_id){
		varify_user_session();
		
		$data['rack_details'] = $this->rack->rack_detail($rack_id) ;
		$data['rack_name'] = $this->rack->rack_name($rack_id) ;
		$template_data['content'] =  $this->load->view('front/racks_detail',$data,true);	
		$this->load->view('front/template', $template_data);
	}
	
	public function books(){
		varify_user_session();
		
		$data['books'] = $this->book->show_books() ;
		$template_data['content'] =  $this->load->view('front/books_listing',$data,true);	
		$this->load->view('front/template', $template_data);
	}
	
	public function search(){
		varify_user_session();	
		$this->form_validation->set_rules('search_word', 'Search Word', 'trim|required');
		
		if($this->form_validation->run() == FALSE)
		{	
			$data['books'] = $this->book->show_books() ;
			$template_data['content'] =  $this->load->view('front/books_listing',$data,true);	
			$this->load->view('front/template', $template_data);
		}
		else
		{
			$data['search_results'] = $this->book->search($this->input->post('search_word')) ;
			$template_data['content'] =  $this->load->view('front/search_results',$data,true);	
			$this->load->view('front/template', $template_data);
		}
	}
	
	function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url('front'));
	}
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Racks extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();	
		
		varify_admin_session(); 
		
		$this->load->model('rack');
		$this->load->library('form_validation');
	}
	
	public function index()
	{
		$data['racks'] = $this->rack->racks_list() ;
		
		$template_data['content'] = $this->load->view('admin/racks_listing', $data,true);
		$this->load->view('admin/template', $template_data);
	}
	
	public function add()
	{	
		$template_data['content'] = $this->load->view('admin/add_rack','',true);
		$this->load->view('admin/template', $template_data);
	}
	
	public function save()
	{	
		$this->form_validation->set_rules('rack_name', 'Rack Name', 'trim|required', array("required" => "Please Enter Rack Name"));
		
		if($this->form_validation->run() == FALSE)
		{	
			$template_data['content'] = $this->load->view('admin/add_rack','',true);
			$this->load->view('admin/template', $template_data);
		}
		else
		{				
			$result = intval($this->rack->add_rack($this->input->post('rack_name'))) ;
			
			if($result == "0")
			{
				$data['db_error'] = "Error: Rack can't be added.";				
				
				$template_data['content'] = $this->load->view('admin/add_rack',$data,true);
				$this->load->view('admin/template', $template_data);
			}
			else
			{	
				$data['racks'] = $this->rack->racks_list() ;
				
				$template_data['content'] = $this->load->view('admin/racks_listing', $data,true);
				$this->load->view('admin/template', $template_data);
			}
		}
	}
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Books extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();	
		
		varify_admin_session(); 
		
		$this->load->model('book');
		$this->load->model('rack');
		$this->load->library('form_validation');
	}
	
	public function index()
	{
		$data['books'] = $this->book->books_list() ;
		
		$template_data['content'] = $this->load->view('admin/books_listing', $data,true);
		$this->load->view('admin/template', $template_data);
	}
	
	public function add()
	{	
		$racks_list = $this->rack->racks_list() ;
		
		if(($racks_list) && count($racks_list) > 0){
			$data['racks'] = $racks_list; 
			
			$template_data['content'] = $this->load->view('admin/add_book', $data,true);
			$this->load->view('admin/template', $template_data);
		}else{
			
			$data['db_error'] = "Please first add Rack.";	
						
			$template_data['content'] = $this->load->view('admin/add_rack',$data,true);
			$this->load->view('admin/template', $template_data);
		}
	}
	
	public function save()
	{	
		$this->form_validation->set_rules('rack_no', 'Rack', 'trim|required');
		$this->form_validation->set_rules('book_title', 'Book Title', 'trim|required');
		$this->form_validation->set_rules('book_author', 'Book Author', 'trim|required');
		
		if($this->form_validation->run() == FALSE)
		{	
			$data['racks'] = $this->rack->racks_list() ;
			
			$template_data['content'] = $this->load->view('admin/add_book', $data,true);
			$this->load->view('admin/template', $template_data);
		}
		else
		{				
			$result = intval($this->book->no_of_books_in_rack($this->input->post('rack_no'))) ;
			
			if($result >= 10)
			{
				$data['db_error'] = "Error: Rack is already filled.";
				$data['racks'] = $this->rack->racks_list() ;				
				
				$template_data['content'] = $this->load->view('admin/add_book', $data,true);
				$this->load->view('admin/template', $template_data);
			}
			else
			{	
				$add_result = intval($this->book->add_book($_POST)) ;
				
				if($add_result == 0)
				{
					$data['db_error'] = "Error: Book can't be added.";				
					$data['racks'] = $this->rack->racks_list() ;				
					
					$template_data['content'] = $this->load->view('admin/add_book', $data,true);
					$this->load->view('admin/template', $template_data);
				}
				else
				{	
					$data['books'] = $this->book->books_list() ;
					
					$template_data['content'] = $this->load->view('admin/books_listing', $data,true);
					$this->load->view('admin/template', $template_data);
				}
			}
		}
	}
}
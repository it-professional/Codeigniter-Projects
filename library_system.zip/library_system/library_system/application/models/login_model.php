<?php
class Login_model extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
	
	function validate_admin_login($username,$password)
	{
		$this->db->select('*');
		$this->db->from( 'tbl_users' );
		$this->db->where( 'tbl_users'.'.strusername',$username); 
		$this->db->where( 'tbl_users'.'.strpassword',$password);
		$this->db->where( 'tbl_users'.'.struserrole',1);			
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->row()->id;
		}		
		else
		{
			return 0 ;
		}
	}
	
	function validate_user_login($username,$password)
	{
		$this->db->select('*');
		$this->db->from( 'tbl_users' );
		$this->db->where( 'tbl_users'.'.strusername',$username); 
		$this->db->where( 'tbl_users'.'.strpassword',$password);
		$this->db->where( 'tbl_users'.'.struserrole',0);			
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->row()->id;
		}		
		else
		{
			return 0 ;
		}
	}
	
	function register_user($username,$password)
	{
		$query = $this->db->insert('tbl_users', array(
		'strusername' => $username,
		'strpassword' => $password, 
		'struserrole' => 0));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
?>
<?php
class Rack extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
	
	function racks_list()
	{
		$this->db->select('*');
		$this->db->from( 'tbl_racks' );
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}		
		else
		{
			return '' ;
		}
	}
	
	function add_rack($rack_name)
	{
		$query = $this->db->insert('tbl_racks', array('name' => $rack_name));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function show_racks()
	{
		$this->db->select('tbl_racks.*, COUNT(tbl_books.rack_no) as no_of_books');
		$this->db->from('tbl_racks');
		$this->db->join('tbl_books', 'tbl_racks.id = tbl_books.rack_no', 'left outer');
		$this->db->group_by("tbl_racks.id");
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}		
		else
		{
			return '' ;
		}
	}
	
	function rack_detail($id){
		$this->db->select('*');
		$this->db->from('tbl_books');
		$this->db->where('rack_no', $id); 
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}		
		else
		{
			return '' ;
		}
	}
	
	function rack_name($id){
		$this->db->select('name');
		$this->db->from('tbl_racks');
		$this->db->where('id', $id); 
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->row();
		}		
		else
		{
			return '' ;
		}
	}
}
?>
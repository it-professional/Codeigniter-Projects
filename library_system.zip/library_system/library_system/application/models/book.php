<?php
class Book extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
	
	function books_list()
	{
		$this->db->select('*');
		$this->db->from( 'tbl_books' );
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}		
		else
		{
			return '' ;
		}
	}
	
	function no_of_books_in_rack($rack_id){
		
		$this->db->select('count(*) as no_of_books');
		$this->db->from( 'tbl_books' );
		$this->db->where( 'tbl_books.rack_no',$rack_id); 	
		$query=$this->db->get();		
		if($query->num_rows() > 0)
		{ 
			$row = $query->row(); 
			return $row->no_of_books;
		}	
		else
		{
			return '';
		}
	}
	
	function add_book($post_data){
		
		extract($post_data);
		
		$query = $this->db->insert('tbl_books', array(
		'book_title' => $book_title,
		'book_author' => $book_author, 
		'published_year' => $published_year,
		'rack_no' => $rack_no ));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function show_books()
	{
		$this->db->select('tbl_books.book_title, tbl_books.book_author, tbl_books.published_year, tbl_racks.name as rack_name');
		$this->db->from('tbl_books');
		$this->db->join('tbl_racks', 'tbl_racks.id = tbl_books.rack_no', 'inner');
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}		
		else
		{
			return '' ;
		}
	}
	
	function search($search_text)
	{
		$this->db->select('tbl_books.book_title, tbl_books.book_author, tbl_books.published_year, tbl_racks.name as rack_name');
		$this->db->from('tbl_books');
		$this->db->join('tbl_racks', 'tbl_racks.id = tbl_books.rack_no', 'inner');
		$this->db->like('book_title', $search_text);
		$this->db->or_like('book_author', $search_text); 
		$this->db->or_like('published_year', $search_text); 
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}		
		else
		{
			return '' ;
		}
	}
}
?>
jQuery(function(){
	initHeaderFixed();
});

// page layout init
function initLayout() {
	jQuery('#wrapper').fixedSlideBlock({
		slideBlock: '.header-fixed'
	});
}
// header state on scroll
function initHeaderFixed() {
	var minScrollTop = 140,
		blackActiveClass = 'hidden',
		ActiveClass = 'active',
		header = jQuery('#header'),
		headerFixed = jQuery('.header-fixed'),
		win = jQuery(window);

	var scrollHandler = function() {
		header.toggleClass(blackActiveClass, win.scrollTop() > minScrollTop)
		headerFixed.toggleClass(ActiveClass, win.scrollTop() > minScrollTop)
	};

	win.on('scroll', scrollHandler);
};

jQuery(function ($) {
	if ($.trim($('.topbar .tell, .topbar .email, .btn-support, .domain-search-form, .live-chat, .form-domains-search .field-holder, .order-summery .summery-list .opener'))){
		$(".topbar .tell, .topbar .email, .btn-support, .domain-search-form, .live-chat, .form-domains-search .field-holder, .order-summery .summery-list .opener").append('<span class="ico"></span>'); 
	};
	if ($.trim($('.testimonial q'))){
		$(".testimonial q").append('<span class="after"></span><span class="before"></span>'); 
	};
	if ($.trim($('.slideshow .textbox'))){
		$(".slideshow .textbox").wrapInner('<div class="holder"><div class="frame"></div></div>'); 
	};
	if ($.trim($('.hosting-area .hosting-features.special .box123'))){
		$(".hosting-area .hosting-features.special .box123").append('<span class="tag"><span></span><i class="icon icon9"></i></span>'); 
	};
	if ($.trim($('.hosting-plans .hosting'))){
		$(".hosting-plans .hosting").wrapInner('<div class="host-block"></div>'); 
	};
});
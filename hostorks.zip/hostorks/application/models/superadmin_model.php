<?php
class Superadmin_model extends CI_Model
{
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	function get_links($linktype)
	{
		$this->db->select('*');
		$this->db->from( 'tbl_links' );
		$this->db->where( 'tbl_links'.'.str_type',$linktype); 	
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{ 
			return $query->result() ;
		}		
	}
	
	function save_menu_item($menu_name,$menu_link,$menu_order,$menu_type,$meu_parent)
	{
		$query = $this->db->insert('tbl_links', array(
		'str_name' => $menu_name,
		'str_url' => $menu_link, 
		'str_type' => $menu_type,
		'int_parent_id' => $meu_parent,
		'int_order' => $menu_order
		));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function update_menu_item($links = array())
	{
		extract($links) ;
		$update_query = 0 ;
		foreach($menuid as $key => $menu)
		{
			$update_query = $this->db->update('tbl_links', array('str_name ' => $menuname[$key], 'int_order' => $menuorder[$key], 'str_url' => $menulink[$key], 'int_parent_id' => $menuparent[$key]), array("iid" => $menuid[$key]));
			$update_query = 1 ;
		}
		return $update_query ; 
	}
	
	function delete_menu_item($menuid)
	{
		$query = $this->db->delete('tbl_links', array('iid' => $menuid)); 
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function save_info($info_names = array(), $info_values = array())
	{
		if($info_names)
		{
			foreach($info_names as $key => $name)
			{	
				$this->db->select('iid');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name',$name); 	
				$query=$this->db->get();		
				
				if($query->num_rows() > 0)
				{ 
					// Update the info
					$row = $query->row(); 
					$query_result = $this->db->update('tbl_info', array('str_value ' => $info_values[$key]), array("iid" => $row->iid));
				}	
				else
				{
					// insert the info
					$query_result = $this->db->insert('tbl_info', array('str_name' => $name, 'str_value' => $info_values[$key] ));
				}
			}
		}
	}
	
	function save_logos($log_name)
	{	
		$query_result = $this->db->insert('tbl_info', array('str_name' => 'footer_logos', 'str_value' => $log_name));
		if($query_result)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function delete_logo($logoid)
	{
		$query = $this->db->delete('tbl_info', array('iid' => $logoid)); 
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function save_slides($title, $desc, $vtext, $vlink, $signuptext, $signuplink, $image)
	{
		$slide_data = implode("{++}", array($title, $desc, $vtext, $vlink, $signuptext, $signuplink, $image)) ;
		$query = $this->db->insert('tbl_content', array(
		'str_title' => 'home_slide',
		'str_content' => $slide_data
		));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function update_slides($id, $title, $desc, $vtext, $vlink, $signuptext, $signuplink, $image)
	{
		$slide_data = implode("{++}", array($title, $desc, $vtext, $vlink, $signuptext, $signuplink, $image)) ;
		$query = $this->db->update('tbl_content', array('str_content ' => $slide_data), array("iid" => $id));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function delete_content($contentid)
	{
		$query = $this->db->delete('tbl_content', array('iid' => $contentid)); 
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function manage_plans($specialplan, $planname, $planlink, $planprice , $plantype , $data = array(), $images_data = array())
	{
		extract($data) ;
		$insertion_query = "" ;
		$tab_data = "" ;
		$uploaded_file_name = "" ;
		
		foreach($tab_title as $key => $tabtitle)
		{
			if($tabtitle)
			{
				if(isset($images_data[$key]))
				{
					$uploaded_file_name = $images_data[$key] ;
				}
				$tab_data .= "[{".implode("{+}", array($tab_text[$key], $uploaded_file_name, $tab_title[$key], $tab_desc[$key], $tab_icon[$key]))."}]" ;
			}
		}
		
		$plan_data = implode("{++}", array($specialplan, $planname, $planlink, $planprice, $plantype , $tab_data)) ;
		$query = $this->db->insert('tbl_content', array(
		'str_title' => 'home_plan',
		'str_content' => $plan_data
		));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function update_plans($id, $specialplan, $planname, $planlink, $planprice , $plantype , $data = array(), $images_data = array())
	{
		extract($data) ;
		$insertion_query = "" ;
		$tab_data = "" ;
		$uploaded_file_name = "" ;
		
		foreach($tab_title as $key => $tabtitle)
		{
			if($tabtitle)
			{
				if(isset($images_data[$key]))
				{
					if($images_data[$key] == "")
					{
						if($delete_photo[$key] == "on")
						{
							$uploaded_file_name = "" ;
						}
						else
						{
							$uploaded_file_name = $old_tab_image[$key] ;
						}
					}
					else
					{
						$uploaded_file_name = $images_data[$key] ;
					}
				}
				$tab_data .= "[{".implode("{+}", array($tab_text[$key], $uploaded_file_name, $tab_title[$key], $tab_desc[$key], $tab_icon[$key]))."}]" ;
			}
		}
		
		$plan_data = implode("{++}", array($specialplan, $planname, $planlink, $planprice, $plantype , $tab_data)) ;
		$query = $this->db->update('tbl_content', array('str_content ' => $plan_data), array("iid" => $id));
		
		if($query)
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
	}
	
}
?>
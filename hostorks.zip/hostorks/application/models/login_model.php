<?php
class Login_model extends CI_Model
{
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	function validate_login($username,$password)
	{
		$this->db->select('*');
		$this->db->from( 'tbl_users' );
		$this->db->where( 'tbl_users'.'.strusername',$username); 
		$this->db->where( 'tbl_users'.'.strpassword',$password);
		$this->db->where( 'tbl_users'.'.struserrole',0);			
		$query=$this->db->get();		
		
		if($query->num_rows() > 0)
		{
			return $query->row()->iid;
		}		
		else
		{
			return 0 ;
		}
	}
}
?>
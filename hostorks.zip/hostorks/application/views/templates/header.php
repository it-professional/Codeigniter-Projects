<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $title; ?></title>
</head>
<body>
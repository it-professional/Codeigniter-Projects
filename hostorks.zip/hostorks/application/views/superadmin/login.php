<html>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<title>HOSTROKS</title>
<link href="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/css/login_style.css" rel="stylesheet" type="text/css">
<form action="<?php echo base_url().'superadmin/login' ;?>" method="post" >
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td><table width="442" align="center" cellpadding="10" cellspacing="0" bgcolor="#f1f3f5" class="tbl">
        <tr>
          <td width="288"><div align="center"><br>
            <img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/security.png" width="64" height="64"><br>
              <br>
                  <p class="heads">Welcome to HOSTROKS </p>
                      <p align="left" class="textbox1">&nbsp;Use a valid username and &nbsp;password to gain access to &nbsp;the administration   console.</p>
                <br>
            <br>
          </div></td>
          <td width="269"><table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="tbl">
            <tr >
              <td height="30" colspan="2" class="GreenButton"><div align="center" class="style6"><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/LOGIN.GIF" width="74" height="33"></div></td>
            </tr>
            <tr>
              <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="2"><div align="center"><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#FF0000">
                  <?php if(isset($error)): ?>
                      Error! <?php echo $error; ?>
                  <?php endif; ?>
                  
                  <?php if(isset($success)): ?>                   
                      <?php echo $success; ?>
                  <?php endif; ?>
              </font></b></font></div></td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274"><div align="right" class="fonte style5">
                <div align="left" class="heads"><strong>Username</strong> :</div>
              </div>
              <input type="text" name="loginusername"  class="textbox1 required validate[required]" placeholder="User Name" />
              </td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274"><div align="right" class="fonte style4">
                <div align="left" class="heads">Password :</div>
              </div>
                <input type="password" name="loginpassword"  onfocus="this.value=''" class="required validate[required]" placeholder="Password" />
               </td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274"><input name="Submit" type="submit" class="btn1" value="LOGIN"></td>
            </tr>
            <tr>
              <td width="123">&nbsp;</td>
              <td width="274">&nbsp;</td>
            </tr>
          </table></td>
        </tr>
        
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
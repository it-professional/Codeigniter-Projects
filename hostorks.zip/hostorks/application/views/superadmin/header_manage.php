<script language="javascript" type="text/javascript">
function delete_item(deleteid)
{
	if(confirm('Are you sure you want to delete this menu item'))
	{
		window.location.href = '<?php echo base_url().'superadmin/delete_menu/' ;?>'+deleteid ;
	}
}
</script>

<ul class="accordion">
	<li>
        <a href="#" class="opener">Manage Contact Info</a>
        <div class="slide">
        	<?php
				$phone_no = $email_address = $support_link = "" ;
            	$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','header_phone_no');		
				$phone_query=$this->db->get();
				if($phone_query->num_rows() > 0)
				{
					$phone_result = $phone_query->row() ;
					$phone_no = $phone_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','header_email');		
				$email_query=$this->db->get();
				if($email_query->num_rows() > 0)
				{
					$email_query_result = $email_query->row() ;
					$email_address = $email_query_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','header_support_link');		
				$support_link_query=$this->db->get();
				if($support_link_query->num_rows() > 0)
				{
					$support_link_query_result = $support_link_query->row() ;
					$support_link = $support_link_query_result->str_value ;
				}
			?>        	
        	<p>&nbsp;</p>
        	<form action="<?php echo base_url().'superadmin/manage_contact_info' ;?>" method="post" >
                Phone: <input class="btn1"  type="text" name="header_phone" <?php if($phone_no): echo 'value="'.$phone_no.'"'; else: echo 'placeholder="Phone no."'; endif; ?>  />
                <input type="hidden" name="info_name_phone" value="header_phone_no"  /> 
                <p>&nbsp;</p>
                Email: <input class="btn1" type="text" name="header_email" <?php if($email_address): echo 'value="'.$email_address.'"'; else: echo 'placeholder="Email Address"'; endif; ?>  /> 
                <input type="hidden" name="info_name_email" value="header_email"  />
                <p>&nbsp;</p>
                Support Link: <input class="btn1" type="text" name="support_link" <?php if($support_link): echo 'value="'.$support_link.'"'; else: echo 'placeholder="Support Link"'; endif; ?> />
                <input type="hidden" name="info_name_support" value="header_support_link"  />
                <p>&nbsp;</p>
				<input class="btn1" type="submit" value="Save"  />
        	</form>
        </div>
    </li>
    <li>
        <a href="#" class="opener">Manage Top Menu</a>
        <div class="slide">
        	<?php
            	$this->db->select('*');
				$this->db->from( 'tbl_links' );
				$this->db->where( 'tbl_links'.'.str_type','top_menu');		
				$top_menu_query=$this->db->get();
				if($top_menu_query->num_rows() > 0)
				{
					$top_query_result = $top_menu_query->result() ;
				}
				else
				{
					$top_query_result = "" ;
				}
			?>
            <br /><br />
            <h2>Add new Link</h2>
            <form action="<?php echo base_url().'superadmin/save_links' ;?>" name="headerlinks" method="post">
                <input type="text" class="btn1" name="menu_name" placeholder=" Name "  />
                <input type="text" class="btn1" name="menu_link" placeholder=" Link "  />
                <?php 
				if($top_query_result)
				{
				?>
                	<select name="menu_parent" class="btn1 parentselect">
                    	<option value="0">Parent</option>
                    	<?php foreach ($top_query_result as $row): ?>
	                    	<option value="<?php echo $row->iid; ?>"><?php echo $row->str_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php
				}
				else
				{
					echo '<input type="hidden" name="menu_parent" value="0" />';
				}
				?>
                <input type="text" class="btn1" name="menu_order" placeholder=" Order "  />
                <input type="hidden" name="link_type" value="top_menu"  />
                <input class="btn1" type="submit" value=" Add New Link "  />
            </form>
            
            <br /><br />
            <h2>Update Menu</h2>
                        
            <?php 
				if($top_query_result)
				{
			?>
            	 <table cellpadding="0" cellspacing="0" >
                      <tr>
                          <td>Name</td>
                          <td>Link</td>
                          <td>Order</td>
                          <td>Parent</td>
                          <td>&nbsp;</td>
                      </tr>
                <form action="<?php echo base_url().'superadmin/update_links' ;?>" name="headerlinks" method="post">
				<?php foreach ($top_query_result as $row): ?>
                    <tr>
                        <td><input type="text" class="btn1" name="menuname[]" value="<?php echo $row->str_name; ?>"  /></td>
                        <td><input type="text" class="btn1" name="menulink[]" value="<?php echo $row->str_url; ?> "  /></td>
                        <td><input type="text" class="btn1" name="menuorder[]" value="<?php echo $row->int_order; ?>"  /></td>
                        <td>
                        <?php 
                        if($top_menu_query->num_rows() > 1)
                        {
                        ?>
                            <select name="menuparent[]" class="btn1 parentselect" >
                                <?php foreach ($top_query_result as $innerrow): ?>
                                    <?php if($innerrow->iid != $row->iid): ?>
                                        <option <?php if($innerrow->iid == $row->int_parent_id): echo 'selected="selected"'; endif; ?> value="<?php echo $innerrow->iid; ?>"><?php echo $innerrow->str_name; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        <?php
                        }
                        else
                        {
                            echo '<input type="hidden" name="menuparent[]" value="0" />';
                        }
                        ?>
                        </td>
                        <td>
                        	<a href="javascript: delete_item('<?php echo $row->iid; ?>')" >Delete</a>
                        	<input type="hidden" name="menuid[]" value="<?php echo $row->iid ; ?>"  />
                        </td>
                    </tr>
				<?php endforeach; ?>
                	<tr>
                        <td class="submitbutton" colspan="5" align="center">
                        <input type="hidden" name="link_type" value="top_menu"  />
                        <input class="btn1" type="submit" name="update" value="Update Menu"  />
                        </td>
                    </tr>
                </form>  
               </table>
               <br /><br />
            <?php } ?>
        </div>
    </li>
    <li>
        <a href="#" class="opener">Manage Main Menu</a>
        <div class="slide">
            <?php
            	$this->db->select('*');
				$this->db->from( 'tbl_links' );
				$this->db->where( 'tbl_links'.'.str_type','main_menu');		
				$main_menu_query=$this->db->get();
				if($main_menu_query->num_rows() > 0)
				{
					$main_query_result = $main_menu_query->result() ;
				}
				else
				{
					$main_query_result = "" ;
				}
			?>
            <br /><br />
            <h2> Add new Link </h2>
            <form action="<?php echo base_url().'superadmin/save_links' ;?>" name="headerlinks" method="post">
                <input type="text" class="btn1" name="menu_name" placeholder=" Name "  />
                <input type="text" class="btn1" name="menu_link" placeholder=" Link "  />
                <?php 
				if($main_query_result)
				{
				?>
                	<select name="menu_parent" class="btn1 parentselect" >
                    	<option value="0">Parent</option>
                    	<?php foreach ($main_query_result as $row): ?>
	                    	<option value="<?php echo $row->iid; ?>"><?php echo $row->str_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php
				}
				else
				{
					echo '<input type="hidden" name="menu_parent" value="0" />';
				}
				?>
                <input type="text" class="btn1" name="menu_order" placeholder=" Order "  />
                <input type="hidden" name="link_type" value="main_menu"  />
                <br /><br />
                <input class="btn1" type="submit" value=" Add New Link "  />
            </form>
            
            <br /><br />
            <h2> Update Menu </h2>
            <?php 
				if($main_query_result)
				{
			?>
            	<table cellpadding="0" cellspacing="0" >
                	<tr>
                    	<td>Name</td>
                        <td>Link</td>
                        <td>Order</td>
                        <td>Parent</td>
                        <td>&nbsp;</td>
                    </tr>
                <form action="<?php echo base_url().'superadmin/update_links' ;?>" name="headerlinks" method="post">
				<?php foreach ($main_query_result as $row): ?>
                    <tr>
                    <td><input type="text" class="btn1" name="menuname[]" value="<?php echo $row->str_name; ?>"  /></td>
                    <td><input type="text" class="btn1" name="menulink[]" value="<?php echo $row->str_url; ?> "  /></td>
                    <td><input type="text" class="btn1" name="menuorder[]" value="<?php echo $row->int_order; ?>"  /></td>
                    <td>
                    <?php 
					if($main_menu_query->num_rows() > 1)
					{
					?>
						<select name="menuparent[]" class="btn1 parentselect" >
							<?php foreach ($main_query_result as $innerrow): ?>
                            	<?php if($innerrow->iid != $row->iid): ?>
									<option <?php if($innerrow->iid == $row->int_parent_id): echo 'selected="selected"'; endif; ?> value="<?php echo $innerrow->iid; ?>"><?php echo $innerrow->str_name; ?></option>
								<?php endif; ?>
							<?php endforeach; ?>
						</select>
					<?php
					}
					else
					{
						echo '<input type="hidden" name="menuparent[]" value="0" />';
					}
					?>
                    </td>
                    <td>
                    	<a href="javascript: delete_item('<?php echo $row->iid; ?>')" >Delete</a>
                   	 	<input type="hidden" name="menuid[]" value="<?php echo $row->iid ; ?>"  />
                    </td>
                	</tr>
				<?php endforeach; ?>
                    <tr>
                    	<td class="submitbutton" colspan="5" align="center">
		                    <input type="hidden" name="link_type" value="main_menu"  />
        		            <input class="btn1" type="submit" name="update" value="Update Menu"  />
                        </td>
                    </tr>
                </form> 
                </table>  
            <?php } ?>
        </div>
    </li>
</ul>
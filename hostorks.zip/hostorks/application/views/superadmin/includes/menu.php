<table width="204" border="0" align="left" cellpadding="3" cellspacing="3" bgcolor="#f1f3f5">
  <tr>
    <td width="192">&nbsp;</td>
  </tr>

  <tr>
       <td class="tbl"><span class="menuehead">Manage Header</span></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/header_manage" class="NavLinksbot1">Manage Header Links</a></td>
  </tr>
  
  <tr>
       <td class="tbl"><span class="menuehead">Manage Home Page</span></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_slider" class="NavLinksbot1">Manage Home Slider</a></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_plans" class="NavLinksbot1">Manage Plans</a></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_custom_order" class="NavLinksbot1">Manage Custom Order</a></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_hostings" class="NavLinksbot1">Manage Hosting Slides</a></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_sidebar" class="NavLinksbot1">Manage Home Sidebar</a></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_reasons" class="NavLinksbot1">Manage Reasons to Work With US</a></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" />
       <a href="<?php echo base_url(); ?>superadmin/home_customers" class="NavLinksbot1">Manage Customer Comments</a></td>
  </tr>
  
  
  
  
  
  <tr>
       <td class="tbl"><span class="menuehead">Manage Content</span></td>
  </tr>
   <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=home" class="NavLinksbot1">Manage Home page</a></td>
     </tr>
    
	 <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=Latestnews" class="NavLinksbot1">Manage Latest News</a></td>
     </tr>
	 
	 <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=gallery" class="NavLinksbot1">Manage Gallery Images</a></td>
     </tr>
	 
	  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="../forum/adm/index.php" class="NavLinksbot1">&nbsp;</a><a href="index.php?pg=portfolio" class="NavLinksbot1">Manage Portfolio</a></td>
     </tr>

 
 <tr>
       <td class="tbl"><span class="menuehead">Manage Footer</span></td>
  </tr>
  <tr>
       <td><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" align="absmiddle" /><a href="<?php echo base_url(); ?>superadmin/footer_manage" class="NavLinksbot1">Manage Footer Links</a></td>
  </tr>
 
 
  <tr>
    <td class="tbl"><a href="login.php?logout=logout" class="menuehead" style="text-decoration:none">LOGOUT</a></td>
  </tr>
  <tr>
    <td>
		<img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/arrow.gif" width="10" height="10" />
		<a href="index.php?pg=changpass" class="NavLinksbot1">Change Password</a>	</td>
  </tr>
</table>
<HTML>
<HEAD>
<TITLE>HOSTROKS</TITLE>
	<LINK HREF="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/css/style.css" REL="stylesheet" TYPE="text/css">
    
	<script type="text/javascript">window.jQuery || document.write('<script src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/js/jquery-1.8.3.min.js"><\/script>')</script>
	<script type="text/javascript" src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/js/jquery.main.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/js/jquery.tags.js"></script>
    <script language="JavaScript" type="text/javascript" src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/editor/wysiwyg.js"></script>
    
    <script type="text/javascript">
	var editorpath = '<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/editor/';
	</script>
</HEAD>

<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LEFTMARGIN="0" TOPMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0">
<TABLE WIDTH="100%" HEIGHT="100%" BORDER="1" CELLPADDING="0" CELLSPACING="0">
  <TR HEIGHT="0">
  <TD HEIGHT="0" COLSPAN="2">
  
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="4%" align="right"><img src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/header_icon.png" width="46" height="38" align="right"></td>
        <td width="30%" background="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/background.gif"><div align="left"><span class="tophead1">HOSTROKS</span><span class="tophead"> </span></div></td>
        <td width="66%" background="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/header_blue.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>&nbsp;</td>
            <td colspan="2"><table width="330" border="0" align="right" cellpadding="0" cellspacing="0">
              <tr>
                <td width="73"><span class="style14">Username:</span></td>
                <td width="92"><span class="style15"><b>
                  Superadmin
                </b></span></td>
                <td width="103"><span class="style14"></span></td>
                <td width="62"><b class="style15">
                  
                </b></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table>
   
   </TD>
  </TR>
  <TR> 
    <TD WIDTH="21%" HEIGHT="500" VALIGN="top" BGCOLOR="#f1f3f5"><?php $this->load->view('superadmin/includes/menu'); ?></TD>
    <TD WIDTH="79%" HEIGHT="100%" VALIGN="top" CLASS="tbl"> 
      <DIV ALIGN="center">

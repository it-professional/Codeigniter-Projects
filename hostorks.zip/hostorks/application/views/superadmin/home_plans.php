<script language="JavaScript" type="text/javascript" src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/editor/wysiwyg.js"></script>
<script language="javascript" type="text/javascript">
  function addtab()
  {
	  var tabfields = document.getElementById('tabsfields').innerHTML ; 
	  jQuery("#addtabs").append("<br>"+tabfields);
  }
  function delete_plan(deleteid)
{
	if(confirm('Are you sure you want to delete this Plan'))
	{
		window.location.href = '<?php echo base_url().'superadmin/delete_plan/' ;?>'+deleteid ;
	}
}
</script>

<?php $edit_plan_id = $is_special_plan = $plan_name = $plan_price = $plan_link = $plan_type = $plan_specs = "" ;  ?>
<?php 
	if($this->uri->segment(3))
	{
		$edit_plan_id = $this->uri->segment(3);
		
		$plans = "" ;
		$this->db->select('*');
		$this->db->from( 'tbl_content' );
		$this->db->where( 'tbl_content'.'.iid',$edit_plan_id);		
		$plan_query=$this->db->get();
		if($plan_query->num_rows() > 0)
		{
			$plans = $plan_query->row() ;
			$plan_content = explode('{++}',$plans->str_content) ;
			if(isset($plan_content[0])): $is_special_plan = $plan_content[0] ; endif;
			if(isset($plan_content[1])): $plan_name = $plan_content[1] ; endif;
			if(isset($plan_content[3])): $plan_link = $plan_content[2] ; endif;
			if(isset($plan_content[2])): $plan_price = $plan_content[3] ; endif;
			if(isset($plan_content[4])): $plan_type = $plan_content[4] ; endif;
			if(isset($plan_content[5])): $plan_specs = $plan_content[5] ; endif;
		}
	}
?>

<?php if($edit_plan_id): $form_action = base_url().'superadmin/update_plans' ; else: $form_action = base_url().'superadmin/manage_plans' ; endif; ?>
<form action="<?php echo $form_action ; ?>" method="post" enctype="multipart/form-data" >
<table width="100%" border="0" cellspacing="3" cellpadding="0" class="singleborder">
  <tr>
    <td colspan="2">&nbsp;</td>
    </tr>
    
    <tr>
        <td width="25%"><div align="right">Special Plan</div></td>
        <td><div align="left">
          <label>
          	<input type="checkbox" <?php if($is_special_plan == "on"): echo 'checked="checked"'; endif; ?> name="special_plan"  >
          </label>
        </div></td>
    </tr>
    <tr>
        <td width="25%"><div align="right">Name</div></td>
        <td><div align="left">
          <label>
          <input type="text" name="plan_name" class="textbox1" value="<?php echo $plan_name; ?>">
          </label>
        </div></td>
    </tr>
    <tr>
        <td width="25%"><div align="right">Price</div></td>
        <td><div align="left">
          <label>
          <input type="text" name="plan_price" class="textbox1" value="<?php echo $plan_price; ?>">
          </label>
        </div></td>
    </tr>
    <tr>
        <td width="25%"><div align="right">Per Month/Year</div></td>
        <td>
          <input type="radio" name="plan_month_year" <?php if(trim($plan_type) == "month"): echo 'checked="checked"'; endif; ?>  value="month"> Per Month
          <input type="radio" name="plan_month_year" <?php if(trim($plan_type) == "year"): echo 'checked="checked"'; endif; ?> value="year"> Per Year
       </td>
    </tr>
    <tr>
        <td width="25%"><div align="right">Link</div></td>
        <td><div align="left">
          <label>
          	<input type="text" name="plan_link" class="textbox1" value="<?php echo $plan_link; ?>">
          </label>
        </div></td>
    </tr>
    
    <?php if($plan_specs):
		  $exploade_plan_specs = explode('[{',$plan_specs); ?>
          
    <?php if($exploade_plan_specs): ?>
    	<?php foreach($exploade_plan_specs as $exploade_plan_spec): ?>
        	<?php 
				if($exploade_plan_spec)
				{	
					 $tab_name = $tab_image = $tab_title = $tab_description = $tab_icon = "" ;
					 $plan_spec_data = explode('{+}',$exploade_plan_spec); 
					 if(isset($plan_spec_data[0])): $tab_name = $plan_spec_data[0] ; endif;
					 if(isset($plan_spec_data[1])): $tab_image = $plan_spec_data[1] ; endif;
					 if(isset($plan_spec_data[2])): $tab_title = $plan_spec_data[2] ; endif;
					 if(isset($plan_spec_data[3])): $tab_description = $plan_spec_data[3] ; endif;
					 if(isset($plan_spec_data[4])): $tab_icon = $plan_spec_data[4] ; endif;
			?>
                    <tr><td colspan="2">
                        <table cellpadding="0" cellspacing="0" class="singleborder" width="100%" style="margin-top:10px; margin-bottom:10px;" >
                            <tr>
                                <td width="25%"><div align="right">Text/Image</div></td>
                                <td><div align="left">
                                  <label>
                                  <input type="text" name="tab_text[]" class="textbox1" value="<?php echo $tab_name; ?>">
                                  </label>
                                </div></td>
                            </tr>
                            <tr>
                                <td width="25%"><div align="right">Image</div></td>
                                <td><div align="left">
                                  <label>
                                  <input type="file" name="tab_image[]" >
                                  <input type="hidden" name="old_tab_image[]" value="<?php echo $tab_image; ?>"  />
                                  </label>
                                  <?php if($tab_image): ?>
                                    <img src="<?php echo base_url(); ?>includes/superadmin/uploads/home_plans/<?php echo $tab_image; ?>" width="100" height="100"  />
                                    <input type="checkbox" name="delete_photo[]"  /> Delete Photo
                                 <?php endif; ?>
                                </div></td>
                            </tr>
                             <tr>
                                <td width="25%"><div align="right">Title</div></td>
                                <td><div align="left">
                                  <label>
                                  <input type="text" name="tab_title[]" class="textbox1" value="<?php echo $tab_title; ?>">
                                  </label>
                                </div></td>
                            </tr>
                             <tr>
                                <td width="25%"><div align="right">Description</div></td>
                                <td><div align="left">
                                  <label>
                                  <input type="text" name="tab_desc[]" class="textbox1" value="<?php echo $tab_description; ?>">
                                  </label>
                                </div></td>
                            </tr>
                            <tr>
                                <td width="25%"><div align="right">Icon</div></td>
                                <td><div align="left">
                                  <label>
                                  <input type="text" name="tab_icon[]" class="textbox1" value="<?php echo str_replace('}]','',$tab_icon); ?>">
                                  </label>
                                </div></td>
                            </tr>
                        </table>
                        </td></tr>
    		<?php } ?>
		<?php endforeach; ?>   
    <?php endif; endif; ?>
        
    <tr><td colspan="2" align="center"><h2><a href="javascript:addtab()">Add Tab</a></h2></td></tr>
       <tr style="display:none;"><td colspan="2" id="tabsfields">
       	<table cellpadding="0" cellspacing="0" class="singleborder" width="100%" style="margin-top:10px; margin-bottom:10px;" >
            <tr>
                <td width="25%"><div align="right">Text/Image</div></td>
                <td><div align="left">
                  <label>
                  <input type="text" name="tab_text[]" class="textbox1" value="<?php //echo $slide_title; ?>">
                  </label>
                </div></td>
            </tr>
            <tr>
                <td width="25%"><div align="right">Image</div></td>
                <td><div align="left">
                  <label>
                  <input type="file" name="tab_image[]" >
                  </label>
                </div></td>
            </tr>
             <tr>
                <td width="25%"><div align="right">Title</div></td>
                <td><div align="left">
                  <label>
                  <input type="text" name="tab_title[]" class="textbox1" value="<?php //echo $slide_title; ?>">
                  </label>
                </div></td>
            </tr>
             <tr>
                <td width="25%"><div align="right">Description</div></td>
                <td><div align="left">
                  <label>
                  <input type="text" name="tab_desc[]" class="textbox1" value="<?php //echo $slide_title; ?>">
                  </label>
                </div></td>
            </tr>
            <tr>
                <td width="25%"><div align="right">Icon</div></td>
                <td><div align="left">
                  <label>
                  <input type="text" name="tab_icon[]" class="textbox1" value="<?php //echo $slide_title; ?>">
                  </label>
                </div></td>
            </tr>
        </table>
        </td></tr>
        <tr><td colspan="2" id="addtabs"></td></tr>
  <tr>
    <td><div align="right"></div></td>
    <td><div align="left">
       <?php if($edit_plan_id){?>
      <input type="hidden" name="hdneditid" value="<?php echo $edit_plan_id; ?>"  />	
      <input name="update" type="submit" class="btn1" id="update" value=" Update ">
      <?php }else{?>
      <input name="add" type="submit" class="btn1" id="add" value="   Add   ">
      <?php }?>
      
    </div></td>
  </tr>
</table>
</form>

<table width="100%" border="0" cellspacing="0" cellpadding="0"> 
	<tr> 
    	<td width="20%" height="20" class="formtext">&nbsp;Nmae</td>
    	<td width="20%" height="20" class="formtext">&nbsp;Link</td>
    	<td width="20%" align="center" class="formtext">&nbsp;Price</td>
        <td width="10%" align="center" class="formtext">&nbsp;</td>
    	<td width="30%" height="10" colspan="2" align="center" class="formtext">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Options</td>
  </tr>
  
  <?php
	$plans = "" ;
	$this->db->select('*');
	$this->db->from( 'tbl_content' );
	$this->db->where( 'tbl_content'.'.str_title','home_plan');		
	$plan_query=$this->db->get();
	if($plan_query->num_rows() > 0)
	{
		$plans = $plan_query->result() ;
	}
 ?>
 <?php if($plans): ?>
 	<?php foreach($plans as $plan): ?>
    	<?php $plan_data = explode('{++}',$plan->str_content); ?>
        <?php //print_r($plan_data); die; ?>
        <tr> 
            <td width="20%" height="20" class="tdfeatured"><?php if(isset($plan_data[1])): echo $plan_data[1]; endif; ?></td>
            <td width="20%" height="20"	class="tdfeatured"><?php if(isset($plan_data[2])): echo $plan_data[2]; endif; ?></td>
            <td width="20%" align="center" class="tdfeatured"><?php if(isset($plan_data[3])): echo $plan_data[3]; endif; ?></td>
            <td width="10%" align="center" class="formtext">&nbsp;</td>
            <td width="10%" height="10" align="center" background="images/bg_part.gif" class="tdfeatured"><a href="<?php echo base_url().'superadmin/home_plans/'.$plan->iid ;?>" >Edit</a></td>
            <td width="10%" height="10" align="center" background="images/bg_part.gif" class="tdfeatured"><a href="javascript: delete_plan('<?php echo $plan->iid; ?>');">Delete</a></td>
      </tr>
    <?php endforeach; ?>
 <?php endif; ?>
	
    		<tr>
			  <td height="30">&nbsp;</td>
			  <td height="30">&nbsp;</td>
			  <td height="30" align="center">			  </td>
			  <td height="30" align="center">			  </td>
			  <td height="30" colspan="2" align="right">&nbsp;</td>
			  <td height="30" align="center">&nbsp;</td>
		  </tr>
</table>
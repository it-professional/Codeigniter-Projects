<script language="javascript" type="text/javascript">
function delete_logo(deleteid)
{
	if(confirm('Are you sure you want to delete this Logo'))
	{
		window.location.href = '<?php echo base_url().'superadmin/delete_logo/' ;?>'+deleteid ;
	}
}
</script>

<ul class="accordion">
	<li>
    	<a href="#" class="opener">Manage Logos</a>
        <div class="slide">
        	<?php 
			$this->db->select('*');
			$this->db->from( 'tbl_info' );
			$this->db->where( 'tbl_info'.'.str_name','footer_logos');		
			$logos_query=$this->db->get();
			if($logos_query->num_rows() > 0)
			{
				echo '<table width="30%" cellpadding="0" cellspacing="0" >' ;
				$logos_query_result = $logos_query->result() ;
				foreach($logos_query_result as $logo)
				{
					echo '<tr>' ;
						echo '<td width="75%">' ;
							echo '<img src="'.base_url().'includes/superadmin/uploads/'.$logo->str_value.'" >';  
						echo '</td>' ;
						
						echo '<td width="25%">' ;
							echo '<a href="javascript: delete_logo('.$logo->iid.')">Delete</a>';
						echo '</td>' ;
					echo '</tr>' ;
				}
				echo '</table>' ;
			}
			
			?>
			
			<?php if(isset($error)): echo $error; endif; ?>
            <br /><br /><br />
            <?php echo form_open_multipart(base_url().'superadmin/upload_logo');?>
            <input class="btn1" type="file" name="upload_footer_logo"  /> <br />
            <input class="btn1" type="submit" value=" Upload Logo "	 />
            </form>
        </div>
    </li>
    <li>
    	<a href="#" class="opener">Manage Quick Links</a>
        <div class="slide">
        	<?php
            	$this->db->select('*');
				$this->db->from( 'tbl_links' );
				$this->db->where( 'tbl_links'.'.str_type','quick_links');		
				$quick_links_query=$this->db->get();
				if($quick_links_query->num_rows() > 0)
				{
					$quick_links_result = $quick_links_query->result() ;
				}
				else
				{
					$quick_links_result = "" ;
				}
			?>
            <br /><br />
            <h2>Add new Link</h2>
            <form action="<?php echo base_url().'superadmin/save_links' ;?>" name="headerlinks" method="post">
                <input type="text" class="btn1" name="menu_name" placeholder=" Name "  />
                <input type="text" class="btn1" name="menu_link" placeholder=" Link "  />
                <?php 
				if($quick_links_result)
				{
				?>
                	<select name="menu_parent" class="btn1 parentselect">
                    	<option value="0">Parent</option>
                    	<?php foreach ($quick_links_result as $row): ?>
	                    	<option value="<?php echo $row->iid; ?>"><?php echo $row->str_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php
				}
				else
				{
					echo '<input type="hidden" name="menu_parent" value="0" />';
				}
				?>
                <input type="text" class="btn1" name="menu_order" placeholder=" Order "  />
                <input type="hidden" name="link_type" value="quick_links"  />
                <input class="btn1" type="submit" value=" Add New Link "  />
            </form>
            
            <br /><br />
            
			<?php 
				if($quick_links_result)
				{
			?>
            	 <h2>Update Menu</h2>
                 <table cellpadding="0" cellspacing="0" >
                      <tr>
                          <td>Name</td>
                          <td>Link</td>
                          <td>Order</td>
                          <td>Parent</td>
                          <td>&nbsp;</td>
                      </tr>
                <form action="<?php echo base_url().'superadmin/update_links' ;?>" name="headerlinks" method="post">
				<?php foreach ($quick_links_result as $row): ?>
                    <tr>
                        <td><input type="text" class="btn1" name="menuname[]" value="<?php echo $row->str_name; ?>"  /></td>
                        <td><input type="text" class="btn1" name="menulink[]" value="<?php echo $row->str_url; ?> "  /></td>
                        <td><input type="text" class="btn1" name="menuorder[]" value="<?php echo $row->int_order; ?>"  /></td>
                        <td>
                        <?php 
                        if($quick_links_query->num_rows() > 1)
                        {
                        ?>
                            <select name="menuparent[]" class="btn1 parentselect" >
                                <?php foreach ($quick_links_result as $innerrow): ?>
                                    <?php if($innerrow->iid != $row->iid): ?>
                                        <option <?php if($innerrow->iid == $row->int_parent_id): echo 'selected="selected"'; endif; ?> value="<?php echo $innerrow->iid; ?>"><?php echo $innerrow->str_name; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        <?php
                        }
                        else
                        {
                            echo '<input type="hidden" name="menuparent[]" value="0" />';
                        }
                        ?>
                        </td>
                        <td>
                        	<a href="javascript: delete_item('<?php echo $row->iid; ?>')" >Delete</a>
                        	<input type="hidden" name="menuid[]" value="<?php echo $row->iid ; ?>"  />
                        </td>
                    </tr>
				<?php endforeach; ?>
                	<tr>
                        <td class="submitbutton" colspan="5" align="center">
                        <input type="hidden" name="link_type" value="quick_links"  />
                        <input class="btn1" type="submit" name="update" value="Update Menu"  />
                        </td>
                    </tr>
                </form>  
               </table>
               <br /><br />
            <?php } ?>
        </div>
    </li>
    <li>
    	<a href="#" class="opener">Manage Information</a>
        <div class="slide">
        	<?php
            	$this->db->select('*');
				$this->db->from( 'tbl_links' );
				$this->db->where( 'tbl_links'.'.str_type','information_links');		
				$info_links_query=$this->db->get();
				if($info_links_query->num_rows() > 0)
				{
					$info_links_result = $info_links_query->result() ;
				}
				else
				{
					$info_links_result = "" ;
				}
			?>
            <br /><br />
            <h2>Add new Link</h2>
            <form action="<?php echo base_url().'superadmin/save_links' ;?>" name="headerlinks" method="post">
                <input type="text" class="btn1" name="menu_name" placeholder=" Name "  />
                <input type="text" class="btn1" name="menu_link" placeholder=" Link "  />
                <?php 
				if($info_links_result)
				{
				?>
                	<select name="menu_parent" class="btn1 parentselect">
                    	<option value="0">Parent</option>
                    	<?php foreach ($info_links_result as $row): ?>
	                    	<option value="<?php echo $row->iid; ?>"><?php echo $row->str_name; ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php
				}
				else
				{
					echo '<input type="hidden" name="menu_parent" value="0" />';
				}
				?>
                <input type="text" class="btn1" name="menu_order" placeholder=" Order "  />
                <input type="hidden" name="link_type" value="information_links"  />
                <input class="btn1" type="submit" value=" Add New Link "  />
            </form>
            
            <br /><br />
            
			<?php 
				if($info_links_result)
				{
			?>
            	<h2>Update Menu</h2>
            	 <table cellpadding="0" cellspacing="0" >
                      <tr>
                          <td>Name</td>
                          <td>Link</td>
                          <td>Order</td>
                          <td>Parent</td>
                          <td>&nbsp;</td>
                      </tr>
                <form action="<?php echo base_url().'superadmin/update_links' ;?>" name="headerlinks" method="post">
				<?php foreach ($info_links_result as $row): ?>
                    <tr>
                        <td><input type="text" class="btn1" name="menuname[]" value="<?php echo $row->str_name; ?>"  /></td>
                        <td><input type="text" class="btn1" name="menulink[]" value="<?php echo $row->str_url; ?> "  /></td>
                        <td><input type="text" class="btn1" name="menuorder[]" value="<?php echo $row->int_order; ?>"  /></td>
                        <td>
                        <?php 
                        if($info_links_query->num_rows() > 1)
                        {
                        ?>
                            <select name="menuparent[]" class="btn1 parentselect" >
                                <?php foreach ($info_links_result as $innerrow): ?>
                                    <?php if($innerrow->iid != $row->iid): ?>
                                        <option <?php if($innerrow->iid == $row->int_parent_id): echo 'selected="selected"'; endif; ?> value="<?php echo $innerrow->iid; ?>"><?php echo $innerrow->str_name; ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        <?php
                        }
                        else
                        {
                            echo '<input type="hidden" name="menuparent[]" value="0" />';
                        }
                        ?>
                        </td>
                        <td>
                        	<a href="javascript: delete_item('<?php echo $row->iid; ?>')" >Delete</a>
                        	<input type="hidden" name="menuid[]" value="<?php echo $row->iid ; ?>"  />
                        </td>
                    </tr>
				<?php endforeach; ?>
                	<tr>
                        <td class="submitbutton" colspan="5" align="center">
                        <input type="hidden" name="link_type" value="information_links"  />
                        <input class="btn1" type="submit" name="update" value="Update Menu"  />
                        </td>
                    </tr>
                </form>  
               </table>
               <br /><br />
            <?php } ?>
        </div>
    </li>
    <li>
    	<a href="#" class="opener">Manage General Info</a>
        <div class="slide">
        	<?php
				$footer_contact_email = $footer_facebook_link = $footer_twitter_link = $footer_linkedin_link = $footer_rss_link = $copyright_info = "" ;
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','footer_contact_email');		
				$footer_contact_email_query=$this->db->get();
				if($footer_contact_email_query->num_rows() > 0)
				{
					$footer_contact_email_query_result = $footer_contact_email_query->row() ;
					$footer_contact_email = $footer_contact_email_query_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','footer_facebook_link');		
				$footer_facebook_link_query=$this->db->get();
				if($footer_facebook_link_query->num_rows() > 0)
				{
					$footer_facebook_link_query_result = $footer_facebook_link_query->row() ;
					$footer_facebook_link = $footer_facebook_link_query_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','footer_twitter_link');		
				$footer_twitter_link_query=$this->db->get();
				if($footer_twitter_link_query->num_rows() > 0)
				{
					$footer_twitter_link_query_result = $footer_twitter_link_query->row() ;
					$footer_twitter_link = $footer_twitter_link_query_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','footer_linkedin_link');		
				$footer_linkedin_link_query=$this->db->get();
				if($footer_linkedin_link_query->num_rows() > 0)
				{
					$footer_linkedin_link_query_result = $footer_linkedin_link_query->row() ;
					$footer_linkedin_link = $footer_linkedin_link_query_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','footer_rss_link');		
				$footer_rss_link_query=$this->db->get();
				if($footer_rss_link_query->num_rows() > 0)
				{
					$footer_rss_link_query_result = $footer_rss_link_query->row() ;
					$footer_rss_link = $footer_rss_link_query_result->str_value ;
				}
				
				$this->db->select('str_value');
				$this->db->from( 'tbl_info' );
				$this->db->where( 'tbl_info'.'.str_name','copyright_info');		
				$copyright_info_query=$this->db->get();
				if($copyright_info_query->num_rows() > 0)
				{
					$copyright_info_query_result = $copyright_info_query->row() ;
					$copyright_info = $copyright_info_query_result->str_value ;
				}
			?>        	
        	<p>&nbsp;</p>
        	<form action="<?php echo base_url().'superadmin/manage_footer_info' ;?>" method="post" >
                Contact US Email: <input class="btn1"  type="text" name="contact_email_address" <?php if($footer_contact_email): echo 'value="'.$footer_contact_email.'"'; else: echo 'placeholder="Contact US Email"'; endif; ?>  />
                <input type="hidden" name="contact_email" value="footer_contact_email"  /> 
                <p>&nbsp;</p>
                
                Facebook Link: <input class="btn1"  type="text" name="facebook_link" <?php if($footer_facebook_link): echo 'value="'.$footer_facebook_link.'"'; else: echo 'placeholder="Facebook Link"'; endif; ?>  />
                <input type="hidden" name="facebook_link_name" value="footer_facebook_link"  /> 
                <p>&nbsp;</p>
                
                Twitter Link: <input class="btn1"  type="text" name="twitter_link" <?php if($footer_twitter_link): echo 'value="'.$footer_twitter_link.'"'; else: echo 'placeholder="Twitter Link"'; endif; ?>  />
                <input type="hidden" name="twitter_link_name" value="footer_twitter_link"  /> 
                <p>&nbsp;</p>
                
                Linkedin Link: <input class="btn1"  type="text" name="linkedin_link" <?php if($footer_linkedin_link): echo 'value="'.$footer_linkedin_link.'"'; else: echo 'placeholder="LinkedIn Link"'; endif; ?>  />
                <input type="hidden" name="linkedin_link_name" value="footer_linkedin_link"  /> 
                <p>&nbsp;</p>
                
                RSS Link: <input class="btn1"  type="text" name="rss_link" <?php if($footer_rss_link): echo 'value="'.$footer_rss_link.'"'; else: echo 'placeholder="RSS Link"'; endif; ?>  />
                <input type="hidden" name="rss_link_name" value="footer_rss_link"  /> 
                <p>&nbsp;</p>
                
                CopyRight: <textarea cols="30" rows="3" name="copyright" ><?php echo $copyright_info; ?></textarea>
                <input type="hidden" name="copyright_name" value="copyright_info"  />
                <p>&nbsp;</p>
				<input class="btn1" type="submit" value="Save"  />
        	</form>
        </div>
    </li>
</ul>

<form action="<?php echo base_url().'superadmin/save_links' ;?>" name="headerlinks" method="post">
	<input type="text" name="menu_name" placeholder=" Name "  />
    <input type="text" name="menu_link" placeholder=" Link "  />
    <input type="text" name="menu_order" placeholder=" Order "  />
    <input type="hideen" name="link_type" value="main_menu"  />
    <input type="submit" value=" Add New Link "  />
</form>

<?php if(isset($header_links)): ?>
	<form action="<?php echo base_url().'superadmin/update_links' ;?>" name="headerlinks" method="post">
	<?php foreach($header_links as $header_link): ?>
    	<input type="text" name="menuname[]" value="<?php echo $header_link->str_name; ?>"  />
        <input type="text" name="menuorder[]" value="<?php echo $header_link->int_order; ?>"  />
        <a href="javascript: delete_item('<?php echo $header_link->iid; ?>')" >Delete</a>
        <input type="hidden" name="menuid[]" value="<?php echo $header_link->iid ; ?>"  /><br />
	<?php endforeach; ?>
    	<input type="hidden" name="link_type" value="main_menu"  />
    	<input type="submit" name="update" value="Update Menu"  />
    </form>    
<?php endif; ?>



<SPAN CLASS="fonte"><BR><BR><BR>
		</SPAN><SPAN CLASS="style2"><IMG SRC="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/images/cpanel.png" WIDTH="48" HEIGHT="48" ALIGN="absmiddle"> Administration Home</SPAN><BR>
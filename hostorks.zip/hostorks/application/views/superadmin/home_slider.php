<script language="JavaScript" type="text/javascript" src="<?php echo base_url(); ?><?php echo SUPERADMIN_USER_RESOURCES;?>/editor/wysiwyg.js"></script>
<script language="javascript" type="text/javascript">
function delete_slide(deleteid)
{
	if(confirm('Are you sure you want to delete this Logo'))
	{
		window.location.href = '<?php echo base_url().'superadmin/delete_slide/' ;?>'+deleteid ;
	}
}
</script>

<?php $edit_slide_id = $slide_title = $slide_desc = $slide_vtext = $slide_vlink = $slide_stext = $slide_slink = $slide_image = "" ;  ?>
<?php 
	if($this->uri->segment(3))
	{
		$edit_slide_id = $this->uri->segment(3);
		
		$slides = "" ;
		$this->db->select('*');
		$this->db->from( 'tbl_content' );
		$this->db->where( 'tbl_content'.'.iid',$edit_slide_id);		
		$slider_query=$this->db->get();
		if($slider_query->num_rows() > 0)
		{
			$slides = $slider_query->row() ;
			$slide_content = explode('{++}',$slides->str_content) ;
			if(isset($slide_content[0])): $slide_title = $slide_content[0] ; endif;
			if(isset($slide_content[1])): $slide_desc = $slide_content[1] ; endif;
			if(isset($slide_content[2])): $slide_vtext = $slide_content[2] ; endif;
			if(isset($slide_content[3])): $slide_vlink = $slide_content[3] ; endif;
			if(isset($slide_content[4])): $slide_stext = $slide_content[4] ; endif;
			if(isset($slide_content[5])): $slide_slink = $slide_content[5] ; endif;
			if(isset($slide_content[6])): $slide_image = $slide_content[6] ; endif; 
		}
	}
?>

<?php if($edit_slide_id): $form_action = base_url().'superadmin/update_slides' ; else: $form_action = base_url().'superadmin/manage_slides' ; endif; ?>
<form action="<?php echo $form_action ;?>" method="post" enctype="multipart/form-data" >
<table width="100%" border="0" cellspacing="3" cellpadding="0" class="singleborder">
  <tr>
    <td colspan="2">&nbsp;</td>
    </tr>
    
    
    <tr>
    <td width="25%"><div align="right">Title</div></td>
    <td><div align="left">
      <label>
      <input type="text" name="slide_title" class="textbox1" value="<?php echo $slide_title; ?>">
      </label>
    </div></td>
  </tr>
              
  <tr>
    <td><div align="right">Short Description</div></td>
    <td><div align="left">
    <textarea id="slide_short_desc" name="slide_short_desc" ><?php echo $slide_desc; ?></textarea>
    <script language="javascript">
          generate_wysiwyg('slide_short_desc');
      </script>
    </div></td>
  </tr>
  
  <tr>
    <td width="25%"><div align="right">View Detail Text</div></td>
    <td><div align="left">
      <label>
      <input type="text" name="slide_view_text" class="textbox1" value="<?php echo $slide_vtext; ?>">
      </label>
    </div></td>
  </tr>
  
  <tr>
    <td width="25%"><div align="right">View Detail Link</div></td>
    <td><div align="left">
      <label>
      <input type="text" name="slide_view_link" class="textbox1" value="<?php echo $slide_vlink ?>">
      </label>
    </div></td>
  </tr>
  
  <tr>
    <td width="25%"><div align="right">Sign UP Text</div></td>
    <td><div align="left">
      <label>
      <input type="text" name="slide_signup_text" class="textbox1" value="<?php echo $slide_stext ?>">
      </label>
    </div></td>
  </tr>
  
  <tr>
    <td width="25%"><div align="right">Sign UP Link</div></td>
    <td><div align="left">
      <label>
      <input type="text" name="slide_signup_link" class="textbox1" value="<?php echo $slide_slink ?>">
      </label>
    </div></td>
  </tr>
  
  <tr>
    <td width="25%"><div align="right">Slide Image</div></td>
    <td><div align="left">
      <label>
      <input type="file" name="slide_image" class="textbox1">
      </label>
      <?php if($slide_image): ?>
      	<img width="100" height="100" src="<?php echo base_url().'includes/superadmin/uploads/home_slides/'.$slide_image ; ?>" >
        <input type="checkbox" name="delete_photo"  /> Delete Photo
      <?php endif; ?>
      <input type="hidden" name="hdn_slide_image" value="<?php echo $slide_image; ?>"  />
      </div></td>
  </tr>
  
  <tr>
    <td><div align="right"></div></td>
    <td><div align="left">
      <?php if($edit_slide_id){?>
      <input type="hidden" name="hdneditid" value="<?php echo $edit_slide_id; ?>"  />	
      <input name="update" type="submit" class="btn1" id="update" value=" Update ">
      <?php }else{?>
      <input name="add" type="submit" class="btn1" id="add" value="   Add   ">
      <?php }?>
    </div></td>
  </tr>
</table>
</form>

<table width="100%" border="0" cellspacing="0" cellpadding="0"> 
	<tr> 
    	<td width="10%" height="20" background="images/bg_part.gif" class="formtext">&nbsp;Title</td>
    	<td width="20%" height="20"	background="images/bg_part.gif" class="formtext">&nbsp;Description</td>
    	<td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;View Text</td>
        <td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;View Link</td>
        <td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;Signup Text</td>
        <td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;Signup Link</td>
        <td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;Image</td>
		<td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;</td>
    	<td width="10%" height="10" colspan="2" align="center" background="images/bg_part.gif" class="formtext">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Options</td>
  </tr>
  
  <?php
	$slides = "" ;
	$this->db->select('*');
	$this->db->from( 'tbl_content' );
	$this->db->where( 'tbl_content'.'.str_title','home_slide');		
	$slider_query=$this->db->get();
	if($slider_query->num_rows() > 0)
	{
		$slides = $slider_query->result() ;
	}
 ?>
 <?php if($slides): ?>
 	<?php foreach($slides as $slide): ?>
    	
        <?php $slide_data = explode('{++}',$slide->str_content); ?>
        <tr> 
            <td width="10%" height="20" background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[0])): echo $slide_data[0]; endif; ?></td>
            <td width="20%" height="20"	background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[1])): echo $slide_data[1]; endif; ?></td>
            <td width="10%" align="center" background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[2])): echo $slide_data[2]; endif; ?></td>
            <td width="10%" align="center" background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[3])): echo $slide_data[3]; endif; ?></td>
            <td width="10%" align="center" background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[4])): echo $slide_data[4]; endif; ?></td>
            <td width="10%" align="center" background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[5])): echo $slide_data[5]; endif; ?></td>
            <td width="10%" align="center" background="images/bg_part.gif" class="tdfeatured"><?php if(isset($slide_data[6]) && $slide_data[6] != ""): echo '<img width="100" height="100" src="'.base_url().'includes/superadmin/uploads/home_slides/'.$slide_data[6].'" >'; endif; ?></td>
            <td width="10%" align="center" background="images/bg_part.gif" class="formtext">&nbsp;</td>
            <td width="5%" height="10" align="center" background="images/bg_part.gif" class="tdfeatured"><a href="<?php echo base_url().'superadmin/home_slider/'.$slide->iid ;?>" >Edit</a></td>
            <td width="5%" height="10" align="center" background="images/bg_part.gif" class="tdfeatured"><a href="javascript: delete_slide('<?php echo $slide->iid; ?>');">Delete</a></td>
      </tr>
    <?php endforeach; ?>
 <?php endif; ?>
	
    		<tr>
			  <td height="30">&nbsp;</td>
			  <td height="30">&nbsp;</td>
			  <td height="30" align="center">			  </td>
			  <td height="30" align="center">			  </td>
			  <td height="30" colspan="2" align="right">&nbsp;</td>
			  <td height="30" align="center">&nbsp;</td>
		  </tr>
</table>
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-15 05:14:31 --> Config Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:14:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:14:31 --> URI Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Router Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Output Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Security Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Input Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:14:31 --> Language Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Loader Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:14:31 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:14:31 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Session Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:14:31 --> A session cookie was not found.
DEBUG - 2014-07-15 05:14:31 --> Session routines successfully run
DEBUG - 2014-07-15 05:14:31 --> Upload Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Controller Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:14:31 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:14:31 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-15 05:14:31 --> Final output sent to browser
DEBUG - 2014-07-15 05:14:31 --> Total execution time: 0.2179
DEBUG - 2014-07-15 05:14:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:14:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:14:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:14:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:14:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:14:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:14:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:14:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-15 05:14:37 --> XSS Filtering completed
DEBUG - 2014-07-15 05:14:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:14:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:14:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:14:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:14:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:14:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:14:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:14:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:14:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:14:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-15 05:14:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:14:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:14:37 --> Total execution time: 0.1117
DEBUG - 2014-07-15 05:15:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:15:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:15:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:15:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:15:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:15:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:15:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:15:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:15:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:15:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:15:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:15:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:15:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:15:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:15:22 --> Total execution time: 0.0994
DEBUG - 2014-07-15 05:17:28 --> Config Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:17:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:17:28 --> URI Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Router Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Output Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Security Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Input Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:17:28 --> Language Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Loader Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:17:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:17:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Session Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:17:28 --> Session routines successfully run
DEBUG - 2014-07-15 05:17:28 --> Upload Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Controller Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:17:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:17:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:17:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:17:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:17:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:17:28 --> Final output sent to browser
DEBUG - 2014-07-15 05:17:28 --> Total execution time: 0.1100
DEBUG - 2014-07-15 05:17:28 --> Config Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:17:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:17:28 --> URI Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Router Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Output Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Security Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Input Class Initialized
DEBUG - 2014-07-15 05:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:17:28 --> Language Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Loader Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:17:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:17:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Session Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:17:29 --> Session routines successfully run
DEBUG - 2014-07-15 05:17:29 --> Upload Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Controller Class Initialized
ERROR - 2014-07-15 05:17:29 --> 404 Page Not Found --> 
DEBUG - 2014-07-15 05:17:29 --> Config Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:17:29 --> URI Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Router Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Output Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Security Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Input Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:17:29 --> Language Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Loader Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:17:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:17:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Session Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:17:29 --> Session routines successfully run
DEBUG - 2014-07-15 05:17:29 --> Upload Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:17:29 --> Controller Class Initialized
ERROR - 2014-07-15 05:17:29 --> 404 Page Not Found --> 
DEBUG - 2014-07-15 05:20:15 --> Config Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:20:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:20:15 --> URI Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Router Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Output Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Security Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Input Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:20:15 --> Language Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Loader Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:20:15 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:20:15 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Session Class Initialized
DEBUG - 2014-07-15 05:20:15 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:20:16 --> Session routines successfully run
DEBUG - 2014-07-15 05:20:16 --> Upload Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Controller Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:20:16 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Model Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Model Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Model Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:20:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:20:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:20:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:20:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:20:16 --> Final output sent to browser
DEBUG - 2014-07-15 05:20:16 --> Total execution time: 0.0970
DEBUG - 2014-07-15 05:20:16 --> Config Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:20:16 --> URI Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Router Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Output Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Security Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Input Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:20:16 --> Language Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Loader Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:20:16 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Session Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:20:16 --> Session routines successfully run
DEBUG - 2014-07-15 05:20:16 --> Upload Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Controller Class Initialized
ERROR - 2014-07-15 05:20:16 --> 404 Page Not Found --> 
DEBUG - 2014-07-15 05:20:16 --> Config Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:20:16 --> URI Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Router Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Output Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Security Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Input Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:20:16 --> Language Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Loader Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:20:16 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Session Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:20:16 --> Session routines successfully run
DEBUG - 2014-07-15 05:20:16 --> Upload Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:20:16 --> Controller Class Initialized
ERROR - 2014-07-15 05:20:16 --> 404 Page Not Found --> 
DEBUG - 2014-07-15 05:20:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:20:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:20:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:20:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:20:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:20:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Controller Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:20:32 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:20:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:20:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:20:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:20:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:20:32 --> Final output sent to browser
DEBUG - 2014-07-15 05:20:32 --> Total execution time: 0.1002
DEBUG - 2014-07-15 05:20:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:20:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:20:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:20:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:20:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:20:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Controller Class Initialized
ERROR - 2014-07-15 05:20:32 --> 404 Page Not Found --> 
DEBUG - 2014-07-15 05:20:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:20:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:20:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:20:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:20:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:20:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:20:32 --> Controller Class Initialized
ERROR - 2014-07-15 05:20:32 --> 404 Page Not Found --> 
DEBUG - 2014-07-15 05:25:34 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:34 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:34 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:35 --> Total execution time: 0.0939
DEBUG - 2014-07-15 05:25:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:35 --> Total execution time: 0.0894
DEBUG - 2014-07-15 05:25:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:35 --> Total execution time: 0.0869
DEBUG - 2014-07-15 05:25:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:35 --> Total execution time: 0.1185
DEBUG - 2014-07-15 05:25:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:36 --> Total execution time: 0.0874
DEBUG - 2014-07-15 05:25:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:36 --> Total execution time: 0.0988
DEBUG - 2014-07-15 05:25:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:36 --> Total execution time: 0.1047
DEBUG - 2014-07-15 05:25:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:36 --> Total execution time: 0.0909
DEBUG - 2014-07-15 05:25:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:36 --> Total execution time: 0.1051
DEBUG - 2014-07-15 05:25:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:37 --> Total execution time: 0.0835
DEBUG - 2014-07-15 05:25:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:37 --> Total execution time: 0.0922
DEBUG - 2014-07-15 05:25:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:37 --> Total execution time: 0.1076
DEBUG - 2014-07-15 05:25:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:37 --> Total execution time: 0.0790
DEBUG - 2014-07-15 05:25:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:37 --> Total execution time: 0.0942
DEBUG - 2014-07-15 05:25:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:37 --> Total execution time: 0.0916
DEBUG - 2014-07-15 05:25:48 --> Config Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:25:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:25:48 --> URI Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Router Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Output Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Security Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Input Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:25:48 --> Language Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Loader Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:25:48 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:25:48 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Session Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:25:48 --> Session routines successfully run
DEBUG - 2014-07-15 05:25:48 --> Upload Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Controller Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:25:48 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:25:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:25:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:25:48 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:25:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:25:48 --> Final output sent to browser
DEBUG - 2014-07-15 05:25:48 --> Total execution time: 0.0992
DEBUG - 2014-07-15 05:26:00 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:00 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:00 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:00 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:00 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:00 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:00 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:00 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:00 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:00 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:00 --> Total execution time: 0.1037
DEBUG - 2014-07-15 05:26:02 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:02 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:02 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:02 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:02 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:02 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:02 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:03 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:03 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:03 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:03 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:03 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:03 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:03 --> Total execution time: 0.0884
DEBUG - 2014-07-15 05:26:03 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:03 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:03 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:03 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:03 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:03 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:03 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:03 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:03 --> Total execution time: 0.0864
DEBUG - 2014-07-15 05:26:04 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:04 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:04 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:04 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:04 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:04 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:04 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:04 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:04 --> Total execution time: 0.1020
DEBUG - 2014-07-15 05:26:04 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:04 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:04 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:04 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:04 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:04 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:04 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:04 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:04 --> Total execution time: 0.1048
DEBUG - 2014-07-15 05:26:04 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:04 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:04 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:04 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:04 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:04 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:04 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:04 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:04 --> Total execution time: 0.1213
DEBUG - 2014-07-15 05:26:04 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:04 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:04 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:04 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:04 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:04 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:04 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:04 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:05 --> Total execution time: 0.1081
DEBUG - 2014-07-15 05:26:05 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:05 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:05 --> Total execution time: 0.0894
DEBUG - 2014-07-15 05:26:05 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:05 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:05 --> Total execution time: 0.1180
DEBUG - 2014-07-15 05:26:05 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:05 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:05 --> Total execution time: 0.0974
DEBUG - 2014-07-15 05:26:23 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:23 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:23 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:23 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:23 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:23 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:23 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:23 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:23 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:23 --> Total execution time: 0.0899
DEBUG - 2014-07-15 05:26:25 --> Config Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:26:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:26:25 --> URI Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Router Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Output Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Security Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Input Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:26:25 --> Language Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Loader Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:26:25 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:26:25 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Session Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:26:25 --> Session routines successfully run
DEBUG - 2014-07-15 05:26:25 --> Upload Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Controller Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:26:25 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:26:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:26:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:26:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:26:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:26:25 --> Final output sent to browser
DEBUG - 2014-07-15 05:26:25 --> Total execution time: 0.0895
DEBUG - 2014-07-15 05:29:48 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:48 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:48 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:48 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:48 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:48 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:48 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:48 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:48 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:48 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:48 --> Total execution time: 0.0908
DEBUG - 2014-07-15 05:29:49 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:49 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:49 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:49 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:49 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:49 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:49 --> Total execution time: 0.0955
DEBUG - 2014-07-15 05:29:49 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:49 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:49 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:49 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:49 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:49 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:49 --> Total execution time: 0.0943
DEBUG - 2014-07-15 05:29:49 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:49 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:49 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:49 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:49 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:49 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:49 --> Total execution time: 0.0901
DEBUG - 2014-07-15 05:29:49 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:49 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:49 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:49 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:49 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:49 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:49 --> Total execution time: 0.1260
DEBUG - 2014-07-15 05:29:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:50 --> Total execution time: 0.0874
DEBUG - 2014-07-15 05:29:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:50 --> Total execution time: 0.0871
DEBUG - 2014-07-15 05:29:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:50 --> Total execution time: 0.1357
DEBUG - 2014-07-15 05:29:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:50 --> Total execution time: 0.0909
DEBUG - 2014-07-15 05:29:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:50 --> Total execution time: 0.0927
DEBUG - 2014-07-15 05:29:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:51 --> Total execution time: 0.1043
DEBUG - 2014-07-15 05:29:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:51 --> Total execution time: 0.1079
DEBUG - 2014-07-15 05:29:52 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:52 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:52 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:52 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:52 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:52 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:52 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:52 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:52 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:52 --> Total execution time: 0.0830
DEBUG - 2014-07-15 05:29:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:53 --> Total execution time: 0.1015
DEBUG - 2014-07-15 05:29:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:29:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:29:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:29:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:29:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:29:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:29:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:29:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:29:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:29:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:29:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:29:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:29:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:29:54 --> Total execution time: 0.0873
DEBUG - 2014-07-15 05:31:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:33 --> Total execution time: 0.0928
DEBUG - 2014-07-15 05:31:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:33 --> Total execution time: 0.0907
DEBUG - 2014-07-15 05:31:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:33 --> Total execution time: 0.0853
DEBUG - 2014-07-15 05:31:34 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:34 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:34 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:34 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:34 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:34 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:34 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:34 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:34 --> Total execution time: 0.0886
DEBUG - 2014-07-15 05:31:34 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:34 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:34 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:34 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:34 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:34 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:34 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:34 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:34 --> Total execution time: 0.0960
DEBUG - 2014-07-15 05:31:34 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:34 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:34 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:34 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:34 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:34 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:34 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:34 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:34 --> Total execution time: 0.0861
DEBUG - 2014-07-15 05:31:34 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:34 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:34 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:34 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:34 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:34 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:34 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:34 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:34 --> Total execution time: 0.1371
DEBUG - 2014-07-15 05:31:34 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:34 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:34 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:34 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:34 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:34 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:34 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:34 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:34 --> Total execution time: 0.0814
DEBUG - 2014-07-15 05:31:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:35 --> Total execution time: 0.1214
DEBUG - 2014-07-15 05:31:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:35 --> Total execution time: 0.0840
DEBUG - 2014-07-15 05:31:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:35 --> Total execution time: 0.0896
DEBUG - 2014-07-15 05:31:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:35 --> Total execution time: 0.0958
DEBUG - 2014-07-15 05:31:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:35 --> Total execution time: 0.0829
DEBUG - 2014-07-15 05:31:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:36 --> Total execution time: 0.0900
DEBUG - 2014-07-15 05:31:39 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:39 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:39 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:39 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:39 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:39 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:39 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:39 --> Total execution time: 0.0844
DEBUG - 2014-07-15 05:31:48 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:48 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:48 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:48 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:48 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:48 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:48 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:48 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:48 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:48 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:48 --> Total execution time: 0.0877
DEBUG - 2014-07-15 05:31:49 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:49 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:49 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:49 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:49 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:50 --> Total execution time: 0.0952
DEBUG - 2014-07-15 05:31:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:50 --> Total execution time: 0.1072
DEBUG - 2014-07-15 05:31:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:50 --> Total execution time: 0.0885
DEBUG - 2014-07-15 05:31:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:50 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:50 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:50 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:50 --> Total execution time: 0.1059
DEBUG - 2014-07-15 05:31:50 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:50 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:50 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:51 --> Total execution time: 0.0940
DEBUG - 2014-07-15 05:31:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:51 --> Total execution time: 0.0976
DEBUG - 2014-07-15 05:31:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:51 --> Total execution time: 0.0962
DEBUG - 2014-07-15 05:31:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:51 --> Total execution time: 0.0833
DEBUG - 2014-07-15 05:31:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:51 --> Total execution time: 0.1219
DEBUG - 2014-07-15 05:31:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:52 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:52 --> Total execution time: 0.0924
DEBUG - 2014-07-15 05:31:52 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:52 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:52 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:52 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:52 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:52 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:52 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:52 --> Config Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Total execution time: 0.1240
DEBUG - 2014-07-15 05:31:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:31:52 --> URI Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Router Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Output Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Security Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Input Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:31:52 --> Language Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Loader Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:31:52 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Session Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:31:52 --> Session routines successfully run
DEBUG - 2014-07-15 05:31:52 --> Upload Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Controller Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:31:52 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:31:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:31:52 --> Final output sent to browser
DEBUG - 2014-07-15 05:31:52 --> Total execution time: 0.0845
DEBUG - 2014-07-15 05:34:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:33 --> Total execution time: 0.0861
DEBUG - 2014-07-15 05:34:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:35 --> Total execution time: 0.0863
DEBUG - 2014-07-15 05:34:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:35 --> Total execution time: 0.0859
DEBUG - 2014-07-15 05:34:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:35 --> Total execution time: 0.0969
DEBUG - 2014-07-15 05:34:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:36 --> Total execution time: 0.0920
DEBUG - 2014-07-15 05:34:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:36 --> Total execution time: 0.0853
DEBUG - 2014-07-15 05:34:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:36 --> Total execution time: 0.1009
DEBUG - 2014-07-15 05:34:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:36 --> Total execution time: 0.0916
DEBUG - 2014-07-15 05:34:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:36 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:36 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:36 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:36 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:36 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:36 --> Total execution time: 0.0920
DEBUG - 2014-07-15 05:34:36 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:37 --> Total execution time: 0.0965
DEBUG - 2014-07-15 05:34:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:37 --> Total execution time: 0.0980
DEBUG - 2014-07-15 05:34:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:37 --> Total execution time: 0.0944
DEBUG - 2014-07-15 05:34:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:37 --> Total execution time: 0.0840
DEBUG - 2014-07-15 05:34:37 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:37 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:37 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:37 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:37 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:37 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:37 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:37 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:37 --> Total execution time: 0.1064
DEBUG - 2014-07-15 05:34:40 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:40 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:40 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:40 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:40 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:40 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:40 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:40 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:40 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:40 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:40 --> Total execution time: 0.0782
DEBUG - 2014-07-15 05:34:41 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:41 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:41 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:41 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:41 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:41 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:41 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:41 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:41 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:41 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:41 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:41 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:41 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:41 --> Total execution time: 0.0767
DEBUG - 2014-07-15 05:34:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:34:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:34:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:34:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:34:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:34:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:34:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:34:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:34:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:34:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:34:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:34:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:34:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:34:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:34:43 --> Total execution time: 0.0821
DEBUG - 2014-07-15 05:36:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:36:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:36:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:36:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:36:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:36:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:36:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:36:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:36:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:36:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:36:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:36:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:36:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:36:13 --> Total execution time: 0.0982
DEBUG - 2014-07-15 05:37:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:06 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:06 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:06 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:06 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:06 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:06 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:06 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:06 --> Total execution time: 0.0829
DEBUG - 2014-07-15 05:37:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:06 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:06 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:06 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:06 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:06 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:06 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:06 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:06 --> Total execution time: 0.0959
DEBUG - 2014-07-15 05:37:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:07 --> Total execution time: 0.0988
DEBUG - 2014-07-15 05:37:07 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:07 --> Total execution time: 0.0965
DEBUG - 2014-07-15 05:37:07 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:07 --> Total execution time: 0.0842
DEBUG - 2014-07-15 05:37:07 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:07 --> Total execution time: 0.1082
DEBUG - 2014-07-15 05:37:07 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:07 --> Total execution time: 0.0882
DEBUG - 2014-07-15 05:37:08 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:08 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:08 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:08 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:08 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:08 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:08 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:08 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:08 --> Total execution time: 0.1136
DEBUG - 2014-07-15 05:37:08 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:08 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:08 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:08 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:08 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:08 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:08 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:08 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:08 --> Total execution time: 0.0872
DEBUG - 2014-07-15 05:37:08 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:08 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:08 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:08 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:08 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:08 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:08 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:08 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:08 --> Total execution time: 0.0811
DEBUG - 2014-07-15 05:37:08 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:08 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:08 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:08 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:08 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:08 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:08 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:08 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:08 --> Total execution time: 0.0893
DEBUG - 2014-07-15 05:37:08 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:08 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:08 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:08 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:08 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:08 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:08 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:09 --> Total execution time: 0.0915
DEBUG - 2014-07-15 05:37:09 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:09 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:09 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:09 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:09 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:09 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:09 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:09 --> Total execution time: 0.0811
DEBUG - 2014-07-15 05:37:09 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:09 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:09 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:09 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:09 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:09 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:09 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:09 --> Total execution time: 0.0925
DEBUG - 2014-07-15 05:37:09 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:09 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:09 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:09 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:09 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:09 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:09 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:09 --> Total execution time: 0.0863
DEBUG - 2014-07-15 05:37:09 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:09 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:09 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:09 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:09 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:09 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:09 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:09 --> Total execution time: 0.0856
DEBUG - 2014-07-15 05:37:09 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:09 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:09 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:09 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:09 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:09 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:09 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:09 --> Total execution time: 0.0939
DEBUG - 2014-07-15 05:37:10 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:10 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:10 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:10 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:10 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:10 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:10 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:10 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:10 --> Total execution time: 0.0842
DEBUG - 2014-07-15 05:37:10 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:10 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:10 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:10 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:10 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:10 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:10 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:10 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:10 --> Total execution time: 0.0856
DEBUG - 2014-07-15 05:37:10 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:10 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:10 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:10 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:10 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:10 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:10 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:10 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:10 --> Total execution time: 0.0919
DEBUG - 2014-07-15 05:37:10 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:10 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:10 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:10 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:10 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:10 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:10 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:10 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:10 --> Total execution time: 0.0840
DEBUG - 2014-07-15 05:37:10 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:10 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:10 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:10 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:10 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:10 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:10 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:10 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:10 --> Total execution time: 0.1032
DEBUG - 2014-07-15 05:37:42 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:42 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:42 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:42 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:42 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:42 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:42 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:42 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:42 --> Total execution time: 0.0981
DEBUG - 2014-07-15 05:37:42 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:42 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:42 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:42 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:42 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:42 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:42 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:42 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:42 --> Total execution time: 0.1094
DEBUG - 2014-07-15 05:37:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:43 --> Total execution time: 0.0920
DEBUG - 2014-07-15 05:37:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:43 --> Total execution time: 0.0866
DEBUG - 2014-07-15 05:37:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:43 --> Total execution time: 0.0779
DEBUG - 2014-07-15 05:37:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:44 --> Total execution time: 0.1029
DEBUG - 2014-07-15 05:37:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:44 --> Total execution time: 0.0868
DEBUG - 2014-07-15 05:37:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:44 --> Total execution time: 0.0988
DEBUG - 2014-07-15 05:37:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:44 --> Total execution time: 0.0878
DEBUG - 2014-07-15 05:37:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:44 --> Total execution time: 0.1001
DEBUG - 2014-07-15 05:37:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:45 --> Total execution time: 0.0941
DEBUG - 2014-07-15 05:37:45 --> Config Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:37:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:37:45 --> URI Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Router Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Output Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Security Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Input Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:37:45 --> Language Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Loader Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:37:45 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:37:45 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Session Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:37:45 --> Session routines successfully run
DEBUG - 2014-07-15 05:37:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:37:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:37:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:37:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:37:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:37:45 --> Total execution time: 0.0789
DEBUG - 2014-07-15 05:38:11 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:11 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:11 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:11 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:11 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:11 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:11 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:11 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:11 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:11 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:11 --> Total execution time: 0.0936
DEBUG - 2014-07-15 05:38:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:12 --> Total execution time: 0.0978
DEBUG - 2014-07-15 05:38:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:12 --> Total execution time: 0.1160
DEBUG - 2014-07-15 05:38:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:12 --> Total execution time: 0.1074
DEBUG - 2014-07-15 05:38:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:12 --> Total execution time: 0.1078
DEBUG - 2014-07-15 05:38:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:13 --> Total execution time: 0.1007
DEBUG - 2014-07-15 05:38:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:13 --> Total execution time: 0.0939
DEBUG - 2014-07-15 05:38:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:13 --> Total execution time: 0.0921
DEBUG - 2014-07-15 05:38:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:13 --> Total execution time: 0.0990
DEBUG - 2014-07-15 05:38:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:14 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:14 --> Total execution time: 0.0945
DEBUG - 2014-07-15 05:38:14 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:14 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:14 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:14 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:14 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:14 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:14 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:14 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:14 --> Total execution time: 0.1028
DEBUG - 2014-07-15 05:38:14 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:14 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:14 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:14 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:14 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:14 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:14 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:14 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:14 --> Total execution time: 0.0855
DEBUG - 2014-07-15 05:38:14 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:14 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:14 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:14 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:14 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:14 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:14 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:14 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:14 --> Total execution time: 0.0885
DEBUG - 2014-07-15 05:38:14 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:14 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:14 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:14 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:14 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:14 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:14 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:14 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:14 --> Total execution time: 0.0956
DEBUG - 2014-07-15 05:38:25 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:25 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:25 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:25 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:25 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:25 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:25 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:25 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:25 --> Total execution time: 0.0890
DEBUG - 2014-07-15 05:38:25 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:25 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:25 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:25 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:25 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:25 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:25 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:25 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:25 --> Total execution time: 0.1141
DEBUG - 2014-07-15 05:38:25 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:25 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:25 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:25 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:25 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:25 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:25 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:25 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:25 --> Total execution time: 0.0851
DEBUG - 2014-07-15 05:38:25 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:25 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:25 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:25 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:26 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:26 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:26 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:26 --> Total execution time: 0.0978
DEBUG - 2014-07-15 05:38:26 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:26 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:26 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:26 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:26 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:26 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:26 --> Total execution time: 0.0990
DEBUG - 2014-07-15 05:38:26 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:26 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:26 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:26 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:26 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:26 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:26 --> Total execution time: 0.1091
DEBUG - 2014-07-15 05:38:26 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:26 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:26 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:26 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:26 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:26 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:26 --> Total execution time: 0.0971
DEBUG - 2014-07-15 05:38:26 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:26 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:26 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:26 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:26 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:26 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:26 --> Total execution time: 0.0944
DEBUG - 2014-07-15 05:38:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:27 --> Total execution time: 0.0963
DEBUG - 2014-07-15 05:38:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:27 --> Total execution time: 0.1126
DEBUG - 2014-07-15 05:38:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:27 --> Total execution time: 0.0878
DEBUG - 2014-07-15 05:38:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:38:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:38:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:38:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:38:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:38:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:38:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:38:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:38:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:38:27 --> Total execution time: 0.1008
DEBUG - 2014-07-15 05:42:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:44 --> Total execution time: 0.0908
DEBUG - 2014-07-15 05:42:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:44 --> Total execution time: 0.0905
DEBUG - 2014-07-15 05:42:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:44 --> Total execution time: 0.1062
DEBUG - 2014-07-15 05:42:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:45 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:45 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:45 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:45 --> Total execution time: 0.0948
DEBUG - 2014-07-15 05:42:45 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:45 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:45 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:45 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:45 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:45 --> Total execution time: 0.1015
DEBUG - 2014-07-15 05:42:45 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:45 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:45 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:45 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:45 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:45 --> Total execution time: 0.0939
DEBUG - 2014-07-15 05:42:45 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:45 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:45 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:45 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:45 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:45 --> Total execution time: 0.1011
DEBUG - 2014-07-15 05:42:45 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:45 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:45 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:45 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:45 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:45 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:45 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:45 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:45 --> Total execution time: 0.0987
DEBUG - 2014-07-15 05:42:46 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:46 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:46 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:46 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:46 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:46 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:46 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:46 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:46 --> Total execution time: 0.0973
DEBUG - 2014-07-15 05:42:46 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:46 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:46 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:46 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:46 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:46 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:46 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:46 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:46 --> Total execution time: 0.0921
DEBUG - 2014-07-15 05:42:46 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:46 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:46 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:46 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:46 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:46 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:46 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:46 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:46 --> Total execution time: 0.0960
DEBUG - 2014-07-15 05:42:46 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:46 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:46 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:46 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:46 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:46 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:46 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:46 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:46 --> Total execution time: 0.1003
DEBUG - 2014-07-15 05:42:46 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:46 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:46 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:46 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:46 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:46 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:46 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:46 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:46 --> Total execution time: 0.0780
DEBUG - 2014-07-15 05:42:47 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:47 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:47 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:47 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:47 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:47 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:47 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:47 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:47 --> Total execution time: 0.0905
DEBUG - 2014-07-15 05:42:47 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:47 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:47 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:47 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:47 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:47 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:47 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:47 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:47 --> Total execution time: 0.0921
DEBUG - 2014-07-15 05:42:47 --> Config Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:42:47 --> URI Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Router Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Output Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Security Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Input Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:42:47 --> Language Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Loader Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:42:47 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Session Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:42:47 --> Session routines successfully run
DEBUG - 2014-07-15 05:42:47 --> Upload Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Controller Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:42:47 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Model Class Initialized
DEBUG - 2014-07-15 05:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:42:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:42:47 --> Final output sent to browser
DEBUG - 2014-07-15 05:42:47 --> Total execution time: 0.0963
DEBUG - 2014-07-15 05:43:23 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:23 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:23 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:23 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:23 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:23 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:23 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:23 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:23 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:23 --> Total execution time: 0.0941
DEBUG - 2014-07-15 05:43:26 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:26 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:26 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:26 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:26 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:26 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:26 --> Total execution time: 0.0839
DEBUG - 2014-07-15 05:43:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:27 --> Total execution time: 0.1251
DEBUG - 2014-07-15 05:43:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:27 --> Total execution time: 0.1007
DEBUG - 2014-07-15 05:43:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:27 --> Total execution time: 0.1059
DEBUG - 2014-07-15 05:43:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:27 --> Total execution time: 0.1109
DEBUG - 2014-07-15 05:43:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:43:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:43:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:43:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:43:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:43:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:43:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:43:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:43:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:43:27 --> Total execution time: 0.1085
DEBUG - 2014-07-15 05:46:35 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:35 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:35 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:35 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:35 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:35 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:35 --> Total execution time: 0.1163
DEBUG - 2014-07-15 05:46:52 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:52 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:52 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:52 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:52 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:52 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:52 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:52 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:52 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:52 --> Total execution time: 0.1238
DEBUG - 2014-07-15 05:46:52 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:52 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:52 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:52 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:52 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:52 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:53 --> Total execution time: 0.0899
DEBUG - 2014-07-15 05:46:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:53 --> Total execution time: 0.0804
DEBUG - 2014-07-15 05:46:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:53 --> Total execution time: 0.1016
DEBUG - 2014-07-15 05:46:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:53 --> Total execution time: 0.0938
DEBUG - 2014-07-15 05:46:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:46:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:46:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:46:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:46:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:46:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:46:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:46:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:46:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:46:53 --> Total execution time: 0.0949
DEBUG - 2014-07-15 05:47:04 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:04 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:05 --> Total execution time: 0.1025
DEBUG - 2014-07-15 05:47:05 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:05 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:05 --> Total execution time: 0.0972
DEBUG - 2014-07-15 05:47:05 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:05 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:05 --> Total execution time: 0.1094
DEBUG - 2014-07-15 05:47:05 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:05 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:05 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:05 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:05 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:05 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:05 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:05 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:05 --> Total execution time: 0.1137
DEBUG - 2014-07-15 05:47:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:06 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:06 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:06 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:06 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:06 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:06 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:06 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:06 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:06 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:06 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:06 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:06 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:06 --> Total execution time: 0.1242
DEBUG - 2014-07-15 05:47:06 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:06 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:06 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:06 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:06 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:06 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:06 --> Total execution time: 0.1183
DEBUG - 2014-07-15 05:47:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:06 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:06 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:06 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:06 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:06 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:06 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:06 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:06 --> Total execution time: 0.1078
DEBUG - 2014-07-15 05:47:06 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:06 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:06 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:06 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:06 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:06 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:06 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:06 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:06 --> Total execution time: 0.0928
DEBUG - 2014-07-15 05:47:07 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:07 --> Total execution time: 0.0956
DEBUG - 2014-07-15 05:47:07 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:07 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:07 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:07 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:07 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:07 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:07 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:07 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:07 --> Total execution time: 0.0890
DEBUG - 2014-07-15 05:47:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:27 --> Total execution time: 0.1177
DEBUG - 2014-07-15 05:47:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:27 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:27 --> Total execution time: 0.1078
DEBUG - 2014-07-15 05:47:27 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:27 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:27 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:27 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:27 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:28 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:28 --> Total execution time: 0.0965
DEBUG - 2014-07-15 05:47:28 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:28 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:28 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:28 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:28 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:28 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:28 --> Total execution time: 0.1161
DEBUG - 2014-07-15 05:47:28 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:28 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:28 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:28 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:28 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:28 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:28 --> Total execution time: 0.1036
DEBUG - 2014-07-15 05:47:28 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:28 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:28 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:28 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:28 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:28 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:28 --> Total execution time: 0.1326
DEBUG - 2014-07-15 05:47:28 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:28 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:28 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:28 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:28 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:28 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:28 --> Total execution time: 0.0831
DEBUG - 2014-07-15 05:47:29 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:29 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:29 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:29 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:29 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:29 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:29 --> Total execution time: 0.1214
DEBUG - 2014-07-15 05:47:29 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:29 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:29 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:29 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:29 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:29 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:29 --> Total execution time: 0.1043
DEBUG - 2014-07-15 05:47:41 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:41 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:41 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:41 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:41 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:41 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:41 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:41 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:41 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:41 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:41 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:41 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:41 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:41 --> Total execution time: 0.1252
DEBUG - 2014-07-15 05:47:42 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:42 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:42 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:42 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:42 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:42 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:42 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:42 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:42 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:42 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:42 --> Total execution time: 0.0913
DEBUG - 2014-07-15 05:47:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:43 --> Total execution time: 0.1028
DEBUG - 2014-07-15 05:47:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:43 --> Total execution time: 0.0962
DEBUG - 2014-07-15 05:47:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:43 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:43 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:43 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:43 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:43 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:43 --> Total execution time: 0.0999
DEBUG - 2014-07-15 05:47:43 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:44 --> Total execution time: 0.0994
DEBUG - 2014-07-15 05:47:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:44 --> Total execution time: 0.0926
DEBUG - 2014-07-15 05:47:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:44 --> Total execution time: 0.0974
DEBUG - 2014-07-15 05:47:44 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:44 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:44 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:44 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:44 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:44 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:44 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:44 --> Total execution time: 0.0928
DEBUG - 2014-07-15 05:47:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:54 --> Total execution time: 0.1109
DEBUG - 2014-07-15 05:47:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:54 --> Total execution time: 0.0977
DEBUG - 2014-07-15 05:47:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:54 --> Total execution time: 0.1267
DEBUG - 2014-07-15 05:47:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:55 --> Total execution time: 0.1068
DEBUG - 2014-07-15 05:47:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:55 --> Total execution time: 0.0882
DEBUG - 2014-07-15 05:47:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:55 --> Total execution time: 0.1003
DEBUG - 2014-07-15 05:47:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:56 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:56 --> Total execution time: 0.0912
DEBUG - 2014-07-15 05:47:56 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:56 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:56 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:56 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:56 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:56 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:56 --> Total execution time: 0.1572
DEBUG - 2014-07-15 05:47:56 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:56 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:56 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:56 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:56 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:56 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:56 --> Total execution time: 0.0871
DEBUG - 2014-07-15 05:47:56 --> Config Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:47:56 --> URI Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Router Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Output Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Security Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Input Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:47:56 --> Language Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Loader Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:47:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Session Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:47:56 --> Session routines successfully run
DEBUG - 2014-07-15 05:47:56 --> Upload Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Controller Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:47:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:47:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:47:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:47:56 --> Final output sent to browser
DEBUG - 2014-07-15 05:47:56 --> Total execution time: 0.1016
DEBUG - 2014-07-15 05:48:11 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:11 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:11 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:11 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:11 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:11 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:11 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:11 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:11 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:11 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:11 --> Total execution time: 0.1061
DEBUG - 2014-07-15 05:48:11 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:11 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:11 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:11 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:11 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:12 --> Total execution time: 0.0919
DEBUG - 2014-07-15 05:48:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:12 --> Total execution time: 0.0966
DEBUG - 2014-07-15 05:48:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:12 --> Total execution time: 0.1007
DEBUG - 2014-07-15 05:48:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:12 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:12 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:12 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:12 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:12 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:12 --> Total execution time: 0.0899
DEBUG - 2014-07-15 05:48:12 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:12 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:12 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:13 --> Total execution time: 0.1011
DEBUG - 2014-07-15 05:48:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:13 --> Total execution time: 0.1093
DEBUG - 2014-07-15 05:48:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:13 --> Total execution time: 0.0955
DEBUG - 2014-07-15 05:48:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:13 --> Total execution time: 0.0917
DEBUG - 2014-07-15 05:48:13 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:13 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:13 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:13 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:13 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:13 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:13 --> Total execution time: 0.1018
DEBUG - 2014-07-15 05:48:29 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:29 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:29 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:29 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:29 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:29 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:29 --> Total execution time: 0.0935
DEBUG - 2014-07-15 05:48:29 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:29 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:29 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:29 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:29 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:29 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:29 --> Total execution time: 0.1143
DEBUG - 2014-07-15 05:48:30 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:30 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:30 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:30 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:30 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:30 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:30 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:30 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:30 --> Total execution time: 0.0798
DEBUG - 2014-07-15 05:48:30 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:30 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:30 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:30 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:30 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:30 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:30 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:30 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:30 --> Total execution time: 0.1001
DEBUG - 2014-07-15 05:48:30 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:30 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:30 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:30 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:30 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:30 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:30 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:30 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:30 --> Total execution time: 0.0880
DEBUG - 2014-07-15 05:48:30 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:30 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:30 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:30 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:30 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:30 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:30 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:30 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:30 --> Total execution time: 0.0912
DEBUG - 2014-07-15 05:48:30 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:30 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:30 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:30 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:30 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:30 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:30 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:30 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:30 --> Total execution time: 0.0918
DEBUG - 2014-07-15 05:48:31 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:31 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:31 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:31 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:31 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:31 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:31 --> Total execution time: 0.0953
DEBUG - 2014-07-15 05:48:31 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:31 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:31 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:31 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:31 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:31 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:31 --> Total execution time: 0.0989
DEBUG - 2014-07-15 05:48:31 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:31 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:31 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:31 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:31 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:31 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:31 --> Total execution time: 0.1084
DEBUG - 2014-07-15 05:48:31 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:31 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:31 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:31 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:31 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:31 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:31 --> Total execution time: 0.1137
DEBUG - 2014-07-15 05:48:31 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:31 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:31 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:31 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:31 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:31 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:31 --> Total execution time: 0.0988
DEBUG - 2014-07-15 05:48:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:32 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:32 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:32 --> Total execution time: 0.0993
DEBUG - 2014-07-15 05:48:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:32 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:32 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:32 --> Total execution time: 0.0962
DEBUG - 2014-07-15 05:48:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:32 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:32 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:32 --> Total execution time: 0.0998
DEBUG - 2014-07-15 05:48:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:32 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:32 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:32 --> Total execution time: 0.0956
DEBUG - 2014-07-15 05:48:32 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:32 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:32 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:32 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:32 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:32 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:32 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:32 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:32 --> Total execution time: 0.1016
DEBUG - 2014-07-15 05:48:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:33 --> Total execution time: 0.0946
DEBUG - 2014-07-15 05:48:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:33 --> Total execution time: 0.0963
DEBUG - 2014-07-15 05:48:33 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:33 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:33 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:33 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:33 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:33 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:33 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:33 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:33 --> Total execution time: 0.0944
DEBUG - 2014-07-15 05:48:52 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:52 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:52 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:53 --> Total execution time: 0.1000
DEBUG - 2014-07-15 05:48:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:53 --> Total execution time: 0.1154
DEBUG - 2014-07-15 05:48:53 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:53 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:53 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:53 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:53 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:53 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:53 --> Total execution time: 0.0965
DEBUG - 2014-07-15 05:48:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:54 --> Total execution time: 0.1415
DEBUG - 2014-07-15 05:48:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:54 --> Total execution time: 0.1024
DEBUG - 2014-07-15 05:48:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:54 --> Total execution time: 0.1059
DEBUG - 2014-07-15 05:48:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:54 --> Total execution time: 0.0935
DEBUG - 2014-07-15 05:48:54 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:54 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:54 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:54 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:54 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:54 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:54 --> Total execution time: 0.0947
DEBUG - 2014-07-15 05:48:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:55 --> Total execution time: 0.0943
DEBUG - 2014-07-15 05:48:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:55 --> Total execution time: 0.1048
DEBUG - 2014-07-15 05:48:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:55 --> Total execution time: 0.1046
DEBUG - 2014-07-15 05:48:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:55 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:55 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:55 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:55 --> Total execution time: 0.0925
DEBUG - 2014-07-15 05:48:55 --> Config Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:48:55 --> URI Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Router Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Output Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Security Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Input Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:48:55 --> Language Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Loader Class Initialized
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:48:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:48:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Session Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:48:56 --> Session routines successfully run
DEBUG - 2014-07-15 05:48:56 --> Upload Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Controller Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:48:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Model Class Initialized
DEBUG - 2014-07-15 05:48:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:48:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:48:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:48:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:48:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:48:56 --> Final output sent to browser
DEBUG - 2014-07-15 05:48:56 --> Total execution time: 0.1036
DEBUG - 2014-07-15 05:55:51 --> Config Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:55:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:55:51 --> URI Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Router Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Output Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Security Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Input Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:55:51 --> Language Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Loader Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:55:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:55:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Session Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:55:51 --> Session routines successfully run
DEBUG - 2014-07-15 05:55:51 --> Upload Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Controller Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:55:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Model Class Initialized
DEBUG - 2014-07-15 05:55:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:55:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:55:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:55:51 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:55:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:55:51 --> Final output sent to browser
DEBUG - 2014-07-15 05:55:51 --> Total execution time: 0.0846
DEBUG - 2014-07-15 05:56:09 --> Config Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:56:09 --> URI Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Router Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Output Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Security Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Input Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:56:09 --> Language Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Loader Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:56:09 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:56:09 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Session Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:56:09 --> Session routines successfully run
DEBUG - 2014-07-15 05:56:09 --> Upload Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Controller Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:56:09 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-15 05:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:56:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:56:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:56:09 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:56:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:56:09 --> Final output sent to browser
DEBUG - 2014-07-15 05:56:09 --> Total execution time: 0.0954
DEBUG - 2014-07-15 05:59:15 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:15 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:15 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:15 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:15 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:15 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:15 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:15 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:15 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:15 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:15 --> Total execution time: 0.0869
DEBUG - 2014-07-15 05:59:18 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:18 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:18 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:18 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:18 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:18 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:18 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:18 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:18 --> Total execution time: 0.0880
DEBUG - 2014-07-15 05:59:18 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:18 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:18 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:18 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:18 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:18 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:18 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:18 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:18 --> Total execution time: 0.1285
DEBUG - 2014-07-15 05:59:19 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:19 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:19 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:19 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:19 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:19 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:19 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:19 --> Total execution time: 0.1552
DEBUG - 2014-07-15 05:59:19 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:19 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:19 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:19 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:19 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:19 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:19 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:19 --> Total execution time: 0.1100
DEBUG - 2014-07-15 05:59:19 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:19 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:19 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:19 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:19 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:19 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:19 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:19 --> Total execution time: 0.0823
DEBUG - 2014-07-15 05:59:19 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:19 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:19 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:19 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:19 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:19 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:19 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:19 --> Total execution time: 0.1023
DEBUG - 2014-07-15 05:59:19 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:19 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:19 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:19 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:19 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:19 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:19 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:19 --> Total execution time: 0.0810
DEBUG - 2014-07-15 05:59:20 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:20 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:20 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:20 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:20 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:20 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:20 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:20 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:20 --> Total execution time: 0.0904
DEBUG - 2014-07-15 05:59:20 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:20 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:20 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:20 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:20 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:20 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:20 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:20 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:20 --> Total execution time: 0.1011
DEBUG - 2014-07-15 05:59:20 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:20 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:20 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:20 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:20 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:20 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:20 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:20 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:20 --> Total execution time: 0.0873
DEBUG - 2014-07-15 05:59:20 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:20 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:20 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:20 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:20 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:20 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:20 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:20 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:20 --> Total execution time: 0.1121
DEBUG - 2014-07-15 05:59:20 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:20 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:20 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:21 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:21 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:21 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:21 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:21 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:21 --> Total execution time: 0.1023
DEBUG - 2014-07-15 05:59:21 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:21 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:21 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:21 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:21 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:21 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:21 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:21 --> Total execution time: 0.0943
DEBUG - 2014-07-15 05:59:21 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:21 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:21 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:21 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:21 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:21 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:21 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:21 --> Total execution time: 0.1152
DEBUG - 2014-07-15 05:59:21 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:21 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:21 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:21 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:21 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:21 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:21 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:21 --> Total execution time: 0.0953
DEBUG - 2014-07-15 05:59:21 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:21 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:21 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:21 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:21 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:21 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:21 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:21 --> Total execution time: 0.1068
DEBUG - 2014-07-15 05:59:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:22 --> Total execution time: 0.2187
DEBUG - 2014-07-15 05:59:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:22 --> Total execution time: 0.1061
DEBUG - 2014-07-15 05:59:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:22 --> Total execution time: 0.0865
DEBUG - 2014-07-15 05:59:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:22 --> Total execution time: 0.0856
DEBUG - 2014-07-15 05:59:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:22 --> Total execution time: 0.1020
DEBUG - 2014-07-15 05:59:22 --> Config Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 05:59:22 --> URI Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Router Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Output Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Security Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Input Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 05:59:22 --> Language Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Loader Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 05:59:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 05:59:22 --> Session routines successfully run
DEBUG - 2014-07-15 05:59:22 --> Upload Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Controller Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 05:59:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Model Class Initialized
DEBUG - 2014-07-15 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 05:59:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 05:59:22 --> Final output sent to browser
DEBUG - 2014-07-15 05:59:22 --> Total execution time: 0.0888
DEBUG - 2014-07-15 06:00:27 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:27 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:27 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:27 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:27 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:27 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:27 --> Total execution time: 0.0800
DEBUG - 2014-07-15 06:00:27 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:27 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:27 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:27 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:27 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:27 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:27 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:27 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:27 --> Total execution time: 0.0978
DEBUG - 2014-07-15 06:00:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:28 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:28 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:28 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:28 --> Total execution time: 0.1016
DEBUG - 2014-07-15 06:00:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:28 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:28 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:28 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:28 --> Total execution time: 0.0904
DEBUG - 2014-07-15 06:00:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:28 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:28 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:28 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:28 --> Total execution time: 0.0829
DEBUG - 2014-07-15 06:00:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:28 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:28 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:28 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:28 --> Total execution time: 0.0965
DEBUG - 2014-07-15 06:00:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:28 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:28 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:28 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:28 --> Total execution time: 0.0899
DEBUG - 2014-07-15 06:00:29 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:29 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:29 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:29 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:29 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:29 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:29 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:29 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:29 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:29 --> Total execution time: 0.1232
DEBUG - 2014-07-15 06:00:29 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:29 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:29 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:29 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:29 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:29 --> Total execution time: 0.1147
DEBUG - 2014-07-15 06:00:29 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:29 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:29 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:29 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:29 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:29 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:29 --> Total execution time: 0.0917
DEBUG - 2014-07-15 06:00:29 --> Config Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:00:29 --> URI Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Router Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Output Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Security Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Input Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:00:29 --> Language Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Loader Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:00:29 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:00:29 --> Session routines successfully run
DEBUG - 2014-07-15 06:00:29 --> Upload Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Controller Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:00:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:00:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:00:29 --> Final output sent to browser
DEBUG - 2014-07-15 06:00:29 --> Total execution time: 0.0904
DEBUG - 2014-07-15 06:01:36 --> Config Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:01:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:01:36 --> URI Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Router Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Output Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Security Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Input Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:01:36 --> Language Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Loader Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:01:36 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:01:36 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Session Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:01:36 --> Session routines successfully run
DEBUG - 2014-07-15 06:01:36 --> Upload Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Controller Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:01:36 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Model Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Model Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Model Class Initialized
DEBUG - 2014-07-15 06:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:01:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:01:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:01:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:01:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:01:36 --> Final output sent to browser
DEBUG - 2014-07-15 06:01:36 --> Total execution time: 0.0898
DEBUG - 2014-07-15 06:11:13 --> Config Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:11:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:11:13 --> URI Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Router Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Output Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Security Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Input Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:11:13 --> Language Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Loader Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:11:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Session Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:11:13 --> Session routines successfully run
DEBUG - 2014-07-15 06:11:13 --> Upload Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Controller Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:11:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:11:13 --> Config Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:11:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:11:13 --> URI Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Router Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Output Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Security Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Input Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:11:13 --> Language Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Loader Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:11:13 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Session Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:11:13 --> Session routines successfully run
DEBUG - 2014-07-15 06:11:13 --> Upload Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Controller Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:11:13 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:11:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:11:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:11:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:11:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:11:13 --> Final output sent to browser
DEBUG - 2014-07-15 06:11:13 --> Total execution time: 0.0830
DEBUG - 2014-07-15 06:11:17 --> Config Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:11:17 --> URI Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Router Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Output Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Security Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Input Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:11:17 --> Language Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Loader Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:11:17 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:11:17 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Session Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:11:17 --> Session routines successfully run
DEBUG - 2014-07-15 06:11:17 --> Upload Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Controller Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:11:17 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Model Class Initialized
DEBUG - 2014-07-15 06:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:11:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:11:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:11:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:11:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:11:17 --> Final output sent to browser
DEBUG - 2014-07-15 06:11:17 --> Total execution time: 0.1067
DEBUG - 2014-07-15 06:14:54 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:54 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:54 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:54 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:54 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:54 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:54 --> Total execution time: 0.0870
DEBUG - 2014-07-15 06:14:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:55 --> Total execution time: 0.1036
DEBUG - 2014-07-15 06:14:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:55 --> Total execution time: 0.0918
DEBUG - 2014-07-15 06:14:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:55 --> Total execution time: 0.1011
DEBUG - 2014-07-15 06:14:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:55 --> Total execution time: 0.1174
DEBUG - 2014-07-15 06:14:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:56 --> Total execution time: 0.0974
DEBUG - 2014-07-15 06:14:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:56 --> Total execution time: 0.1017
DEBUG - 2014-07-15 06:14:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:56 --> Total execution time: 0.1086
DEBUG - 2014-07-15 06:14:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:56 --> Total execution time: 0.1050
DEBUG - 2014-07-15 06:14:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:56 --> Total execution time: 0.0962
DEBUG - 2014-07-15 06:14:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:57 --> Total execution time: 0.1308
DEBUG - 2014-07-15 06:14:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:57 --> Total execution time: 0.0931
DEBUG - 2014-07-15 06:14:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:57 --> Total execution time: 0.0949
DEBUG - 2014-07-15 06:14:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:57 --> Total execution time: 0.0951
DEBUG - 2014-07-15 06:14:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:58 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:58 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:58 --> Total execution time: 0.0993
DEBUG - 2014-07-15 06:14:58 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:58 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:58 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:58 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:58 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:58 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:58 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:58 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:58 --> Total execution time: 0.0889
DEBUG - 2014-07-15 06:14:58 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:58 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:58 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:58 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:58 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:58 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:58 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:58 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:58 --> Total execution time: 0.1016
DEBUG - 2014-07-15 06:14:58 --> Config Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:14:58 --> URI Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Router Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Output Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Security Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Input Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:14:58 --> Language Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Loader Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:14:58 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:14:58 --> Session routines successfully run
DEBUG - 2014-07-15 06:14:58 --> Upload Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Controller Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:14:58 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:14:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:14:58 --> Final output sent to browser
DEBUG - 2014-07-15 06:14:58 --> Total execution time: 0.0983
DEBUG - 2014-07-15 06:17:43 --> Config Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:17:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:17:43 --> URI Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Router Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Output Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Security Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Input Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:17:43 --> Language Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Loader Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:17:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:17:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Session Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:17:43 --> Session routines successfully run
DEBUG - 2014-07-15 06:17:43 --> Upload Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Controller Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:17:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Model Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Model Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Model Class Initialized
DEBUG - 2014-07-15 06:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:17:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:17:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:17:43 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:17:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:17:43 --> Final output sent to browser
DEBUG - 2014-07-15 06:17:43 --> Total execution time: 0.0876
DEBUG - 2014-07-15 06:18:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:18:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:18:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:18:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:18:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:18:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:18:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:18:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:18:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:18:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:18:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:18:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:18:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:18:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:18:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:18:57 --> Total execution time: 0.1054
DEBUG - 2014-07-15 06:19:17 --> Config Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:19:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:19:17 --> URI Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Router Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Output Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Security Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Input Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:19:17 --> Language Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Loader Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:19:17 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:19:17 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Session Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:19:17 --> Session routines successfully run
DEBUG - 2014-07-15 06:19:17 --> Upload Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Controller Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:19:17 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Model Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Model Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Model Class Initialized
DEBUG - 2014-07-15 06:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:19:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:19:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:19:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:19:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:19:17 --> Final output sent to browser
DEBUG - 2014-07-15 06:19:17 --> Total execution time: 0.0941
DEBUG - 2014-07-15 06:23:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:23:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:23:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:23:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:23:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:23:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:23:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Session Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:23:29 --> Session routines successfully run
DEBUG - 2014-07-15 06:23:29 --> Upload Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Controller Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:23:29 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Model Class Initialized
DEBUG - 2014-07-15 06:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:23:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:23:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:23:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:23:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:23:29 --> Final output sent to browser
DEBUG - 2014-07-15 06:23:29 --> Total execution time: 0.1069
DEBUG - 2014-07-15 06:24:53 --> Config Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:24:53 --> URI Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Router Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Output Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Security Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Input Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:24:53 --> Language Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Loader Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:24:53 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:24:53 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Session Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:24:53 --> Session routines successfully run
DEBUG - 2014-07-15 06:24:53 --> Upload Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Controller Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:24:53 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Model Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Model Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Model Class Initialized
DEBUG - 2014-07-15 06:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:24:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:24:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:24:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:24:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:24:53 --> Final output sent to browser
DEBUG - 2014-07-15 06:24:53 --> Total execution time: 0.0948
DEBUG - 2014-07-15 06:25:47 --> Config Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:25:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:25:47 --> URI Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Router Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Output Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Security Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Input Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:25:47 --> Language Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Loader Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:25:47 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:25:47 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Session Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:25:47 --> Session routines successfully run
DEBUG - 2014-07-15 06:25:47 --> Upload Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Controller Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:25:47 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Model Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Model Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Model Class Initialized
DEBUG - 2014-07-15 06:25:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:25:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:25:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:25:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:25:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:25:47 --> Final output sent to browser
DEBUG - 2014-07-15 06:25:47 --> Total execution time: 0.1317
DEBUG - 2014-07-15 06:26:01 --> Config Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:26:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:26:01 --> URI Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Router Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Output Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Security Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Input Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:26:01 --> Language Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Loader Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:26:01 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:26:01 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Session Class Initialized
DEBUG - 2014-07-15 06:26:01 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:26:01 --> Session routines successfully run
DEBUG - 2014-07-15 06:26:02 --> Upload Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Controller Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:26:02 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:26:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:26:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:26:02 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:26:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:26:02 --> Final output sent to browser
DEBUG - 2014-07-15 06:26:02 --> Total execution time: 0.0868
DEBUG - 2014-07-15 06:26:16 --> Config Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:26:16 --> URI Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Router Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Output Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Security Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Input Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:26:16 --> Language Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Loader Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:26:16 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:26:16 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Session Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:26:16 --> Session routines successfully run
DEBUG - 2014-07-15 06:26:16 --> Upload Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Controller Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:26:16 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:26:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:26:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:26:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:26:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:26:16 --> Final output sent to browser
DEBUG - 2014-07-15 06:26:16 --> Total execution time: 0.1018
DEBUG - 2014-07-15 06:26:28 --> Config Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:26:28 --> URI Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Router Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Output Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Security Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Input Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:26:28 --> Language Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Loader Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:26:28 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:26:28 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Session Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:26:28 --> Session routines successfully run
DEBUG - 2014-07-15 06:26:28 --> Upload Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Controller Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:26:28 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:26:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:26:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:26:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:26:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:26:28 --> Final output sent to browser
DEBUG - 2014-07-15 06:26:28 --> Total execution time: 0.1139
DEBUG - 2014-07-15 06:26:50 --> Config Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:26:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:26:50 --> URI Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Router Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Output Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Security Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Input Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:26:50 --> Language Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Loader Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:26:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:26:50 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Session Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:26:50 --> Session routines successfully run
DEBUG - 2014-07-15 06:26:50 --> Upload Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Controller Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:26:50 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Model Class Initialized
DEBUG - 2014-07-15 06:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:26:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:26:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:26:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:26:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:26:50 --> Final output sent to browser
DEBUG - 2014-07-15 06:26:50 --> Total execution time: 0.0953
DEBUG - 2014-07-15 06:27:38 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:38 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:38 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:38 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:38 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:38 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:38 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:38 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:38 --> Total execution time: 0.0980
DEBUG - 2014-07-15 06:27:38 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:38 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:38 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:38 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:38 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:38 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:38 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:38 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:38 --> Total execution time: 0.0938
DEBUG - 2014-07-15 06:27:38 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:38 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:38 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:38 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:38 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:38 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:38 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:38 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:38 --> Total execution time: 0.0926
DEBUG - 2014-07-15 06:27:38 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:38 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:38 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:38 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:39 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:39 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:39 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:39 --> Total execution time: 0.0906
DEBUG - 2014-07-15 06:27:39 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:39 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:39 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:39 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:39 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:39 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:39 --> Total execution time: 0.0881
DEBUG - 2014-07-15 06:27:39 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:39 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:39 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:39 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:39 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:39 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:39 --> Total execution time: 0.1191
DEBUG - 2014-07-15 06:27:39 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:39 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:39 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:39 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:39 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:39 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:39 --> Total execution time: 0.1120
DEBUG - 2014-07-15 06:27:39 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:39 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:39 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:39 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:39 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:39 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:39 --> Total execution time: 0.1013
DEBUG - 2014-07-15 06:27:39 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:39 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:39 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:39 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:39 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:39 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:39 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:39 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:39 --> Total execution time: 0.0885
DEBUG - 2014-07-15 06:27:40 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:40 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:40 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:40 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:40 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:40 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:40 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:40 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:40 --> Total execution time: 0.1410
DEBUG - 2014-07-15 06:27:40 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:40 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:40 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:40 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:40 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:40 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:40 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:40 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:40 --> Total execution time: 0.0961
DEBUG - 2014-07-15 06:27:40 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:40 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:40 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:40 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:40 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:40 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:40 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:40 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:40 --> Total execution time: 0.0901
DEBUG - 2014-07-15 06:27:40 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:40 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:40 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:40 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:40 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:40 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:40 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:40 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:40 --> Total execution time: 0.1189
DEBUG - 2014-07-15 06:27:40 --> Config Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:27:40 --> URI Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Router Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Output Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Security Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Input Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:27:40 --> Language Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Loader Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:27:40 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:27:40 --> Session routines successfully run
DEBUG - 2014-07-15 06:27:40 --> Upload Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Controller Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:27:40 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Model Class Initialized
DEBUG - 2014-07-15 06:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:27:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:27:40 --> Final output sent to browser
DEBUG - 2014-07-15 06:27:40 --> Total execution time: 0.0893
DEBUG - 2014-07-15 06:29:52 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:52 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:52 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:52 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:52 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:52 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:52 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:52 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:52 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:52 --> Total execution time: 0.0879
DEBUG - 2014-07-15 06:29:54 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:54 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:54 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:54 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:54 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:54 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:54 --> Total execution time: 0.0798
DEBUG - 2014-07-15 06:29:54 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:54 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:54 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:54 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:54 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:54 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:54 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:54 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:54 --> Total execution time: 0.1002
DEBUG - 2014-07-15 06:29:54 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:54 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:54 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:54 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:55 --> Total execution time: 0.0927
DEBUG - 2014-07-15 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:55 --> Total execution time: 0.1125
DEBUG - 2014-07-15 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:55 --> Total execution time: 0.0818
DEBUG - 2014-07-15 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:55 --> Total execution time: 0.1118
DEBUG - 2014-07-15 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:55 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:55 --> Total execution time: 0.0884
DEBUG - 2014-07-15 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:56 --> Total execution time: 0.0869
DEBUG - 2014-07-15 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:56 --> Total execution time: 0.0969
DEBUG - 2014-07-15 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:56 --> Total execution time: 0.1205
DEBUG - 2014-07-15 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:56 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:56 --> Total execution time: 0.0834
DEBUG - 2014-07-15 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:57 --> Total execution time: 0.1519
DEBUG - 2014-07-15 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:57 --> Total execution time: 0.0920
DEBUG - 2014-07-15 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:57 --> Total execution time: 0.0985
DEBUG - 2014-07-15 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:57 --> Total execution time: 0.0898
DEBUG - 2014-07-15 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:57 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:57 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:57 --> Total execution time: 0.0900
DEBUG - 2014-07-15 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Router Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Output Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Security Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Input Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:29:58 --> Language Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Loader Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:29:58 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:29:58 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Session Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:29:58 --> Session routines successfully run
DEBUG - 2014-07-15 06:29:58 --> Upload Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Controller Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:29:58 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Model Class Initialized
DEBUG - 2014-07-15 06:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:29:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:29:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:29:58 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:29:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:29:58 --> Final output sent to browser
DEBUG - 2014-07-15 06:29:58 --> Total execution time: 0.0967
DEBUG - 2014-07-15 06:39:26 --> Config Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:39:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:39:26 --> URI Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Router Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Output Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Security Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Input Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:39:26 --> Language Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Loader Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:39:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:39:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Session Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:39:26 --> Session routines successfully run
DEBUG - 2014-07-15 06:39:26 --> Upload Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Controller Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:39:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Model Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Model Class Initialized
DEBUG - 2014-07-15 06:39:26 --> Model Class Initialized
DEBUG - 2014-07-15 06:39:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:39:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:39:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:39:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:39:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:39:27 --> Final output sent to browser
DEBUG - 2014-07-15 06:39:27 --> Total execution time: 0.0966
DEBUG - 2014-07-15 06:40:24 --> Config Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:40:24 --> URI Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Router Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Output Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Security Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Input Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:40:24 --> Language Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Loader Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:40:24 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:40:24 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Session Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:40:24 --> Session routines successfully run
DEBUG - 2014-07-15 06:40:24 --> Upload Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Controller Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:40:24 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Model Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Model Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Model Class Initialized
DEBUG - 2014-07-15 06:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:40:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:40:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:40:24 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:40:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:40:24 --> Final output sent to browser
DEBUG - 2014-07-15 06:40:24 --> Total execution time: 0.0869
DEBUG - 2014-07-15 06:44:49 --> Config Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:44:49 --> URI Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Router Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Output Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Security Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Input Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:44:49 --> Language Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Loader Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:44:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Session Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:44:49 --> Session routines successfully run
DEBUG - 2014-07-15 06:44:49 --> Upload Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Controller Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:44:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Model Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Model Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Model Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:44:49 --> Config Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Hooks Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Utf8 Class Initialized
DEBUG - 2014-07-15 06:44:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 06:44:49 --> URI Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Router Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Output Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Security Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Input Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 06:44:49 --> Language Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Loader Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: url_helper
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: file_helper
DEBUG - 2014-07-15 06:44:49 --> Database Driver Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Session Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: string_helper
DEBUG - 2014-07-15 06:44:49 --> Session routines successfully run
DEBUG - 2014-07-15 06:44:49 --> Upload Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Pagination Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Controller Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Helper loaded: form_helper
DEBUG - 2014-07-15 06:44:49 --> Form Validation Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Model Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Model Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Model Class Initialized
DEBUG - 2014-07-15 06:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 06:44:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 06:44:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 06:44:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 06:44:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 06:44:49 --> Final output sent to browser
DEBUG - 2014-07-15 06:44:49 --> Total execution time: 0.0921
DEBUG - 2014-07-15 07:05:55 --> Config Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Hooks Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Utf8 Class Initialized
DEBUG - 2014-07-15 07:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 07:05:55 --> URI Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Router Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Output Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Security Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Input Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 07:05:55 --> Language Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Loader Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Helper loaded: url_helper
DEBUG - 2014-07-15 07:05:55 --> Helper loaded: file_helper
DEBUG - 2014-07-15 07:05:55 --> Database Driver Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Session Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Helper loaded: string_helper
DEBUG - 2014-07-15 07:05:55 --> Session routines successfully run
DEBUG - 2014-07-15 07:05:55 --> Upload Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Pagination Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Controller Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Helper loaded: form_helper
DEBUG - 2014-07-15 07:05:55 --> Form Validation Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Model Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Model Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Model Class Initialized
DEBUG - 2014-07-15 07:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 07:05:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 07:05:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 07:05:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 07:05:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 07:05:55 --> Final output sent to browser
DEBUG - 2014-07-15 07:05:55 --> Total execution time: 0.0868
DEBUG - 2014-07-15 07:20:14 --> Config Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Hooks Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Utf8 Class Initialized
DEBUG - 2014-07-15 07:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 07:20:14 --> URI Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Router Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Output Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Security Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Input Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 07:20:14 --> Language Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Loader Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Helper loaded: url_helper
DEBUG - 2014-07-15 07:20:14 --> Helper loaded: file_helper
DEBUG - 2014-07-15 07:20:14 --> Database Driver Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Session Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Helper loaded: string_helper
DEBUG - 2014-07-15 07:20:14 --> Session routines successfully run
DEBUG - 2014-07-15 07:20:14 --> Upload Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Pagination Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Controller Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Helper loaded: form_helper
DEBUG - 2014-07-15 07:20:14 --> Form Validation Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 07:20:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 07:20:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 07:20:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 07:20:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 07:20:14 --> Final output sent to browser
DEBUG - 2014-07-15 07:20:14 --> Total execution time: 0.0988
DEBUG - 2014-07-15 07:20:22 --> Config Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 07:20:22 --> URI Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Router Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Output Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Security Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Input Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 07:20:22 --> Language Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Loader Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 07:20:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 07:20:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Session Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 07:20:22 --> Session routines successfully run
DEBUG - 2014-07-15 07:20:22 --> Upload Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Controller Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Helper loaded: form_helper
DEBUG - 2014-07-15 07:20:22 --> Form Validation Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 07:20:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 07:20:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 07:20:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 07:20:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 07:20:22 --> Final output sent to browser
DEBUG - 2014-07-15 07:20:22 --> Total execution time: 0.0865
DEBUG - 2014-07-15 07:20:47 --> Config Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Hooks Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Utf8 Class Initialized
DEBUG - 2014-07-15 07:20:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 07:20:47 --> URI Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Router Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Output Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Security Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Input Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 07:20:47 --> Language Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Loader Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: url_helper
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: file_helper
DEBUG - 2014-07-15 07:20:47 --> Database Driver Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Session Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: string_helper
DEBUG - 2014-07-15 07:20:47 --> Session routines successfully run
DEBUG - 2014-07-15 07:20:47 --> Upload Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Pagination Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Controller Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: form_helper
DEBUG - 2014-07-15 07:20:47 --> Form Validation Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 07:20:47 --> Config Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Hooks Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Utf8 Class Initialized
DEBUG - 2014-07-15 07:20:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 07:20:47 --> URI Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Router Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Output Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Security Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Input Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 07:20:47 --> Language Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Loader Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: url_helper
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: file_helper
DEBUG - 2014-07-15 07:20:47 --> Database Driver Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Session Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: string_helper
DEBUG - 2014-07-15 07:20:47 --> Session routines successfully run
DEBUG - 2014-07-15 07:20:47 --> Upload Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Pagination Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Controller Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Helper loaded: form_helper
DEBUG - 2014-07-15 07:20:47 --> Form Validation Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Model Class Initialized
DEBUG - 2014-07-15 07:20:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 07:20:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 07:20:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 07:20:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 07:20:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 07:20:47 --> Final output sent to browser
DEBUG - 2014-07-15 07:20:47 --> Total execution time: 0.0980
DEBUG - 2014-07-15 07:21:58 --> Config Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Hooks Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Utf8 Class Initialized
DEBUG - 2014-07-15 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 07:21:58 --> URI Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Router Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Output Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Security Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Input Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 07:21:58 --> Language Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Loader Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Helper loaded: url_helper
DEBUG - 2014-07-15 07:21:58 --> Helper loaded: file_helper
DEBUG - 2014-07-15 07:21:58 --> Database Driver Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Session Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Helper loaded: string_helper
DEBUG - 2014-07-15 07:21:58 --> Session routines successfully run
DEBUG - 2014-07-15 07:21:58 --> Upload Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Pagination Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Controller Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Helper loaded: form_helper
DEBUG - 2014-07-15 07:21:58 --> Form Validation Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Model Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Model Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Model Class Initialized
DEBUG - 2014-07-15 07:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 07:21:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 07:21:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 07:21:58 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 07:21:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 07:21:58 --> Final output sent to browser
DEBUG - 2014-07-15 07:21:58 --> Total execution time: 0.0896
DEBUG - 2014-07-15 10:08:58 --> Config Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Hooks Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Utf8 Class Initialized
DEBUG - 2014-07-15 10:08:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 10:08:58 --> URI Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Router Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Output Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Security Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Input Class Initialized
DEBUG - 2014-07-15 10:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 10:08:58 --> Language Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Loader Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Helper loaded: url_helper
DEBUG - 2014-07-15 10:08:59 --> Helper loaded: file_helper
DEBUG - 2014-07-15 10:08:59 --> Database Driver Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Session Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Helper loaded: string_helper
DEBUG - 2014-07-15 10:08:59 --> A session cookie was not found.
DEBUG - 2014-07-15 10:08:59 --> Session routines successfully run
DEBUG - 2014-07-15 10:08:59 --> Upload Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Pagination Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Controller Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Helper loaded: form_helper
DEBUG - 2014-07-15 10:08:59 --> Form Validation Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Model Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Model Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Model Class Initialized
DEBUG - 2014-07-15 10:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 10:08:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 10:08:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 10:08:59 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-15 10:08:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 10:08:59 --> Final output sent to browser
DEBUG - 2014-07-15 10:08:59 --> Total execution time: 0.1541
DEBUG - 2014-07-15 10:19:24 --> Config Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Hooks Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Utf8 Class Initialized
DEBUG - 2014-07-15 10:19:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 10:19:24 --> URI Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Router Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Output Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Security Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Input Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 10:19:24 --> Language Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Loader Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Helper loaded: url_helper
DEBUG - 2014-07-15 10:19:24 --> Helper loaded: file_helper
DEBUG - 2014-07-15 10:19:24 --> Database Driver Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Session Class Initialized
DEBUG - 2014-07-15 10:19:24 --> Helper loaded: string_helper
DEBUG - 2014-07-15 10:19:25 --> Session routines successfully run
DEBUG - 2014-07-15 10:19:25 --> Upload Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Pagination Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Controller Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Helper loaded: form_helper
DEBUG - 2014-07-15 10:19:25 --> Form Validation Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Model Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Model Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Model Class Initialized
DEBUG - 2014-07-15 10:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 10:19:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 10:19:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 10:19:25 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 10:19:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 10:19:25 --> Final output sent to browser
DEBUG - 2014-07-15 10:19:25 --> Total execution time: 0.0997
DEBUG - 2014-07-15 10:32:35 --> Config Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Hooks Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Utf8 Class Initialized
DEBUG - 2014-07-15 10:32:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 10:32:35 --> URI Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Router Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Output Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Security Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Input Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 10:32:35 --> Language Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Loader Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Helper loaded: url_helper
DEBUG - 2014-07-15 10:32:35 --> Helper loaded: file_helper
DEBUG - 2014-07-15 10:32:35 --> Database Driver Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Session Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Helper loaded: string_helper
DEBUG - 2014-07-15 10:32:35 --> Session routines successfully run
DEBUG - 2014-07-15 10:32:35 --> Upload Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Pagination Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Controller Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Helper loaded: form_helper
DEBUG - 2014-07-15 10:32:35 --> Form Validation Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Model Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Model Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Model Class Initialized
DEBUG - 2014-07-15 10:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 10:32:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 10:32:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 10:32:35 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 10:32:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 10:32:35 --> Final output sent to browser
DEBUG - 2014-07-15 10:32:35 --> Total execution time: 0.1000
DEBUG - 2014-07-15 10:33:51 --> Config Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Hooks Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Utf8 Class Initialized
DEBUG - 2014-07-15 10:33:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 10:33:51 --> URI Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Router Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Output Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Security Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Input Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 10:33:51 --> Language Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Loader Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Helper loaded: url_helper
DEBUG - 2014-07-15 10:33:51 --> Helper loaded: file_helper
DEBUG - 2014-07-15 10:33:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Session Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 10:33:51 --> Session routines successfully run
DEBUG - 2014-07-15 10:33:51 --> Upload Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Controller Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 10:33:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Model Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Model Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Model Class Initialized
DEBUG - 2014-07-15 10:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 10:33:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 10:33:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 10:33:51 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 10:33:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 10:33:51 --> Final output sent to browser
DEBUG - 2014-07-15 10:33:51 --> Total execution time: 0.0946
DEBUG - 2014-07-15 10:34:15 --> Config Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Hooks Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Utf8 Class Initialized
DEBUG - 2014-07-15 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 10:34:15 --> URI Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Router Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Output Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Security Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Input Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 10:34:15 --> Language Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Loader Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Helper loaded: url_helper
DEBUG - 2014-07-15 10:34:15 --> Helper loaded: file_helper
DEBUG - 2014-07-15 10:34:15 --> Database Driver Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Session Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Helper loaded: string_helper
DEBUG - 2014-07-15 10:34:15 --> Session routines successfully run
DEBUG - 2014-07-15 10:34:15 --> Upload Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Pagination Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Controller Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Helper loaded: form_helper
DEBUG - 2014-07-15 10:34:15 --> Form Validation Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Model Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Model Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Model Class Initialized
DEBUG - 2014-07-15 10:34:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 10:34:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 10:34:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 10:34:15 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 10:34:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 10:34:15 --> Final output sent to browser
DEBUG - 2014-07-15 10:34:15 --> Total execution time: 0.0799
DEBUG - 2014-07-15 10:37:50 --> Config Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Hooks Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Utf8 Class Initialized
DEBUG - 2014-07-15 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 10:37:50 --> URI Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Router Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Output Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Security Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Input Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 10:37:50 --> Language Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Loader Class Initialized
DEBUG - 2014-07-15 10:37:50 --> Helper loaded: url_helper
DEBUG - 2014-07-15 10:37:50 --> Helper loaded: file_helper
DEBUG - 2014-07-15 10:37:51 --> Database Driver Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Session Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Helper loaded: string_helper
DEBUG - 2014-07-15 10:37:51 --> Session routines successfully run
DEBUG - 2014-07-15 10:37:51 --> Upload Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Pagination Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Controller Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Helper loaded: form_helper
DEBUG - 2014-07-15 10:37:51 --> Form Validation Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Model Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Model Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Model Class Initialized
DEBUG - 2014-07-15 10:37:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 10:37:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 10:37:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 10:37:51 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 10:37:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 10:37:51 --> Final output sent to browser
DEBUG - 2014-07-15 10:37:51 --> Total execution time: 0.1164
DEBUG - 2014-07-15 12:55:43 --> Config Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:55:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:55:43 --> URI Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Router Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Output Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Security Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Input Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:55:43 --> Language Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Loader Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:55:43 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:55:43 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Session Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:55:43 --> A session cookie was not found.
DEBUG - 2014-07-15 12:55:43 --> Session routines successfully run
DEBUG - 2014-07-15 12:55:43 --> Upload Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Controller Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Helper loaded: form_helper
DEBUG - 2014-07-15 12:55:43 --> Form Validation Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Model Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Model Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Model Class Initialized
DEBUG - 2014-07-15 12:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:55:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 12:55:43 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-15 12:55:43 --> Severity: Notice  --> Undefined variable: error F:\wamp\www\hostorks\application\views\superadmin\footer_manage.php 5
ERROR - 2014-07-15 12:55:43 --> Severity: Notice  --> Undefined variable: upload_data F:\wamp\www\hostorks\application\views\superadmin\footer_manage.php 14
DEBUG - 2014-07-15 12:55:43 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 12:55:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 12:55:43 --> Final output sent to browser
DEBUG - 2014-07-15 12:55:43 --> Total execution time: 0.1168
DEBUG - 2014-07-15 12:56:26 --> Config Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:56:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:56:26 --> URI Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Router Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Output Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Security Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Input Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:56:26 --> Language Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Loader Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:56:26 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:56:26 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Session Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:56:26 --> Session routines successfully run
DEBUG - 2014-07-15 12:56:26 --> Upload Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Controller Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Helper loaded: form_helper
DEBUG - 2014-07-15 12:56:26 --> Form Validation Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Model Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Model Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Model Class Initialized
DEBUG - 2014-07-15 12:56:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:56:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 12:56:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 12:56:26 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 12:56:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 12:56:26 --> Final output sent to browser
DEBUG - 2014-07-15 12:56:26 --> Total execution time: 0.0970
DEBUG - 2014-07-15 12:56:38 --> Config Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:56:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:56:38 --> URI Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Router Class Initialized
DEBUG - 2014-07-15 12:56:38 --> No URI present. Default controller set.
DEBUG - 2014-07-15 12:56:38 --> Output Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Security Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Input Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:56:38 --> Language Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Loader Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:56:38 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:56:38 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Session Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:56:38 --> Session routines successfully run
DEBUG - 2014-07-15 12:56:38 --> Upload Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:56:38 --> Controller Class Initialized
DEBUG - 2014-07-15 12:56:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-15 12:56:38 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-15 12:56:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-15 12:56:38 --> Final output sent to browser
DEBUG - 2014-07-15 12:56:38 --> Total execution time: 0.0818
DEBUG - 2014-07-15 12:57:14 --> Config Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:57:14 --> URI Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Router Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Output Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Security Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Input Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:57:14 --> Language Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Loader Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:57:14 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:57:14 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Session Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:57:14 --> Session routines successfully run
DEBUG - 2014-07-15 12:57:14 --> Upload Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Controller Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Helper loaded: form_helper
DEBUG - 2014-07-15 12:57:14 --> Form Validation Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Model Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Model Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Model Class Initialized
DEBUG - 2014-07-15 12:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:57:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 12:57:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 12:57:14 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 12:57:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 12:57:14 --> Final output sent to browser
DEBUG - 2014-07-15 12:57:14 --> Total execution time: 0.1202
DEBUG - 2014-07-15 12:57:22 --> Config Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:57:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:57:22 --> URI Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Router Class Initialized
DEBUG - 2014-07-15 12:57:22 --> No URI present. Default controller set.
DEBUG - 2014-07-15 12:57:22 --> Output Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Security Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Input Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:57:22 --> Language Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Loader Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:57:22 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:57:22 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Session Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:57:22 --> Session routines successfully run
DEBUG - 2014-07-15 12:57:22 --> Upload Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:57:22 --> Controller Class Initialized
DEBUG - 2014-07-15 12:57:22 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-15 12:57:22 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-15 12:57:22 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-15 12:57:22 --> Final output sent to browser
DEBUG - 2014-07-15 12:57:22 --> Total execution time: 0.0886
DEBUG - 2014-07-15 12:58:01 --> Config Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:58:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:58:01 --> URI Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Router Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Output Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Security Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Input Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:58:01 --> Language Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Loader Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:58:01 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:58:01 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Session Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:58:01 --> Session routines successfully run
DEBUG - 2014-07-15 12:58:01 --> Upload Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Controller Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Helper loaded: form_helper
DEBUG - 2014-07-15 12:58:01 --> Form Validation Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:58:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 12:58:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 12:58:01 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 12:58:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 12:58:01 --> Final output sent to browser
DEBUG - 2014-07-15 12:58:01 --> Total execution time: 0.0799
DEBUG - 2014-07-15 12:58:34 --> Config Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:58:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:58:34 --> URI Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Router Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Output Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Security Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Input Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:58:34 --> Language Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Loader Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:58:34 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:58:34 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Session Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:58:34 --> Session routines successfully run
DEBUG - 2014-07-15 12:58:34 --> Upload Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Controller Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Helper loaded: form_helper
DEBUG - 2014-07-15 12:58:34 --> Form Validation Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:58:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-15 12:58:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-15 12:58:34 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-15 12:58:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-15 12:58:34 --> Final output sent to browser
DEBUG - 2014-07-15 12:58:34 --> Total execution time: 0.0885
DEBUG - 2014-07-15 12:58:42 --> Config Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Hooks Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Utf8 Class Initialized
DEBUG - 2014-07-15 12:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-15 12:58:42 --> URI Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Router Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Output Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Security Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Input Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-15 12:58:42 --> Language Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Loader Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Helper loaded: url_helper
DEBUG - 2014-07-15 12:58:42 --> Helper loaded: file_helper
DEBUG - 2014-07-15 12:58:42 --> Database Driver Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Session Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Helper loaded: string_helper
DEBUG - 2014-07-15 12:58:42 --> Session routines successfully run
DEBUG - 2014-07-15 12:58:42 --> Upload Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Pagination Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Controller Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Helper loaded: form_helper
DEBUG - 2014-07-15 12:58:42 --> Form Validation Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Model Class Initialized
DEBUG - 2014-07-15 12:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:58:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-15 12:58:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-15 12:58:42 --> You did not select a file to upload.

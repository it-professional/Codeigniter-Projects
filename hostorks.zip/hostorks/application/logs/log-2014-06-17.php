<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-17 02:06:36 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:36 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:36 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:36 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:36 --> Router Class Initialized
ERROR - 2014-06-17 02:06:36 --> 404 Page Not Found --> admin
DEBUG - 2014-06-17 02:06:39 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:39 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Router Class Initialized
ERROR - 2014-06-17 02:06:39 --> 404 Page Not Found --> admin
DEBUG - 2014-06-17 02:06:39 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:39 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Router Class Initialized
ERROR - 2014-06-17 02:06:39 --> 404 Page Not Found --> admin
DEBUG - 2014-06-17 02:06:39 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:39 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Router Class Initialized
ERROR - 2014-06-17 02:06:39 --> 404 Page Not Found --> admin
DEBUG - 2014-06-17 02:06:39 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:39 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:39 --> Router Class Initialized
ERROR - 2014-06-17 02:06:39 --> 404 Page Not Found --> admin
DEBUG - 2014-06-17 02:06:40 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:40 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:40 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:40 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:40 --> Router Class Initialized
ERROR - 2014-06-17 02:06:40 --> 404 Page Not Found --> admin
DEBUG - 2014-06-17 02:06:40 --> Config Class Initialized
DEBUG - 2014-06-17 02:06:40 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:06:40 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:06:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:06:40 --> URI Class Initialized
DEBUG - 2014-06-17 02:06:40 --> Router Class Initialized
ERROR - 2014-06-17 02:06:40 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:07:02 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:07:04 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:07:04 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:07:04 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:07:04 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:08:22 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:08:30 --> 404 Page Not Found --> superadmin/index
ERROR - 2014-06-17 02:09:00 --> 404 Page Not Found --> superadmin/index
ERROR - 2014-06-17 02:11:44 --> 404 Page Not Found --> 
ERROR - 2014-06-17 02:17:06 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:18:08 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:18:21 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:18:33 --> 404 Page Not Found --> admin
ERROR - 2014-06-17 02:23:10 --> 404 Page Not Found --> superadmin/index
ERROR - 2014-06-17 02:23:13 --> 404 Page Not Found --> superadmin/index
ERROR - 2014-06-17 02:23:13 --> 404 Page Not Found --> superadmin/index
ERROR - 2014-06-17 02:23:14 --> 404 Page Not Found --> superadmin/index
ERROR - 2014-06-17 02:23:14 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:40 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:40 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:40 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:40 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:40 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:40 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:40 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:42 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:42 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:42 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:42 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:42 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:42 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:42 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:42 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:42 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:42 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:42 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:42 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:42 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:42 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:42 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:42 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:42 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:42 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:42 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:42 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:42 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:42 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:42 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:42 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:42 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:43 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:43 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:43 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:43 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:43 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:43 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:43 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:43 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:43 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:43 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:43 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:43 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:43 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:52 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:52 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:52 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:52 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:52 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:52 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:52 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:53 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:53 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:53 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:53 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:53 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:53 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:53 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:54 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:54 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:54 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:54 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:54 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:54 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:54 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:54 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:54 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Controller Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Upload Class Initialized
ERROR - 2014-06-17 02:23:54 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:54 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:54 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:23:54 --> Config Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:23:54 --> URI Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Router Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Output Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Security Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Input Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:23:54 --> Language Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Loader Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Session Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:23:54 --> Session routines successfully run
DEBUG - 2014-06-17 02:23:54 --> Upload Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:23:54 --> Controller Class Initialized
ERROR - 2014-06-17 02:23:54 --> 404 Page Not Found --> superadmin/index
DEBUG - 2014-06-17 02:28:45 --> Config Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:28:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:28:45 --> URI Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Router Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Output Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Security Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Input Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:28:45 --> Language Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Loader Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Session Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:28:45 --> Session routines successfully run
DEBUG - 2014-06-17 02:28:45 --> Upload Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:28:45 --> Controller Class Initialized
DEBUG - 2014-06-17 02:28:45 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:28:45 --> Final output sent to browser
DEBUG - 2014-06-17 02:28:45 --> Total execution time: 0.1274
DEBUG - 2014-06-17 02:29:00 --> Config Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:29:00 --> URI Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Router Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Output Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Security Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Input Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:29:00 --> Language Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Loader Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Session Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:29:00 --> Session routines successfully run
DEBUG - 2014-06-17 02:29:00 --> Upload Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:29:00 --> Controller Class Initialized
ERROR - 2014-06-17 02:29:00 --> 404 Page Not Found --> superadmin/abc
DEBUG - 2014-06-17 02:29:08 --> Config Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:29:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:29:08 --> URI Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Router Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Output Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Security Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Input Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:29:08 --> Language Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Loader Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Session Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:29:08 --> Session routines successfully run
DEBUG - 2014-06-17 02:29:08 --> Upload Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:29:08 --> Controller Class Initialized
DEBUG - 2014-06-17 02:29:08 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:29:08 --> Final output sent to browser
DEBUG - 2014-06-17 02:29:08 --> Total execution time: 0.1123
DEBUG - 2014-06-17 02:29:58 --> Config Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:29:58 --> URI Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Router Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Output Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Security Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Input Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:29:58 --> Language Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Loader Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Session Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:29:58 --> Session routines successfully run
DEBUG - 2014-06-17 02:29:58 --> Upload Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:29:58 --> Controller Class Initialized
DEBUG - 2014-06-17 02:29:58 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:29:58 --> Final output sent to browser
DEBUG - 2014-06-17 02:29:58 --> Total execution time: 0.1002
DEBUG - 2014-06-17 02:30:00 --> Config Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:30:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:30:00 --> URI Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Router Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Output Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Security Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Input Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:30:00 --> Language Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Loader Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Session Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:30:00 --> Session routines successfully run
DEBUG - 2014-06-17 02:30:00 --> Upload Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:30:00 --> Controller Class Initialized
DEBUG - 2014-06-17 02:30:00 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:30:00 --> Final output sent to browser
DEBUG - 2014-06-17 02:30:00 --> Total execution time: 0.1283
DEBUG - 2014-06-17 02:30:01 --> Config Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:30:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:30:01 --> URI Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Router Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Output Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Security Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Input Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:30:01 --> Language Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Loader Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Session Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:30:01 --> Session routines successfully run
DEBUG - 2014-06-17 02:30:01 --> Upload Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Controller Class Initialized
DEBUG - 2014-06-17 02:30:01 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:30:01 --> Final output sent to browser
DEBUG - 2014-06-17 02:30:01 --> Total execution time: 0.1122
DEBUG - 2014-06-17 02:30:01 --> Config Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:30:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:30:01 --> URI Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Router Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Output Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Security Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Input Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:30:01 --> Language Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Loader Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Session Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:30:01 --> Session routines successfully run
DEBUG - 2014-06-17 02:30:01 --> Upload Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:30:01 --> Controller Class Initialized
DEBUG - 2014-06-17 02:30:01 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:30:01 --> Final output sent to browser
DEBUG - 2014-06-17 02:30:01 --> Total execution time: 0.1189
DEBUG - 2014-06-17 02:31:59 --> Config Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:31:59 --> URI Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Router Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Output Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Security Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Input Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:31:59 --> Language Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Loader Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Session Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:31:59 --> Session routines successfully run
DEBUG - 2014-06-17 02:31:59 --> Upload Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:31:59 --> Controller Class Initialized
DEBUG - 2014-06-17 02:31:59 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:31:59 --> Final output sent to browser
DEBUG - 2014-06-17 02:31:59 --> Total execution time: 0.1160
DEBUG - 2014-06-17 02:32:03 --> Config Class Initialized
DEBUG - 2014-06-17 02:32:03 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:32:03 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:32:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:32:03 --> URI Class Initialized
DEBUG - 2014-06-17 02:32:03 --> Router Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Output Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Security Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Input Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:32:04 --> Language Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Loader Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Session Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:32:04 --> Session routines successfully run
DEBUG - 2014-06-17 02:32:04 --> Upload Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:32:04 --> Controller Class Initialized
DEBUG - 2014-06-17 02:32:04 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:32:04 --> Final output sent to browser
DEBUG - 2014-06-17 02:32:04 --> Total execution time: 0.1001
DEBUG - 2014-06-17 02:46:44 --> Config Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:46:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:46:44 --> URI Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Router Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Output Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Security Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Input Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:46:44 --> Language Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Loader Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Session Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:46:44 --> Session routines successfully run
DEBUG - 2014-06-17 02:46:44 --> Upload Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Controller Class Initialized
DEBUG - 2014-06-17 02:46:44 --> Helper loaded: form_helper
DEBUG - 2014-06-17 02:46:44 --> Form Validation Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Config Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:47:02 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:47:02 --> URI Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Router Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Output Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Security Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Input Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:47:02 --> Language Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Loader Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Session Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:47:02 --> Session routines successfully run
DEBUG - 2014-06-17 02:47:02 --> Upload Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Controller Class Initialized
DEBUG - 2014-06-17 02:47:02 --> Helper loaded: form_helper
DEBUG - 2014-06-17 02:47:02 --> Form Validation Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Config Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Hooks Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Utf8 Class Initialized
DEBUG - 2014-06-17 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 02:50:48 --> URI Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Router Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Output Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Security Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Input Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 02:50:48 --> Language Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Loader Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Helper loaded: url_helper
DEBUG - 2014-06-17 02:50:48 --> Helper loaded: file_helper
DEBUG - 2014-06-17 02:50:48 --> Database Driver Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Session Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Helper loaded: string_helper
DEBUG - 2014-06-17 02:50:48 --> Session routines successfully run
DEBUG - 2014-06-17 02:50:48 --> Upload Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Pagination Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Controller Class Initialized
DEBUG - 2014-06-17 02:50:48 --> Helper loaded: form_helper
DEBUG - 2014-06-17 02:50:48 --> Form Validation Class Initialized
DEBUG - 2014-06-17 02:50:48 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 02:50:48 --> Final output sent to browser
DEBUG - 2014-06-17 02:50:48 --> Total execution time: 0.1486
DEBUG - 2014-06-17 03:13:39 --> Config Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Hooks Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Utf8 Class Initialized
DEBUG - 2014-06-17 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 03:13:39 --> URI Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Router Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Output Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Security Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Input Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 03:13:39 --> Language Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Loader Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Helper loaded: url_helper
DEBUG - 2014-06-17 03:13:39 --> Helper loaded: file_helper
DEBUG - 2014-06-17 03:13:39 --> Database Driver Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Session Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Helper loaded: string_helper
DEBUG - 2014-06-17 03:13:39 --> Session routines successfully run
DEBUG - 2014-06-17 03:13:39 --> Upload Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Pagination Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Controller Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Helper loaded: form_helper
DEBUG - 2014-06-17 03:13:39 --> Form Validation Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Model Class Initialized
DEBUG - 2014-06-17 03:13:39 --> Model Class Initialized
DEBUG - 2014-06-17 03:13:39 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 03:13:39 --> Final output sent to browser
DEBUG - 2014-06-17 03:13:39 --> Total execution time: 0.1859
DEBUG - 2014-06-17 03:13:47 --> Config Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Hooks Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Utf8 Class Initialized
DEBUG - 2014-06-17 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 03:13:47 --> URI Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Router Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Output Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Security Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Input Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 03:13:47 --> Language Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Loader Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Helper loaded: url_helper
DEBUG - 2014-06-17 03:13:47 --> Helper loaded: file_helper
DEBUG - 2014-06-17 03:13:47 --> Database Driver Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Session Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Helper loaded: string_helper
DEBUG - 2014-06-17 03:13:47 --> Session routines successfully run
DEBUG - 2014-06-17 03:13:47 --> Upload Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Pagination Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Controller Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Helper loaded: form_helper
DEBUG - 2014-06-17 03:13:47 --> Form Validation Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Model Class Initialized
DEBUG - 2014-06-17 03:13:47 --> Model Class Initialized
DEBUG - 2014-06-17 03:13:47 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 03:13:47 --> Final output sent to browser
DEBUG - 2014-06-17 03:13:47 --> Total execution time: 0.1310
DEBUG - 2014-06-17 03:14:25 --> Config Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Hooks Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Utf8 Class Initialized
DEBUG - 2014-06-17 03:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 03:14:25 --> URI Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Router Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Output Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Security Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Input Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 03:14:25 --> Language Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Loader Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Helper loaded: url_helper
DEBUG - 2014-06-17 03:14:25 --> Helper loaded: file_helper
DEBUG - 2014-06-17 03:14:25 --> Database Driver Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Session Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Helper loaded: string_helper
DEBUG - 2014-06-17 03:14:25 --> Session routines successfully run
DEBUG - 2014-06-17 03:14:25 --> Upload Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Pagination Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Controller Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Helper loaded: form_helper
DEBUG - 2014-06-17 03:14:25 --> Form Validation Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Model Class Initialized
DEBUG - 2014-06-17 03:14:25 --> Model Class Initialized
DEBUG - 2014-06-17 03:14:25 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 03:14:25 --> Final output sent to browser
DEBUG - 2014-06-17 03:14:25 --> Total execution time: 0.1321
DEBUG - 2014-06-17 06:26:14 --> Config Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Hooks Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Utf8 Class Initialized
DEBUG - 2014-06-17 06:26:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 06:26:14 --> URI Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Router Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Output Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Security Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Input Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 06:26:14 --> Language Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Loader Class Initialized
DEBUG - 2014-06-17 06:26:14 --> Helper loaded: url_helper
DEBUG - 2014-06-17 06:26:14 --> Helper loaded: file_helper
DEBUG - 2014-06-17 06:26:14 --> Database Driver Class Initialized
ERROR - 2014-06-17 06:26:14 --> Unable to select database: hostorks
DEBUG - 2014-06-17 06:26:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-17 06:26:37 --> Config Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Hooks Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Utf8 Class Initialized
DEBUG - 2014-06-17 06:26:37 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 06:26:37 --> URI Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Router Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Output Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Security Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Input Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 06:26:37 --> Language Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Loader Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Helper loaded: url_helper
DEBUG - 2014-06-17 06:26:37 --> Helper loaded: file_helper
DEBUG - 2014-06-17 06:26:37 --> Database Driver Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Session Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Helper loaded: string_helper
DEBUG - 2014-06-17 06:26:37 --> A session cookie was not found.
DEBUG - 2014-06-17 06:26:37 --> Session routines successfully run
DEBUG - 2014-06-17 06:26:37 --> Upload Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Pagination Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Controller Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Helper loaded: form_helper
DEBUG - 2014-06-17 06:26:37 --> Form Validation Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Model Class Initialized
DEBUG - 2014-06-17 06:26:37 --> Model Class Initialized
DEBUG - 2014-06-17 06:26:37 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 06:26:37 --> Final output sent to browser
DEBUG - 2014-06-17 06:26:37 --> Total execution time: 0.0808
DEBUG - 2014-06-17 07:21:25 --> Config Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:21:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:21:25 --> URI Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Router Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Output Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Security Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Input Class Initialized
DEBUG - 2014-06-17 07:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:21:25 --> Language Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Loader Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:21:26 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:21:26 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Session Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:21:26 --> Session routines successfully run
DEBUG - 2014-06-17 07:21:26 --> Upload Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Controller Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:21:26 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Model Class Initialized
DEBUG - 2014-06-17 07:21:26 --> Model Class Initialized
DEBUG - 2014-06-17 07:21:26 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:21:26 --> Final output sent to browser
DEBUG - 2014-06-17 07:21:26 --> Total execution time: 0.0667
DEBUG - 2014-06-17 07:21:33 --> Config Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:21:33 --> URI Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Router Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Output Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Security Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Input Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:21:33 --> Language Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Loader Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:21:33 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:21:33 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Session Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:21:33 --> Session routines successfully run
DEBUG - 2014-06-17 07:21:33 --> Upload Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Controller Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:21:33 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Model Class Initialized
DEBUG - 2014-06-17 07:21:33 --> Model Class Initialized
DEBUG - 2014-06-17 07:21:33 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:21:33 --> Final output sent to browser
DEBUG - 2014-06-17 07:21:33 --> Total execution time: 0.0675
DEBUG - 2014-06-17 07:23:27 --> Config Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:23:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:23:27 --> URI Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Router Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Output Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Security Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Input Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:23:27 --> Language Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Loader Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:23:27 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:23:27 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Session Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:23:27 --> Session routines successfully run
DEBUG - 2014-06-17 07:23:27 --> Upload Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Controller Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:23:27 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Model Class Initialized
DEBUG - 2014-06-17 07:23:27 --> Model Class Initialized
DEBUG - 2014-06-17 07:23:27 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:23:27 --> Final output sent to browser
DEBUG - 2014-06-17 07:23:27 --> Total execution time: 0.0741
DEBUG - 2014-06-17 07:23:30 --> Config Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:23:30 --> URI Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Router Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Output Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Security Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Input Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:23:30 --> Language Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Loader Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:23:30 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:23:30 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Session Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:23:30 --> Session routines successfully run
DEBUG - 2014-06-17 07:23:30 --> Upload Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Controller Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:23:30 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Model Class Initialized
DEBUG - 2014-06-17 07:23:30 --> Model Class Initialized
DEBUG - 2014-06-17 07:23:30 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:23:30 --> Final output sent to browser
DEBUG - 2014-06-17 07:23:30 --> Total execution time: 0.0835
DEBUG - 2014-06-17 07:24:07 --> Config Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:24:07 --> URI Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Router Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Output Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Security Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Input Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:24:07 --> Language Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Loader Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:24:07 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:24:07 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Session Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:24:07 --> Session routines successfully run
DEBUG - 2014-06-17 07:24:07 --> Upload Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Controller Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:24:07 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Model Class Initialized
DEBUG - 2014-06-17 07:24:07 --> Model Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Config Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:24:56 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:24:56 --> URI Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Router Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Output Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Security Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Input Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:24:56 --> Language Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Loader Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:24:56 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:24:56 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Session Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:24:56 --> Session routines successfully run
DEBUG - 2014-06-17 07:24:56 --> Upload Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Controller Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:24:56 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Model Class Initialized
DEBUG - 2014-06-17 07:24:56 --> Model Class Initialized
DEBUG - 2014-06-17 07:24:56 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:24:56 --> Final output sent to browser
DEBUG - 2014-06-17 07:24:56 --> Total execution time: 0.0716
DEBUG - 2014-06-17 07:24:59 --> Config Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:24:59 --> URI Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Router Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Output Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Security Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Input Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:24:59 --> Language Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Loader Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:24:59 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:24:59 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Session Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:24:59 --> Session routines successfully run
DEBUG - 2014-06-17 07:24:59 --> Upload Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:24:59 --> Controller Class Initialized
ERROR - 2014-06-17 07:24:59 --> 404 Page Not Found --> 
DEBUG - 2014-06-17 07:25:20 --> Config Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:25:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:25:20 --> URI Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Router Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Output Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Security Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Input Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:25:20 --> Language Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Loader Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:25:20 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:25:20 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Session Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:25:20 --> Session routines successfully run
DEBUG - 2014-06-17 07:25:20 --> Upload Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Controller Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:25:20 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:25:20 --> XSS Filtering completed
DEBUG - 2014-06-17 07:25:30 --> Config Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:25:30 --> URI Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Router Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Output Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Security Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Input Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:25:30 --> Language Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Loader Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:25:30 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:25:30 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Session Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:25:30 --> Session routines successfully run
DEBUG - 2014-06-17 07:25:30 --> Upload Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Controller Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:25:30 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:30 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:30 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:25:30 --> Final output sent to browser
DEBUG - 2014-06-17 07:25:30 --> Total execution time: 0.0739
DEBUG - 2014-06-17 07:25:32 --> Config Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:25:32 --> URI Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Router Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Output Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Security Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Input Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:25:32 --> Language Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Loader Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:25:32 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:25:32 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Session Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:25:32 --> Session routines successfully run
DEBUG - 2014-06-17 07:25:32 --> Upload Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Controller Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:25:32 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:25:32 --> XSS Filtering completed
DEBUG - 2014-06-17 07:25:45 --> Config Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:25:45 --> URI Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Router Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Output Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Security Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Input Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:25:45 --> Language Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Loader Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:25:45 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:25:45 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Session Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:25:45 --> Session routines successfully run
DEBUG - 2014-06-17 07:25:45 --> Upload Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Controller Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:25:45 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:25:45 --> XSS Filtering completed
DEBUG - 2014-06-17 07:25:47 --> Config Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:25:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:25:47 --> URI Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Router Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Output Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Security Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Input Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:25:47 --> Language Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Loader Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:25:47 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:25:47 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Session Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:25:47 --> Session routines successfully run
DEBUG - 2014-06-17 07:25:47 --> Upload Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Controller Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:25:47 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:25:47 --> XSS Filtering completed
DEBUG - 2014-06-17 07:25:51 --> Config Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:25:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:25:51 --> URI Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Router Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Output Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Security Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Input Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:25:51 --> Language Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Loader Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:25:51 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:25:51 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Session Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:25:51 --> Session routines successfully run
DEBUG - 2014-06-17 07:25:51 --> Upload Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Controller Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:25:51 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:51 --> Model Class Initialized
DEBUG - 2014-06-17 07:25:51 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:25:51 --> Final output sent to browser
DEBUG - 2014-06-17 07:25:51 --> Total execution time: 0.0604
DEBUG - 2014-06-17 07:26:11 --> Config Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:26:11 --> URI Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Router Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Output Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Security Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Input Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:26:11 --> Language Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Loader Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:26:11 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:26:11 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Session Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:26:11 --> Session routines successfully run
DEBUG - 2014-06-17 07:26:11 --> Upload Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Controller Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:26:11 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Model Class Initialized
DEBUG - 2014-06-17 07:26:11 --> Model Class Initialized
DEBUG - 2014-06-17 07:26:11 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:26:11 --> Final output sent to browser
DEBUG - 2014-06-17 07:26:11 --> Total execution time: 0.0655
DEBUG - 2014-06-17 07:26:19 --> Config Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:26:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:26:19 --> URI Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Router Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Output Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Security Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Input Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:26:19 --> Language Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Loader Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:26:19 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:26:19 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Session Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:26:19 --> Session routines successfully run
DEBUG - 2014-06-17 07:26:19 --> Upload Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Controller Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:26:19 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Model Class Initialized
DEBUG - 2014-06-17 07:26:19 --> Model Class Initialized
DEBUG - 2014-06-17 07:26:19 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:26:19 --> Final output sent to browser
DEBUG - 2014-06-17 07:26:19 --> Total execution time: 0.0743
DEBUG - 2014-06-17 07:26:24 --> Config Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:26:24 --> URI Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Router Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Output Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Security Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Input Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:26:24 --> Language Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Loader Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:26:24 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:26:24 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Session Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:26:24 --> Session routines successfully run
DEBUG - 2014-06-17 07:26:24 --> Upload Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Controller Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:26:24 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Model Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Model Class Initialized
DEBUG - 2014-06-17 07:26:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:26:24 --> XSS Filtering completed
DEBUG - 2014-06-17 07:27:21 --> Config Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:27:21 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:27:21 --> URI Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Router Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Output Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Security Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Input Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:27:21 --> Language Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Loader Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:27:21 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:27:21 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Session Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:27:21 --> Session routines successfully run
DEBUG - 2014-06-17 07:27:21 --> Upload Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Controller Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:27:21 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Model Class Initialized
DEBUG - 2014-06-17 07:27:21 --> Model Class Initialized
DEBUG - 2014-06-17 07:27:21 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:27:21 --> Final output sent to browser
DEBUG - 2014-06-17 07:27:21 --> Total execution time: 0.0829
DEBUG - 2014-06-17 07:28:08 --> Config Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:28:08 --> URI Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Router Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Output Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Security Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Input Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:28:08 --> Language Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Loader Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:28:08 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:28:08 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Session Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:28:08 --> Session routines successfully run
DEBUG - 2014-06-17 07:28:08 --> Upload Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Controller Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:28:08 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Model Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Model Class Initialized
DEBUG - 2014-06-17 07:28:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:28:08 --> XSS Filtering completed
DEBUG - 2014-06-17 07:28:32 --> Config Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:28:32 --> URI Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Router Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Output Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Security Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Input Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:28:32 --> Language Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Loader Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:28:32 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:28:32 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Session Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:28:32 --> Session routines successfully run
DEBUG - 2014-06-17 07:28:32 --> Upload Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Controller Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:28:32 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Model Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Model Class Initialized
DEBUG - 2014-06-17 07:28:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:28:32 --> XSS Filtering completed
DEBUG - 2014-06-17 07:28:32 --> XSS Filtering completed
DEBUG - 2014-06-17 07:28:51 --> Config Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:28:51 --> URI Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Router Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Output Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Security Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Input Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:28:51 --> Language Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Loader Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:28:51 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:28:51 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Session Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:28:51 --> Session routines successfully run
DEBUG - 2014-06-17 07:28:51 --> Upload Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Controller Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:28:51 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Model Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Model Class Initialized
DEBUG - 2014-06-17 07:28:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:28:51 --> XSS Filtering completed
DEBUG - 2014-06-17 07:28:51 --> XSS Filtering completed
DEBUG - 2014-06-17 07:29:48 --> Config Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:29:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:29:48 --> URI Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Router Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Output Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Security Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Input Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:29:48 --> Language Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Loader Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:29:48 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:29:48 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Session Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:29:48 --> Session routines successfully run
DEBUG - 2014-06-17 07:29:48 --> Upload Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Controller Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:29:48 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Model Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Model Class Initialized
DEBUG - 2014-06-17 07:29:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:29:48 --> XSS Filtering completed
DEBUG - 2014-06-17 07:29:48 --> XSS Filtering completed
DEBUG - 2014-06-17 07:30:22 --> Config Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:30:22 --> URI Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Router Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Output Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Security Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Input Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:30:22 --> Language Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Loader Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:30:22 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:30:22 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Session Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:30:22 --> Session routines successfully run
DEBUG - 2014-06-17 07:30:22 --> Upload Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Controller Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:30:22 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Model Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Model Class Initialized
DEBUG - 2014-06-17 07:30:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:30:22 --> XSS Filtering completed
DEBUG - 2014-06-17 07:32:07 --> Config Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:32:07 --> URI Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Router Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Output Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Security Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Input Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:32:07 --> Language Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Loader Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:32:07 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:32:07 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Session Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:32:07 --> Session routines successfully run
DEBUG - 2014-06-17 07:32:07 --> Upload Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:32:07 --> Controller Class Initialized
DEBUG - 2014-06-17 07:32:08 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:32:08 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:32:08 --> Model Class Initialized
DEBUG - 2014-06-17 07:32:08 --> Model Class Initialized
DEBUG - 2014-06-17 07:32:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:32:08 --> XSS Filtering completed
DEBUG - 2014-06-17 07:33:00 --> Config Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:33:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:33:00 --> URI Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Router Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Output Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Security Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Input Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:33:00 --> Language Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Loader Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:33:00 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:33:00 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Session Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:33:00 --> Session routines successfully run
DEBUG - 2014-06-17 07:33:00 --> Upload Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Controller Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:33:00 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:00 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:00 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:33:00 --> Final output sent to browser
DEBUG - 2014-06-17 07:33:00 --> Total execution time: 0.0658
DEBUG - 2014-06-17 07:33:07 --> Config Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:33:07 --> URI Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Router Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Output Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Security Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Input Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:33:07 --> Language Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Loader Class Initialized
DEBUG - 2014-06-17 07:33:07 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:33:07 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:33:08 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Session Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:33:08 --> Session routines successfully run
DEBUG - 2014-06-17 07:33:08 --> Upload Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Controller Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:33:08 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:33:08 --> XSS Filtering completed
DEBUG - 2014-06-17 07:33:19 --> Config Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:33:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:33:19 --> URI Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Router Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Output Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Security Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Input Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:33:19 --> Language Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Loader Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:33:19 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:33:19 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Session Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:33:19 --> Session routines successfully run
DEBUG - 2014-06-17 07:33:19 --> Upload Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Controller Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:33:19 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:19 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:19 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:33:19 --> Final output sent to browser
DEBUG - 2014-06-17 07:33:19 --> Total execution time: 0.0791
DEBUG - 2014-06-17 07:33:34 --> Config Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:33:34 --> URI Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Router Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Output Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Security Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Input Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:33:34 --> Language Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Loader Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:33:34 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Session Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:33:34 --> Session routines successfully run
DEBUG - 2014-06-17 07:33:34 --> Upload Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Controller Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:33:34 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Model Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 07:33:34 --> XSS Filtering completed
DEBUG - 2014-06-17 07:33:34 --> Config Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:33:34 --> URI Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Router Class Initialized
DEBUG - 2014-06-17 07:33:34 --> No URI present. Default controller set.
DEBUG - 2014-06-17 07:33:34 --> Output Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Security Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Input Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:33:34 --> Language Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Loader Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:33:34 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Session Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:33:34 --> Session routines successfully run
DEBUG - 2014-06-17 07:33:34 --> Upload Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:33:34 --> Controller Class Initialized
DEBUG - 2014-06-17 07:33:34 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-17 07:33:34 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-17 07:33:34 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-17 07:33:34 --> Final output sent to browser
DEBUG - 2014-06-17 07:33:34 --> Total execution time: 0.0866
DEBUG - 2014-06-17 07:35:15 --> Config Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:35:15 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:35:15 --> URI Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Router Class Initialized
DEBUG - 2014-06-17 07:35:15 --> No URI present. Default controller set.
DEBUG - 2014-06-17 07:35:15 --> Output Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Security Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Input Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:35:15 --> Language Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Loader Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:35:15 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:35:15 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Session Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:35:15 --> Session routines successfully run
DEBUG - 2014-06-17 07:35:15 --> Upload Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:35:15 --> Controller Class Initialized
DEBUG - 2014-06-17 07:35:15 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-17 07:35:16 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-17 07:35:16 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-17 07:35:16 --> Final output sent to browser
DEBUG - 2014-06-17 07:35:16 --> Total execution time: 0.0774
DEBUG - 2014-06-17 07:37:55 --> Config Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:37:55 --> URI Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Router Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Output Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Security Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Input Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:37:55 --> Language Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Loader Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:37:55 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:37:55 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Session Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:37:55 --> Session routines successfully run
DEBUG - 2014-06-17 07:37:55 --> Upload Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Controller Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:37:55 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Model Class Initialized
DEBUG - 2014-06-17 07:37:55 --> Model Class Initialized
DEBUG - 2014-06-17 07:37:55 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:37:55 --> Final output sent to browser
DEBUG - 2014-06-17 07:37:55 --> Total execution time: 0.0790
DEBUG - 2014-06-17 07:37:57 --> Config Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:37:57 --> URI Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Router Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Output Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Security Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Input Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:37:57 --> Language Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Loader Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:37:57 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:37:57 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Session Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:37:57 --> Session routines successfully run
DEBUG - 2014-06-17 07:37:57 --> Upload Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Controller Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:37:57 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Model Class Initialized
DEBUG - 2014-06-17 07:37:57 --> Model Class Initialized
DEBUG - 2014-06-17 07:37:57 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:37:57 --> Final output sent to browser
DEBUG - 2014-06-17 07:37:57 --> Total execution time: 0.0745
DEBUG - 2014-06-17 07:45:31 --> Config Class Initialized
DEBUG - 2014-06-17 07:45:31 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:45:31 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:45:31 --> URI Class Initialized
DEBUG - 2014-06-17 07:45:31 --> Router Class Initialized
DEBUG - 2014-06-17 07:45:31 --> Output Class Initialized
DEBUG - 2014-06-17 07:45:31 --> Security Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Input Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:45:32 --> Language Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Loader Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:45:32 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:45:32 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Session Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:45:32 --> Session routines successfully run
DEBUG - 2014-06-17 07:45:32 --> Upload Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Controller Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:45:32 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Model Class Initialized
DEBUG - 2014-06-17 07:45:32 --> Model Class Initialized
DEBUG - 2014-06-17 07:45:32 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:45:32 --> Final output sent to browser
DEBUG - 2014-06-17 07:45:32 --> Total execution time: 0.0808
DEBUG - 2014-06-17 07:46:25 --> Config Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:46:25 --> URI Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Router Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Output Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Security Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Input Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:46:25 --> Language Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Loader Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:46:25 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:46:25 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Session Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:46:25 --> Session routines successfully run
DEBUG - 2014-06-17 07:46:25 --> Upload Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Controller Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:46:25 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Model Class Initialized
DEBUG - 2014-06-17 07:46:25 --> Model Class Initialized
DEBUG - 2014-06-17 07:46:25 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:46:25 --> Final output sent to browser
DEBUG - 2014-06-17 07:46:25 --> Total execution time: 0.0665
DEBUG - 2014-06-17 07:49:48 --> Config Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:49:48 --> URI Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Router Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Output Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Security Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Input Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:49:48 --> Language Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Loader Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:49:48 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:49:48 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Session Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:49:48 --> Session routines successfully run
DEBUG - 2014-06-17 07:49:48 --> Upload Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Controller Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:49:48 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Model Class Initialized
DEBUG - 2014-06-17 07:49:48 --> Model Class Initialized
DEBUG - 2014-06-17 07:49:48 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:49:48 --> Final output sent to browser
DEBUG - 2014-06-17 07:49:48 --> Total execution time: 0.0789
DEBUG - 2014-06-17 07:50:00 --> Config Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:50:00 --> URI Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Router Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Output Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Security Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Input Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:50:00 --> Language Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Loader Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:50:00 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:50:00 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Session Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:50:00 --> Session routines successfully run
DEBUG - 2014-06-17 07:50:00 --> Upload Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Controller Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:50:00 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Model Class Initialized
DEBUG - 2014-06-17 07:50:00 --> Model Class Initialized
DEBUG - 2014-06-17 07:50:00 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:50:00 --> Final output sent to browser
DEBUG - 2014-06-17 07:50:00 --> Total execution time: 0.0666
DEBUG - 2014-06-17 07:51:49 --> Config Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:51:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:51:49 --> URI Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Router Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Output Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Security Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Input Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:51:49 --> Language Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Loader Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:51:49 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:51:49 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Session Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:51:49 --> Session routines successfully run
DEBUG - 2014-06-17 07:51:49 --> Upload Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Controller Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:51:49 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Model Class Initialized
DEBUG - 2014-06-17 07:51:49 --> Model Class Initialized
DEBUG - 2014-06-17 07:51:49 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:51:49 --> Final output sent to browser
DEBUG - 2014-06-17 07:51:49 --> Total execution time: 0.0742
DEBUG - 2014-06-17 07:51:58 --> Config Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Hooks Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Utf8 Class Initialized
DEBUG - 2014-06-17 07:51:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 07:51:58 --> URI Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Router Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Output Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Security Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Input Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 07:51:58 --> Language Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Loader Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Helper loaded: url_helper
DEBUG - 2014-06-17 07:51:58 --> Helper loaded: file_helper
DEBUG - 2014-06-17 07:51:58 --> Database Driver Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Session Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Helper loaded: string_helper
DEBUG - 2014-06-17 07:51:58 --> Session routines successfully run
DEBUG - 2014-06-17 07:51:58 --> Upload Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Pagination Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Controller Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Helper loaded: form_helper
DEBUG - 2014-06-17 07:51:58 --> Form Validation Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Model Class Initialized
DEBUG - 2014-06-17 07:51:58 --> Model Class Initialized
DEBUG - 2014-06-17 07:51:58 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 07:51:58 --> Final output sent to browser
DEBUG - 2014-06-17 07:51:58 --> Total execution time: 0.0690
DEBUG - 2014-06-17 08:18:04 --> Config Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:18:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:18:04 --> URI Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Router Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Output Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Security Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Input Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:18:04 --> Language Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Loader Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:18:04 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:18:04 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Session Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:18:04 --> Session routines successfully run
DEBUG - 2014-06-17 08:18:04 --> Upload Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Controller Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:18:04 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Model Class Initialized
DEBUG - 2014-06-17 08:18:04 --> Model Class Initialized
DEBUG - 2014-06-17 08:18:04 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:18:04 --> Final output sent to browser
DEBUG - 2014-06-17 08:18:04 --> Total execution time: 0.0833
DEBUG - 2014-06-17 08:20:34 --> Config Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:20:34 --> URI Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Router Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Output Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Security Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Input Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:20:34 --> Language Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Loader Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:20:34 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:20:34 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Session Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:20:34 --> Session routines successfully run
DEBUG - 2014-06-17 08:20:34 --> Upload Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Controller Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:20:34 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:34 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:34 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:20:34 --> Final output sent to browser
DEBUG - 2014-06-17 08:20:34 --> Total execution time: 0.0791
DEBUG - 2014-06-17 08:20:42 --> Config Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:20:42 --> URI Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Router Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Output Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Security Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Input Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:20:42 --> Language Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Loader Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:20:42 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:20:42 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Session Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:20:42 --> Session routines successfully run
DEBUG - 2014-06-17 08:20:42 --> Upload Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Controller Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:20:42 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 08:20:42 --> XSS Filtering completed
DEBUG - 2014-06-17 08:20:42 --> Final output sent to browser
DEBUG - 2014-06-17 08:20:42 --> Total execution time: 0.0919
DEBUG - 2014-06-17 08:20:50 --> Config Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:20:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:20:50 --> URI Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Router Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Output Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Security Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Input Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:20:50 --> Language Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Loader Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:20:50 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:20:50 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Session Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:20:50 --> Session routines successfully run
DEBUG - 2014-06-17 08:20:50 --> Upload Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Controller Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:20:50 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:50 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:50 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:20:50 --> Final output sent to browser
DEBUG - 2014-06-17 08:20:50 --> Total execution time: 0.0733
DEBUG - 2014-06-17 08:20:54 --> Config Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:20:54 --> URI Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Router Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Output Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Security Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Input Class Initialized
DEBUG - 2014-06-17 08:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:20:54 --> Language Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Loader Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:20:55 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:20:55 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Session Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:20:55 --> Session routines successfully run
DEBUG - 2014-06-17 08:20:55 --> Upload Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Controller Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:20:55 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:55 --> Model Class Initialized
DEBUG - 2014-06-17 08:20:55 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:20:55 --> Final output sent to browser
DEBUG - 2014-06-17 08:20:55 --> Total execution time: 0.0639
DEBUG - 2014-06-17 08:21:23 --> Config Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:21:23 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:21:23 --> URI Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Router Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Output Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Security Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Input Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:21:23 --> Language Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Loader Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:21:23 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:21:23 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Session Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:21:23 --> Session routines successfully run
DEBUG - 2014-06-17 08:21:23 --> Upload Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Controller Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:21:23 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Model Class Initialized
DEBUG - 2014-06-17 08:21:23 --> Model Class Initialized
DEBUG - 2014-06-17 08:21:23 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:21:23 --> Final output sent to browser
DEBUG - 2014-06-17 08:21:23 --> Total execution time: 0.0681
DEBUG - 2014-06-17 08:21:33 --> Config Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:21:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:21:33 --> URI Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Router Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Output Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Security Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Input Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:21:33 --> Language Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Loader Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:21:33 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:21:33 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Session Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:21:33 --> Session routines successfully run
DEBUG - 2014-06-17 08:21:33 --> Upload Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Controller Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:21:33 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Model Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Model Class Initialized
DEBUG - 2014-06-17 08:21:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 08:21:33 --> XSS Filtering completed
DEBUG - 2014-06-17 08:21:33 --> Final output sent to browser
DEBUG - 2014-06-17 08:21:33 --> Total execution time: 0.1001
DEBUG - 2014-06-17 08:22:02 --> Config Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:22:02 --> URI Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Router Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Output Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Security Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Input Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:22:02 --> Language Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Loader Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:22:02 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:22:02 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Session Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:22:02 --> Session routines successfully run
DEBUG - 2014-06-17 08:22:02 --> Upload Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Controller Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:22:02 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Model Class Initialized
DEBUG - 2014-06-17 08:22:02 --> Model Class Initialized
DEBUG - 2014-06-17 08:22:02 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:22:02 --> Final output sent to browser
DEBUG - 2014-06-17 08:22:02 --> Total execution time: 0.0597
DEBUG - 2014-06-17 08:22:53 --> Config Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:22:53 --> URI Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Router Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Output Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Security Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Input Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:22:53 --> Language Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Loader Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:22:53 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:22:53 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Session Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:22:53 --> Session routines successfully run
DEBUG - 2014-06-17 08:22:53 --> Upload Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Controller Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:22:53 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Model Class Initialized
DEBUG - 2014-06-17 08:22:53 --> Model Class Initialized
DEBUG - 2014-06-17 08:22:53 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 08:22:53 --> Final output sent to browser
DEBUG - 2014-06-17 08:22:53 --> Total execution time: 0.0780
DEBUG - 2014-06-17 08:22:59 --> Config Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Hooks Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Utf8 Class Initialized
DEBUG - 2014-06-17 08:22:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 08:22:59 --> URI Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Router Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Output Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Security Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Input Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 08:22:59 --> Language Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Loader Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Helper loaded: url_helper
DEBUG - 2014-06-17 08:22:59 --> Helper loaded: file_helper
DEBUG - 2014-06-17 08:22:59 --> Database Driver Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Session Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Helper loaded: string_helper
DEBUG - 2014-06-17 08:22:59 --> Session routines successfully run
DEBUG - 2014-06-17 08:22:59 --> Upload Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Pagination Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Controller Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Helper loaded: form_helper
DEBUG - 2014-06-17 08:22:59 --> Form Validation Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Model Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Model Class Initialized
DEBUG - 2014-06-17 08:22:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 08:22:59 --> XSS Filtering completed
DEBUG - 2014-06-17 12:00:31 --> Config Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:00:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:00:31 --> URI Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Router Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Output Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Security Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Input Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:00:31 --> Language Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Loader Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:00:31 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:00:31 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Session Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:00:31 --> A session cookie was not found.
DEBUG - 2014-06-17 12:00:31 --> Session routines successfully run
DEBUG - 2014-06-17 12:00:31 --> Upload Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Controller Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:00:31 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Model Class Initialized
DEBUG - 2014-06-17 12:00:31 --> Model Class Initialized
DEBUG - 2014-06-17 12:00:31 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:00:31 --> Final output sent to browser
DEBUG - 2014-06-17 12:00:31 --> Total execution time: 0.1753
DEBUG - 2014-06-17 12:03:43 --> Config Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:03:43 --> URI Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Router Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Output Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Security Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Input Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:03:43 --> Language Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Loader Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:03:43 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:03:43 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Session Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:03:43 --> Session routines successfully run
DEBUG - 2014-06-17 12:03:43 --> Upload Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Controller Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:03:43 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Model Class Initialized
DEBUG - 2014-06-17 12:03:43 --> Model Class Initialized
DEBUG - 2014-06-17 12:03:43 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:03:43 --> Final output sent to browser
DEBUG - 2014-06-17 12:03:43 --> Total execution time: 0.0993
DEBUG - 2014-06-17 12:03:46 --> Config Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:03:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:03:46 --> URI Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Router Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Output Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Security Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Input Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:03:46 --> Language Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Loader Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:03:46 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:03:46 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Session Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:03:46 --> Session routines successfully run
DEBUG - 2014-06-17 12:03:46 --> Upload Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Controller Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:03:46 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Model Class Initialized
DEBUG - 2014-06-17 12:03:46 --> Model Class Initialized
DEBUG - 2014-06-17 12:03:46 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:03:46 --> Final output sent to browser
DEBUG - 2014-06-17 12:03:46 --> Total execution time: 0.0712
DEBUG - 2014-06-17 12:04:31 --> Config Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:04:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:04:31 --> URI Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Router Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Output Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Security Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Input Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:04:31 --> Language Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Loader Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:04:31 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:04:31 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Session Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:04:31 --> Session routines successfully run
DEBUG - 2014-06-17 12:04:31 --> Upload Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Controller Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:04:31 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Model Class Initialized
DEBUG - 2014-06-17 12:04:31 --> Model Class Initialized
DEBUG - 2014-06-17 12:04:31 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:04:31 --> Final output sent to browser
DEBUG - 2014-06-17 12:04:31 --> Total execution time: 0.0805
DEBUG - 2014-06-17 12:04:34 --> Config Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:04:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:04:34 --> URI Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Router Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Output Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Security Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Input Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:04:34 --> Language Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Loader Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:04:34 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:04:34 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Session Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:04:34 --> Session routines successfully run
DEBUG - 2014-06-17 12:04:34 --> Upload Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Controller Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:04:34 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Model Class Initialized
DEBUG - 2014-06-17 12:04:34 --> Model Class Initialized
DEBUG - 2014-06-17 12:04:34 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:04:34 --> Final output sent to browser
DEBUG - 2014-06-17 12:04:34 --> Total execution time: 0.0750
DEBUG - 2014-06-17 12:04:41 --> Config Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:04:41 --> URI Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Router Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Output Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Security Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Input Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:04:41 --> Language Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Loader Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:04:41 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:04:41 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Session Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:04:41 --> Session routines successfully run
DEBUG - 2014-06-17 12:04:41 --> Upload Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Controller Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:04:41 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Model Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Model Class Initialized
DEBUG - 2014-06-17 12:04:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 12:04:41 --> XSS Filtering completed
DEBUG - 2014-06-17 12:04:41 --> Final output sent to browser
DEBUG - 2014-06-17 12:04:41 --> Total execution time: 0.1381
DEBUG - 2014-06-17 12:07:27 --> Config Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:07:27 --> URI Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Router Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Output Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Security Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Input Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:07:27 --> Language Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Loader Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:07:27 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:07:27 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Session Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:07:27 --> Session routines successfully run
DEBUG - 2014-06-17 12:07:27 --> Upload Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Controller Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:07:27 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Model Class Initialized
DEBUG - 2014-06-17 12:07:27 --> Model Class Initialized
DEBUG - 2014-06-17 12:07:27 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:07:27 --> Final output sent to browser
DEBUG - 2014-06-17 12:07:27 --> Total execution time: 0.0659
DEBUG - 2014-06-17 12:07:33 --> Config Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Hooks Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Utf8 Class Initialized
DEBUG - 2014-06-17 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 12:07:33 --> URI Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Router Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Output Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Security Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Input Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 12:07:33 --> Language Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Loader Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Helper loaded: url_helper
DEBUG - 2014-06-17 12:07:33 --> Helper loaded: file_helper
DEBUG - 2014-06-17 12:07:33 --> Database Driver Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Session Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Helper loaded: string_helper
DEBUG - 2014-06-17 12:07:33 --> Session routines successfully run
DEBUG - 2014-06-17 12:07:33 --> Upload Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Pagination Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Controller Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Helper loaded: form_helper
DEBUG - 2014-06-17 12:07:33 --> Form Validation Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Model Class Initialized
DEBUG - 2014-06-17 12:07:33 --> Model Class Initialized
DEBUG - 2014-06-17 12:07:33 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 12:07:33 --> Final output sent to browser
DEBUG - 2014-06-17 12:07:33 --> Total execution time: 0.0992
DEBUG - 2014-06-17 14:15:07 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:07 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:07 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:07 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:07 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:07 --> A session cookie was not found.
DEBUG - 2014-06-17 14:15:07 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:07 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:07 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:07 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:07 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:07 --> Total execution time: 0.0881
DEBUG - 2014-06-17 14:15:11 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:11 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:11 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:11 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:11 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:11 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:11 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:11 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:11 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:11 --> Total execution time: 0.0655
DEBUG - 2014-06-17 14:15:11 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:11 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:11 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:11 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:11 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:11 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:11 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:11 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:11 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:11 --> Total execution time: 0.0689
DEBUG - 2014-06-17 14:15:12 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:12 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:12 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:12 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:12 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:12 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:12 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:12 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:12 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:12 --> Total execution time: 0.0866
DEBUG - 2014-06-17 14:15:12 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:12 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:12 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:12 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:12 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:12 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:12 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:12 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:12 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:12 --> Total execution time: 0.0727
DEBUG - 2014-06-17 14:15:12 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:12 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:12 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:12 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:12 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:12 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:12 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:12 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:12 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:12 --> Total execution time: 0.0865
DEBUG - 2014-06-17 14:15:12 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:12 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:12 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:12 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:12 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:12 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:12 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:12 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:12 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:12 --> Total execution time: 0.0717
DEBUG - 2014-06-17 14:15:12 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:12 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:12 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:12 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:12 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:12 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:12 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:12 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:12 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:12 --> Total execution time: 0.0887
DEBUG - 2014-06-17 14:15:13 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:13 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:13 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:13 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:13 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:13 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:13 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:13 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:13 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:13 --> Total execution time: 0.0881
DEBUG - 2014-06-17 14:15:13 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:13 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:13 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:13 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:13 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:13 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:13 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:13 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:13 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:13 --> Total execution time: 0.0749
DEBUG - 2014-06-17 14:15:13 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:13 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:13 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:13 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:13 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:13 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:13 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:13 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:13 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:13 --> Total execution time: 0.0847
DEBUG - 2014-06-17 14:15:13 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:13 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:13 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:13 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:13 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:13 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:13 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:13 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:13 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:13 --> Total execution time: 0.0715
DEBUG - 2014-06-17 14:15:14 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:14 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:14 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:14 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:14 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:14 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:14 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:14 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:14 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:15:14 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:14 --> Total execution time: 0.0761
DEBUG - 2014-06-17 14:15:17 --> Config Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:15:17 --> URI Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Router Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Output Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Security Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Input Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:15:17 --> Language Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Loader Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:15:17 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:15:17 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Session Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:15:17 --> Session routines successfully run
DEBUG - 2014-06-17 14:15:17 --> Upload Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Controller Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:15:17 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Model Class Initialized
DEBUG - 2014-06-17 14:15:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:15:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 14:15:17 --> XSS Filtering completed
DEBUG - 2014-06-17 14:15:17 --> Final output sent to browser
DEBUG - 2014-06-17 14:15:17 --> Total execution time: 0.0895
DEBUG - 2014-06-17 14:17:38 --> Config Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:17:38 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:17:38 --> URI Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Router Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Output Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Security Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Input Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:17:38 --> Language Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Loader Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:17:38 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:17:38 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Session Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:17:38 --> Session routines successfully run
DEBUG - 2014-06-17 14:17:38 --> Upload Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Controller Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:17:38 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Model Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Model Class Initialized
DEBUG - 2014-06-17 14:17:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:17:38 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:17:38 --> Final output sent to browser
DEBUG - 2014-06-17 14:17:38 --> Total execution time: 0.1012
DEBUG - 2014-06-17 14:18:25 --> Config Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:18:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:18:25 --> URI Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Router Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Output Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Security Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Input Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:18:25 --> Language Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Loader Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:18:25 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:18:25 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Session Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:18:25 --> Session routines successfully run
DEBUG - 2014-06-17 14:18:25 --> Upload Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Controller Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:18:25 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Model Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Model Class Initialized
DEBUG - 2014-06-17 14:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:18:25 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:18:25 --> Final output sent to browser
DEBUG - 2014-06-17 14:18:25 --> Total execution time: 0.0826
DEBUG - 2014-06-17 14:18:44 --> Config Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:18:44 --> URI Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Router Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Output Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Security Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Input Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:18:44 --> Language Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Loader Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:18:44 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:18:44 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Session Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:18:44 --> Session routines successfully run
DEBUG - 2014-06-17 14:18:44 --> Upload Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Controller Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:18:44 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Model Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Model Class Initialized
DEBUG - 2014-06-17 14:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:18:44 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:18:44 --> Final output sent to browser
DEBUG - 2014-06-17 14:18:44 --> Total execution time: 0.0672
DEBUG - 2014-06-17 14:44:29 --> Config Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:44:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:44:29 --> URI Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Router Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Output Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Security Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Input Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:44:29 --> Language Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Loader Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:44:29 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:44:29 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:44:29 --> Session Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Config Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:44:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:44:43 --> URI Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Router Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Output Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Security Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Input Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:44:43 --> Language Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Loader Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:44:43 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:44:43 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Session Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:44:43 --> Session routines successfully run
DEBUG - 2014-06-17 14:44:43 --> Upload Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Controller Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:44:43 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Model Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Model Class Initialized
DEBUG - 2014-06-17 14:44:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:44:43 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:44:43 --> Final output sent to browser
DEBUG - 2014-06-17 14:44:43 --> Total execution time: 0.0757
DEBUG - 2014-06-17 14:47:00 --> Config Class Initialized
DEBUG - 2014-06-17 14:47:00 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:47:00 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:47:00 --> URI Class Initialized
DEBUG - 2014-06-17 14:47:00 --> Router Class Initialized
DEBUG - 2014-06-17 14:47:00 --> Output Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Security Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Input Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:47:01 --> Language Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Loader Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:47:01 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:47:01 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Session Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:47:01 --> Session routines successfully run
DEBUG - 2014-06-17 14:47:01 --> Upload Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Controller Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:47:01 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Model Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Model Class Initialized
DEBUG - 2014-06-17 14:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:47:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 14:47:01 --> XSS Filtering completed
DEBUG - 2014-06-17 14:47:01 --> Final output sent to browser
DEBUG - 2014-06-17 14:47:01 --> Total execution time: 0.0898
DEBUG - 2014-06-17 14:47:07 --> Config Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:47:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:47:07 --> URI Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Router Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Output Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Security Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Input Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:47:07 --> Language Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Loader Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:47:07 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:47:07 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Session Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:47:07 --> Session routines successfully run
DEBUG - 2014-06-17 14:47:07 --> Upload Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Controller Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:47:07 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Model Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Model Class Initialized
DEBUG - 2014-06-17 14:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:47:07 --> Final output sent to browser
DEBUG - 2014-06-17 14:47:07 --> Total execution time: 0.0926
DEBUG - 2014-06-17 14:50:04 --> Config Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:50:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:50:04 --> URI Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Router Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Output Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Security Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Input Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:50:04 --> Language Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Loader Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:50:04 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:50:04 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Session Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:50:04 --> Session routines successfully run
DEBUG - 2014-06-17 14:50:04 --> Upload Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Controller Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:50:04 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Model Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Model Class Initialized
DEBUG - 2014-06-17 14:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:50:04 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:50:04 --> Final output sent to browser
DEBUG - 2014-06-17 14:50:04 --> Total execution time: 0.0883
DEBUG - 2014-06-17 14:50:11 --> Config Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:50:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:50:11 --> URI Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Router Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Output Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Security Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Input Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:50:11 --> Language Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Loader Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:50:11 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Session Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:50:11 --> Session routines successfully run
DEBUG - 2014-06-17 14:50:11 --> Upload Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Controller Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:50:11 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Model Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Model Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:50:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 14:50:11 --> XSS Filtering completed
DEBUG - 2014-06-17 14:50:11 --> Config Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:50:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:50:11 --> URI Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Router Class Initialized
DEBUG - 2014-06-17 14:50:11 --> No URI present. Default controller set.
DEBUG - 2014-06-17 14:50:11 --> Output Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Security Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Input Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:50:11 --> Language Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Loader Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:50:11 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Session Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:50:11 --> Session routines successfully run
DEBUG - 2014-06-17 14:50:11 --> Upload Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:50:11 --> Controller Class Initialized
DEBUG - 2014-06-17 14:50:11 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-17 14:50:11 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-17 14:50:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-17 14:50:11 --> Final output sent to browser
DEBUG - 2014-06-17 14:50:11 --> Total execution time: 0.0718
DEBUG - 2014-06-17 14:51:55 --> Config Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:51:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:51:55 --> URI Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Router Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Output Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Security Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Input Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:51:55 --> Language Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Loader Class Initialized
DEBUG - 2014-06-17 14:51:55 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:51:55 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:51:56 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Session Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:51:56 --> Session routines successfully run
DEBUG - 2014-06-17 14:51:56 --> Upload Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Controller Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:51:56 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Model Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Model Class Initialized
DEBUG - 2014-06-17 14:51:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:51:56 --> Final output sent to browser
DEBUG - 2014-06-17 14:51:56 --> Total execution time: 0.0880
DEBUG - 2014-06-17 14:52:35 --> Config Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:52:35 --> URI Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Router Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Output Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Security Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Input Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:52:35 --> Language Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Loader Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:52:35 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:52:35 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Session Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:52:35 --> Session routines successfully run
DEBUG - 2014-06-17 14:52:35 --> Upload Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Controller Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:52:35 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Model Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Model Class Initialized
DEBUG - 2014-06-17 14:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:52:35 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:52:35 --> Final output sent to browser
DEBUG - 2014-06-17 14:52:35 --> Total execution time: 0.1185
DEBUG - 2014-06-17 14:52:37 --> Config Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:52:37 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:52:37 --> URI Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Router Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Output Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Security Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Input Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:52:37 --> Language Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Loader Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:52:37 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:52:37 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Session Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:52:37 --> Session routines successfully run
DEBUG - 2014-06-17 14:52:37 --> Upload Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Controller Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:52:37 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Model Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Model Class Initialized
DEBUG - 2014-06-17 14:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:52:37 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:52:37 --> Final output sent to browser
DEBUG - 2014-06-17 14:52:37 --> Total execution time: 0.0757
DEBUG - 2014-06-17 14:52:42 --> Config Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:52:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:52:42 --> URI Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Router Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Output Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Security Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Input Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:52:42 --> Language Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Loader Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:52:42 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:52:42 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Session Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:52:42 --> Session routines successfully run
DEBUG - 2014-06-17 14:52:42 --> Upload Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Controller Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:52:42 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Model Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Model Class Initialized
DEBUG - 2014-06-17 14:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:52:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 14:52:42 --> XSS Filtering completed
DEBUG - 2014-06-17 14:52:43 --> Config Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:52:43 --> URI Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Router Class Initialized
DEBUG - 2014-06-17 14:52:43 --> No URI present. Default controller set.
DEBUG - 2014-06-17 14:52:43 --> Output Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Security Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Input Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:52:43 --> Language Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Loader Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:52:43 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:52:43 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Session Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:52:43 --> Session routines successfully run
DEBUG - 2014-06-17 14:52:43 --> Upload Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Controller Class Initialized
DEBUG - 2014-06-17 14:52:43 --> Final output sent to browser
DEBUG - 2014-06-17 14:52:43 --> Total execution time: 0.0583
DEBUG - 2014-06-17 14:53:37 --> Config Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:53:37 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:53:37 --> URI Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Router Class Initialized
DEBUG - 2014-06-17 14:53:37 --> No URI present. Default controller set.
DEBUG - 2014-06-17 14:53:37 --> Output Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Security Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Input Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:53:37 --> Language Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Loader Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:53:37 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:53:37 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Session Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:53:37 --> Session routines successfully run
DEBUG - 2014-06-17 14:53:37 --> Upload Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:53:37 --> Controller Class Initialized
DEBUG - 2014-06-17 14:53:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-17 14:53:37 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-17 14:53:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-17 14:53:37 --> Final output sent to browser
DEBUG - 2014-06-17 14:53:37 --> Total execution time: 0.0579
DEBUG - 2014-06-17 14:53:40 --> Config Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:53:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:53:40 --> URI Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Router Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Output Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Security Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Input Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:53:40 --> Language Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Loader Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:53:40 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:53:40 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Session Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:53:40 --> Session routines successfully run
DEBUG - 2014-06-17 14:53:40 --> Upload Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Controller Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:53:40 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Model Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Model Class Initialized
DEBUG - 2014-06-17 14:53:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:53:40 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:53:40 --> Final output sent to browser
DEBUG - 2014-06-17 14:53:40 --> Total execution time: 0.0763
DEBUG - 2014-06-17 14:53:43 --> Config Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:53:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:53:43 --> URI Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Router Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Output Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Security Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Input Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:53:43 --> Language Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Loader Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:53:43 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:53:43 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Session Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:53:43 --> Session routines successfully run
DEBUG - 2014-06-17 14:53:43 --> Upload Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Controller Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:53:43 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Model Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Model Class Initialized
DEBUG - 2014-06-17 14:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:53:43 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:53:43 --> Final output sent to browser
DEBUG - 2014-06-17 14:53:43 --> Total execution time: 0.0850
DEBUG - 2014-06-17 14:53:48 --> Config Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:53:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:53:48 --> URI Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Router Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Output Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Security Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Input Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:53:48 --> Language Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Loader Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:53:48 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Session Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:53:48 --> Session routines successfully run
DEBUG - 2014-06-17 14:53:48 --> Upload Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Controller Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:53:48 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Model Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Model Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:53:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 14:53:48 --> XSS Filtering completed
DEBUG - 2014-06-17 14:53:48 --> Config Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:53:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:53:48 --> URI Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Router Class Initialized
DEBUG - 2014-06-17 14:53:48 --> No URI present. Default controller set.
DEBUG - 2014-06-17 14:53:48 --> Output Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Security Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Input Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:53:48 --> Language Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Loader Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:53:48 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Session Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:53:48 --> Session routines successfully run
DEBUG - 2014-06-17 14:53:48 --> Upload Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:53:48 --> Controller Class Initialized
DEBUG - 2014-06-17 14:53:48 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-17 14:53:48 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-17 14:53:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-17 14:53:48 --> Final output sent to browser
DEBUG - 2014-06-17 14:53:48 --> Total execution time: 0.0754
DEBUG - 2014-06-17 14:54:09 --> Config Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:54:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:54:09 --> URI Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Router Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Output Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Security Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Input Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:54:09 --> Language Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Loader Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:54:09 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:54:09 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Session Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:54:09 --> Session routines successfully run
DEBUG - 2014-06-17 14:54:09 --> Upload Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Controller Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:54:09 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Model Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Model Class Initialized
DEBUG - 2014-06-17 14:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:54:09 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-17 14:54:09 --> Final output sent to browser
DEBUG - 2014-06-17 14:54:09 --> Total execution time: 0.0792
DEBUG - 2014-06-17 14:54:14 --> Config Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:54:14 --> URI Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Router Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Output Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Security Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Input Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:54:14 --> Language Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Loader Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:54:14 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Session Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:54:14 --> Session routines successfully run
DEBUG - 2014-06-17 14:54:14 --> Upload Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Controller Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: form_helper
DEBUG - 2014-06-17 14:54:14 --> Form Validation Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Model Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Model Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-17 14:54:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-17 14:54:14 --> XSS Filtering completed
DEBUG - 2014-06-17 14:54:14 --> Config Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Hooks Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Utf8 Class Initialized
DEBUG - 2014-06-17 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-17 14:54:14 --> URI Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Router Class Initialized
DEBUG - 2014-06-17 14:54:14 --> No URI present. Default controller set.
DEBUG - 2014-06-17 14:54:14 --> Output Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Security Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Input Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-17 14:54:14 --> Language Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Loader Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: url_helper
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: file_helper
DEBUG - 2014-06-17 14:54:14 --> Database Driver Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Session Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Helper loaded: string_helper
DEBUG - 2014-06-17 14:54:14 --> Session routines successfully run
DEBUG - 2014-06-17 14:54:14 --> Upload Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Pagination Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Controller Class Initialized
DEBUG - 2014-06-17 14:54:14 --> Final output sent to browser
DEBUG - 2014-06-17 14:54:14 --> Total execution time: 0.0665

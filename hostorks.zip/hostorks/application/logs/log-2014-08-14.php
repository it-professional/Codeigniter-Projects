<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-14 07:52:32 --> Config Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Hooks Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Utf8 Class Initialized
DEBUG - 2014-08-14 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 07:52:32 --> URI Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Router Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Output Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Security Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Input Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 07:52:32 --> Language Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Loader Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Helper loaded: url_helper
DEBUG - 2014-08-14 07:52:32 --> Helper loaded: file_helper
DEBUG - 2014-08-14 07:52:32 --> Database Driver Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Session Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Helper loaded: string_helper
DEBUG - 2014-08-14 07:52:32 --> A session cookie was not found.
DEBUG - 2014-08-14 07:52:32 --> Session routines successfully run
DEBUG - 2014-08-14 07:52:32 --> Upload Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Pagination Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Controller Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Helper loaded: form_helper
DEBUG - 2014-08-14 07:52:32 --> Form Validation Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 07:52:33 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-14 07:52:33 --> Final output sent to browser
DEBUG - 2014-08-14 07:52:33 --> Total execution time: 0.7814
DEBUG - 2014-08-14 07:52:39 --> Config Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Hooks Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Utf8 Class Initialized
DEBUG - 2014-08-14 07:52:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 07:52:39 --> URI Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Router Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Output Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Security Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Input Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 07:52:39 --> Language Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Loader Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: url_helper
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: file_helper
DEBUG - 2014-08-14 07:52:39 --> Database Driver Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Session Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: string_helper
DEBUG - 2014-08-14 07:52:39 --> Session routines successfully run
DEBUG - 2014-08-14 07:52:39 --> Upload Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Pagination Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Controller Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: form_helper
DEBUG - 2014-08-14 07:52:39 --> Form Validation Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 07:52:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 07:52:39 --> XSS Filtering completed
DEBUG - 2014-08-14 07:52:39 --> Config Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Hooks Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Utf8 Class Initialized
DEBUG - 2014-08-14 07:52:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 07:52:39 --> URI Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Router Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Output Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Security Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Input Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 07:52:39 --> Language Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Loader Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: url_helper
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: file_helper
DEBUG - 2014-08-14 07:52:39 --> Database Driver Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Session Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: string_helper
DEBUG - 2014-08-14 07:52:39 --> Session routines successfully run
DEBUG - 2014-08-14 07:52:39 --> Upload Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Pagination Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Controller Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Helper loaded: form_helper
DEBUG - 2014-08-14 07:52:39 --> Form Validation Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 07:52:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 07:52:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 07:52:40 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-14 07:52:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 07:52:40 --> Final output sent to browser
DEBUG - 2014-08-14 07:52:40 --> Total execution time: 0.2650
DEBUG - 2014-08-14 07:52:44 --> Config Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Hooks Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Utf8 Class Initialized
DEBUG - 2014-08-14 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 07:52:44 --> URI Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Router Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Output Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Security Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Input Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 07:52:44 --> Language Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Loader Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Helper loaded: url_helper
DEBUG - 2014-08-14 07:52:44 --> Helper loaded: file_helper
DEBUG - 2014-08-14 07:52:44 --> Database Driver Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Session Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Helper loaded: string_helper
DEBUG - 2014-08-14 07:52:44 --> Session routines successfully run
DEBUG - 2014-08-14 07:52:44 --> Upload Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Pagination Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Controller Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Helper loaded: form_helper
DEBUG - 2014-08-14 07:52:44 --> Form Validation Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 07:52:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 07:52:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 07:52:44 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 07:52:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 07:52:44 --> Final output sent to browser
DEBUG - 2014-08-14 07:52:44 --> Total execution time: 0.2276
DEBUG - 2014-08-14 07:52:45 --> Config Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Hooks Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Utf8 Class Initialized
DEBUG - 2014-08-14 07:52:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 07:52:45 --> URI Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Router Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Output Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Security Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Input Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 07:52:45 --> Language Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Loader Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Helper loaded: url_helper
DEBUG - 2014-08-14 07:52:45 --> Helper loaded: file_helper
DEBUG - 2014-08-14 07:52:45 --> Database Driver Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Session Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Helper loaded: string_helper
DEBUG - 2014-08-14 07:52:45 --> Session routines successfully run
DEBUG - 2014-08-14 07:52:45 --> Upload Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Pagination Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Controller Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Helper loaded: form_helper
DEBUG - 2014-08-14 07:52:45 --> Form Validation Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Model Class Initialized
DEBUG - 2014-08-14 07:52:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 07:52:45 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:46:40 --> Config Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:46:40 --> URI Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Router Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Output Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Security Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Input Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:46:40 --> Language Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Loader Class Initialized
DEBUG - 2014-08-14 11:46:40 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:46:40 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:46:40 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Session Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:46:41 --> A session cookie was not found.
DEBUG - 2014-08-14 11:46:41 --> Session routines successfully run
DEBUG - 2014-08-14 11:46:41 --> Upload Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Controller Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:46:41 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:46:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:46:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:46:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:46:42 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:46:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:46:42 --> Final output sent to browser
DEBUG - 2014-08-14 11:46:42 --> Total execution time: 2.1842
DEBUG - 2014-08-14 11:46:46 --> Config Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:46:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:46:46 --> URI Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Router Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Output Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Security Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Input Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:46:46 --> Language Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Loader Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:46:46 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:46:46 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Session Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:46:46 --> Session routines successfully run
DEBUG - 2014-08-14 11:46:46 --> Upload Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Controller Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:46:46 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Model Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Model Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Model Class Initialized
DEBUG - 2014-08-14 11:46:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:46:46 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:48:46 --> Config Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:48:46 --> URI Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Router Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Output Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Security Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Input Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:48:46 --> Language Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Loader Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:48:46 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:48:46 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Session Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:48:46 --> Session routines successfully run
DEBUG - 2014-08-14 11:48:46 --> Upload Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Controller Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:48:46 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:48:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:48:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:48:46 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:48:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:48:46 --> Final output sent to browser
DEBUG - 2014-08-14 11:48:46 --> Total execution time: 0.1666
DEBUG - 2014-08-14 11:48:46 --> Config Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:48:46 --> URI Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Router Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Output Class Initialized
DEBUG - 2014-08-14 11:48:46 --> Security Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Input Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:48:47 --> Language Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Loader Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:48:47 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:48:47 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Session Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:48:47 --> Session routines successfully run
DEBUG - 2014-08-14 11:48:47 --> Upload Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Controller Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:48:47 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:48:47 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:48:51 --> Config Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:48:51 --> URI Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Router Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Output Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Security Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Input Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:48:51 --> Language Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Loader Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:48:51 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:48:51 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Session Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:48:51 --> Session routines successfully run
DEBUG - 2014-08-14 11:48:51 --> Upload Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Controller Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:48:51 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:48:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:48:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:48:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:48:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:48:51 --> Final output sent to browser
DEBUG - 2014-08-14 11:48:51 --> Total execution time: 0.2572
DEBUG - 2014-08-14 11:48:52 --> Config Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:48:52 --> URI Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Router Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Output Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Security Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Input Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:48:52 --> Language Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Loader Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:48:52 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:48:52 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Session Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:48:52 --> Session routines successfully run
DEBUG - 2014-08-14 11:48:52 --> Upload Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Controller Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:48:52 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Model Class Initialized
DEBUG - 2014-08-14 11:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:48:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:48:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:48:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:48:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:48:52 --> Final output sent to browser
DEBUG - 2014-08-14 11:48:52 --> Total execution time: 0.2268
DEBUG - 2014-08-14 11:53:13 --> Config Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:53:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:53:13 --> URI Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Router Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Output Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Security Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Input Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:53:13 --> Language Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Loader Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:53:13 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:53:13 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Session Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:53:13 --> Session routines successfully run
DEBUG - 2014-08-14 11:53:13 --> Upload Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Controller Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:53:13 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:53:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:53:14 --> Config Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:53:14 --> URI Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Router Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Output Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Security Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Input Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:53:14 --> Language Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Loader Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:53:14 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:53:14 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Session Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:53:14 --> Session routines successfully run
DEBUG - 2014-08-14 11:53:14 --> Upload Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Controller Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:53:14 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:53:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:53:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:53:14 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:53:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:53:14 --> Final output sent to browser
DEBUG - 2014-08-14 11:53:14 --> Total execution time: 0.1980
DEBUG - 2014-08-14 11:53:15 --> Config Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:53:15 --> URI Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Router Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Output Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Security Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Input Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:53:15 --> Language Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Loader Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:53:15 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:53:15 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Session Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:53:15 --> Session routines successfully run
DEBUG - 2014-08-14 11:53:15 --> Upload Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Controller Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:53:15 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:53:15 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:53:18 --> Config Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:53:18 --> URI Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Router Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Output Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Security Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Input Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:53:18 --> Language Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Loader Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:53:18 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:53:18 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Session Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:53:18 --> Session routines successfully run
DEBUG - 2014-08-14 11:53:18 --> Upload Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Controller Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:53:18 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:53:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:53:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:53:18 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:53:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:53:18 --> Final output sent to browser
DEBUG - 2014-08-14 11:53:18 --> Total execution time: 0.1654
DEBUG - 2014-08-14 11:53:19 --> Config Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:53:19 --> URI Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Router Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Output Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Security Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Input Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:53:19 --> Language Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Loader Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:53:19 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:53:19 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Session Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:53:19 --> Session routines successfully run
DEBUG - 2014-08-14 11:53:19 --> Upload Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Controller Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:53:19 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Model Class Initialized
DEBUG - 2014-08-14 11:53:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:53:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:53:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:53:19 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:53:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:53:19 --> Final output sent to browser
DEBUG - 2014-08-14 11:53:19 --> Total execution time: 0.2204
DEBUG - 2014-08-14 11:54:49 --> Config Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:54:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:54:49 --> URI Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Router Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Output Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Security Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Input Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:54:49 --> Language Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Loader Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:54:49 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:54:49 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Session Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:54:49 --> Session routines successfully run
DEBUG - 2014-08-14 11:54:49 --> Upload Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Controller Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:54:49 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:54:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:54:50 --> Config Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:54:50 --> URI Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Router Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Output Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Security Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Input Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:54:50 --> Language Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Loader Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:54:50 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:54:50 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Session Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:54:50 --> Session routines successfully run
DEBUG - 2014-08-14 11:54:50 --> Upload Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Controller Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:54:50 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:54:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:54:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:54:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:54:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:54:50 --> Final output sent to browser
DEBUG - 2014-08-14 11:54:50 --> Total execution time: 0.1776
DEBUG - 2014-08-14 11:54:51 --> Config Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:54:51 --> URI Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Router Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Output Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Security Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Input Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:54:51 --> Language Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Loader Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:54:51 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:54:51 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Session Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:54:51 --> Session routines successfully run
DEBUG - 2014-08-14 11:54:51 --> Upload Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Controller Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:54:51 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:54:51 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:54:53 --> Config Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:54:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:54:53 --> URI Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Router Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Output Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Security Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Input Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:54:53 --> Language Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Loader Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:54:53 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:54:53 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Session Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:54:53 --> Session routines successfully run
DEBUG - 2014-08-14 11:54:53 --> Upload Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Controller Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:54:53 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:54:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:54:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:54:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:54:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:54:53 --> Final output sent to browser
DEBUG - 2014-08-14 11:54:53 --> Total execution time: 0.1561
DEBUG - 2014-08-14 11:54:54 --> Config Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:54:54 --> URI Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Router Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Output Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Security Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Input Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:54:54 --> Language Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Loader Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:54:54 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:54:54 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Session Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:54:54 --> Session routines successfully run
DEBUG - 2014-08-14 11:54:54 --> Upload Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Controller Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:54:54 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Model Class Initialized
DEBUG - 2014-08-14 11:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:54:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:54:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:54:54 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:54:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:54:54 --> Final output sent to browser
DEBUG - 2014-08-14 11:54:54 --> Total execution time: 0.1967
DEBUG - 2014-08-14 11:55:09 --> Config Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:55:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:55:09 --> URI Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Router Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Output Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Security Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Input Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:55:09 --> Language Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Loader Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:55:09 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:55:09 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Session Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:55:09 --> Session routines successfully run
DEBUG - 2014-08-14 11:55:09 --> Upload Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:55:09 --> Controller Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:55:10 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Model Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Model Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Model Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:55:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:55:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:55:10 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:55:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:55:10 --> Final output sent to browser
DEBUG - 2014-08-14 11:55:10 --> Total execution time: 0.1929
DEBUG - 2014-08-14 11:55:10 --> Config Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:55:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:55:10 --> URI Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Router Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Output Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Security Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Input Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:55:10 --> Language Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Loader Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:55:10 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:55:10 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Session Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:55:10 --> Session routines successfully run
DEBUG - 2014-08-14 11:55:10 --> Upload Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Controller Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:55:10 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Model Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Model Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Model Class Initialized
DEBUG - 2014-08-14 11:55:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:55:10 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:56:22 --> Config Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:56:22 --> URI Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Router Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Output Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Security Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Input Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:56:22 --> Language Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Loader Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:56:22 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Session Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:56:22 --> Session routines successfully run
DEBUG - 2014-08-14 11:56:22 --> Upload Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Controller Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:56:22 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:56:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:56:22 --> Config Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:56:22 --> URI Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Router Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Output Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Security Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Input Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:56:22 --> Language Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Loader Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:56:22 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Session Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:56:22 --> Session routines successfully run
DEBUG - 2014-08-14 11:56:22 --> Upload Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Controller Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:56:22 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:56:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:56:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:56:22 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:56:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:56:22 --> Final output sent to browser
DEBUG - 2014-08-14 11:56:22 --> Total execution time: 0.1757
DEBUG - 2014-08-14 11:56:23 --> Config Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:56:23 --> URI Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Router Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Output Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Security Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Input Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:56:23 --> Language Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Loader Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:56:23 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:56:23 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Session Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:56:23 --> Session routines successfully run
DEBUG - 2014-08-14 11:56:23 --> Upload Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Controller Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:56:23 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Model Class Initialized
DEBUG - 2014-08-14 11:56:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:56:23 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 11:58:40 --> Config Class Initialized
DEBUG - 2014-08-14 11:58:40 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:58:40 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:58:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:58:40 --> URI Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Router Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Output Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Security Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Input Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:58:41 --> Language Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Loader Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:58:41 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Session Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:58:41 --> Session routines successfully run
DEBUG - 2014-08-14 11:58:41 --> Upload Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Controller Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:58:41 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:58:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:58:41 --> Config Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:58:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:58:41 --> URI Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Router Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Output Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Security Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Input Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:58:41 --> Language Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Loader Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:58:41 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Session Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:58:41 --> Session routines successfully run
DEBUG - 2014-08-14 11:58:41 --> Upload Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Controller Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:58:41 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 11:58:41 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 11:58:41 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 11:58:41 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 11:58:41 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 11:58:41 --> Final output sent to browser
DEBUG - 2014-08-14 11:58:41 --> Total execution time: 0.1885
DEBUG - 2014-08-14 11:58:42 --> Config Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Hooks Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Utf8 Class Initialized
DEBUG - 2014-08-14 11:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 11:58:42 --> URI Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Router Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Output Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Security Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Input Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 11:58:42 --> Language Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Loader Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Helper loaded: url_helper
DEBUG - 2014-08-14 11:58:42 --> Helper loaded: file_helper
DEBUG - 2014-08-14 11:58:42 --> Database Driver Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Session Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Helper loaded: string_helper
DEBUG - 2014-08-14 11:58:42 --> Session routines successfully run
DEBUG - 2014-08-14 11:58:42 --> Upload Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Pagination Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Controller Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Helper loaded: form_helper
DEBUG - 2014-08-14 11:58:42 --> Form Validation Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Model Class Initialized
DEBUG - 2014-08-14 11:58:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 11:58:42 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 12:00:13 --> Config Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:00:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:00:13 --> URI Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Router Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Output Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Security Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Input Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:00:13 --> Language Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Loader Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:00:13 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:00:13 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Session Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:00:13 --> Session routines successfully run
DEBUG - 2014-08-14 12:00:13 --> Upload Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Controller Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:00:13 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:00:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:00:42 --> Config Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:00:42 --> URI Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Router Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Output Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Security Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Input Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:00:42 --> Language Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Loader Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:00:42 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:00:42 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:00:42 --> Session Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:00:43 --> Session routines successfully run
DEBUG - 2014-08-14 12:00:43 --> Upload Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Controller Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:00:43 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:00:43 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-14 12:00:43 --> Severity: Notice  --> Undefined variable: tab_title C:\wamp\www\hostorks\application\models\superadmin_model.php 179
ERROR - 2014-08-14 12:00:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\hostorks\application\models\superadmin_model.php 179
DEBUG - 2014-08-14 12:00:43 --> Config Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:00:43 --> URI Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Router Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Output Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Security Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Input Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:00:43 --> Language Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Loader Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:00:43 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:00:43 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Session Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:00:43 --> Session routines successfully run
DEBUG - 2014-08-14 12:00:43 --> Upload Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Controller Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:00:43 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:00:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 12:00:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 12:00:43 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 12:00:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 12:00:43 --> Final output sent to browser
DEBUG - 2014-08-14 12:00:43 --> Total execution time: 0.1920
DEBUG - 2014-08-14 12:00:44 --> Config Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:00:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:00:44 --> URI Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Router Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Output Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Security Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Input Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:00:44 --> Language Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Loader Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:00:44 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:00:44 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Session Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:00:44 --> Session routines successfully run
DEBUG - 2014-08-14 12:00:44 --> Upload Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Controller Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:00:44 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Model Class Initialized
DEBUG - 2014-08-14 12:00:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 12:00:44 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 12:01:01 --> Config Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:01:01 --> URI Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Router Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Output Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Security Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Input Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:01:01 --> Language Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Loader Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:01:01 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:01:01 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Session Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:01:01 --> Session routines successfully run
DEBUG - 2014-08-14 12:01:01 --> Upload Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Controller Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:01:01 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:01:01 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-14 12:01:01 --> Severity: Notice  --> Undefined variable: tabimage C:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-08-14 12:01:01 --> Severity: Notice  --> Undefined index:  C:\wamp\www\hostorks\application\models\superadmin_model.php 183
DEBUG - 2014-08-14 12:01:52 --> Config Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:01:52 --> URI Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Router Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Output Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Security Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Input Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:01:52 --> Language Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Loader Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:01:52 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Session Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:01:52 --> Session routines successfully run
DEBUG - 2014-08-14 12:01:52 --> Upload Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Controller Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:01:52 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:01:52 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-14 12:01:52 --> Severity: Notice  --> Undefined variable: tab_title C:\wamp\www\hostorks\application\models\superadmin_model.php 179
ERROR - 2014-08-14 12:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\hostorks\application\models\superadmin_model.php 179
DEBUG - 2014-08-14 12:01:52 --> Config Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:01:52 --> URI Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Router Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Output Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Security Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Input Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:01:52 --> Language Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Loader Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:01:52 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Session Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:01:52 --> Session routines successfully run
DEBUG - 2014-08-14 12:01:52 --> Upload Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Controller Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:01:52 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:01:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-14 12:01:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-14 12:01:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-14 12:01:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-14 12:01:52 --> Final output sent to browser
DEBUG - 2014-08-14 12:01:52 --> Total execution time: 0.2164
DEBUG - 2014-08-14 12:01:53 --> Config Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:01:53 --> URI Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Router Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Output Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Security Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Input Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:01:53 --> Language Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Loader Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:01:53 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:01:53 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Session Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:01:53 --> Session routines successfully run
DEBUG - 2014-08-14 12:01:53 --> Upload Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Controller Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:01:53 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Model Class Initialized
DEBUG - 2014-08-14 12:01:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-14 12:01:53 --> 404 Page Not Found --> 
DEBUG - 2014-08-14 12:02:09 --> Config Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Hooks Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Utf8 Class Initialized
DEBUG - 2014-08-14 12:02:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 12:02:09 --> URI Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Router Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Output Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Security Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Input Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 12:02:09 --> Language Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Loader Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Helper loaded: url_helper
DEBUG - 2014-08-14 12:02:09 --> Helper loaded: file_helper
DEBUG - 2014-08-14 12:02:09 --> Database Driver Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Session Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Helper loaded: string_helper
DEBUG - 2014-08-14 12:02:09 --> Session routines successfully run
DEBUG - 2014-08-14 12:02:09 --> Upload Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Pagination Class Initialized
DEBUG - 2014-08-14 12:02:09 --> Controller Class Initialized
DEBUG - 2014-08-14 12:02:10 --> Helper loaded: form_helper
DEBUG - 2014-08-14 12:02:10 --> Form Validation Class Initialized
DEBUG - 2014-08-14 12:02:10 --> Model Class Initialized
DEBUG - 2014-08-14 12:02:10 --> Model Class Initialized
DEBUG - 2014-08-14 12:02:10 --> Model Class Initialized
DEBUG - 2014-08-14 12:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 12:02:10 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-14 12:02:10 --> Severity: Notice  --> Undefined variable: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-08-14 12:02:10 --> Severity: Notice  --> Undefined index:  C:\wamp\www\hostorks\application\models\superadmin_model.php 184
DEBUG - 2014-08-14 17:10:56 --> Config Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Hooks Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Utf8 Class Initialized
DEBUG - 2014-08-14 17:10:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 17:10:56 --> URI Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Router Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Output Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Security Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Input Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 17:10:56 --> Language Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Loader Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Helper loaded: url_helper
DEBUG - 2014-08-14 17:10:56 --> Helper loaded: file_helper
DEBUG - 2014-08-14 17:10:56 --> Database Driver Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Session Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Helper loaded: string_helper
DEBUG - 2014-08-14 17:10:56 --> A session cookie was not found.
DEBUG - 2014-08-14 17:10:56 --> Session routines successfully run
DEBUG - 2014-08-14 17:10:56 --> Upload Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Pagination Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Controller Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Helper loaded: form_helper
DEBUG - 2014-08-14 17:10:56 --> Form Validation Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Model Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Model Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Model Class Initialized
DEBUG - 2014-08-14 17:10:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 17:10:56 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-14 17:10:56 --> Severity: Notice  --> Undefined variable: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 183
DEBUG - 2014-08-14 17:12:56 --> Config Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Hooks Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Utf8 Class Initialized
DEBUG - 2014-08-14 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 17:12:56 --> URI Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Router Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Output Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Security Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Input Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 17:12:56 --> Language Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Loader Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Helper loaded: url_helper
DEBUG - 2014-08-14 17:12:56 --> Helper loaded: file_helper
DEBUG - 2014-08-14 17:12:56 --> Database Driver Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Session Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Helper loaded: string_helper
DEBUG - 2014-08-14 17:12:56 --> Session routines successfully run
DEBUG - 2014-08-14 17:12:56 --> Upload Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Pagination Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Controller Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Helper loaded: form_helper
DEBUG - 2014-08-14 17:12:56 --> Form Validation Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Model Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Model Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Model Class Initialized
DEBUG - 2014-08-14 17:12:56 --> Session class already loaded. Second attempt ignored.

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-06-30 05:59:31 --> Config Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Hooks Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Utf8 Class Initialized
DEBUG - 2015-06-30 05:59:31 --> UTF-8 Support Enabled
DEBUG - 2015-06-30 05:59:31 --> URI Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Router Class Initialized
DEBUG - 2015-06-30 05:59:31 --> No URI present. Default controller set.
DEBUG - 2015-06-30 05:59:31 --> Output Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Security Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Input Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-30 05:59:31 --> Language Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Loader Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Helper loaded: url_helper
DEBUG - 2015-06-30 05:59:31 --> Helper loaded: file_helper
DEBUG - 2015-06-30 05:59:31 --> Database Driver Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Session Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Helper loaded: string_helper
DEBUG - 2015-06-30 05:59:31 --> A session cookie was not found.
DEBUG - 2015-06-30 05:59:31 --> Session routines successfully run
DEBUG - 2015-06-30 05:59:31 --> Upload Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Pagination Class Initialized
DEBUG - 2015-06-30 05:59:31 --> Controller Class Initialized
DEBUG - 2015-06-30 05:59:31 --> File loaded: application/views/templates/header.php
DEBUG - 2015-06-30 05:59:31 --> File loaded: application/views/pages/home.php
DEBUG - 2015-06-30 05:59:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2015-06-30 05:59:31 --> Final output sent to browser
DEBUG - 2015-06-30 05:59:31 --> Total execution time: 0.2088
DEBUG - 2015-06-30 05:59:36 --> Config Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Hooks Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Utf8 Class Initialized
DEBUG - 2015-06-30 05:59:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-30 05:59:36 --> URI Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Router Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Output Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Security Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Input Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-30 05:59:36 --> Language Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Loader Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Helper loaded: url_helper
DEBUG - 2015-06-30 05:59:36 --> Helper loaded: file_helper
DEBUG - 2015-06-30 05:59:36 --> Database Driver Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Session Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Helper loaded: string_helper
DEBUG - 2015-06-30 05:59:36 --> Session routines successfully run
DEBUG - 2015-06-30 05:59:36 --> Upload Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Pagination Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Controller Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Helper loaded: form_helper
DEBUG - 2015-06-30 05:59:36 --> Form Validation Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2015-06-30 05:59:36 --> File loaded: application/views/superadmin/login.php
DEBUG - 2015-06-30 05:59:36 --> Final output sent to browser
DEBUG - 2015-06-30 05:59:36 --> Total execution time: 0.1626
DEBUG - 2015-06-30 05:59:42 --> Config Class Initialized
DEBUG - 2015-06-30 05:59:42 --> Hooks Class Initialized
DEBUG - 2015-06-30 05:59:42 --> Utf8 Class Initialized
DEBUG - 2015-06-30 05:59:42 --> UTF-8 Support Enabled
DEBUG - 2015-06-30 05:59:42 --> URI Class Initialized
DEBUG - 2015-06-30 05:59:42 --> Router Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Output Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Security Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Input Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-30 05:59:43 --> Language Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Loader Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Helper loaded: url_helper
DEBUG - 2015-06-30 05:59:43 --> Helper loaded: file_helper
DEBUG - 2015-06-30 05:59:43 --> Database Driver Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Session Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Helper loaded: string_helper
DEBUG - 2015-06-30 05:59:43 --> Session routines successfully run
DEBUG - 2015-06-30 05:59:43 --> Upload Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Pagination Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Controller Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Helper loaded: form_helper
DEBUG - 2015-06-30 05:59:43 --> Form Validation Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2015-06-30 05:59:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-30 05:59:43 --> XSS Filtering completed
DEBUG - 2015-06-30 05:59:43 --> File loaded: application/views/superadmin/login.php
DEBUG - 2015-06-30 05:59:43 --> Final output sent to browser
DEBUG - 2015-06-30 05:59:43 --> Total execution time: 0.2362
DEBUG - 2015-06-30 05:59:56 --> Config Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Hooks Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Utf8 Class Initialized
DEBUG - 2015-06-30 05:59:56 --> UTF-8 Support Enabled
DEBUG - 2015-06-30 05:59:56 --> URI Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Router Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Output Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Security Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Input Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-30 05:59:56 --> Language Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Loader Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Helper loaded: url_helper
DEBUG - 2015-06-30 05:59:56 --> Helper loaded: file_helper
DEBUG - 2015-06-30 05:59:56 --> Database Driver Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Session Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Helper loaded: string_helper
DEBUG - 2015-06-30 05:59:56 --> Session routines successfully run
DEBUG - 2015-06-30 05:59:56 --> Upload Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Pagination Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Controller Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Helper loaded: form_helper
DEBUG - 2015-06-30 05:59:56 --> Form Validation Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Model Class Initialized
DEBUG - 2015-06-30 05:59:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2015-06-30 05:59:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-30 05:59:56 --> XSS Filtering completed
DEBUG - 2015-06-30 05:59:56 --> File loaded: application/views/superadmin/login.php
DEBUG - 2015-06-30 05:59:56 --> Final output sent to browser
DEBUG - 2015-06-30 05:59:56 --> Total execution time: 0.1373

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-20 06:11:52 --> Config Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Hooks Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Utf8 Class Initialized
DEBUG - 2014-07-20 06:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-20 06:11:52 --> URI Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Router Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Output Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Security Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Input Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-20 06:11:52 --> Language Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Loader Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Helper loaded: url_helper
DEBUG - 2014-07-20 06:11:52 --> Helper loaded: file_helper
DEBUG - 2014-07-20 06:11:52 --> Database Driver Class Initialized
ERROR - 2014-07-20 06:11:52 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\hostorks\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-20 06:11:52 --> Session Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Helper loaded: string_helper
DEBUG - 2014-07-20 06:11:52 --> A session cookie was not found.
DEBUG - 2014-07-20 06:11:52 --> Session routines successfully run
DEBUG - 2014-07-20 06:11:52 --> Upload Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Pagination Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Controller Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Helper loaded: form_helper
DEBUG - 2014-07-20 06:11:52 --> Form Validation Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Model Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Model Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Model Class Initialized
DEBUG - 2014-07-20 06:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-20 06:11:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-20 06:11:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-20 06:11:52 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-20 06:11:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-20 06:11:52 --> Final output sent to browser
DEBUG - 2014-07-20 06:11:52 --> Total execution time: 0.6413

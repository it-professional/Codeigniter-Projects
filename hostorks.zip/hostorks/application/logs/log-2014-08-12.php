<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-12 17:42:14 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:14 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:14 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:14 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:14 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:14 --> A session cookie was not found.
DEBUG - 2014-08-12 17:42:14 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:14 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:14 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 17:42:14 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-12 17:42:14 --> Final output sent to browser
DEBUG - 2014-08-12 17:42:14 --> Total execution time: 0.2219
DEBUG - 2014-08-12 17:42:21 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:21 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:21 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:21 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:21 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:21 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:21 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 17:42:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 17:42:21 --> XSS Filtering completed
DEBUG - 2014-08-12 17:42:21 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:21 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:21 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:21 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:21 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:22 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:22 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:22 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 17:42:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-12 17:42:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-12 17:42:22 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-12 17:42:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-12 17:42:22 --> Final output sent to browser
DEBUG - 2014-08-12 17:42:22 --> Total execution time: 0.2215
DEBUG - 2014-08-12 17:42:28 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:28 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:28 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:28 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:28 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:28 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:28 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:28 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 17:42:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-12 17:42:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-12 17:42:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-12 17:42:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-12 17:42:28 --> Final output sent to browser
DEBUG - 2014-08-12 17:42:28 --> Total execution time: 0.1841
DEBUG - 2014-08-12 17:42:28 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:28 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:29 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:29 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:29 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:29 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:29 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:29 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:29 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 17:42:29 --> 404 Page Not Found --> 
DEBUG - 2014-08-12 17:42:36 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:36 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:36 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:36 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:36 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:36 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:36 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:36 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 17:42:36 --> 404 Page Not Found --> 
DEBUG - 2014-08-12 17:42:39 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:39 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:39 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:39 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:39 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:39 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:39 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:39 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 17:42:39 --> 404 Page Not Found --> 
DEBUG - 2014-08-12 17:42:40 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:40 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:40 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:40 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:40 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:40 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:40 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:40 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 17:42:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-12 17:42:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-12 17:42:40 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-12 17:42:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-12 17:42:40 --> Final output sent to browser
DEBUG - 2014-08-12 17:42:40 --> Total execution time: 0.1716
DEBUG - 2014-08-12 17:42:41 --> Config Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Hooks Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Utf8 Class Initialized
DEBUG - 2014-08-12 17:42:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 17:42:41 --> URI Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Router Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Output Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Security Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Input Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 17:42:41 --> Language Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Loader Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Helper loaded: url_helper
DEBUG - 2014-08-12 17:42:41 --> Helper loaded: file_helper
DEBUG - 2014-08-12 17:42:41 --> Database Driver Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Session Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Helper loaded: string_helper
DEBUG - 2014-08-12 17:42:41 --> Session routines successfully run
DEBUG - 2014-08-12 17:42:41 --> Upload Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Pagination Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Controller Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Helper loaded: form_helper
DEBUG - 2014-08-12 17:42:41 --> Form Validation Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Model Class Initialized
DEBUG - 2014-08-12 17:42:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 17:42:41 --> 404 Page Not Found --> 
DEBUG - 2014-08-12 18:01:50 --> Config Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:01:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:01:50 --> URI Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Router Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Output Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Security Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Input Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:01:50 --> Language Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Loader Class Initialized
DEBUG - 2014-08-12 18:01:50 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:01:50 --> Helper loaded: file_helper
DEBUG - 2014-08-12 18:01:50 --> Database Driver Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Session Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:01:51 --> Session routines successfully run
DEBUG - 2014-08-12 18:01:51 --> Upload Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Pagination Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Controller Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:01:51 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Model Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Model Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Model Class Initialized
DEBUG - 2014-08-12 18:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 18:01:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-12 18:01:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-12 18:01:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-12 18:01:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-12 18:01:51 --> Final output sent to browser
DEBUG - 2014-08-12 18:01:51 --> Total execution time: 0.7231
DEBUG - 2014-08-12 18:01:52 --> Config Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:01:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:01:52 --> URI Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Router Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Output Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Security Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Input Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:01:52 --> Language Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Loader Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:01:52 --> Helper loaded: file_helper
DEBUG - 2014-08-12 18:01:52 --> Database Driver Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Session Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:01:52 --> Session routines successfully run
DEBUG - 2014-08-12 18:01:52 --> Upload Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Pagination Class Initialized
DEBUG - 2014-08-12 18:01:52 --> Controller Class Initialized
DEBUG - 2014-08-12 18:01:53 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:01:53 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:01:53 --> Model Class Initialized
DEBUG - 2014-08-12 18:01:53 --> Model Class Initialized
DEBUG - 2014-08-12 18:01:53 --> Model Class Initialized
DEBUG - 2014-08-12 18:01:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 18:01:53 --> 404 Page Not Found --> 
DEBUG - 2014-08-12 18:02:14 --> Config Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:02:14 --> URI Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Router Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Output Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Security Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Input Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:02:14 --> Language Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Loader Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:02:14 --> Helper loaded: file_helper
DEBUG - 2014-08-12 18:02:14 --> Database Driver Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Session Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:02:14 --> Session routines successfully run
DEBUG - 2014-08-12 18:02:14 --> Upload Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Pagination Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Controller Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:02:14 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 18:02:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-12 18:02:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-12 18:02:14 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-12 18:02:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-12 18:02:14 --> Final output sent to browser
DEBUG - 2014-08-12 18:02:14 --> Total execution time: 0.1808
DEBUG - 2014-08-12 18:02:15 --> Config Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:02:15 --> URI Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Router Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Output Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Security Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Input Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:02:15 --> Language Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Loader Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:02:15 --> Helper loaded: file_helper
DEBUG - 2014-08-12 18:02:15 --> Database Driver Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Session Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:02:15 --> Session routines successfully run
DEBUG - 2014-08-12 18:02:15 --> Upload Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Pagination Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Controller Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:02:15 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 18:02:15 --> 404 Page Not Found --> 
DEBUG - 2014-08-12 18:02:45 --> Config Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:02:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:02:45 --> URI Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Router Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Output Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Security Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Input Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:02:45 --> Language Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Loader Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:02:45 --> Helper loaded: file_helper
DEBUG - 2014-08-12 18:02:45 --> Database Driver Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Session Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:02:45 --> Session routines successfully run
DEBUG - 2014-08-12 18:02:45 --> Upload Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Pagination Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Controller Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:02:45 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-12 18:02:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-12 18:02:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-12 18:02:45 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-12 18:02:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-12 18:02:45 --> Final output sent to browser
DEBUG - 2014-08-12 18:02:45 --> Total execution time: 0.2554
DEBUG - 2014-08-12 18:02:46 --> Config Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:02:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:02:46 --> URI Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Router Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Output Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Security Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Input Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:02:46 --> Language Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Loader Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:02:46 --> Helper loaded: file_helper
DEBUG - 2014-08-12 18:02:46 --> Database Driver Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Session Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:02:46 --> Session routines successfully run
DEBUG - 2014-08-12 18:02:46 --> Upload Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Pagination Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Controller Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:02:46 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Model Class Initialized
DEBUG - 2014-08-12 18:02:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-12 18:02:46 --> 404 Page Not Found --> 

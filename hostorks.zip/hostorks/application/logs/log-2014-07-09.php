<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-09 10:24:50 --> Config Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:24:50 --> URI Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Router Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Output Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Security Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Input Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:24:50 --> Language Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Loader Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:24:50 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:24:50 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Session Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:24:50 --> A session cookie was not found.
DEBUG - 2014-07-09 10:24:50 --> Session routines successfully run
DEBUG - 2014-07-09 10:24:50 --> Upload Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Controller Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:24:50 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:24:50 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-09 10:24:50 --> Final output sent to browser
DEBUG - 2014-07-09 10:24:50 --> Total execution time: 0.1283
DEBUG - 2014-07-09 10:24:57 --> Config Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:24:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:24:57 --> URI Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Router Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Output Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Security Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Input Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:24:57 --> Language Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Loader Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:24:57 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Session Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:24:57 --> Session routines successfully run
DEBUG - 2014-07-09 10:24:57 --> Upload Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Controller Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:24:57 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:24:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-09 10:24:57 --> XSS Filtering completed
DEBUG - 2014-07-09 10:24:57 --> Config Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:24:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:24:57 --> URI Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Router Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Output Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Security Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Input Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:24:57 --> Language Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Loader Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:24:57 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Session Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:24:57 --> Session routines successfully run
DEBUG - 2014-07-09 10:24:57 --> Upload Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Controller Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:24:57 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Model Class Initialized
DEBUG - 2014-07-09 10:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:24:57 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:24:57 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:24:57 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:24:57 --> Final output sent to browser
DEBUG - 2014-07-09 10:24:57 --> Total execution time: 0.0970
DEBUG - 2014-07-09 10:25:13 --> Config Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:25:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:25:13 --> URI Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Router Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Output Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Security Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Input Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:25:13 --> Language Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Loader Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:25:13 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:25:13 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Session Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:25:13 --> Session routines successfully run
DEBUG - 2014-07-09 10:25:13 --> Upload Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Controller Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:25:13 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:25:13 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:25:13 --> Final output sent to browser
DEBUG - 2014-07-09 10:25:13 --> Total execution time: 0.2179
DEBUG - 2014-07-09 10:25:20 --> Config Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:25:20 --> URI Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Router Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Output Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Security Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Input Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:25:20 --> Language Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Loader Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:25:20 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:25:20 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Session Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:25:20 --> Session routines successfully run
DEBUG - 2014-07-09 10:25:20 --> Upload Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Controller Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:25:20 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:25:21 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:25:21 --> Final output sent to browser
DEBUG - 2014-07-09 10:25:21 --> Total execution time: 0.2221
DEBUG - 2014-07-09 10:25:25 --> Config Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:25:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:25:25 --> URI Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Router Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Output Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Security Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Input Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:25:25 --> Language Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Loader Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:25:25 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:25:25 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Session Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:25:25 --> Session routines successfully run
DEBUG - 2014-07-09 10:25:25 --> Upload Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Controller Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:25:25 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:25:25 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:25:25 --> Final output sent to browser
DEBUG - 2014-07-09 10:25:25 --> Total execution time: 0.0985
DEBUG - 2014-07-09 10:25:30 --> Config Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:25:30 --> URI Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Router Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Output Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Security Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Input Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:25:30 --> Language Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Loader Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:25:30 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:25:30 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Session Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:25:30 --> Session routines successfully run
DEBUG - 2014-07-09 10:25:30 --> Upload Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:25:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:25:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:25:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:25:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:25:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:25:30 --> Total execution time: 0.1140
DEBUG - 2014-07-09 10:26:02 --> Config Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:26:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:26:02 --> URI Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Router Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Output Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Security Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Input Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:26:02 --> Language Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Loader Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:26:02 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:26:02 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Session Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:26:02 --> Session routines successfully run
DEBUG - 2014-07-09 10:26:02 --> Upload Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Controller Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:26:02 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Model Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Model Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Model Class Initialized
DEBUG - 2014-07-09 10:26:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:26:02 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:26:02 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:26:02 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:26:02 --> Final output sent to browser
DEBUG - 2014-07-09 10:26:02 --> Total execution time: 0.1047
DEBUG - 2014-07-09 10:29:56 --> Config Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:29:56 --> URI Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Router Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Output Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Security Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Input Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:29:56 --> Language Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Loader Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Session Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:29:56 --> Session routines successfully run
DEBUG - 2014-07-09 10:29:56 --> Upload Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Controller Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Model Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Model Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Model Class Initialized
DEBUG - 2014-07-09 10:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:29:56 --> Final output sent to browser
DEBUG - 2014-07-09 10:29:56 --> Total execution time: 0.0872
DEBUG - 2014-07-09 10:30:00 --> Config Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:30:00 --> URI Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Router Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Output Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Security Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Input Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:30:00 --> Language Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Loader Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:30:00 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:30:00 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Session Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:30:00 --> Session routines successfully run
DEBUG - 2014-07-09 10:30:00 --> Upload Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Controller Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:30:00 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Model Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Model Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Model Class Initialized
DEBUG - 2014-07-09 10:30:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:30:00 --> Final output sent to browser
DEBUG - 2014-07-09 10:30:00 --> Total execution time: 0.0857
DEBUG - 2014-07-09 10:33:27 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:27 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:27 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:27 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:27 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:27 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:27 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:27 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:27 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:28 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:28 --> Total execution time: 0.0928
DEBUG - 2014-07-09 10:33:28 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:28 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:28 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:28 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:28 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:28 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:28 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:28 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:28 --> Total execution time: 0.1058
DEBUG - 2014-07-09 10:33:28 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:28 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:28 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:28 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:28 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:28 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:28 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:28 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:28 --> Total execution time: 0.1111
DEBUG - 2014-07-09 10:33:28 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:28 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:28 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:28 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:28 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:28 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:28 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:28 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:28 --> Total execution time: 0.1010
DEBUG - 2014-07-09 10:33:28 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:28 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:28 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:28 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:28 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:28 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:28 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:28 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:28 --> Total execution time: 0.1104
DEBUG - 2014-07-09 10:33:29 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:29 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:29 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:29 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:29 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:29 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:29 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:29 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:29 --> Total execution time: 0.1047
DEBUG - 2014-07-09 10:33:29 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:29 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:29 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:29 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:29 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:29 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:29 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:29 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:29 --> Total execution time: 0.1072
DEBUG - 2014-07-09 10:33:29 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:29 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:29 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:29 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:29 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:29 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:29 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:29 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:29 --> Total execution time: 0.1015
DEBUG - 2014-07-09 10:33:29 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:29 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:29 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:29 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:29 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:29 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:29 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:29 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:29 --> Total execution time: 0.0968
DEBUG - 2014-07-09 10:33:29 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:29 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:29 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:29 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:29 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:29 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:29 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:30 --> Total execution time: 0.0986
DEBUG - 2014-07-09 10:33:30 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:30 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:30 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:30 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:30 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:30 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:30 --> Total execution time: 0.0992
DEBUG - 2014-07-09 10:33:30 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:30 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:30 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:30 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:30 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:30 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:30 --> Total execution time: 0.1165
DEBUG - 2014-07-09 10:33:30 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:30 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:30 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:30 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:30 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:30 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:30 --> Total execution time: 0.0971
DEBUG - 2014-07-09 10:33:30 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:30 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:30 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:30 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:30 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:30 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:30 --> Total execution time: 0.1376
DEBUG - 2014-07-09 10:33:30 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:30 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:30 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:30 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:30 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:30 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:30 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:30 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:30 --> Total execution time: 0.1075
DEBUG - 2014-07-09 10:33:36 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:36 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:36 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:36 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:36 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:36 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:36 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:36 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:36 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:36 --> Total execution time: 0.0938
DEBUG - 2014-07-09 10:33:41 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:41 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:41 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:41 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:41 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:41 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:41 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:41 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:41 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:41 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:41 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:41 --> Total execution time: 0.1009
DEBUG - 2014-07-09 10:33:44 --> Config Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:33:44 --> URI Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Router Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Output Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Security Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Input Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:33:44 --> Language Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Loader Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:33:44 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:33:44 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Session Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:33:44 --> Session routines successfully run
DEBUG - 2014-07-09 10:33:44 --> Upload Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Controller Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:33:44 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Model Class Initialized
DEBUG - 2014-07-09 10:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:33:44 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:33:44 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:33:44 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:33:44 --> Final output sent to browser
DEBUG - 2014-07-09 10:33:44 --> Total execution time: 0.1048
DEBUG - 2014-07-09 10:34:04 --> Config Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:34:04 --> URI Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Router Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Output Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Security Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Input Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:34:04 --> Language Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Loader Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:34:04 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:34:04 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Session Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:34:04 --> Session routines successfully run
DEBUG - 2014-07-09 10:34:04 --> Upload Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Controller Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:34:04 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Model Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Model Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Model Class Initialized
DEBUG - 2014-07-09 10:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:34:04 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:34:04 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:34:04 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:34:04 --> Final output sent to browser
DEBUG - 2014-07-09 10:34:04 --> Total execution time: 0.0980
DEBUG - 2014-07-09 10:34:17 --> Config Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:34:17 --> URI Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Router Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Output Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Security Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Input Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:34:17 --> Language Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Loader Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:34:17 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:34:17 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Session Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:34:17 --> Session routines successfully run
DEBUG - 2014-07-09 10:34:17 --> Upload Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Controller Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:34:17 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Model Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Model Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Model Class Initialized
DEBUG - 2014-07-09 10:34:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-09 10:34:17 --> Severity: Notice  --> Undefined variable: menuid F:\wamp\www\hostorks\application\models\superadmin_model.php 58
ERROR - 2014-07-09 10:34:17 --> Severity: Warning  --> Invalid argument supplied for foreach() F:\wamp\www\hostorks\application\models\superadmin_model.php 58
DEBUG - 2014-07-09 10:34:17 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:34:17 --> Final output sent to browser
DEBUG - 2014-07-09 10:34:17 --> Total execution time: 0.1060
DEBUG - 2014-07-09 10:35:34 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:34 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:34 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:34 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:34 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:34 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:34 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:34 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:34 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:34 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:34 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:34 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:34 --> Total execution time: 0.1040
DEBUG - 2014-07-09 10:35:36 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:36 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:36 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:36 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:36 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:36 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:36 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:36 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:36 --> Total execution time: 0.1172
DEBUG - 2014-07-09 10:35:36 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:36 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:36 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:36 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:36 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:36 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:36 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:36 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:36 --> Total execution time: 0.0995
DEBUG - 2014-07-09 10:35:36 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:36 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:36 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:36 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:36 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:36 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:36 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:36 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:36 --> Total execution time: 0.0976
DEBUG - 2014-07-09 10:35:36 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:36 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:36 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:36 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:36 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:36 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:36 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:36 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:36 --> Total execution time: 0.0930
DEBUG - 2014-07-09 10:35:37 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:37 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:37 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:37 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:37 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:37 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:37 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:37 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:37 --> Total execution time: 0.1009
DEBUG - 2014-07-09 10:35:37 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:37 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:37 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:37 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:37 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:37 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:37 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:37 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:37 --> Total execution time: 0.0991
DEBUG - 2014-07-09 10:35:37 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:37 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:37 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:37 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:37 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:37 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:37 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:37 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:37 --> Total execution time: 0.1405
DEBUG - 2014-07-09 10:35:37 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:37 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:37 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:37 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:37 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:37 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:37 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:37 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:37 --> Total execution time: 0.1173
DEBUG - 2014-07-09 10:35:37 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:37 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:37 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:37 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:37 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:37 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:37 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:38 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:38 --> Total execution time: 0.1006
DEBUG - 2014-07-09 10:35:38 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:38 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:38 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:38 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:38 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:38 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:38 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:38 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:38 --> Total execution time: 0.1002
DEBUG - 2014-07-09 10:35:38 --> Config Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:35:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:35:38 --> URI Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Router Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Output Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Security Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Input Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:35:38 --> Language Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Loader Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:35:38 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Session Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:35:38 --> Session routines successfully run
DEBUG - 2014-07-09 10:35:38 --> Upload Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Controller Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:35:38 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Model Class Initialized
DEBUG - 2014-07-09 10:35:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:35:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:35:38 --> Final output sent to browser
DEBUG - 2014-07-09 10:35:38 --> Total execution time: 0.0914
DEBUG - 2014-07-09 10:36:15 --> Config Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:36:15 --> URI Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Router Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Output Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Security Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Input Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:36:15 --> Language Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Loader Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:36:15 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:36:15 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Session Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:36:15 --> Session routines successfully run
DEBUG - 2014-07-09 10:36:15 --> Upload Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Controller Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:36:15 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:36:15 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:36:15 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:36:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:36:15 --> Final output sent to browser
DEBUG - 2014-07-09 10:36:15 --> Total execution time: 0.1090
DEBUG - 2014-07-09 10:36:16 --> Config Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:36:16 --> URI Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Router Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Output Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Security Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Input Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:36:16 --> Language Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Loader Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:36:16 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:36:16 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Session Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:36:16 --> Session routines successfully run
DEBUG - 2014-07-09 10:36:16 --> Upload Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Controller Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:36:16 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:36:16 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:36:16 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:36:16 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:36:16 --> Final output sent to browser
DEBUG - 2014-07-09 10:36:16 --> Total execution time: 0.1031
DEBUG - 2014-07-09 10:36:18 --> Config Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:36:18 --> URI Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Router Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Output Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Security Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Input Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:36:18 --> Language Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Loader Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:36:18 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:36:18 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Session Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:36:18 --> Session routines successfully run
DEBUG - 2014-07-09 10:36:18 --> Upload Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Controller Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:36:18 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:36:18 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:36:18 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:36:18 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:36:18 --> Final output sent to browser
DEBUG - 2014-07-09 10:36:18 --> Total execution time: 0.1138
DEBUG - 2014-07-09 10:36:29 --> Config Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:36:29 --> URI Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Router Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Output Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Security Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Input Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:36:29 --> Language Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Loader Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:36:29 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:36:29 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Session Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:36:29 --> Session routines successfully run
DEBUG - 2014-07-09 10:36:29 --> Upload Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Controller Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:36:29 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:36:29 --> Final output sent to browser
DEBUG - 2014-07-09 10:36:29 --> Total execution time: 0.0860
DEBUG - 2014-07-09 10:36:37 --> Config Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:36:37 --> URI Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Router Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Output Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Security Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Input Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:36:37 --> Language Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Loader Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:36:37 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:36:37 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Session Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:36:37 --> Session routines successfully run
DEBUG - 2014-07-09 10:36:37 --> Upload Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Controller Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:36:37 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:36:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:36:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:36:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:36:37 --> Final output sent to browser
DEBUG - 2014-07-09 10:36:37 --> Total execution time: 0.0962
DEBUG - 2014-07-09 10:36:41 --> Config Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:36:41 --> URI Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Router Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Output Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Security Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Input Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:36:41 --> Language Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Loader Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:36:41 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:36:41 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Session Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:36:41 --> Session routines successfully run
DEBUG - 2014-07-09 10:36:41 --> Upload Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Controller Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:36:41 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Model Class Initialized
DEBUG - 2014-07-09 10:36:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:36:41 --> Final output sent to browser
DEBUG - 2014-07-09 10:36:41 --> Total execution time: 0.0875
DEBUG - 2014-07-09 10:42:33 --> Config Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Hooks Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Utf8 Class Initialized
DEBUG - 2014-07-09 10:42:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 10:42:33 --> URI Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Router Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Output Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Security Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Input Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 10:42:33 --> Language Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Loader Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Helper loaded: url_helper
DEBUG - 2014-07-09 10:42:33 --> Helper loaded: file_helper
DEBUG - 2014-07-09 10:42:33 --> Database Driver Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Session Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Helper loaded: string_helper
DEBUG - 2014-07-09 10:42:33 --> Session routines successfully run
DEBUG - 2014-07-09 10:42:33 --> Upload Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Pagination Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Controller Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Helper loaded: form_helper
DEBUG - 2014-07-09 10:42:33 --> Form Validation Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Model Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Model Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Model Class Initialized
DEBUG - 2014-07-09 10:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 10:42:33 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 10:42:33 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 10:42:33 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 10:42:33 --> Final output sent to browser
DEBUG - 2014-07-09 10:42:33 --> Total execution time: 0.1056
DEBUG - 2014-07-09 11:05:31 --> Config Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Hooks Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Utf8 Class Initialized
DEBUG - 2014-07-09 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 11:05:31 --> URI Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Router Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Output Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Security Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Input Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 11:05:31 --> Language Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Loader Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Helper loaded: url_helper
DEBUG - 2014-07-09 11:05:31 --> Helper loaded: file_helper
DEBUG - 2014-07-09 11:05:31 --> Database Driver Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Session Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Helper loaded: string_helper
DEBUG - 2014-07-09 11:05:31 --> Session routines successfully run
DEBUG - 2014-07-09 11:05:31 --> Upload Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Pagination Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Controller Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Helper loaded: form_helper
DEBUG - 2014-07-09 11:05:31 --> Form Validation Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 11:05:31 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 11:05:31 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 11:05:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 11:05:31 --> Final output sent to browser
DEBUG - 2014-07-09 11:05:31 --> Total execution time: 0.1009
DEBUG - 2014-07-09 11:05:33 --> Config Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Hooks Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Utf8 Class Initialized
DEBUG - 2014-07-09 11:05:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 11:05:33 --> URI Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Router Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Output Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Security Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Input Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 11:05:33 --> Language Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Loader Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Helper loaded: url_helper
DEBUG - 2014-07-09 11:05:33 --> Helper loaded: file_helper
DEBUG - 2014-07-09 11:05:33 --> Database Driver Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Session Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Helper loaded: string_helper
DEBUG - 2014-07-09 11:05:33 --> Session routines successfully run
DEBUG - 2014-07-09 11:05:33 --> Upload Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Pagination Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Controller Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Helper loaded: form_helper
DEBUG - 2014-07-09 11:05:33 --> Form Validation Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 11:05:33 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 11:05:33 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 11:05:33 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 11:05:33 --> Final output sent to browser
DEBUG - 2014-07-09 11:05:33 --> Total execution time: 0.0936
DEBUG - 2014-07-09 11:05:38 --> Config Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Hooks Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Utf8 Class Initialized
DEBUG - 2014-07-09 11:05:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 11:05:38 --> URI Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Router Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Output Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Security Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Input Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 11:05:38 --> Language Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Loader Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Helper loaded: url_helper
DEBUG - 2014-07-09 11:05:38 --> Helper loaded: file_helper
DEBUG - 2014-07-09 11:05:38 --> Database Driver Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Session Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Helper loaded: string_helper
DEBUG - 2014-07-09 11:05:38 --> Session routines successfully run
DEBUG - 2014-07-09 11:05:38 --> Upload Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Pagination Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Controller Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Helper loaded: form_helper
DEBUG - 2014-07-09 11:05:38 --> Form Validation Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 11:05:38 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 11:05:38 --> Final output sent to browser
DEBUG - 2014-07-09 11:05:38 --> Total execution time: 0.1537
DEBUG - 2014-07-09 11:05:43 --> Config Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Hooks Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Utf8 Class Initialized
DEBUG - 2014-07-09 11:05:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 11:05:43 --> URI Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Router Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Output Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Security Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Input Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 11:05:43 --> Language Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Loader Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Helper loaded: url_helper
DEBUG - 2014-07-09 11:05:43 --> Helper loaded: file_helper
DEBUG - 2014-07-09 11:05:43 --> Database Driver Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Session Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Helper loaded: string_helper
DEBUG - 2014-07-09 11:05:43 --> Session routines successfully run
DEBUG - 2014-07-09 11:05:43 --> Upload Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Pagination Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Controller Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Helper loaded: form_helper
DEBUG - 2014-07-09 11:05:43 --> Form Validation Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 11:05:43 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 11:05:43 --> Final output sent to browser
DEBUG - 2014-07-09 11:05:43 --> Total execution time: 0.1053
DEBUG - 2014-07-09 11:05:46 --> Config Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Hooks Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Utf8 Class Initialized
DEBUG - 2014-07-09 11:05:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-09 11:05:46 --> URI Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Router Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Output Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Security Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Input Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-09 11:05:46 --> Language Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Loader Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Helper loaded: url_helper
DEBUG - 2014-07-09 11:05:46 --> Helper loaded: file_helper
DEBUG - 2014-07-09 11:05:46 --> Database Driver Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Session Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Helper loaded: string_helper
DEBUG - 2014-07-09 11:05:46 --> Session routines successfully run
DEBUG - 2014-07-09 11:05:46 --> Upload Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Pagination Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Controller Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Helper loaded: form_helper
DEBUG - 2014-07-09 11:05:46 --> Form Validation Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Model Class Initialized
DEBUG - 2014-07-09 11:05:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-09 11:05:46 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-09 11:05:46 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-09 11:05:47 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-09 11:05:47 --> Final output sent to browser
DEBUG - 2014-07-09 11:05:47 --> Total execution time: 0.0996

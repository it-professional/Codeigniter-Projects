<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-19 05:16:18 --> Config Class Initialized
DEBUG - 2014-07-19 05:16:18 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:16:18 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:16:18 --> URI Class Initialized
DEBUG - 2014-07-19 05:16:18 --> Router Class Initialized
DEBUG - 2014-07-19 05:16:18 --> Output Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Security Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Input Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:16:19 --> Language Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Loader Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:16:19 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:16:19 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Session Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:16:19 --> A session cookie was not found.
DEBUG - 2014-07-19 05:16:19 --> Session routines successfully run
DEBUG - 2014-07-19 05:16:19 --> Upload Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Controller Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:16:19 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:16:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:16:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:16:19 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-19 05:16:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:16:19 --> Final output sent to browser
DEBUG - 2014-07-19 05:16:19 --> Total execution time: 0.6987
DEBUG - 2014-07-19 05:16:28 --> Config Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:16:28 --> URI Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Router Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Output Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Security Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Input Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:16:28 --> Language Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Loader Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:16:28 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:16:28 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Session Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:16:28 --> Session routines successfully run
DEBUG - 2014-07-19 05:16:28 --> Upload Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Controller Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:16:28 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:16:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:16:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:16:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-19 05:16:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:16:28 --> Final output sent to browser
DEBUG - 2014-07-19 05:16:28 --> Total execution time: 0.2299
DEBUG - 2014-07-19 05:16:40 --> Config Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:16:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:16:40 --> URI Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Router Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Output Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Security Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Input Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:16:40 --> Language Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Loader Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:16:40 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:16:40 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Session Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:16:40 --> Session routines successfully run
DEBUG - 2014-07-19 05:16:40 --> Upload Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Controller Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:16:40 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Model Class Initialized
DEBUG - 2014-07-19 05:16:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:16:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:16:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:16:40 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:16:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:16:40 --> Final output sent to browser
DEBUG - 2014-07-19 05:16:40 --> Total execution time: 0.1761
DEBUG - 2014-07-19 05:17:12 --> Config Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:17:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:17:12 --> URI Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Router Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Output Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Security Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Input Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:17:12 --> Language Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Loader Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:17:12 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:17:12 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Session Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:17:12 --> Session routines successfully run
DEBUG - 2014-07-19 05:17:12 --> Upload Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Controller Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:17:12 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Model Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Model Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Model Class Initialized
DEBUG - 2014-07-19 05:17:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:17:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:17:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:17:12 --> You did not select a file to upload.
DEBUG - 2014-07-19 05:20:10 --> Config Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:20:10 --> URI Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Router Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Output Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Security Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Input Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:20:10 --> Language Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Loader Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:20:10 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:20:10 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Session Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:20:10 --> Session routines successfully run
DEBUG - 2014-07-19 05:20:10 --> Upload Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Controller Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:20:10 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:20:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:20:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:20:10 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:20:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:20:10 --> Final output sent to browser
DEBUG - 2014-07-19 05:20:10 --> Total execution time: 0.1584
DEBUG - 2014-07-19 05:20:15 --> Config Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:20:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:20:15 --> URI Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Router Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Output Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Security Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Input Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:20:15 --> Language Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Loader Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:20:15 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:20:15 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Session Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:20:15 --> Session routines successfully run
DEBUG - 2014-07-19 05:20:15 --> Upload Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Controller Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:20:15 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:20:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:20:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:20:15 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:20:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:20:15 --> Final output sent to browser
DEBUG - 2014-07-19 05:20:15 --> Total execution time: 0.2033
DEBUG - 2014-07-19 05:20:16 --> Config Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:20:16 --> URI Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Router Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Output Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Security Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Input Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:20:16 --> Language Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Loader Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:20:16 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:20:16 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Session Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:20:16 --> Session routines successfully run
DEBUG - 2014-07-19 05:20:16 --> Upload Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Controller Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:20:16 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:20:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:20:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:20:16 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:20:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:20:16 --> Final output sent to browser
DEBUG - 2014-07-19 05:20:16 --> Total execution time: 0.1615
DEBUG - 2014-07-19 05:20:25 --> Config Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:20:25 --> URI Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Router Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Output Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Security Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Input Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:20:25 --> Language Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Loader Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:20:25 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:20:25 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Session Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:20:25 --> Session routines successfully run
DEBUG - 2014-07-19 05:20:25 --> Upload Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:20:25 --> Controller Class Initialized
DEBUG - 2014-07-19 05:20:26 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:20:26 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:20:26 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:26 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:26 --> Model Class Initialized
DEBUG - 2014-07-19 05:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:20:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:20:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:20:26 --> You did not select a file to upload.
DEBUG - 2014-07-19 05:22:17 --> Config Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:22:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:22:17 --> URI Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Router Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Output Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Security Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Input Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:22:17 --> Language Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Loader Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:22:17 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:22:17 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Session Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:22:17 --> Session routines successfully run
DEBUG - 2014-07-19 05:22:17 --> Upload Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Controller Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:22:17 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:22:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:22:17 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:22:17 --> You did not select a file to upload.
DEBUG - 2014-07-19 05:22:17 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:22:17 --> Final output sent to browser
DEBUG - 2014-07-19 05:22:17 --> Total execution time: 0.1509
DEBUG - 2014-07-19 05:22:58 --> Config Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:22:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:22:58 --> URI Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Router Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Output Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Security Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Input Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:22:58 --> Language Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Loader Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:22:58 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:22:58 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Session Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:22:58 --> Session routines successfully run
DEBUG - 2014-07-19 05:22:58 --> Upload Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Controller Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:22:58 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:22:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:22:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:22:58 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:22:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:22:58 --> Final output sent to browser
DEBUG - 2014-07-19 05:22:58 --> Total execution time: 0.1559
DEBUG - 2014-07-19 05:22:59 --> Config Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:22:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:22:59 --> URI Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Router Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Output Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Security Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Input Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:22:59 --> Language Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Loader Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:22:59 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:22:59 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Session Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:22:59 --> Session routines successfully run
DEBUG - 2014-07-19 05:22:59 --> Upload Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Controller Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:22:59 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Model Class Initialized
DEBUG - 2014-07-19 05:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:22:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:22:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:22:59 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:22:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:22:59 --> Final output sent to browser
DEBUG - 2014-07-19 05:22:59 --> Total execution time: 0.1599
DEBUG - 2014-07-19 05:23:07 --> Config Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:23:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:23:07 --> URI Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Router Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Output Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Security Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Input Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:23:07 --> Language Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Loader Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:23:07 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:23:07 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Session Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:23:07 --> Session routines successfully run
DEBUG - 2014-07-19 05:23:07 --> Upload Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Controller Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:23:07 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Model Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Model Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Model Class Initialized
DEBUG - 2014-07-19 05:23:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:23:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:23:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:23:07 --> You did not select a file to upload.
DEBUG - 2014-07-19 05:23:07 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:23:07 --> Final output sent to browser
DEBUG - 2014-07-19 05:23:07 --> Total execution time: 0.1573
DEBUG - 2014-07-19 05:29:11 --> Config Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:29:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:29:11 --> URI Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Router Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Output Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Security Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Input Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:29:11 --> Language Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Loader Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:29:11 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:29:11 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Session Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:29:11 --> Session routines successfully run
DEBUG - 2014-07-19 05:29:11 --> Upload Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Controller Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:29:11 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:29:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:29:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:29:11 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:29:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:29:11 --> Final output sent to browser
DEBUG - 2014-07-19 05:29:11 --> Total execution time: 0.7219
DEBUG - 2014-07-19 05:29:13 --> Config Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:29:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:29:13 --> URI Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Router Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Output Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Security Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Input Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:29:13 --> Language Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Loader Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:29:13 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:29:13 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Session Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:29:13 --> Session routines successfully run
DEBUG - 2014-07-19 05:29:13 --> Upload Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Controller Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:29:13 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:29:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:29:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:29:13 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:29:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:29:13 --> Final output sent to browser
DEBUG - 2014-07-19 05:29:13 --> Total execution time: 0.1672
DEBUG - 2014-07-19 05:29:23 --> Config Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:29:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:29:23 --> URI Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Router Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Output Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Security Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Input Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:29:23 --> Language Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Loader Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:29:23 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:29:23 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Session Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:29:23 --> Session routines successfully run
DEBUG - 2014-07-19 05:29:23 --> Upload Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Controller Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:29:23 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Model Class Initialized
DEBUG - 2014-07-19 05:29:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:29:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:29:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:29:23 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:29:23 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:29:23 --> Final output sent to browser
DEBUG - 2014-07-19 05:29:23 --> Total execution time: 0.2118
DEBUG - 2014-07-19 05:30:28 --> Config Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:30:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:30:28 --> URI Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Router Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Output Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Security Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Input Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:30:28 --> Language Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Loader Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:30:28 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:30:28 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Session Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:30:28 --> Session routines successfully run
DEBUG - 2014-07-19 05:30:28 --> Upload Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Controller Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:30:28 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:30:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:30:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:30:28 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:30:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:30:28 --> Final output sent to browser
DEBUG - 2014-07-19 05:30:28 --> Total execution time: 0.1666
DEBUG - 2014-07-19 05:30:29 --> Config Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:30:29 --> URI Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Router Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Output Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Security Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Input Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:30:29 --> Language Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Loader Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:30:29 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:30:29 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Session Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:30:29 --> Session routines successfully run
DEBUG - 2014-07-19 05:30:29 --> Upload Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Controller Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:30:29 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:30:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:30:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:30:29 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:30:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:30:29 --> Final output sent to browser
DEBUG - 2014-07-19 05:30:29 --> Total execution time: 0.1507
DEBUG - 2014-07-19 05:30:31 --> Config Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:30:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:30:31 --> URI Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Router Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Output Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Security Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Input Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:30:31 --> Language Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Loader Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:30:31 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:30:31 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Session Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:30:31 --> Session routines successfully run
DEBUG - 2014-07-19 05:30:31 --> Upload Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Controller Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:30:31 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:30:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:30:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:30:31 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:30:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:30:31 --> Final output sent to browser
DEBUG - 2014-07-19 05:30:31 --> Total execution time: 0.1646
DEBUG - 2014-07-19 05:30:44 --> Config Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:30:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:30:44 --> URI Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Router Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Output Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Security Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Input Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:30:44 --> Language Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Loader Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:30:44 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:30:44 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Session Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:30:44 --> Session routines successfully run
DEBUG - 2014-07-19 05:30:44 --> Upload Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Controller Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:30:44 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Model Class Initialized
DEBUG - 2014-07-19 05:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:30:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:30:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:30:44 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:30:44 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:30:44 --> Final output sent to browser
DEBUG - 2014-07-19 05:30:44 --> Total execution time: 0.1913
DEBUG - 2014-07-19 05:33:08 --> Config Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:33:08 --> URI Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Router Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Output Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Security Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Input Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:33:08 --> Language Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Loader Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:33:08 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:33:08 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Session Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:33:08 --> Session routines successfully run
DEBUG - 2014-07-19 05:33:08 --> Upload Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Controller Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:33:08 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:33:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:33:08 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:33:08 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:33:08 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:33:08 --> Final output sent to browser
DEBUG - 2014-07-19 05:33:08 --> Total execution time: 0.2051
DEBUG - 2014-07-19 05:34:28 --> Config Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:34:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:34:28 --> URI Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Router Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Output Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Security Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Input Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:34:28 --> Language Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Loader Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:34:28 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:34:28 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Session Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:34:28 --> Session routines successfully run
DEBUG - 2014-07-19 05:34:28 --> Upload Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Controller Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:34:28 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:34:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:34:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:34:28 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:34:28 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:34:28 --> Final output sent to browser
DEBUG - 2014-07-19 05:34:28 --> Total execution time: 0.1908
DEBUG - 2014-07-19 05:34:43 --> Config Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:34:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:34:43 --> URI Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Router Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Output Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Security Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Input Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:34:43 --> Language Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Loader Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:34:43 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:34:43 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Session Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:34:43 --> Session routines successfully run
DEBUG - 2014-07-19 05:34:43 --> Upload Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Controller Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:34:43 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:34:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:34:43 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:34:43 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:34:43 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:34:43 --> Final output sent to browser
DEBUG - 2014-07-19 05:34:43 --> Total execution time: 0.2543
DEBUG - 2014-07-19 05:34:52 --> Config Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:34:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:34:52 --> URI Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Router Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Output Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Security Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Input Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:34:52 --> Language Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Loader Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:34:52 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:34:52 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Session Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:34:52 --> Session routines successfully run
DEBUG - 2014-07-19 05:34:52 --> Upload Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Controller Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:34:52 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:34:52 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-19 05:34:52 --> Final output sent to browser
DEBUG - 2014-07-19 05:34:52 --> Total execution time: 0.1848
DEBUG - 2014-07-19 05:34:58 --> Config Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:34:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:34:58 --> URI Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Router Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Output Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Security Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Input Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:34:58 --> Language Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Loader Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:34:58 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:34:58 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Session Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:34:58 --> Session routines successfully run
DEBUG - 2014-07-19 05:34:58 --> Upload Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Controller Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:34:58 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:34:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:34:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:34:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:34:58 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-19 05:34:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:34:58 --> Final output sent to browser
DEBUG - 2014-07-19 05:34:58 --> Total execution time: 0.2077
DEBUG - 2014-07-19 05:35:00 --> Config Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:35:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:35:00 --> URI Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Router Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Output Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Security Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Input Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:35:00 --> Language Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Loader Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:35:00 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:35:00 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Session Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:35:00 --> Session routines successfully run
DEBUG - 2014-07-19 05:35:00 --> Upload Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Controller Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:35:00 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Model Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Model Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Model Class Initialized
DEBUG - 2014-07-19 05:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:35:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:35:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:35:00 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:35:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:35:00 --> Final output sent to browser
DEBUG - 2014-07-19 05:35:00 --> Total execution time: 0.1803
DEBUG - 2014-07-19 05:35:09 --> Config Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:35:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:35:09 --> URI Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Router Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Output Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Security Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Input Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:35:09 --> Language Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Loader Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:35:09 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:35:09 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Session Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:35:09 --> Session routines successfully run
DEBUG - 2014-07-19 05:35:09 --> Upload Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Controller Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:35:09 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Model Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Model Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Model Class Initialized
DEBUG - 2014-07-19 05:35:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:35:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:35:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:35:09 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:35:09 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:35:09 --> Final output sent to browser
DEBUG - 2014-07-19 05:35:09 --> Total execution time: 0.2050
DEBUG - 2014-07-19 05:37:28 --> Config Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:37:28 --> URI Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Router Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Output Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Security Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Input Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:37:28 --> Language Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Loader Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:37:28 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:37:28 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Session Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:37:28 --> Session routines successfully run
DEBUG - 2014-07-19 05:37:28 --> Upload Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Controller Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:37:28 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:37:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:37:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:37:28 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:37:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:37:28 --> Final output sent to browser
DEBUG - 2014-07-19 05:37:28 --> Total execution time: 0.1773
DEBUG - 2014-07-19 05:37:30 --> Config Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:37:30 --> URI Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Router Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Output Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Security Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Input Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:37:30 --> Language Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Loader Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:37:30 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:37:30 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Session Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:37:30 --> Session routines successfully run
DEBUG - 2014-07-19 05:37:30 --> Upload Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Controller Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:37:30 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:37:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:37:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:37:30 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:37:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:37:30 --> Final output sent to browser
DEBUG - 2014-07-19 05:37:30 --> Total execution time: 0.1600
DEBUG - 2014-07-19 05:37:37 --> Config Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:37:37 --> URI Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Router Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Output Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Security Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Input Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:37:37 --> Language Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Loader Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:37:37 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:37:37 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Session Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:37:37 --> Session routines successfully run
DEBUG - 2014-07-19 05:37:37 --> Upload Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Controller Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:37:37 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:37:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:37:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:37:37 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:37:37 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:37:37 --> Final output sent to browser
DEBUG - 2014-07-19 05:37:37 --> Total execution time: 0.1891
DEBUG - 2014-07-19 05:37:58 --> Config Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:37:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:37:58 --> URI Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Router Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Output Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Security Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Input Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:37:58 --> Language Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Loader Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:37:58 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:37:58 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Session Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:37:58 --> Session routines successfully run
DEBUG - 2014-07-19 05:37:58 --> Upload Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Controller Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:37:58 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Model Class Initialized
DEBUG - 2014-07-19 05:37:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:37:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:37:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:37:58 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:37:58 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:37:58 --> Final output sent to browser
DEBUG - 2014-07-19 05:37:58 --> Total execution time: 0.1644
DEBUG - 2014-07-19 05:38:53 --> Config Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:38:53 --> URI Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Router Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Output Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Security Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Input Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:38:53 --> Language Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Loader Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:38:53 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:38:53 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Session Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:38:53 --> Session routines successfully run
DEBUG - 2014-07-19 05:38:53 --> Upload Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Controller Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:38:53 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Model Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Model Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Model Class Initialized
DEBUG - 2014-07-19 05:38:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:38:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:38:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:38:53 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:38:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:38:53 --> Final output sent to browser
DEBUG - 2014-07-19 05:38:53 --> Total execution time: 0.1687
DEBUG - 2014-07-19 05:38:54 --> Config Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:38:54 --> URI Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Router Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Output Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Security Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Input Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:38:54 --> Language Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Loader Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:38:54 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:38:54 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Session Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:38:54 --> Session routines successfully run
DEBUG - 2014-07-19 05:38:54 --> Upload Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Controller Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:38:54 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Model Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Model Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Model Class Initialized
DEBUG - 2014-07-19 05:38:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:38:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:38:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:38:54 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:38:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:38:54 --> Final output sent to browser
DEBUG - 2014-07-19 05:38:54 --> Total execution time: 0.1509
DEBUG - 2014-07-19 05:39:10 --> Config Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:39:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:39:10 --> URI Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Router Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Output Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Security Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Input Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:39:10 --> Language Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Loader Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:39:10 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:39:10 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Session Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:39:10 --> Session routines successfully run
DEBUG - 2014-07-19 05:39:10 --> Upload Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Controller Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:39:10 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Model Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Model Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Model Class Initialized
DEBUG - 2014-07-19 05:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:39:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:39:10 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:39:10 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:39:10 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:39:10 --> Final output sent to browser
DEBUG - 2014-07-19 05:39:10 --> Total execution time: 0.1832
DEBUG - 2014-07-19 05:39:21 --> Config Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:39:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:39:21 --> URI Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Router Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Output Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Security Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Input Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:39:21 --> Language Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Loader Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:39:21 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:39:21 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Session Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:39:21 --> Session routines successfully run
DEBUG - 2014-07-19 05:39:21 --> Upload Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Controller Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:39:21 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Model Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Model Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Model Class Initialized
DEBUG - 2014-07-19 05:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:39:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:39:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:39:21 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:39:21 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:39:21 --> Final output sent to browser
DEBUG - 2014-07-19 05:39:21 --> Total execution time: 0.1641
DEBUG - 2014-07-19 05:41:30 --> Config Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:41:30 --> URI Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Router Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Output Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Security Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Input Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:41:30 --> Language Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Loader Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:41:30 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:41:30 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Session Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:41:30 --> Session routines successfully run
DEBUG - 2014-07-19 05:41:30 --> Upload Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Controller Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:41:30 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:41:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:41:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:41:30 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:41:30 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:52:50 --> Config Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:52:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:52:50 --> URI Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Router Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Output Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Security Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Input Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:52:50 --> Language Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Loader Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:52:50 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:52:50 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Session Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:52:50 --> Session routines successfully run
DEBUG - 2014-07-19 05:52:50 --> Upload Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Controller Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:52:50 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Model Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Model Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Model Class Initialized
DEBUG - 2014-07-19 05:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:52:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:52:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:52:50 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:52:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:52:50 --> Final output sent to browser
DEBUG - 2014-07-19 05:52:50 --> Total execution time: 0.1693
DEBUG - 2014-07-19 05:52:52 --> Config Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:52:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:52:52 --> URI Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Router Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Output Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Security Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Input Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:52:52 --> Language Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Loader Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:52:52 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:52:52 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Session Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:52:52 --> Session routines successfully run
DEBUG - 2014-07-19 05:52:52 --> Upload Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Controller Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:52:52 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Model Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Model Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Model Class Initialized
DEBUG - 2014-07-19 05:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:52:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:52:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:52:52 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:52:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:52:52 --> Final output sent to browser
DEBUG - 2014-07-19 05:52:52 --> Total execution time: 0.1767
DEBUG - 2014-07-19 05:53:03 --> Config Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:53:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:53:03 --> URI Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Router Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Output Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Security Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Input Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:53:03 --> Language Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Loader Class Initialized
DEBUG - 2014-07-19 05:53:03 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:53:03 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:53:03 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Session Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:53:04 --> Session routines successfully run
DEBUG - 2014-07-19 05:53:04 --> Upload Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Controller Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:53:04 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Model Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Model Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Model Class Initialized
DEBUG - 2014-07-19 05:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:53:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:53:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:53:04 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:53:04 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:53:04 --> Final output sent to browser
DEBUG - 2014-07-19 05:53:04 --> Total execution time: 0.1791
DEBUG - 2014-07-19 05:54:22 --> Config Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:54:22 --> URI Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Router Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Output Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Security Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Input Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:54:22 --> Language Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Loader Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:54:22 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:54:22 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Session Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:54:22 --> Session routines successfully run
DEBUG - 2014-07-19 05:54:22 --> Upload Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Controller Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:54:22 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:54:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:54:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:54:22 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:54:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:54:22 --> Final output sent to browser
DEBUG - 2014-07-19 05:54:22 --> Total execution time: 0.1748
DEBUG - 2014-07-19 05:54:23 --> Config Class Initialized
DEBUG - 2014-07-19 05:54:23 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:54:23 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:54:24 --> URI Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Router Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Output Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Security Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Input Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:54:24 --> Language Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Loader Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:54:24 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:54:24 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Session Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:54:24 --> Session routines successfully run
DEBUG - 2014-07-19 05:54:24 --> Upload Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Controller Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:54:24 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:54:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:54:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:54:24 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:54:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:54:24 --> Final output sent to browser
DEBUG - 2014-07-19 05:54:24 --> Total execution time: 0.2013
DEBUG - 2014-07-19 05:54:30 --> Config Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:54:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:54:30 --> URI Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Router Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Output Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Security Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Input Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:54:30 --> Language Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Loader Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:54:30 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:54:30 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Session Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:54:30 --> Session routines successfully run
DEBUG - 2014-07-19 05:54:30 --> Upload Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Controller Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:54:30 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:54:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:54:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:54:31 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:54:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:54:31 --> Final output sent to browser
DEBUG - 2014-07-19 05:54:31 --> Total execution time: 0.1503
DEBUG - 2014-07-19 05:54:38 --> Config Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:54:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:54:38 --> URI Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Router Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Output Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Security Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Input Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:54:38 --> Language Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Loader Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:54:38 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:54:38 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Session Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:54:38 --> Session routines successfully run
DEBUG - 2014-07-19 05:54:38 --> Upload Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Controller Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:54:38 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Model Class Initialized
DEBUG - 2014-07-19 05:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:54:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:54:38 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:54:38 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:54:38 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:54:38 --> Final output sent to browser
DEBUG - 2014-07-19 05:54:38 --> Total execution time: 0.1630
DEBUG - 2014-07-19 05:56:06 --> Config Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:56:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:56:06 --> URI Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Router Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Output Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Security Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Input Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:56:06 --> Language Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Loader Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:56:06 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:56:06 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Session Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:56:06 --> Session routines successfully run
DEBUG - 2014-07-19 05:56:06 --> Upload Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Controller Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:56:06 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:56:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:56:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:56:06 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:56:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:56:06 --> Final output sent to browser
DEBUG - 2014-07-19 05:56:06 --> Total execution time: 0.1477
DEBUG - 2014-07-19 05:56:07 --> Config Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:56:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:56:07 --> URI Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Router Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Output Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Security Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Input Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:56:07 --> Language Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Loader Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:56:07 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:56:07 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Session Class Initialized
DEBUG - 2014-07-19 05:56:07 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:56:08 --> Session routines successfully run
DEBUG - 2014-07-19 05:56:08 --> Upload Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Controller Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:56:08 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:56:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:56:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:56:08 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:56:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:56:08 --> Final output sent to browser
DEBUG - 2014-07-19 05:56:08 --> Total execution time: 0.2299
DEBUG - 2014-07-19 05:56:16 --> Config Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:56:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:56:16 --> URI Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Router Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Output Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Security Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Input Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:56:16 --> Language Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Loader Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:56:16 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:56:16 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Session Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:56:16 --> Session routines successfully run
DEBUG - 2014-07-19 05:56:16 --> Upload Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Controller Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:56:16 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Model Class Initialized
DEBUG - 2014-07-19 05:56:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:56:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:56:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:56:16 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:56:16 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:56:16 --> Final output sent to browser
DEBUG - 2014-07-19 05:56:16 --> Total execution time: 0.1539
DEBUG - 2014-07-19 05:59:02 --> Config Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:59:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:59:02 --> URI Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Router Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Output Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Security Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Input Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:59:02 --> Language Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Loader Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:59:02 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:59:02 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Session Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:59:02 --> Session routines successfully run
DEBUG - 2014-07-19 05:59:02 --> Upload Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Controller Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:59:02 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:59:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:59:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:59:02 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:59:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:59:02 --> Final output sent to browser
DEBUG - 2014-07-19 05:59:02 --> Total execution time: 0.1937
DEBUG - 2014-07-19 05:59:06 --> Config Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:59:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:59:06 --> URI Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Router Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Output Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Security Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Input Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:59:06 --> Language Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Loader Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:59:06 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:59:06 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Session Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:59:06 --> Session routines successfully run
DEBUG - 2014-07-19 05:59:06 --> Upload Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Controller Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:59:06 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:59:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:59:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:59:06 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:59:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:59:06 --> Final output sent to browser
DEBUG - 2014-07-19 05:59:06 --> Total execution time: 0.1891
DEBUG - 2014-07-19 05:59:08 --> Config Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:59:08 --> URI Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Router Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Output Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Security Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Input Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:59:08 --> Language Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Loader Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:59:08 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:59:08 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Session Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:59:08 --> Session routines successfully run
DEBUG - 2014-07-19 05:59:08 --> Upload Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Controller Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:59:08 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:59:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 05:59:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 05:59:08 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:59:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 05:59:08 --> Final output sent to browser
DEBUG - 2014-07-19 05:59:08 --> Total execution time: 0.1746
DEBUG - 2014-07-19 05:59:15 --> Config Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Hooks Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Utf8 Class Initialized
DEBUG - 2014-07-19 05:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 05:59:15 --> URI Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Router Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Output Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Security Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Input Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 05:59:15 --> Language Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Loader Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Helper loaded: url_helper
DEBUG - 2014-07-19 05:59:15 --> Helper loaded: file_helper
DEBUG - 2014-07-19 05:59:15 --> Database Driver Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Session Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Helper loaded: string_helper
DEBUG - 2014-07-19 05:59:15 --> Session routines successfully run
DEBUG - 2014-07-19 05:59:15 --> Upload Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Pagination Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Controller Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Helper loaded: form_helper
DEBUG - 2014-07-19 05:59:15 --> Form Validation Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Model Class Initialized
DEBUG - 2014-07-19 05:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:59:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 05:59:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 05:59:15 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 05:59:15 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 05:59:15 --> Final output sent to browser
DEBUG - 2014-07-19 05:59:15 --> Total execution time: 0.1729
DEBUG - 2014-07-19 06:06:28 --> Config Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:06:28 --> URI Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Router Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Output Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Security Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Input Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:06:28 --> Language Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Loader Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:06:28 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:06:28 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Session Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:06:28 --> Session routines successfully run
DEBUG - 2014-07-19 06:06:28 --> Upload Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Controller Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:06:28 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Model Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Model Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Model Class Initialized
DEBUG - 2014-07-19 06:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:06:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:06:49 --> Config Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:06:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:06:49 --> URI Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Router Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Output Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Security Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Input Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:06:49 --> Language Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Loader Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:06:49 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:06:49 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Session Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:06:49 --> Session routines successfully run
DEBUG - 2014-07-19 06:06:49 --> Upload Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Controller Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:06:49 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:06:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:07:24 --> Config Class Initialized
DEBUG - 2014-07-19 06:07:24 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:07:24 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:07:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:07:24 --> URI Class Initialized
DEBUG - 2014-07-19 06:07:24 --> Router Class Initialized
DEBUG - 2014-07-19 06:07:24 --> Output Class Initialized
DEBUG - 2014-07-19 06:07:24 --> Security Class Initialized
DEBUG - 2014-07-19 06:07:24 --> Input Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:07:25 --> Language Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Loader Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:07:25 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:07:25 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Session Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:07:25 --> Session routines successfully run
DEBUG - 2014-07-19 06:07:25 --> Upload Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Controller Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:07:25 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Model Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Model Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Model Class Initialized
DEBUG - 2014-07-19 06:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:07:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:09:26 --> Config Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:09:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:09:26 --> URI Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Router Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Output Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Security Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Input Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:09:26 --> Language Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Loader Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:09:26 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:09:26 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Session Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:09:26 --> Session routines successfully run
DEBUG - 2014-07-19 06:09:26 --> Upload Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Controller Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:09:26 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Model Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Model Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Model Class Initialized
DEBUG - 2014-07-19 06:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:09:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:09:46 --> Config Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:09:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:09:46 --> URI Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Router Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Output Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Security Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Input Class Initialized
DEBUG - 2014-07-19 06:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:09:46 --> Language Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Loader Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:09:47 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:09:47 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Session Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:09:47 --> Session routines successfully run
DEBUG - 2014-07-19 06:09:47 --> Upload Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Controller Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:09:47 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Model Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Model Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Model Class Initialized
DEBUG - 2014-07-19 06:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:09:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:09:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-07-19 06:09:47 --> The upload path does not appear to be valid.
DEBUG - 2014-07-19 06:09:47 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:09:47 --> Final output sent to browser
DEBUG - 2014-07-19 06:09:47 --> Total execution time: 0.1716
DEBUG - 2014-07-19 06:10:51 --> Config Class Initialized
DEBUG - 2014-07-19 06:10:51 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:10:51 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:10:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:10:52 --> URI Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Router Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Output Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Security Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Input Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:10:52 --> Language Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Loader Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:10:52 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:10:52 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Session Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:10:52 --> Session routines successfully run
DEBUG - 2014-07-19 06:10:52 --> Upload Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Controller Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:10:52 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Model Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Model Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Model Class Initialized
DEBUG - 2014-07-19 06:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:10:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:10:52 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:10:52 --> Final output sent to browser
DEBUG - 2014-07-19 06:10:52 --> Total execution time: 0.2352
DEBUG - 2014-07-19 06:11:49 --> Config Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:11:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:11:49 --> URI Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Router Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Output Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Security Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Input Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:11:49 --> Language Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Loader Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:11:49 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:11:49 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Session Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:11:49 --> Session routines successfully run
DEBUG - 2014-07-19 06:11:49 --> Upload Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Controller Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:11:49 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:11:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:11:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:11:49 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:11:49 --> Final output sent to browser
DEBUG - 2014-07-19 06:11:49 --> Total execution time: 0.1689
DEBUG - 2014-07-19 06:19:14 --> Config Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:19:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:19:14 --> URI Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Router Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Output Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Security Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Input Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:19:14 --> Language Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Loader Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:19:14 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:19:14 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Session Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:19:14 --> Session routines successfully run
DEBUG - 2014-07-19 06:19:14 --> Upload Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Controller Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:19:14 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:19:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 06:19:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 06:19:14 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:19:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 06:19:14 --> Final output sent to browser
DEBUG - 2014-07-19 06:19:14 --> Total execution time: 0.1572
DEBUG - 2014-07-19 06:19:25 --> Config Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:19:25 --> URI Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Router Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Output Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Security Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Input Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:19:25 --> Language Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Loader Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:19:25 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:19:25 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Session Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:19:25 --> Session routines successfully run
DEBUG - 2014-07-19 06:19:25 --> Upload Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Controller Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:19:25 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:19:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:19:25 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:19:25 --> Final output sent to browser
DEBUG - 2014-07-19 06:19:25 --> Total execution time: 0.1648
DEBUG - 2014-07-19 06:19:49 --> Config Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:19:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:19:49 --> URI Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Router Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Output Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Security Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Input Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:19:49 --> Language Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Loader Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:19:49 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:19:49 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Session Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:19:49 --> Session routines successfully run
DEBUG - 2014-07-19 06:19:49 --> Upload Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Controller Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:19:49 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:19:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 06:19:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 06:19:49 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:19:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 06:19:49 --> Final output sent to browser
DEBUG - 2014-07-19 06:19:49 --> Total execution time: 0.1735
DEBUG - 2014-07-19 06:19:52 --> Config Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:19:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:19:52 --> URI Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Router Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Output Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Security Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Input Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:19:52 --> Language Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Loader Class Initialized
DEBUG - 2014-07-19 06:19:52 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:19:52 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:19:53 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Session Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:19:53 --> Session routines successfully run
DEBUG - 2014-07-19 06:19:53 --> Upload Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Controller Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:19:53 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Model Class Initialized
DEBUG - 2014-07-19 06:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:19:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 06:19:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 06:19:53 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:19:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 06:19:53 --> Final output sent to browser
DEBUG - 2014-07-19 06:19:53 --> Total execution time: 0.1766
DEBUG - 2014-07-19 06:20:03 --> Config Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:20:03 --> URI Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Router Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Output Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Security Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Input Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:20:03 --> Language Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Loader Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:20:03 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:20:03 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Session Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:20:03 --> Session routines successfully run
DEBUG - 2014-07-19 06:20:03 --> Upload Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Controller Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:20:03 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Model Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Model Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Model Class Initialized
DEBUG - 2014-07-19 06:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:20:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:20:03 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:20:03 --> Final output sent to browser
DEBUG - 2014-07-19 06:20:03 --> Total execution time: 0.1697
DEBUG - 2014-07-19 06:25:15 --> Config Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:25:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:25:15 --> URI Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Router Class Initialized
DEBUG - 2014-07-19 06:25:15 --> No URI present. Default controller set.
DEBUG - 2014-07-19 06:25:15 --> Output Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Security Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Input Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:25:15 --> Language Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Loader Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:25:15 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:25:15 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Session Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:25:15 --> Session routines successfully run
DEBUG - 2014-07-19 06:25:15 --> Upload Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:25:15 --> Controller Class Initialized
DEBUG - 2014-07-19 06:25:15 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-19 06:25:15 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-19 06:25:15 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-19 06:25:15 --> Final output sent to browser
DEBUG - 2014-07-19 06:25:15 --> Total execution time: 0.1400
DEBUG - 2014-07-19 06:45:56 --> Config Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:45:56 --> URI Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Router Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Output Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Security Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Input Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:45:56 --> Language Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Loader Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:45:56 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:45:56 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Session Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:45:56 --> Session routines successfully run
DEBUG - 2014-07-19 06:45:56 --> Upload Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Controller Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:45:56 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Model Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Model Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Model Class Initialized
DEBUG - 2014-07-19 06:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:45:56 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-07-19 06:45:56 --> Severity: Notice  --> Undefined variable: upload_data C:\wamp\www\hostorks\application\controllers\superadmin.php 183
DEBUG - 2014-07-19 06:46:53 --> Config Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:46:53 --> URI Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Router Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Output Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Security Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Input Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:46:53 --> Language Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Loader Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:46:53 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:46:53 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Session Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:46:53 --> Session routines successfully run
DEBUG - 2014-07-19 06:46:53 --> Upload Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Controller Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:46:53 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Model Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Model Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Model Class Initialized
DEBUG - 2014-07-19 06:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:46:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:48:12 --> Config Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:48:12 --> URI Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Router Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Output Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Security Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Input Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:48:12 --> Language Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Loader Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:48:12 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:48:12 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Session Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:48:12 --> Session routines successfully run
DEBUG - 2014-07-19 06:48:12 --> Upload Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Controller Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:48:12 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Model Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Model Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Model Class Initialized
DEBUG - 2014-07-19 06:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:48:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:49:03 --> Config Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:49:03 --> URI Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Router Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Output Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Security Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Input Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:49:03 --> Language Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Loader Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:49:03 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:49:03 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Session Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:49:03 --> Session routines successfully run
DEBUG - 2014-07-19 06:49:03 --> Upload Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Controller Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:49:03 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:49:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 06:49:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 06:49:03 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:49:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 06:49:03 --> Final output sent to browser
DEBUG - 2014-07-19 06:49:03 --> Total execution time: 0.1823
DEBUG - 2014-07-19 06:49:04 --> Config Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:49:04 --> URI Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Router Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Output Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Security Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Input Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:49:04 --> Language Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Loader Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:49:04 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:49:04 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Session Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:49:04 --> Session routines successfully run
DEBUG - 2014-07-19 06:49:04 --> Upload Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Controller Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:49:04 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:49:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 06:49:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 06:49:04 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:49:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 06:49:04 --> Final output sent to browser
DEBUG - 2014-07-19 06:49:04 --> Total execution time: 0.1691
DEBUG - 2014-07-19 06:49:11 --> Config Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:49:11 --> URI Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Router Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Output Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Security Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Input Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:49:11 --> Language Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Loader Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:49:11 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Session Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:49:11 --> Session routines successfully run
DEBUG - 2014-07-19 06:49:11 --> Upload Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Controller Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:49:11 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:49:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:49:11 --> Config Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Hooks Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Utf8 Class Initialized
DEBUG - 2014-07-19 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 06:49:11 --> URI Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Router Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Output Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Security Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Input Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 06:49:11 --> Language Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Loader Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: url_helper
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: file_helper
DEBUG - 2014-07-19 06:49:11 --> Database Driver Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Session Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: string_helper
DEBUG - 2014-07-19 06:49:11 --> Session routines successfully run
DEBUG - 2014-07-19 06:49:11 --> Upload Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Pagination Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Controller Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Helper loaded: form_helper
DEBUG - 2014-07-19 06:49:11 --> Form Validation Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Model Class Initialized
DEBUG - 2014-07-19 06:49:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 06:49:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 06:49:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 06:49:11 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 06:49:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 06:49:11 --> Final output sent to browser
DEBUG - 2014-07-19 06:49:11 --> Total execution time: 0.1596
DEBUG - 2014-07-19 07:08:16 --> Config Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:08:16 --> URI Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Router Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Output Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Security Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Input Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:08:16 --> Language Class Initialized
DEBUG - 2014-07-19 07:08:16 --> Loader Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:08:17 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:08:17 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Session Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:08:17 --> Session routines successfully run
DEBUG - 2014-07-19 07:08:17 --> Upload Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Controller Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:08:17 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Model Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Model Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Model Class Initialized
DEBUG - 2014-07-19 07:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:08:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:08:17 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-19 07:08:17 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\hostorks\application\views\superadmin\footer_manage.php 18
DEBUG - 2014-07-19 07:08:17 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:08:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:08:17 --> Final output sent to browser
DEBUG - 2014-07-19 07:08:17 --> Total execution time: 0.7044
DEBUG - 2014-07-19 07:09:08 --> Config Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:09:08 --> URI Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Router Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Output Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Security Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Input Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:09:08 --> Language Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Loader Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:09:08 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:09:08 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Session Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:09:08 --> Session routines successfully run
DEBUG - 2014-07-19 07:09:08 --> Upload Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Controller Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:09:08 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Model Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Model Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Model Class Initialized
DEBUG - 2014-07-19 07:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:09:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:09:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:09:08 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:09:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:09:08 --> Final output sent to browser
DEBUG - 2014-07-19 07:09:08 --> Total execution time: 0.1809
DEBUG - 2014-07-19 07:10:05 --> Config Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:10:05 --> URI Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Router Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Output Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Security Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Input Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:10:05 --> Language Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Loader Class Initialized
DEBUG - 2014-07-19 07:10:05 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:10:05 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:10:06 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Session Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:10:06 --> Session routines successfully run
DEBUG - 2014-07-19 07:10:06 --> Upload Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Controller Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:10:06 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Model Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Model Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Model Class Initialized
DEBUG - 2014-07-19 07:10:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:10:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:10:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:10:06 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:10:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:10:06 --> Final output sent to browser
DEBUG - 2014-07-19 07:10:06 --> Total execution time: 0.1934
DEBUG - 2014-07-19 07:11:10 --> Config Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:11:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:11:10 --> URI Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Router Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Output Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Security Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Input Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:11:10 --> Language Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Loader Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:11:10 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:11:10 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Session Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:11:10 --> Session routines successfully run
DEBUG - 2014-07-19 07:11:10 --> Upload Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Controller Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:11:10 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:11:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:11:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:11:10 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:11:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:11:10 --> Final output sent to browser
DEBUG - 2014-07-19 07:11:10 --> Total execution time: 0.1867
DEBUG - 2014-07-19 07:11:38 --> Config Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:11:38 --> URI Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Router Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Output Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Security Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Input Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:11:38 --> Language Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Loader Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:11:38 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:11:38 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Session Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:11:38 --> Session routines successfully run
DEBUG - 2014-07-19 07:11:38 --> Upload Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Controller Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:11:38 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Model Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Model Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Model Class Initialized
DEBUG - 2014-07-19 07:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:11:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:11:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:11:38 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:11:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:11:38 --> Final output sent to browser
DEBUG - 2014-07-19 07:11:38 --> Total execution time: 0.2285
DEBUG - 2014-07-19 07:12:03 --> Config Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:12:03 --> URI Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Router Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Output Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Security Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Input Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:12:03 --> Language Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Loader Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:12:03 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:12:03 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Session Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:12:03 --> Session routines successfully run
DEBUG - 2014-07-19 07:12:03 --> Upload Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Controller Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:12:03 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Model Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Model Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Model Class Initialized
DEBUG - 2014-07-19 07:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:12:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:12:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:12:03 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:12:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:12:03 --> Final output sent to browser
DEBUG - 2014-07-19 07:12:03 --> Total execution time: 0.2541
DEBUG - 2014-07-19 07:19:13 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:13 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:13 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:13 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:13 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:13 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:13 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:13 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:13 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:13 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:13 --> Total execution time: 0.1761
DEBUG - 2014-07-19 07:19:17 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:17 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:17 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:17 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:17 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:17 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:17 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:17 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:17 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:17 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:17 --> Total execution time: 0.1516
DEBUG - 2014-07-19 07:19:18 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:18 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:18 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:18 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:18 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:18 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:18 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:18 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:18 --> Total execution time: 0.1774
DEBUG - 2014-07-19 07:19:18 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:18 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:18 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:18 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:18 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:18 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:18 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:18 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:18 --> Total execution time: 0.1767
DEBUG - 2014-07-19 07:19:18 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:18 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:18 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:18 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:18 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:18 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:18 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:18 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:18 --> Total execution time: 0.1677
DEBUG - 2014-07-19 07:19:18 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:18 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:19 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:19 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:19 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:19 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:19 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:19 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:19 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:19 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:19 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:19 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:19 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:19 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:19 --> Total execution time: 0.1739
DEBUG - 2014-07-19 07:19:19 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:19 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:19 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:19 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:19 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:19 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:19 --> Total execution time: 0.2062
DEBUG - 2014-07-19 07:19:19 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:19 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:19 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:19 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:19 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:19 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:19 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:19 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:19 --> Total execution time: 0.1794
DEBUG - 2014-07-19 07:19:19 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:19 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:19 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:19 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:19 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:19 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:19 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:19 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:19 --> Total execution time: 0.1976
DEBUG - 2014-07-19 07:19:19 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:19 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:19 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:19 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:19 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:19 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:19 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:19 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:19 --> Total execution time: 0.1644
DEBUG - 2014-07-19 07:19:31 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:31 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:31 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:31 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:31 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:31 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:31 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:31 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:31 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:31 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:31 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:31 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:31 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:31 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:31 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:31 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:31 --> Total execution time: 0.1892
DEBUG - 2014-07-19 07:19:43 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:43 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:43 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:43 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:43 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:43 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:43 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:43 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-19 07:19:43 --> Severity: Notice  --> Undefined variable: menuid C:\wamp\www\hostorks\application\models\superadmin_model.php 108
DEBUG - 2014-07-19 07:19:44 --> Config Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:19:44 --> URI Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Router Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Output Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Security Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Input Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:19:44 --> Language Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Loader Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:19:44 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:19:44 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Session Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:19:44 --> Session routines successfully run
DEBUG - 2014-07-19 07:19:44 --> Upload Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Controller Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:19:44 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Model Class Initialized
DEBUG - 2014-07-19 07:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:19:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:19:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:19:44 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:19:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:19:44 --> Final output sent to browser
DEBUG - 2014-07-19 07:19:44 --> Total execution time: 0.1686
DEBUG - 2014-07-19 07:20:50 --> Config Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:20:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:20:50 --> URI Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Router Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Output Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Security Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Input Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:20:50 --> Language Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Loader Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:20:50 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:20:50 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Session Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:20:50 --> Session routines successfully run
DEBUG - 2014-07-19 07:20:50 --> Upload Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Controller Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:20:50 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Model Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Model Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Model Class Initialized
DEBUG - 2014-07-19 07:20:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:20:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:20:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:20:50 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:20:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:20:50 --> Final output sent to browser
DEBUG - 2014-07-19 07:20:50 --> Total execution time: 0.2093
DEBUG - 2014-07-19 07:22:01 --> Config Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:22:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:22:01 --> URI Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Router Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Output Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Security Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Input Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:22:01 --> Language Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Loader Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:22:01 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:22:01 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Session Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:22:01 --> Session routines successfully run
DEBUG - 2014-07-19 07:22:01 --> Upload Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:22:01 --> Controller Class Initialized
DEBUG - 2014-07-19 07:22:02 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:22:02 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:22:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:22:31 --> Config Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:22:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:22:31 --> URI Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Router Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Output Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Security Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Input Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:22:31 --> Language Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Loader Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:22:31 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:22:31 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Session Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:22:31 --> Session routines successfully run
DEBUG - 2014-07-19 07:22:31 --> Upload Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Controller Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:22:31 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:22:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:22:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:22:31 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:22:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:22:31 --> Final output sent to browser
DEBUG - 2014-07-19 07:22:31 --> Total execution time: 0.1745
DEBUG - 2014-07-19 07:22:37 --> Config Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:22:37 --> URI Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Router Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Output Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Security Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Input Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:22:37 --> Language Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Loader Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:22:37 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:22:37 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Session Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:22:37 --> Session routines successfully run
DEBUG - 2014-07-19 07:22:37 --> Upload Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Controller Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:22:37 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:22:38 --> Config Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:22:38 --> URI Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Router Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Output Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Security Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Input Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:22:38 --> Language Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Loader Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:22:38 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:22:38 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Session Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:22:38 --> Session routines successfully run
DEBUG - 2014-07-19 07:22:38 --> Upload Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Controller Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:22:38 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Model Class Initialized
DEBUG - 2014-07-19 07:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:22:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:22:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:22:38 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:22:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:22:38 --> Final output sent to browser
DEBUG - 2014-07-19 07:22:38 --> Total execution time: 0.1715
DEBUG - 2014-07-19 07:23:02 --> Config Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:23:02 --> URI Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Router Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Output Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Security Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Input Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:23:02 --> Language Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Loader Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:23:02 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Session Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:23:02 --> Session routines successfully run
DEBUG - 2014-07-19 07:23:02 --> Upload Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Controller Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:23:02 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:02 --> Config Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:23:02 --> URI Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Router Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Output Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Security Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Input Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:23:02 --> Language Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Loader Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:23:02 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Session Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:23:02 --> Session routines successfully run
DEBUG - 2014-07-19 07:23:02 --> Upload Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Controller Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:23:02 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:23:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:23:02 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:23:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:23:02 --> Final output sent to browser
DEBUG - 2014-07-19 07:23:02 --> Total execution time: 0.1537
DEBUG - 2014-07-19 07:23:10 --> Config Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:23:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:23:10 --> URI Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Router Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Output Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Security Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Input Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:23:10 --> Language Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Loader Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:23:10 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:23:10 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Session Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:23:10 --> Session routines successfully run
DEBUG - 2014-07-19 07:23:10 --> Upload Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Controller Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:23:10 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:10 --> Config Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:23:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:23:10 --> URI Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Router Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Output Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Security Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Input Class Initialized
DEBUG - 2014-07-19 07:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:23:10 --> Language Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Loader Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:23:11 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:23:11 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Session Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:23:11 --> Session routines successfully run
DEBUG - 2014-07-19 07:23:11 --> Upload Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Controller Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:23:11 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:23:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:23:11 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:23:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:23:11 --> Final output sent to browser
DEBUG - 2014-07-19 07:23:11 --> Total execution time: 0.1766
DEBUG - 2014-07-19 07:23:31 --> Config Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:23:31 --> URI Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Router Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Output Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Security Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Input Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:23:31 --> Language Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Loader Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:23:31 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Session Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:23:31 --> Session routines successfully run
DEBUG - 2014-07-19 07:23:31 --> Upload Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Controller Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:23:31 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:31 --> Config Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:23:31 --> URI Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Router Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Output Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Security Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Input Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:23:31 --> Language Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Loader Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:23:31 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Session Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:23:31 --> Session routines successfully run
DEBUG - 2014-07-19 07:23:31 --> Upload Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Controller Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:23:31 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Model Class Initialized
DEBUG - 2014-07-19 07:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:23:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:23:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:23:31 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:23:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:23:31 --> Final output sent to browser
DEBUG - 2014-07-19 07:23:31 --> Total execution time: 0.1696
DEBUG - 2014-07-19 07:25:32 --> Config Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:25:32 --> URI Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Router Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Output Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Security Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Input Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:25:32 --> Language Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Loader Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:25:32 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:25:32 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Session Class Initialized
DEBUG - 2014-07-19 07:25:32 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:25:32 --> Session routines successfully run
DEBUG - 2014-07-19 07:25:33 --> Upload Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Controller Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:25:33 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Model Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Model Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Model Class Initialized
DEBUG - 2014-07-19 07:25:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:25:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:25:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:25:33 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:25:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:25:33 --> Final output sent to browser
DEBUG - 2014-07-19 07:25:33 --> Total execution time: 0.1551
DEBUG - 2014-07-19 07:34:09 --> Config Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:34:09 --> URI Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Router Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Output Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Security Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Input Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:34:09 --> Language Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Loader Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:34:09 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:34:09 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Session Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:34:09 --> Session routines successfully run
DEBUG - 2014-07-19 07:34:09 --> Upload Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Controller Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:34:09 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:34:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:34:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:34:09 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:34:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:34:09 --> Final output sent to browser
DEBUG - 2014-07-19 07:34:09 --> Total execution time: 0.1644
DEBUG - 2014-07-19 07:34:10 --> Config Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:34:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:34:10 --> URI Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Router Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Output Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Security Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Input Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:34:10 --> Language Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Loader Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:34:10 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:34:10 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Session Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:34:10 --> Session routines successfully run
DEBUG - 2014-07-19 07:34:10 --> Upload Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Controller Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:34:10 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:34:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:34:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:34:10 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:34:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:34:10 --> Final output sent to browser
DEBUG - 2014-07-19 07:34:10 --> Total execution time: 0.1661
DEBUG - 2014-07-19 07:34:33 --> Config Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:34:33 --> URI Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Router Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Output Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Security Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Input Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:34:33 --> Language Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Loader Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:34:33 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:34:33 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Session Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:34:33 --> Session routines successfully run
DEBUG - 2014-07-19 07:34:33 --> Upload Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Controller Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:34:33 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:34:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-19 07:34:33 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-19 07:34:33 --> Final output sent to browser
DEBUG - 2014-07-19 07:34:33 --> Total execution time: 0.1977
DEBUG - 2014-07-19 07:34:41 --> Config Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:34:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:34:41 --> URI Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Router Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Output Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Security Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Input Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:34:41 --> Language Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Loader Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:34:41 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:34:41 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Session Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:34:41 --> Session routines successfully run
DEBUG - 2014-07-19 07:34:41 --> Upload Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Controller Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:34:41 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:34:41 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-19 07:34:41 --> Final output sent to browser
DEBUG - 2014-07-19 07:34:41 --> Total execution time: 0.2178
DEBUG - 2014-07-19 07:34:50 --> Config Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:34:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:34:50 --> URI Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Router Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Output Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Security Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Input Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:34:50 --> Language Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Loader Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:34:50 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:34:50 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Session Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:34:50 --> Session routines successfully run
DEBUG - 2014-07-19 07:34:50 --> Upload Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Controller Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:34:50 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:34:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:34:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:34:50 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-19 07:34:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:34:50 --> Final output sent to browser
DEBUG - 2014-07-19 07:34:50 --> Total execution time: 0.1877
DEBUG - 2014-07-19 07:34:52 --> Config Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:34:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:34:52 --> URI Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Router Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Output Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Security Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Input Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:34:52 --> Language Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Loader Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:34:52 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:34:52 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Session Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:34:52 --> Session routines successfully run
DEBUG - 2014-07-19 07:34:52 --> Upload Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Controller Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:34:52 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Model Class Initialized
DEBUG - 2014-07-19 07:34:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:34:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:34:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:34:52 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:34:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:34:52 --> Final output sent to browser
DEBUG - 2014-07-19 07:34:52 --> Total execution time: 0.1720
DEBUG - 2014-07-19 07:35:13 --> Config Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:35:13 --> URI Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Router Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Output Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Security Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Input Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:35:13 --> Language Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Loader Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:35:13 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:35:13 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Session Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:35:13 --> Session routines successfully run
DEBUG - 2014-07-19 07:35:13 --> Upload Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Controller Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:35:13 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:35:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:35:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:35:13 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:35:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:35:13 --> Final output sent to browser
DEBUG - 2014-07-19 07:35:13 --> Total execution time: 0.1576
DEBUG - 2014-07-19 07:35:28 --> Config Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:35:28 --> URI Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Router Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Output Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Security Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Input Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:35:28 --> Language Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Loader Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:35:28 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:35:28 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Session Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:35:28 --> Session routines successfully run
DEBUG - 2014-07-19 07:35:28 --> Upload Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Controller Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:35:28 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:35:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-19 07:35:28 --> Config Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:35:28 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:35:29 --> URI Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Router Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Output Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Security Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Input Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:35:29 --> Language Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Loader Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:35:29 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:35:29 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Session Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:35:29 --> Session routines successfully run
DEBUG - 2014-07-19 07:35:29 --> Upload Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Controller Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:35:29 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:35:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:35:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:35:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-19 07:35:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:35:29 --> Final output sent to browser
DEBUG - 2014-07-19 07:35:29 --> Total execution time: 0.2707
DEBUG - 2014-07-19 07:35:33 --> Config Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Hooks Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Utf8 Class Initialized
DEBUG - 2014-07-19 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-19 07:35:33 --> URI Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Router Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Output Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Security Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Input Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-19 07:35:33 --> Language Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Loader Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Helper loaded: url_helper
DEBUG - 2014-07-19 07:35:33 --> Helper loaded: file_helper
DEBUG - 2014-07-19 07:35:33 --> Database Driver Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Session Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Helper loaded: string_helper
DEBUG - 2014-07-19 07:35:33 --> Session routines successfully run
DEBUG - 2014-07-19 07:35:33 --> Upload Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Pagination Class Initialized
DEBUG - 2014-07-19 07:35:33 --> Controller Class Initialized
DEBUG - 2014-07-19 07:35:34 --> Helper loaded: form_helper
DEBUG - 2014-07-19 07:35:34 --> Form Validation Class Initialized
DEBUG - 2014-07-19 07:35:34 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:34 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:34 --> Model Class Initialized
DEBUG - 2014-07-19 07:35:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-19 07:35:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-19 07:35:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-19 07:35:34 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-19 07:35:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-19 07:35:34 --> Final output sent to browser
DEBUG - 2014-07-19 07:35:34 --> Total execution time: 0.1906

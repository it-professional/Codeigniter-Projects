<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-27 06:38:46 --> Config Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:38:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:38:46 --> URI Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Router Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Output Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Security Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Input Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:38:46 --> Language Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Loader Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:38:46 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:38:46 --> Database Driver Class Initialized
ERROR - 2014-07-27 06:38:46 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\hostorks\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-27 06:38:46 --> Session Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:38:46 --> A session cookie was not found.
DEBUG - 2014-07-27 06:38:46 --> Session routines successfully run
DEBUG - 2014-07-27 06:38:46 --> Upload Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Controller Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:38:46 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 06:38:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 06:38:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 06:38:47 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-27 06:38:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 06:38:47 --> Final output sent to browser
DEBUG - 2014-07-27 06:38:47 --> Total execution time: 1.1190
DEBUG - 2014-07-27 06:38:51 --> Config Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:38:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:38:51 --> URI Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Router Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Output Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Security Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Input Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:38:51 --> Language Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Loader Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:38:51 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:38:51 --> Database Driver Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Session Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:38:51 --> Session routines successfully run
DEBUG - 2014-07-27 06:38:51 --> Upload Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Controller Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:38:51 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 06:38:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 06:38:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 06:38:51 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 06:38:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 06:38:51 --> Final output sent to browser
DEBUG - 2014-07-27 06:38:51 --> Total execution time: 0.2354
DEBUG - 2014-07-27 06:38:52 --> Config Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:38:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:38:52 --> URI Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Router Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Output Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Security Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Input Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:38:52 --> Language Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Loader Class Initialized
DEBUG - 2014-07-27 06:38:52 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:38:52 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:38:52 --> Database Driver Class Initialized
ERROR - 2014-07-27 06:38:52 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\hostorks\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-27 06:38:53 --> Session Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:38:53 --> Session routines successfully run
DEBUG - 2014-07-27 06:38:53 --> Upload Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Controller Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:38:53 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Model Class Initialized
DEBUG - 2014-07-27 06:38:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 06:38:53 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 06:40:53 --> Config Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:40:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:40:53 --> URI Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Router Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Output Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Security Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Input Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:40:53 --> Language Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Loader Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:40:53 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:40:53 --> Database Driver Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Session Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:40:53 --> Session routines successfully run
DEBUG - 2014-07-27 06:40:53 --> Upload Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Controller Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:40:53 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Model Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Model Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Model Class Initialized
DEBUG - 2014-07-27 06:40:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 06:40:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 06:40:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 06:40:53 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 06:40:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 06:40:53 --> Final output sent to browser
DEBUG - 2014-07-27 06:40:53 --> Total execution time: 0.1847
DEBUG - 2014-07-27 06:40:54 --> Config Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:40:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:40:54 --> URI Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Router Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Output Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Security Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Input Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:40:54 --> Language Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Loader Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:40:54 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:40:54 --> Database Driver Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Session Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:40:54 --> Session routines successfully run
DEBUG - 2014-07-27 06:40:54 --> Upload Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Controller Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:40:54 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Model Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Model Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Model Class Initialized
DEBUG - 2014-07-27 06:40:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 06:40:54 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 06:41:00 --> Config Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:41:00 --> URI Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Router Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Output Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Security Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Input Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:41:00 --> Language Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Loader Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:41:00 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:41:00 --> Database Driver Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Session Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:41:00 --> Session routines successfully run
DEBUG - 2014-07-27 06:41:00 --> Upload Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Controller Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:41:00 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Model Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Model Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Model Class Initialized
DEBUG - 2014-07-27 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 06:41:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 06:41:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 06:41:00 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 06:41:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 06:41:00 --> Final output sent to browser
DEBUG - 2014-07-27 06:41:00 --> Total execution time: 0.1943
DEBUG - 2014-07-27 06:41:01 --> Config Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Hooks Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Utf8 Class Initialized
DEBUG - 2014-07-27 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 06:41:01 --> URI Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Router Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Output Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Security Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Input Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 06:41:01 --> Language Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Loader Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Helper loaded: url_helper
DEBUG - 2014-07-27 06:41:01 --> Helper loaded: file_helper
DEBUG - 2014-07-27 06:41:01 --> Database Driver Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Session Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Helper loaded: string_helper
DEBUG - 2014-07-27 06:41:01 --> Session routines successfully run
DEBUG - 2014-07-27 06:41:01 --> Upload Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Pagination Class Initialized
DEBUG - 2014-07-27 06:41:01 --> Controller Class Initialized
DEBUG - 2014-07-27 06:41:02 --> Helper loaded: form_helper
DEBUG - 2014-07-27 06:41:02 --> Form Validation Class Initialized
DEBUG - 2014-07-27 06:41:02 --> Model Class Initialized
DEBUG - 2014-07-27 06:41:02 --> Model Class Initialized
DEBUG - 2014-07-27 06:41:02 --> Model Class Initialized
DEBUG - 2014-07-27 06:41:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 06:41:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 06:41:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 06:41:02 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 06:41:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 06:41:02 --> Final output sent to browser
DEBUG - 2014-07-27 06:41:02 --> Total execution time: 0.2170
DEBUG - 2014-07-27 07:15:52 --> Config Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:15:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:15:52 --> URI Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Router Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Output Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Security Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Input Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:15:52 --> Language Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Loader Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:15:52 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:15:52 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Session Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:15:52 --> Session routines successfully run
DEBUG - 2014-07-27 07:15:52 --> Upload Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Controller Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:15:52 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Model Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Model Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Model Class Initialized
DEBUG - 2014-07-27 07:15:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:15:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:15:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:15:52 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:15:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:15:52 --> Final output sent to browser
DEBUG - 2014-07-27 07:15:52 --> Total execution time: 0.1700
DEBUG - 2014-07-27 07:15:53 --> Config Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:15:53 --> URI Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Router Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Output Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Security Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Input Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:15:53 --> Language Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Loader Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:15:53 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:15:53 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Session Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:15:53 --> Session routines successfully run
DEBUG - 2014-07-27 07:15:53 --> Upload Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Controller Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:15:53 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Model Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Model Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Model Class Initialized
DEBUG - 2014-07-27 07:15:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:15:53 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:16:45 --> Config Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:16:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:16:45 --> URI Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Router Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Output Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Security Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Input Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:16:45 --> Language Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Loader Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:16:45 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:16:45 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Session Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:16:45 --> Session routines successfully run
DEBUG - 2014-07-27 07:16:45 --> Upload Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Controller Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:16:45 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:16:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:16:46 --> Config Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:16:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:16:46 --> URI Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Router Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Output Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Security Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Input Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:16:46 --> Language Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Loader Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:16:46 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:16:46 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Session Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:16:46 --> Session routines successfully run
DEBUG - 2014-07-27 07:16:46 --> Upload Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Controller Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:16:46 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:16:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:16:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:16:46 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:16:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:16:46 --> Final output sent to browser
DEBUG - 2014-07-27 07:16:46 --> Total execution time: 0.1698
DEBUG - 2014-07-27 07:16:47 --> Config Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:16:47 --> URI Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Router Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Output Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Security Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Input Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:16:47 --> Language Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Loader Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:16:47 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:16:47 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Session Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:16:47 --> Session routines successfully run
DEBUG - 2014-07-27 07:16:47 --> Upload Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Controller Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:16:47 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:16:47 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:16:55 --> Config Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:16:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:16:55 --> URI Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Router Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Output Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Security Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Input Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:16:55 --> Language Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Loader Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:16:55 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:16:55 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Session Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:16:55 --> Session routines successfully run
DEBUG - 2014-07-27 07:16:55 --> Upload Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Controller Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:16:55 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:16:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:16:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:16:55 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:16:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:16:55 --> Final output sent to browser
DEBUG - 2014-07-27 07:16:55 --> Total execution time: 0.1747
DEBUG - 2014-07-27 07:16:57 --> Config Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:16:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:16:57 --> URI Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Router Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Output Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Security Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Input Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:16:57 --> Language Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Loader Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:16:57 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:16:57 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Session Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:16:57 --> Session routines successfully run
DEBUG - 2014-07-27 07:16:57 --> Upload Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Controller Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:16:57 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Model Class Initialized
DEBUG - 2014-07-27 07:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:16:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:16:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:16:57 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:16:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:16:57 --> Final output sent to browser
DEBUG - 2014-07-27 07:16:57 --> Total execution time: 0.1979
DEBUG - 2014-07-27 07:17:27 --> Config Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:17:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:17:27 --> URI Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Router Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Output Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Security Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Input Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:17:27 --> Language Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Loader Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:17:27 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:17:27 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Session Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:17:27 --> Session routines successfully run
DEBUG - 2014-07-27 07:17:27 --> Upload Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Controller Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:17:27 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:17:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:17:28 --> Config Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:17:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:17:28 --> URI Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Router Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Output Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Security Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Input Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:17:28 --> Language Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Loader Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:17:28 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:17:28 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Session Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:17:28 --> Session routines successfully run
DEBUG - 2014-07-27 07:17:28 --> Upload Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Controller Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:17:28 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:17:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:17:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:17:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:17:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:17:28 --> Final output sent to browser
DEBUG - 2014-07-27 07:17:28 --> Total execution time: 0.1683
DEBUG - 2014-07-27 07:17:28 --> Config Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:17:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:17:28 --> URI Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Router Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Output Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Security Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Input Class Initialized
DEBUG - 2014-07-27 07:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:17:28 --> Language Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Loader Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:17:29 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:17:29 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Session Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:17:29 --> Session routines successfully run
DEBUG - 2014-07-27 07:17:29 --> Upload Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Controller Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:17:29 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:17:29 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:17:38 --> Config Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:17:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:17:38 --> URI Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Router Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Output Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Security Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Input Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:17:38 --> Language Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Loader Class Initialized
DEBUG - 2014-07-27 07:17:38 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:17:38 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:17:39 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Session Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:17:39 --> Session routines successfully run
DEBUG - 2014-07-27 07:17:39 --> Upload Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Controller Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:17:39 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:17:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:17:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:17:39 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:17:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:17:39 --> Final output sent to browser
DEBUG - 2014-07-27 07:17:39 --> Total execution time: 0.2315
DEBUG - 2014-07-27 07:17:40 --> Config Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:17:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:17:40 --> URI Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Router Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Output Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Security Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Input Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:17:40 --> Language Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Loader Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:17:40 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:17:40 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Session Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:17:40 --> Session routines successfully run
DEBUG - 2014-07-27 07:17:40 --> Upload Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Controller Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:17:40 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Model Class Initialized
DEBUG - 2014-07-27 07:17:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:17:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:17:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:17:40 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:17:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:17:40 --> Final output sent to browser
DEBUG - 2014-07-27 07:17:40 --> Total execution time: 0.2368
DEBUG - 2014-07-27 07:19:49 --> Config Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:19:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:19:49 --> URI Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Router Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Output Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Security Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Input Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:19:49 --> Language Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Loader Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:19:49 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:19:49 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Session Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:19:49 --> Session routines successfully run
DEBUG - 2014-07-27 07:19:49 --> Upload Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Controller Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:19:49 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Model Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Model Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Model Class Initialized
DEBUG - 2014-07-27 07:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:19:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:19:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:19:49 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:19:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:19:49 --> Final output sent to browser
DEBUG - 2014-07-27 07:19:49 --> Total execution time: 0.2325
DEBUG - 2014-07-27 07:19:50 --> Config Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:19:50 --> URI Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Router Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Output Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Security Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Input Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:19:50 --> Language Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Loader Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:19:50 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:19:50 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Session Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:19:50 --> Session routines successfully run
DEBUG - 2014-07-27 07:19:50 --> Upload Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Controller Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:19:50 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Model Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Model Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Model Class Initialized
DEBUG - 2014-07-27 07:19:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:19:50 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:20:41 --> Config Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:20:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:20:41 --> URI Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Router Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Output Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Security Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Input Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:20:41 --> Language Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Loader Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:20:41 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:20:41 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Session Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:20:41 --> Session routines successfully run
DEBUG - 2014-07-27 07:20:41 --> Upload Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Controller Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:20:41 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Model Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Model Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Model Class Initialized
DEBUG - 2014-07-27 07:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:20:41 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:20:41 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:20:41 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:20:41 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:20:41 --> Final output sent to browser
DEBUG - 2014-07-27 07:20:41 --> Total execution time: 0.1748
DEBUG - 2014-07-27 07:20:42 --> Config Class Initialized
DEBUG - 2014-07-27 07:20:42 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:20:42 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:20:43 --> URI Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Router Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Output Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Security Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Input Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:20:43 --> Language Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Loader Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:20:43 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:20:43 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Session Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:20:43 --> Session routines successfully run
DEBUG - 2014-07-27 07:20:43 --> Upload Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Controller Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:20:43 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Model Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Model Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Model Class Initialized
DEBUG - 2014-07-27 07:20:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:20:43 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:30:35 --> Config Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:30:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:30:35 --> URI Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Router Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Output Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Security Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Input Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:30:35 --> Language Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Loader Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:30:35 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:30:35 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Session Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:30:35 --> Session routines successfully run
DEBUG - 2014-07-27 07:30:35 --> Upload Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Controller Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:30:35 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Model Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Model Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Model Class Initialized
DEBUG - 2014-07-27 07:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:30:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:30:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:30:35 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:30:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:30:35 --> Final output sent to browser
DEBUG - 2014-07-27 07:30:35 --> Total execution time: 0.1720
DEBUG - 2014-07-27 07:30:36 --> Config Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:30:36 --> URI Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Router Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Output Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Security Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Input Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:30:36 --> Language Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Loader Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:30:36 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:30:36 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Session Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:30:36 --> Session routines successfully run
DEBUG - 2014-07-27 07:30:36 --> Upload Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:30:36 --> Controller Class Initialized
DEBUG - 2014-07-27 07:30:37 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:30:37 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:30:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:30:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:30:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:30:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:30:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:30:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:30:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:30:37 --> Final output sent to browser
DEBUG - 2014-07-27 07:30:37 --> Total execution time: 0.2177
DEBUG - 2014-07-27 07:31:01 --> Config Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:31:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:31:01 --> URI Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Router Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Output Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Security Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Input Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:31:01 --> Language Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Loader Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:31:01 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:31:01 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Session Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:31:01 --> Session routines successfully run
DEBUG - 2014-07-27 07:31:01 --> Upload Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Controller Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:31:01 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Model Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Model Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Model Class Initialized
DEBUG - 2014-07-27 07:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:31:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:31:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:31:01 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:31:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:31:01 --> Final output sent to browser
DEBUG - 2014-07-27 07:31:01 --> Total execution time: 0.1708
DEBUG - 2014-07-27 07:31:02 --> Config Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:31:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:31:02 --> URI Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Router Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Output Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Security Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Input Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:31:02 --> Language Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Loader Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:31:02 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:31:02 --> Database Driver Class Initialized
ERROR - 2014-07-27 07:31:02 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\hostorks\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-27 07:31:02 --> Session Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:31:02 --> Session routines successfully run
DEBUG - 2014-07-27 07:31:02 --> Upload Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Controller Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:31:02 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Model Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Model Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Model Class Initialized
DEBUG - 2014-07-27 07:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:31:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:31:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:31:03 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:31:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:31:03 --> Final output sent to browser
DEBUG - 2014-07-27 07:31:03 --> Total execution time: 0.3197
DEBUG - 2014-07-27 07:31:59 --> Config Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:31:59 --> URI Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Router Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Output Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Security Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Input Class Initialized
DEBUG - 2014-07-27 07:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:31:59 --> Language Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Loader Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:32:00 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:32:00 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Session Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:32:00 --> Session routines successfully run
DEBUG - 2014-07-27 07:32:00 --> Upload Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Controller Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:32:00 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Model Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Model Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Model Class Initialized
DEBUG - 2014-07-27 07:32:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:32:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:32:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:32:00 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:32:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:32:00 --> Final output sent to browser
DEBUG - 2014-07-27 07:32:00 --> Total execution time: 0.1915
DEBUG - 2014-07-27 07:32:01 --> Config Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:32:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:32:01 --> URI Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Router Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Output Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Security Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Input Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:32:01 --> Language Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Loader Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:32:01 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:32:01 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Session Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:32:01 --> Session routines successfully run
DEBUG - 2014-07-27 07:32:01 --> Upload Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Controller Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:32:01 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Model Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Model Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Model Class Initialized
DEBUG - 2014-07-27 07:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:32:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:32:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:32:01 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:32:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:32:01 --> Final output sent to browser
DEBUG - 2014-07-27 07:32:01 --> Total execution time: 0.1813
DEBUG - 2014-07-27 07:33:31 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:31 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:31 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:31 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:31 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:31 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:31 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:31 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:32 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:32 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:32 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:32 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:32 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:33:37 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:37 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:37 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:37 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:37 --> Database Driver Class Initialized
ERROR - 2014-07-27 07:33:37 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\hostorks\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-27 07:33:37 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:37 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:37 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:37 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:33:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:33:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:33:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:33:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:33:37 --> Final output sent to browser
DEBUG - 2014-07-27 07:33:37 --> Total execution time: 0.2425
DEBUG - 2014-07-27 07:33:37 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:37 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:37 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:37 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:38 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:38 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:38 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:38 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:33:38 --> Final output sent to browser
DEBUG - 2014-07-27 07:33:38 --> Total execution time: 0.1973
DEBUG - 2014-07-27 07:33:38 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:38 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:38 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:38 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:38 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:38 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:38 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:33:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:33:38 --> Final output sent to browser
DEBUG - 2014-07-27 07:33:38 --> Total execution time: 0.2207
DEBUG - 2014-07-27 07:33:42 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:42 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:42 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:42 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:42 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:42 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:42 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:42 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:33:52 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:52 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:52 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:52 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:52 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:52 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:52 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:52 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:33:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:33:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:33:52 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:33:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:33:52 --> Final output sent to browser
DEBUG - 2014-07-27 07:33:52 --> Total execution time: 0.3026
DEBUG - 2014-07-27 07:33:56 --> Config Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:33:56 --> URI Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Router Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Output Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Security Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Input Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:33:56 --> Language Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Loader Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:33:56 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:33:56 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Session Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:33:56 --> Session routines successfully run
DEBUG - 2014-07-27 07:33:56 --> Upload Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Controller Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:33:56 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Model Class Initialized
DEBUG - 2014-07-27 07:33:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:23 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:23 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:23 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:23 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:23 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:23 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:23 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:23 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:23 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:24 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:24 --> Total execution time: 0.1939
DEBUG - 2014-07-27 07:37:26 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:26 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:26 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:26 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:26 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:26 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:26 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:26 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:26 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:26 --> Total execution time: 0.1811
DEBUG - 2014-07-27 07:37:27 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:27 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:27 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:27 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:28 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:28 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:28 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:28 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:28 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:37:28 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:37:35 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:35 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:35 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:35 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:35 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:35 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:35 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:35 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:35 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:35 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:35 --> Total execution time: 0.1758
DEBUG - 2014-07-27 07:37:37 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:37 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:37 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:37 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:37 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:37 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:37 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:37 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:37 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:37 --> Total execution time: 0.2004
DEBUG - 2014-07-27 07:37:43 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:43 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:43 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:43 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:43 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:43 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:44 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:44 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:44 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:44 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:44 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:44 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:44 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:44 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:44 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:44 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:44 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:44 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:44 --> Total execution time: 0.1715
DEBUG - 2014-07-27 07:37:44 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:44 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:44 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:45 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:45 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:45 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:45 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:45 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:45 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:37:45 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:37:48 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:48 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:48 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:48 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:48 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:49 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:49 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:49 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:49 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:49 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:49 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:49 --> Total execution time: 0.1640
DEBUG - 2014-07-27 07:37:50 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:50 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:50 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:50 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:50 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:50 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:50 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:50 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:50 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:50 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:50 --> Total execution time: 0.2163
DEBUG - 2014-07-27 07:37:56 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:56 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:56 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:56 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:56 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:56 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:56 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:56 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:57 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:57 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:57 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:57 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:57 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:57 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:57 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:57 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:37:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:37:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:37:57 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:37:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:37:57 --> Final output sent to browser
DEBUG - 2014-07-27 07:37:57 --> Total execution time: 0.1800
DEBUG - 2014-07-27 07:37:58 --> Config Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:37:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:37:58 --> URI Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Router Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Output Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Security Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Input Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:37:58 --> Language Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Loader Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:37:58 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:37:58 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Session Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:37:58 --> Session routines successfully run
DEBUG - 2014-07-27 07:37:58 --> Upload Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Controller Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:37:58 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Model Class Initialized
DEBUG - 2014-07-27 07:37:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:37:58 --> 404 Page Not Found --> 
DEBUG - 2014-07-27 07:38:03 --> Config Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:38:03 --> URI Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Router Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Output Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Security Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Input Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:38:03 --> Language Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Loader Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:38:03 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:38:03 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Session Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:38:03 --> Session routines successfully run
DEBUG - 2014-07-27 07:38:03 --> Upload Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Controller Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:38:03 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Model Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Model Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Model Class Initialized
DEBUG - 2014-07-27 07:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:38:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:38:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:38:03 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:38:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:38:03 --> Final output sent to browser
DEBUG - 2014-07-27 07:38:03 --> Total execution time: 0.1770
DEBUG - 2014-07-27 07:38:05 --> Config Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:38:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:38:05 --> URI Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Router Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Output Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Security Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Input Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:38:05 --> Language Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Loader Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:38:05 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:38:05 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Session Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:38:05 --> Session routines successfully run
DEBUG - 2014-07-27 07:38:05 --> Upload Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Controller Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:38:05 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Model Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Model Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Model Class Initialized
DEBUG - 2014-07-27 07:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:38:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:38:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:38:05 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:38:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:38:05 --> Final output sent to browser
DEBUG - 2014-07-27 07:38:05 --> Total execution time: 0.2165
DEBUG - 2014-07-27 07:39:31 --> Config Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:39:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:39:31 --> URI Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Router Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Output Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Security Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Input Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:39:31 --> Language Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Loader Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:39:31 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:39:31 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Session Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:39:31 --> Session routines successfully run
DEBUG - 2014-07-27 07:39:31 --> Upload Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Controller Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:39:31 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Model Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Model Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Model Class Initialized
DEBUG - 2014-07-27 07:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 07:39:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-27 07:39:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-27 07:39:31 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-27 07:39:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-27 07:39:31 --> Final output sent to browser
DEBUG - 2014-07-27 07:39:31 --> Total execution time: 0.1668
DEBUG - 2014-07-27 07:39:32 --> Config Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Hooks Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Utf8 Class Initialized
DEBUG - 2014-07-27 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 07:39:32 --> URI Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Router Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Output Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Security Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Input Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 07:39:32 --> Language Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Loader Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Helper loaded: url_helper
DEBUG - 2014-07-27 07:39:32 --> Helper loaded: file_helper
DEBUG - 2014-07-27 07:39:32 --> Database Driver Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Session Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Helper loaded: string_helper
DEBUG - 2014-07-27 07:39:32 --> Session routines successfully run
DEBUG - 2014-07-27 07:39:32 --> Upload Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Pagination Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Controller Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Helper loaded: form_helper
DEBUG - 2014-07-27 07:39:32 --> Form Validation Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Model Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Model Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Model Class Initialized
DEBUG - 2014-07-27 07:39:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-27 07:39:32 --> 404 Page Not Found --> 

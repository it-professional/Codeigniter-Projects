<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-12 04:05:43 --> Config Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:05:43 --> URI Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Router Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Output Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Security Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Input Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:05:43 --> Language Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Loader Class Initialized
DEBUG - 2014-07-12 04:05:43 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:05:43 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:05:43 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Session Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:05:44 --> A session cookie was not found.
DEBUG - 2014-07-12 04:05:44 --> Session routines successfully run
DEBUG - 2014-07-12 04:05:44 --> Upload Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Controller Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:05:44 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Model Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Model Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Model Class Initialized
DEBUG - 2014-07-12 04:05:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:05:44 --> Severity: Notice  --> Use of undefined constant USER_RESOURCES - assumed 'USER_RESOURCES' C:\wamp\www\hostorks\application\views\superadmin\login.php 4
ERROR - 2014-07-12 04:05:44 --> Severity: Notice  --> Use of undefined constant USER_RESOURCES - assumed 'USER_RESOURCES' C:\wamp\www\hostorks\application\views\superadmin\login.php 13
ERROR - 2014-07-12 04:05:44 --> Severity: Notice  --> Use of undefined constant USER_RESOURCES - assumed 'USER_RESOURCES' C:\wamp\www\hostorks\application\views\superadmin\login.php 22
DEBUG - 2014-07-12 04:05:44 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-12 04:05:44 --> Final output sent to browser
DEBUG - 2014-07-12 04:05:44 --> Total execution time: 1.2184
DEBUG - 2014-07-12 04:06:22 --> Config Class Initialized
DEBUG - 2014-07-12 04:06:22 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:06:22 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:06:23 --> URI Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Router Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Output Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Security Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Input Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:06:23 --> Language Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Loader Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:06:23 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:06:23 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Session Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:06:23 --> Session routines successfully run
DEBUG - 2014-07-12 04:06:23 --> Upload Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Controller Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:06:23 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Model Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Model Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Model Class Initialized
DEBUG - 2014-07-12 04:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:06:23 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-12 04:06:23 --> Final output sent to browser
DEBUG - 2014-07-12 04:06:23 --> Total execution time: 0.1898
DEBUG - 2014-07-12 04:33:10 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:10 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:10 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:10 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:10 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:10 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:33:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-12 04:33:10 --> XSS Filtering completed
DEBUG - 2014-07-12 04:33:11 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:11 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:11 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:11 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:11 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:11 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:11 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:33:11 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-12 04:33:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 04:33:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 04:33:11 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 04:33:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-12 04:33:11 --> Final output sent to browser
DEBUG - 2014-07-12 04:33:11 --> Total execution time: 0.2490
DEBUG - 2014-07-12 04:33:11 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:11 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:11 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:11 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:11 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:11 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:11 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:11 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:11 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:11 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:11 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:11 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:11 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Controller Class Initialized
ERROR - 2014-07-12 04:33:11 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:11 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:11 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:33:11 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:12 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:12 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:12 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Controller Class Initialized
ERROR - 2014-07-12 04:33:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:12 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:12 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:12 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:12 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:33:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:12 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:12 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:12 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:12 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:12 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:12 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:12 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:12 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:12 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:12 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: url_helper
ERROR - 2014-07-12 04:33:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:12 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:12 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:12 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:12 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:12 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Config Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:33:12 --> URI Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Router Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Output Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:12 --> Security Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:12 --> Input Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:33:12 --> Language Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Loader Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:33:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:33:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Controller Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:33:12 --> Session routines successfully run
DEBUG - 2014-07-12 04:33:12 --> Upload Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:33:12 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Controller Class Initialized
ERROR - 2014-07-12 04:33:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Model Class Initialized
DEBUG - 2014-07-12 04:33:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:33:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:50:38 --> Config Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:50:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:50:38 --> URI Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Router Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Output Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Security Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Input Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:50:38 --> Language Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Loader Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:50:38 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:50:38 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Session Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:50:38 --> Session routines successfully run
DEBUG - 2014-07-12 04:50:38 --> Upload Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Controller Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:50:38 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:50:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-12 04:50:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 04:50:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 04:50:38 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 04:50:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-12 04:50:38 --> Final output sent to browser
DEBUG - 2014-07-12 04:50:38 --> Total execution time: 0.2046
DEBUG - 2014-07-12 04:50:45 --> Config Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:50:45 --> URI Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Router Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Output Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Security Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Input Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:50:45 --> Language Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Loader Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:50:45 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Session Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:50:45 --> Session routines successfully run
DEBUG - 2014-07-12 04:50:45 --> Upload Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Controller Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:50:45 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:50:45 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:50:45 --> Config Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:50:45 --> URI Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Router Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Output Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Security Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Input Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:50:45 --> Language Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Loader Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:50:45 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Session Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:50:45 --> Session routines successfully run
DEBUG - 2014-07-12 04:50:45 --> Upload Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Controller Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:50:45 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-12 04:50:45 --> 404 Page Not Found --> 
DEBUG - 2014-07-12 04:50:50 --> Config Class Initialized
DEBUG - 2014-07-12 04:50:50 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:50:50 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:50:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:50:51 --> URI Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Router Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Output Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Security Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Input Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:50:51 --> Language Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Loader Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:50:51 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:50:51 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Session Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:50:51 --> Session routines successfully run
DEBUG - 2014-07-12 04:50:51 --> Upload Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Controller Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:50:51 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Model Class Initialized
DEBUG - 2014-07-12 04:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:50:51 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-12 04:50:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 04:50:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 04:50:51 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 04:50:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-12 04:50:51 --> Final output sent to browser
DEBUG - 2014-07-12 04:50:51 --> Total execution time: 0.1783
DEBUG - 2014-07-12 04:51:53 --> Config Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:51:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:51:53 --> URI Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Router Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Output Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Security Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Input Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:51:53 --> Language Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Loader Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:51:53 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:51:53 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Session Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:51:53 --> Session routines successfully run
DEBUG - 2014-07-12 04:51:53 --> Upload Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Controller Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:51:53 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Model Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Model Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Model Class Initialized
DEBUG - 2014-07-12 04:51:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:51:53 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-12 04:51:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 04:51:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 04:51:53 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 04:51:53 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-12 04:51:53 --> Final output sent to browser
DEBUG - 2014-07-12 04:51:53 --> Total execution time: 0.1945
DEBUG - 2014-07-12 04:52:52 --> Config Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Hooks Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Utf8 Class Initialized
DEBUG - 2014-07-12 04:52:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 04:52:52 --> URI Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Router Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Output Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Security Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Input Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 04:52:52 --> Language Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Loader Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Helper loaded: url_helper
DEBUG - 2014-07-12 04:52:52 --> Helper loaded: file_helper
DEBUG - 2014-07-12 04:52:52 --> Database Driver Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Session Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Helper loaded: string_helper
DEBUG - 2014-07-12 04:52:52 --> Session routines successfully run
DEBUG - 2014-07-12 04:52:52 --> Upload Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Pagination Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Controller Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Helper loaded: form_helper
DEBUG - 2014-07-12 04:52:52 --> Form Validation Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Model Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Model Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Model Class Initialized
DEBUG - 2014-07-12 04:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 04:52:52 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-12 04:52:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 04:52:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 04:52:52 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 04:52:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-12 04:52:52 --> Final output sent to browser
DEBUG - 2014-07-12 04:52:52 --> Total execution time: 0.1877
DEBUG - 2014-07-12 05:23:19 --> Config Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Hooks Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Utf8 Class Initialized
DEBUG - 2014-07-12 05:23:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 05:23:19 --> URI Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Router Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Output Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Security Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Input Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 05:23:19 --> Language Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Loader Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Helper loaded: url_helper
DEBUG - 2014-07-12 05:23:19 --> Helper loaded: file_helper
DEBUG - 2014-07-12 05:23:19 --> Database Driver Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Session Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Helper loaded: string_helper
DEBUG - 2014-07-12 05:23:19 --> Session routines successfully run
DEBUG - 2014-07-12 05:23:19 --> Upload Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Pagination Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Controller Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Helper loaded: form_helper
DEBUG - 2014-07-12 05:23:19 --> Form Validation Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Model Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Model Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Model Class Initialized
DEBUG - 2014-07-12 05:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 05:23:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 05:23:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 05:23:19 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 05:23:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 05:23:19 --> Final output sent to browser
DEBUG - 2014-07-12 05:23:19 --> Total execution time: 0.2227
DEBUG - 2014-07-12 05:23:49 --> Config Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Hooks Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Utf8 Class Initialized
DEBUG - 2014-07-12 05:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 05:23:49 --> URI Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Router Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Output Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Security Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Input Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 05:23:49 --> Language Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Loader Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Helper loaded: url_helper
DEBUG - 2014-07-12 05:23:49 --> Helper loaded: file_helper
DEBUG - 2014-07-12 05:23:49 --> Database Driver Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Session Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Helper loaded: string_helper
DEBUG - 2014-07-12 05:23:49 --> Session routines successfully run
DEBUG - 2014-07-12 05:23:49 --> Upload Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Pagination Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Controller Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Helper loaded: form_helper
DEBUG - 2014-07-12 05:23:49 --> Form Validation Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Model Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Model Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Model Class Initialized
DEBUG - 2014-07-12 05:23:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 05:23:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 05:23:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 05:23:49 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 05:23:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 05:23:49 --> Final output sent to browser
DEBUG - 2014-07-12 05:23:49 --> Total execution time: 0.1851
DEBUG - 2014-07-12 05:26:12 --> Config Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Hooks Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Utf8 Class Initialized
DEBUG - 2014-07-12 05:26:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 05:26:12 --> URI Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Router Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Output Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Security Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Input Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 05:26:12 --> Language Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Loader Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Helper loaded: url_helper
DEBUG - 2014-07-12 05:26:12 --> Helper loaded: file_helper
DEBUG - 2014-07-12 05:26:12 --> Database Driver Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Session Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 05:26:12 --> Session routines successfully run
DEBUG - 2014-07-12 05:26:12 --> Upload Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Controller Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Helper loaded: form_helper
DEBUG - 2014-07-12 05:26:12 --> Form Validation Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Model Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Model Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Model Class Initialized
DEBUG - 2014-07-12 05:26:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 05:26:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 05:26:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 05:26:12 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 05:26:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 05:26:12 --> Final output sent to browser
DEBUG - 2014-07-12 05:26:12 --> Total execution time: 0.2238
DEBUG - 2014-07-12 06:59:50 --> Config Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Hooks Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Utf8 Class Initialized
DEBUG - 2014-07-12 06:59:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 06:59:50 --> URI Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Router Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Output Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Security Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Input Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 06:59:50 --> Language Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Loader Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Helper loaded: url_helper
DEBUG - 2014-07-12 06:59:50 --> Helper loaded: file_helper
DEBUG - 2014-07-12 06:59:50 --> Database Driver Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Session Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Helper loaded: string_helper
DEBUG - 2014-07-12 06:59:50 --> Session routines successfully run
DEBUG - 2014-07-12 06:59:50 --> Upload Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Pagination Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Controller Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Helper loaded: form_helper
DEBUG - 2014-07-12 06:59:50 --> Form Validation Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Model Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Model Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Model Class Initialized
DEBUG - 2014-07-12 06:59:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 06:59:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 06:59:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 06:59:50 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 06:59:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 06:59:50 --> Final output sent to browser
DEBUG - 2014-07-12 06:59:50 --> Total execution time: 0.1816
DEBUG - 2014-07-12 07:02:12 --> Config Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:02:12 --> URI Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Router Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Output Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Security Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Input Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:02:12 --> Language Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Loader Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:02:12 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:02:12 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Session Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:02:12 --> Session routines successfully run
DEBUG - 2014-07-12 07:02:12 --> Upload Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Controller Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:02:12 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Model Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Model Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Model Class Initialized
DEBUG - 2014-07-12 07:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:02:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:02:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:02:12 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 07:02:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:02:12 --> Final output sent to browser
DEBUG - 2014-07-12 07:02:12 --> Total execution time: 0.1693
DEBUG - 2014-07-12 07:24:06 --> Config Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:24:06 --> URI Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Router Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Output Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Security Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Input Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:24:06 --> Language Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Loader Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:24:06 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:24:06 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Session Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:24:06 --> Session routines successfully run
DEBUG - 2014-07-12 07:24:06 --> Upload Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Controller Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:24:06 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:24:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:24:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:24:06 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 07:24:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:24:06 --> Final output sent to browser
DEBUG - 2014-07-12 07:24:06 --> Total execution time: 0.5946
DEBUG - 2014-07-12 07:24:20 --> Config Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:24:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:24:20 --> URI Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Router Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Output Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Security Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Input Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:24:20 --> Language Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Loader Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:24:20 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:24:20 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Session Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:24:20 --> Session routines successfully run
DEBUG - 2014-07-12 07:24:20 --> Upload Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Controller Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:24:20 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:24:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:24:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:24:20 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-12 07:24:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:24:20 --> Final output sent to browser
DEBUG - 2014-07-12 07:24:20 --> Total execution time: 0.2179
DEBUG - 2014-07-12 07:24:24 --> Config Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:24:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:24:24 --> URI Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Router Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Output Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Security Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Input Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:24:24 --> Language Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Loader Class Initialized
DEBUG - 2014-07-12 07:24:24 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:24:24 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:24:25 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Session Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:24:25 --> Session routines successfully run
DEBUG - 2014-07-12 07:24:25 --> Upload Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Controller Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:24:25 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Model Class Initialized
DEBUG - 2014-07-12 07:24:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:24:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:24:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:24:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-12 07:24:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:24:25 --> Final output sent to browser
DEBUG - 2014-07-12 07:24:25 --> Total execution time: 0.1691
DEBUG - 2014-07-12 07:33:55 --> Config Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:33:55 --> URI Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Router Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Output Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Security Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Input Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:33:55 --> Language Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Loader Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:33:55 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:33:55 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Session Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:33:55 --> Session routines successfully run
DEBUG - 2014-07-12 07:33:55 --> Upload Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Controller Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:33:55 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Model Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Model Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Model Class Initialized
DEBUG - 2014-07-12 07:33:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:33:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:33:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:33:55 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-12 07:33:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:33:55 --> Final output sent to browser
DEBUG - 2014-07-12 07:33:55 --> Total execution time: 0.1695
DEBUG - 2014-07-12 07:34:29 --> Config Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:34:29 --> URI Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Router Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Output Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Security Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Input Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:34:29 --> Language Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Loader Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:34:29 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:34:29 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Session Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:34:29 --> Session routines successfully run
DEBUG - 2014-07-12 07:34:29 --> Upload Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Controller Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:34:29 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Model Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Model Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Model Class Initialized
DEBUG - 2014-07-12 07:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:34:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:34:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:34:29 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-12 07:34:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:34:29 --> Final output sent to browser
DEBUG - 2014-07-12 07:34:29 --> Total execution time: 0.2185
DEBUG - 2014-07-12 07:35:19 --> Config Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:35:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:35:19 --> URI Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Router Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Output Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Security Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Input Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:35:19 --> Language Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Loader Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:35:19 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:35:19 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Session Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:35:19 --> Session routines successfully run
DEBUG - 2014-07-12 07:35:19 --> Upload Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Controller Class Initialized
DEBUG - 2014-07-12 07:35:19 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:35:19 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:35:20 --> Model Class Initialized
DEBUG - 2014-07-12 07:35:20 --> Model Class Initialized
DEBUG - 2014-07-12 07:35:20 --> Model Class Initialized
DEBUG - 2014-07-12 07:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:35:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:35:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:35:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-12 07:35:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:35:20 --> Final output sent to browser
DEBUG - 2014-07-12 07:35:20 --> Total execution time: 0.1681
DEBUG - 2014-07-12 07:38:47 --> Config Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Hooks Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Utf8 Class Initialized
DEBUG - 2014-07-12 07:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 07:38:47 --> URI Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Router Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Output Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Security Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Input Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 07:38:47 --> Language Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Loader Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Helper loaded: url_helper
DEBUG - 2014-07-12 07:38:47 --> Helper loaded: file_helper
DEBUG - 2014-07-12 07:38:47 --> Database Driver Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Session Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Helper loaded: string_helper
DEBUG - 2014-07-12 07:38:47 --> Session routines successfully run
DEBUG - 2014-07-12 07:38:47 --> Upload Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Pagination Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Controller Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Helper loaded: form_helper
DEBUG - 2014-07-12 07:38:47 --> Form Validation Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Model Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Model Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Model Class Initialized
DEBUG - 2014-07-12 07:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-12 07:38:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-12 07:38:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-12 07:38:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-12 07:38:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-12 07:38:47 --> Final output sent to browser
DEBUG - 2014-07-12 07:38:47 --> Total execution time: 0.2014

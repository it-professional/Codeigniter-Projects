<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-13 01:55:19 --> Config Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:55:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:55:19 --> URI Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Router Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Output Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Security Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Input Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:55:19 --> Language Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Loader Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:55:19 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:55:19 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Session Class Initialized
DEBUG - 2014-08-13 01:55:19 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:55:19 --> A session cookie was not found.
DEBUG - 2014-08-13 01:55:19 --> Session routines successfully run
DEBUG - 2014-08-13 01:55:19 --> Upload Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Controller Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:55:20 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Model Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Model Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Model Class Initialized
DEBUG - 2014-08-13 01:55:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 01:55:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 01:55:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 01:55:21 --> Config Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:55:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:55:21 --> URI Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Router Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Output Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Security Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Input Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:55:21 --> Language Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Loader Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:55:21 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:55:21 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Session Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:55:21 --> Session routines successfully run
DEBUG - 2014-08-13 01:55:21 --> Upload Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Controller Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:55:21 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Model Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Model Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Model Class Initialized
DEBUG - 2014-08-13 01:55:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 01:55:21 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 01:56:26 --> Config Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:56:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:56:26 --> URI Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Router Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Output Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Security Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Input Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:56:26 --> Language Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Loader Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:56:26 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:56:26 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Session Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:56:26 --> Session routines successfully run
DEBUG - 2014-08-13 01:56:26 --> Upload Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Controller Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:56:26 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Model Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Model Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Model Class Initialized
DEBUG - 2014-08-13 01:56:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 01:56:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 01:56:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 01:56:26 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 01:56:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 01:56:26 --> Final output sent to browser
DEBUG - 2014-08-13 01:56:26 --> Total execution time: 0.1854
DEBUG - 2014-08-13 01:56:27 --> Config Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:56:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:56:27 --> URI Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Router Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Output Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Security Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Input Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:56:27 --> Language Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Loader Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:56:27 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:56:27 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Session Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:56:27 --> Session routines successfully run
DEBUG - 2014-08-13 01:56:27 --> Upload Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Controller Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:56:27 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Model Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Model Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Model Class Initialized
DEBUG - 2014-08-13 01:56:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 01:56:27 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 01:57:59 --> Config Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:57:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:57:59 --> URI Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Router Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Output Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Security Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Input Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:57:59 --> Language Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Loader Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:57:59 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:57:59 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Session Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:57:59 --> Session routines successfully run
DEBUG - 2014-08-13 01:57:59 --> Upload Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Controller Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:57:59 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Model Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Model Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Model Class Initialized
DEBUG - 2014-08-13 01:57:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 01:57:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 01:58:00 --> Config Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:58:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:58:00 --> URI Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Router Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Output Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Security Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Input Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:58:00 --> Language Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Loader Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:58:00 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:58:00 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Session Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:58:00 --> Session routines successfully run
DEBUG - 2014-08-13 01:58:00 --> Upload Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Controller Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:58:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 01:58:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 01:58:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 01:58:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 01:58:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 01:58:00 --> Final output sent to browser
DEBUG - 2014-08-13 01:58:00 --> Total execution time: 0.1937
DEBUG - 2014-08-13 01:58:00 --> Config Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:58:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:58:00 --> URI Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Router Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Output Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Security Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Input Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:58:00 --> Language Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Loader Class Initialized
DEBUG - 2014-08-13 01:58:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:58:00 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:58:01 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Session Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:58:01 --> Session routines successfully run
DEBUG - 2014-08-13 01:58:01 --> Upload Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Controller Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:58:01 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 01:58:01 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 01:58:22 --> Config Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:58:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:58:22 --> URI Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Router Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Output Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Security Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Input Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:58:22 --> Language Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Loader Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:58:22 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Session Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:58:22 --> Session routines successfully run
DEBUG - 2014-08-13 01:58:22 --> Upload Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Controller Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:58:22 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 01:58:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 01:58:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 01:58:22 --> Config Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 01:58:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 01:58:22 --> URI Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Router Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Output Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Security Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Input Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 01:58:22 --> Language Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Loader Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: file_helper
DEBUG - 2014-08-13 01:58:22 --> Database Driver Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Session Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 01:58:22 --> Session routines successfully run
DEBUG - 2014-08-13 01:58:22 --> Upload Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Pagination Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Controller Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Helper loaded: form_helper
DEBUG - 2014-08-13 01:58:22 --> Form Validation Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Model Class Initialized
DEBUG - 2014-08-13 01:58:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 01:58:22 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 02:02:54 --> Config Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:02:54 --> URI Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Router Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Output Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Security Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Input Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:02:54 --> Language Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Loader Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:02:54 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:02:54 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Session Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:02:54 --> Session routines successfully run
DEBUG - 2014-08-13 02:02:54 --> Upload Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Controller Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:02:54 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Model Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Model Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Model Class Initialized
DEBUG - 2014-08-13 02:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 02:02:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 02:02:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 02:03:59 --> Config Class Initialized
DEBUG - 2014-08-13 02:03:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:03:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:04:00 --> URI Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Router Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Output Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Security Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Input Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:04:00 --> Language Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Loader Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:04:00 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:04:00 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Session Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:04:00 --> Session routines successfully run
DEBUG - 2014-08-13 02:04:00 --> Upload Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Controller Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:04:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Model Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Model Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Model Class Initialized
DEBUG - 2014-08-13 02:04:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 02:04:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 02:04:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 02:04:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 02:04:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 02:04:00 --> Final output sent to browser
DEBUG - 2014-08-13 02:04:00 --> Total execution time: 0.1893
DEBUG - 2014-08-13 02:04:01 --> Config Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:04:01 --> URI Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Router Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Output Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Security Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Input Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:04:01 --> Language Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Loader Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:04:01 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:04:01 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Session Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:04:01 --> Session routines successfully run
DEBUG - 2014-08-13 02:04:01 --> Upload Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Controller Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:04:01 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Model Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Model Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Model Class Initialized
DEBUG - 2014-08-13 02:04:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 02:04:01 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 02:05:08 --> Config Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:05:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:05:08 --> URI Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Router Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Output Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Security Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Input Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:05:08 --> Language Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Loader Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:05:08 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:05:08 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Session Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:05:08 --> Session routines successfully run
DEBUG - 2014-08-13 02:05:08 --> Upload Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Controller Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:05:08 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 02:05:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 02:05:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 02:05:08 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 02:05:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 02:05:08 --> Final output sent to browser
DEBUG - 2014-08-13 02:05:08 --> Total execution time: 0.1890
DEBUG - 2014-08-13 02:05:09 --> Config Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:05:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:05:09 --> URI Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Router Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Output Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Security Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Input Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:05:09 --> Language Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Loader Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:05:09 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:05:09 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Session Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:05:09 --> Session routines successfully run
DEBUG - 2014-08-13 02:05:09 --> Upload Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Controller Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:05:09 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 02:05:09 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 02:05:37 --> Config Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:05:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:05:37 --> URI Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Router Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Output Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Security Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Input Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:05:37 --> Language Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Loader Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:05:37 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:05:37 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Session Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:05:37 --> Session routines successfully run
DEBUG - 2014-08-13 02:05:37 --> Upload Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Controller Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:05:37 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 02:05:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 02:05:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 02:05:37 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 02:05:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 02:05:37 --> Final output sent to browser
DEBUG - 2014-08-13 02:05:37 --> Total execution time: 0.1806
DEBUG - 2014-08-13 02:05:38 --> Config Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:05:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:05:38 --> URI Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Router Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Output Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Security Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Input Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:05:38 --> Language Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Loader Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:05:38 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:05:38 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Session Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:05:38 --> Session routines successfully run
DEBUG - 2014-08-13 02:05:38 --> Upload Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Controller Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:05:38 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Model Class Initialized
DEBUG - 2014-08-13 02:05:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 02:05:38 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 02:13:30 --> Config Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:13:30 --> URI Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Router Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Output Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Security Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Input Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:13:30 --> Language Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Loader Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:13:30 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:13:30 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Session Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:13:30 --> Session routines successfully run
DEBUG - 2014-08-13 02:13:30 --> Upload Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Controller Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:13:30 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Model Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Model Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Model Class Initialized
DEBUG - 2014-08-13 02:13:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 02:13:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 02:13:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 02:13:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 02:13:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 02:13:30 --> Final output sent to browser
DEBUG - 2014-08-13 02:13:30 --> Total execution time: 0.1945
DEBUG - 2014-08-13 02:13:31 --> Config Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 02:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 02:13:31 --> URI Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Router Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Output Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Security Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Input Class Initialized
DEBUG - 2014-08-13 02:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 02:13:31 --> Language Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Loader Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Helper loaded: url_helper
DEBUG - 2014-08-13 02:13:32 --> Helper loaded: file_helper
DEBUG - 2014-08-13 02:13:32 --> Database Driver Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Session Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Helper loaded: string_helper
DEBUG - 2014-08-13 02:13:32 --> Session routines successfully run
DEBUG - 2014-08-13 02:13:32 --> Upload Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Pagination Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Controller Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Helper loaded: form_helper
DEBUG - 2014-08-13 02:13:32 --> Form Validation Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Model Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Model Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Model Class Initialized
DEBUG - 2014-08-13 02:13:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 02:13:32 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 07:51:05 --> Config Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:51:05 --> URI Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Router Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Output Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Security Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Input Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:51:05 --> Language Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Loader Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:51:05 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:51:05 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Session Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:51:05 --> A session cookie was not found.
DEBUG - 2014-08-13 07:51:05 --> Session routines successfully run
DEBUG - 2014-08-13 07:51:05 --> Upload Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Controller Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:51:05 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Model Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Model Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Model Class Initialized
DEBUG - 2014-08-13 07:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:51:05 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:51:05 --> Final output sent to browser
DEBUG - 2014-08-13 07:51:05 --> Total execution time: 0.1230
DEBUG - 2014-08-13 07:52:11 --> Config Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:52:11 --> URI Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Router Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Output Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Security Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Input Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:52:11 --> Language Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Loader Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:52:11 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:52:11 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Session Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:52:11 --> Session routines successfully run
DEBUG - 2014-08-13 07:52:11 --> Upload Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Controller Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:52:11 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Model Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Model Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Model Class Initialized
DEBUG - 2014-08-13 07:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:52:11 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:52:11 --> Final output sent to browser
DEBUG - 2014-08-13 07:52:11 --> Total execution time: 0.0874
DEBUG - 2014-08-13 07:54:51 --> Config Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:54:51 --> URI Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Router Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Output Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Security Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Input Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:54:51 --> Language Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Loader Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:54:51 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:54:51 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Session Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:54:51 --> Session routines successfully run
DEBUG - 2014-08-13 07:54:51 --> Upload Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Controller Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:54:51 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Model Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Model Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Model Class Initialized
DEBUG - 2014-08-13 07:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:54:51 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:54:51 --> Final output sent to browser
DEBUG - 2014-08-13 07:54:51 --> Total execution time: 0.0732
DEBUG - 2014-08-13 07:54:55 --> Config Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:54:55 --> URI Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Router Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Output Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Security Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Input Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:54:55 --> Language Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Loader Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:54:55 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:54:55 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Session Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:54:55 --> Session routines successfully run
DEBUG - 2014-08-13 07:54:55 --> Upload Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Controller Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:54:55 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Model Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Model Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Model Class Initialized
DEBUG - 2014-08-13 07:54:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:54:55 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:54:55 --> Final output sent to browser
DEBUG - 2014-08-13 07:54:55 --> Total execution time: 0.0780
DEBUG - 2014-08-13 07:57:13 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:13 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:13 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:13 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:13 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:13 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:13 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:13 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:13 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:13 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:13 --> Total execution time: 0.0761
DEBUG - 2014-08-13 07:57:14 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:14 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:14 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:14 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:14 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:14 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:14 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:14 --> Total execution time: 0.0772
DEBUG - 2014-08-13 07:57:14 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:14 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:14 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:14 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:14 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:14 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:14 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:14 --> Total execution time: 0.0747
DEBUG - 2014-08-13 07:57:14 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:14 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:14 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:14 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:14 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:14 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:14 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:14 --> Total execution time: 0.0789
DEBUG - 2014-08-13 07:57:14 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:14 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:14 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:14 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:14 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:14 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:14 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:14 --> Total execution time: 0.0926
DEBUG - 2014-08-13 07:57:15 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:15 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:15 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:15 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:15 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:15 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:15 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:15 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:15 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:15 --> Total execution time: 0.0735
DEBUG - 2014-08-13 07:57:15 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:15 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:15 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:15 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:15 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:15 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:15 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:15 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:15 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:15 --> Total execution time: 0.0709
DEBUG - 2014-08-13 07:57:15 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:15 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:15 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:15 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:15 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:15 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:15 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:15 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:15 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:15 --> Total execution time: 0.0822
DEBUG - 2014-08-13 07:57:15 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:15 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:15 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:16 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:16 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:16 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:16 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:16 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:16 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:16 --> Total execution time: 0.0774
DEBUG - 2014-08-13 07:57:16 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:16 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:16 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:16 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:16 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:16 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:16 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:16 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:16 --> Total execution time: 0.0906
DEBUG - 2014-08-13 07:57:16 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:16 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:16 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:16 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:16 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:16 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:16 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:16 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:16 --> Total execution time: 0.0814
DEBUG - 2014-08-13 07:57:16 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:16 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:16 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:16 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:16 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:16 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:16 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-13 07:57:16 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:16 --> Total execution time: 0.0797
DEBUG - 2014-08-13 07:57:29 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:29 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:29 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:29 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:29 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:29 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 07:57:29 --> XSS Filtering completed
DEBUG - 2014-08-13 07:57:29 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:29 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:29 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:29 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:29 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:29 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 07:57:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 07:57:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-13 07:57:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 07:57:30 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:30 --> Total execution time: 0.1047
DEBUG - 2014-08-13 07:57:35 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:35 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:35 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:35 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:35 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:35 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:35 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 07:57:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 07:57:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 07:57:35 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 07:57:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 07:57:35 --> Final output sent to browser
DEBUG - 2014-08-13 07:57:35 --> Total execution time: 0.1013
DEBUG - 2014-08-13 07:57:35 --> Config Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Hooks Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Utf8 Class Initialized
DEBUG - 2014-08-13 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 07:57:35 --> URI Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Router Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Output Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Security Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Input Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 07:57:35 --> Language Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Loader Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: url_helper
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: file_helper
DEBUG - 2014-08-13 07:57:35 --> Database Driver Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Session Class Initialized
DEBUG - 2014-08-13 07:57:35 --> Helper loaded: string_helper
DEBUG - 2014-08-13 07:57:35 --> Session routines successfully run
DEBUG - 2014-08-13 07:57:36 --> Upload Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Pagination Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Controller Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Helper loaded: form_helper
DEBUG - 2014-08-13 07:57:36 --> Form Validation Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Model Class Initialized
DEBUG - 2014-08-13 07:57:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 07:57:36 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 08:19:50 --> Config Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:19:50 --> URI Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Router Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Output Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Security Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Input Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:19:50 --> Language Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Loader Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:19:50 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:19:50 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Session Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:19:50 --> Session routines successfully run
DEBUG - 2014-08-13 08:19:50 --> Upload Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Controller Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:19:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Model Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Model Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Model Class Initialized
DEBUG - 2014-08-13 08:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:19:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:19:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:19:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 08:19:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 08:19:50 --> Final output sent to browser
DEBUG - 2014-08-13 08:19:50 --> Total execution time: 0.0800
DEBUG - 2014-08-13 08:21:00 --> Config Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:21:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:21:00 --> URI Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Router Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Output Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Security Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Input Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:21:00 --> Language Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Loader Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:21:00 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Session Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:21:00 --> Session routines successfully run
DEBUG - 2014-08-13 08:21:00 --> Upload Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Controller Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:21:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:21:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:21:00 --> Config Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:21:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:21:00 --> URI Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Router Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Output Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Security Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Input Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:21:00 --> Language Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Loader Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:21:00 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Session Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:21:00 --> Session routines successfully run
DEBUG - 2014-08-13 08:21:00 --> Upload Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Controller Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:21:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:21:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:21:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:21:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 08:21:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 08:21:00 --> Final output sent to browser
DEBUG - 2014-08-13 08:21:00 --> Total execution time: 0.0845
DEBUG - 2014-08-13 08:21:01 --> Config Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:21:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:21:01 --> URI Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Router Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Output Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Security Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Input Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:21:01 --> Language Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Loader Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:21:01 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:21:01 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Session Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:21:01 --> Session routines successfully run
DEBUG - 2014-08-13 08:21:01 --> Upload Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Controller Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:21:01 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 08:21:01 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 08:21:19 --> Config Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:21:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:21:19 --> URI Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Router Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Output Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Security Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Input Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:21:19 --> Language Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Loader Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:21:19 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:21:19 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Session Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:21:19 --> Session routines successfully run
DEBUG - 2014-08-13 08:21:19 --> Upload Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Controller Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:21:19 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:21:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:21:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:21:52 --> Config Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:21:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:21:52 --> URI Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Router Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Output Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Security Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Input Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:21:52 --> Language Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Loader Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:21:52 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:21:52 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Session Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:21:52 --> Session routines successfully run
DEBUG - 2014-08-13 08:21:52 --> Upload Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Controller Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:21:52 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:21:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:21:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:21:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 08:21:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 08:21:52 --> Final output sent to browser
DEBUG - 2014-08-13 08:21:52 --> Total execution time: 0.1083
DEBUG - 2014-08-13 08:21:53 --> Config Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:21:53 --> URI Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Router Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Output Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Security Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Input Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:21:53 --> Language Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Loader Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:21:53 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:21:53 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Session Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:21:53 --> Session routines successfully run
DEBUG - 2014-08-13 08:21:53 --> Upload Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Controller Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:21:53 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Model Class Initialized
DEBUG - 2014-08-13 08:21:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 08:21:53 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 08:24:47 --> Config Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:24:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:24:47 --> URI Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Router Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Output Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Security Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Input Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:24:47 --> Language Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Loader Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:24:47 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:24:47 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Session Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:24:47 --> Session routines successfully run
DEBUG - 2014-08-13 08:24:47 --> Upload Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Controller Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:24:47 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Model Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Model Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Model Class Initialized
DEBUG - 2014-08-13 08:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:24:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:24:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:24:47 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 08:24:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 08:24:47 --> Final output sent to browser
DEBUG - 2014-08-13 08:24:47 --> Total execution time: 0.0875
DEBUG - 2014-08-13 08:24:48 --> Config Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:24:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:24:48 --> URI Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Router Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Output Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Security Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Input Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:24:48 --> Language Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Loader Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:24:48 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:24:48 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Session Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:24:48 --> Session routines successfully run
DEBUG - 2014-08-13 08:24:48 --> Upload Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Controller Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:24:48 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:24:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 08:24:48 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 08:31:36 --> Config Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:31:36 --> URI Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Router Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Output Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Security Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Input Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:31:36 --> Language Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Loader Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:31:36 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:31:36 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Session Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:31:36 --> Session routines successfully run
DEBUG - 2014-08-13 08:31:36 --> Upload Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Controller Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:31:36 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:31:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:31:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:31:48 --> Config Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:31:48 --> URI Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Router Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Output Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Security Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Input Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:31:48 --> Language Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Loader Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:31:48 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Session Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:31:48 --> Session routines successfully run
DEBUG - 2014-08-13 08:31:48 --> Upload Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Controller Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:31:48 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 08:31:48 --> Final output sent to browser
DEBUG - 2014-08-13 08:31:48 --> Total execution time: 0.0833
DEBUG - 2014-08-13 08:31:48 --> Config Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 08:31:48 --> URI Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Router Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Output Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Security Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Input Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 08:31:48 --> Language Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Loader Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: file_helper
DEBUG - 2014-08-13 08:31:48 --> Database Driver Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Session Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 08:31:48 --> Session routines successfully run
DEBUG - 2014-08-13 08:31:48 --> Upload Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Pagination Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Controller Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 08:31:48 --> Form Validation Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Model Class Initialized
DEBUG - 2014-08-13 08:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 08:31:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 08:31:48 --> Final output sent to browser
DEBUG - 2014-08-13 08:31:48 --> Total execution time: 0.1021
DEBUG - 2014-08-13 09:32:02 --> Config Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:32:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:32:02 --> URI Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Router Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Output Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Security Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Input Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:32:02 --> Language Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Loader Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:32:02 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:32:02 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Session Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:32:02 --> Session routines successfully run
DEBUG - 2014-08-13 09:32:02 --> Upload Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Controller Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:32:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:32:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:32:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:32:02 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:32:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:32:02 --> Final output sent to browser
DEBUG - 2014-08-13 09:32:02 --> Total execution time: 0.1180
DEBUG - 2014-08-13 09:32:03 --> Config Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:32:03 --> URI Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Router Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Output Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Security Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Input Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:32:03 --> Language Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Loader Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:32:03 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:32:03 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Session Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:32:03 --> Session routines successfully run
DEBUG - 2014-08-13 09:32:03 --> Upload Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Controller Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:32:03 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:32:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:32:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:32:03 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:32:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:32:03 --> Final output sent to browser
DEBUG - 2014-08-13 09:32:03 --> Total execution time: 0.1318
DEBUG - 2014-08-13 09:32:28 --> Config Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:32:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:32:28 --> URI Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Router Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Output Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Security Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Input Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:32:28 --> Language Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Loader Class Initialized
DEBUG - 2014-08-13 09:32:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:32:28 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:32:28 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Session Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:32:29 --> Session routines successfully run
DEBUG - 2014-08-13 09:32:29 --> Upload Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Controller Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:32:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Model Class Initialized
DEBUG - 2014-08-13 09:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:32:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:32:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:55:50 --> Config Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:55:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:55:50 --> URI Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Router Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Output Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Security Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Input Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:55:50 --> Language Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Loader Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:55:50 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Session Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:55:50 --> Session routines successfully run
DEBUG - 2014-08-13 09:55:50 --> Upload Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Controller Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:55:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:55:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:55:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:55:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:55:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:55:50 --> Final output sent to browser
DEBUG - 2014-08-13 09:55:50 --> Total execution time: 0.0753
DEBUG - 2014-08-13 09:55:50 --> Config Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:55:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:55:50 --> URI Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Router Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Output Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Security Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Input Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:55:50 --> Language Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Loader Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:55:50 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Session Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:55:50 --> Session routines successfully run
DEBUG - 2014-08-13 09:55:50 --> Upload Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Controller Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:55:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 09:55:50 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 09:55:52 --> Config Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:55:52 --> URI Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Router Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Output Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Security Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Input Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:55:52 --> Language Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Loader Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:55:52 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:55:52 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Session Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:55:52 --> Session routines successfully run
DEBUG - 2014-08-13 09:55:52 --> Upload Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Controller Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:55:52 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:55:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:55:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:55:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:55:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:55:52 --> Final output sent to browser
DEBUG - 2014-08-13 09:55:52 --> Total execution time: 0.0742
DEBUG - 2014-08-13 09:55:53 --> Config Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:55:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:55:53 --> URI Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Router Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Output Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Security Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Input Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:55:53 --> Language Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Loader Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:55:53 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:55:53 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Session Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:55:53 --> Session routines successfully run
DEBUG - 2014-08-13 09:55:53 --> Upload Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Controller Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:55:53 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Model Class Initialized
DEBUG - 2014-08-13 09:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:55:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:55:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:55:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:55:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:55:53 --> Final output sent to browser
DEBUG - 2014-08-13 09:55:53 --> Total execution time: 0.0847
DEBUG - 2014-08-13 09:56:24 --> Config Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:56:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:56:24 --> URI Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Router Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Output Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Security Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Input Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:56:24 --> Language Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Loader Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:56:24 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Session Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:56:24 --> Session routines successfully run
DEBUG - 2014-08-13 09:56:24 --> Upload Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Controller Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:56:24 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:56:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:56:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:56:24 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:56:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:56:24 --> Final output sent to browser
DEBUG - 2014-08-13 09:56:24 --> Total execution time: 0.0704
DEBUG - 2014-08-13 09:56:24 --> Config Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:56:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:56:24 --> URI Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Router Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Output Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Security Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Input Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:56:24 --> Language Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Loader Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:56:24 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Session Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:56:24 --> Session routines successfully run
DEBUG - 2014-08-13 09:56:24 --> Upload Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Controller Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:56:24 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 09:56:24 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 09:56:27 --> Config Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:56:27 --> URI Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Router Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Output Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Security Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Input Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:56:27 --> Language Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Loader Class Initialized
DEBUG - 2014-08-13 09:56:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:56:27 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:56:27 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Session Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:56:28 --> Session routines successfully run
DEBUG - 2014-08-13 09:56:28 --> Upload Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Controller Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:56:28 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:56:28 --> Final output sent to browser
DEBUG - 2014-08-13 09:56:28 --> Total execution time: 0.0812
DEBUG - 2014-08-13 09:56:28 --> Config Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:56:28 --> URI Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Router Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Output Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Security Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Input Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:56:28 --> Language Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Loader Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:56:28 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:56:28 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Session Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:56:28 --> Session routines successfully run
DEBUG - 2014-08-13 09:56:28 --> Upload Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Controller Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:56:28 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:56:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:56:28 --> Final output sent to browser
DEBUG - 2014-08-13 09:56:28 --> Total execution time: 0.0996
DEBUG - 2014-08-13 09:56:56 --> Config Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:56:56 --> URI Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Router Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Output Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Security Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Input Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:56:56 --> Language Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Loader Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:56:56 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:56:56 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Session Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:56:56 --> Session routines successfully run
DEBUG - 2014-08-13 09:56:56 --> Upload Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Controller Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:56:56 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Model Class Initialized
DEBUG - 2014-08-13 09:56:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:56:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:56:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:57:05 --> Config Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:57:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:57:05 --> URI Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Router Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Output Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Security Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Input Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:57:05 --> Language Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Loader Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:57:05 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:57:05 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Session Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:57:05 --> Session routines successfully run
DEBUG - 2014-08-13 09:57:05 --> Upload Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Controller Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:57:05 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:57:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:57:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:57:29 --> Config Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:57:29 --> URI Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Router Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Output Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Security Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Input Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:57:29 --> Language Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Loader Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:57:29 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:57:29 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Session Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:57:29 --> Session routines successfully run
DEBUG - 2014-08-13 09:57:29 --> Upload Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Controller Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:57:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:57:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:57:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:57:37 --> Config Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:57:37 --> URI Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Router Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Output Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Security Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Input Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:57:37 --> Language Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Loader Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:57:37 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Session Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:57:37 --> Session routines successfully run
DEBUG - 2014-08-13 09:57:37 --> Upload Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Controller Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:57:37 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:57:37 --> Final output sent to browser
DEBUG - 2014-08-13 09:57:37 --> Total execution time: 0.0953
DEBUG - 2014-08-13 09:57:37 --> Config Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:57:37 --> URI Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Router Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Output Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Security Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Input Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:57:37 --> Language Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Loader Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: file_helper
DEBUG - 2014-08-13 09:57:37 --> Database Driver Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Session Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:57:37 --> Session routines successfully run
DEBUG - 2014-08-13 09:57:37 --> Upload Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Pagination Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Controller Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:57:37 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 09:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 09:57:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 09:57:37 --> Final output sent to browser
DEBUG - 2014-08-13 09:57:37 --> Total execution time: 0.1207
DEBUG - 2014-08-13 10:38:05 --> Config Class Initialized
DEBUG - 2014-08-13 10:38:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:38:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:38:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:38:05 --> URI Class Initialized
DEBUG - 2014-08-13 10:38:05 --> Router Class Initialized
DEBUG - 2014-08-13 10:38:05 --> Output Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Security Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Input Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:38:06 --> Language Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Loader Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:38:06 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Session Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:38:06 --> Session routines successfully run
DEBUG - 2014-08-13 10:38:06 --> Upload Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Controller Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:38:06 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:38:06 --> Final output sent to browser
DEBUG - 2014-08-13 10:38:06 --> Total execution time: 0.0871
DEBUG - 2014-08-13 10:38:06 --> Config Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:38:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:38:06 --> URI Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Router Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Output Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Security Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Input Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:38:06 --> Language Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Loader Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:38:06 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Session Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:38:06 --> Session routines successfully run
DEBUG - 2014-08-13 10:38:06 --> Upload Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Controller Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:38:06 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:38:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:38:06 --> Final output sent to browser
DEBUG - 2014-08-13 10:38:06 --> Total execution time: 0.0846
DEBUG - 2014-08-13 10:38:18 --> Config Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:38:18 --> URI Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Router Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Output Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Security Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Input Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:38:18 --> Language Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Loader Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:38:18 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Session Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:38:18 --> Session routines successfully run
DEBUG - 2014-08-13 10:38:18 --> Upload Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Controller Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:38:18 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:38:18 --> Final output sent to browser
DEBUG - 2014-08-13 10:38:18 --> Total execution time: 0.0807
DEBUG - 2014-08-13 10:38:18 --> Config Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:38:18 --> URI Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Router Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Output Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Security Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Input Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:38:18 --> Language Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Loader Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:38:18 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Session Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:38:18 --> Session routines successfully run
DEBUG - 2014-08-13 10:38:18 --> Upload Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Controller Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:38:18 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Model Class Initialized
DEBUG - 2014-08-13 10:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:38:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:38:18 --> Final output sent to browser
DEBUG - 2014-08-13 10:38:18 --> Total execution time: 0.0749
DEBUG - 2014-08-13 10:53:50 --> Config Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:53:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:53:50 --> URI Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Router Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Output Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Security Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Input Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:53:50 --> Language Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Loader Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:53:50 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:53:50 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Session Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:53:50 --> Session routines successfully run
DEBUG - 2014-08-13 10:53:50 --> Upload Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Controller Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:53:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Model Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Model Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Model Class Initialized
DEBUG - 2014-08-13 10:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:53:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:53:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:53:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:53:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:53:50 --> Final output sent to browser
DEBUG - 2014-08-13 10:53:50 --> Total execution time: 0.0853
DEBUG - 2014-08-13 10:53:51 --> Config Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:53:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:53:51 --> URI Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Router Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Output Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Security Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Input Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:53:51 --> Language Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Loader Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:53:51 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:53:51 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Session Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:53:51 --> Session routines successfully run
DEBUG - 2014-08-13 10:53:51 --> Upload Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Controller Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:53:51 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Model Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Model Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Model Class Initialized
DEBUG - 2014-08-13 10:53:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:53:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:53:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:53:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:53:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:53:51 --> Final output sent to browser
DEBUG - 2014-08-13 10:53:51 --> Total execution time: 0.0846
DEBUG - 2014-08-13 10:55:14 --> Config Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:55:14 --> URI Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Router Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Output Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Security Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Input Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:55:14 --> Language Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Loader Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:55:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Session Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:55:14 --> Session routines successfully run
DEBUG - 2014-08-13 10:55:14 --> Upload Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Controller Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:55:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:55:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:55:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:55:14 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:55:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:55:14 --> Final output sent to browser
DEBUG - 2014-08-13 10:55:14 --> Total execution time: 0.0815
DEBUG - 2014-08-13 10:55:14 --> Config Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:55:14 --> URI Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Router Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Output Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Security Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Input Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:55:14 --> Language Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Loader Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:55:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Session Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:55:14 --> Session routines successfully run
DEBUG - 2014-08-13 10:55:14 --> Upload Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Controller Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:55:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 10:55:14 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 10:55:16 --> Config Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:55:16 --> URI Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Router Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Output Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Security Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Input Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:55:16 --> Language Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Loader Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:55:16 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:55:16 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Session Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:55:16 --> Session routines successfully run
DEBUG - 2014-08-13 10:55:16 --> Upload Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Controller Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:55:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:55:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:55:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:55:16 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:55:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:55:16 --> Final output sent to browser
DEBUG - 2014-08-13 10:55:16 --> Total execution time: 0.1238
DEBUG - 2014-08-13 10:55:17 --> Config Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:55:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:55:17 --> URI Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Router Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Output Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Security Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Input Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:55:17 --> Language Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Loader Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:55:17 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:55:17 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Session Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:55:17 --> Session routines successfully run
DEBUG - 2014-08-13 10:55:17 --> Upload Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Controller Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:55:17 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Model Class Initialized
DEBUG - 2014-08-13 10:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:55:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:55:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:55:17 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:55:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:55:17 --> Final output sent to browser
DEBUG - 2014-08-13 10:55:17 --> Total execution time: 0.0850
DEBUG - 2014-08-13 10:56:42 --> Config Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:56:42 --> URI Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Router Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Output Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Security Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Input Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:56:42 --> Language Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Loader Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:56:42 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Session Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:56:42 --> Session routines successfully run
DEBUG - 2014-08-13 10:56:42 --> Upload Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Controller Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:56:42 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:56:42 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-13 10:56:42 --> Severity: Notice  --> Undefined variable: id F:\wamp\www\hostorks\application\models\superadmin_model.php 259
DEBUG - 2014-08-13 10:56:42 --> Config Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:56:42 --> URI Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Router Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Output Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Security Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Input Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:56:42 --> Language Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Loader Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:56:42 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Session Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:56:42 --> Session routines successfully run
DEBUG - 2014-08-13 10:56:42 --> Upload Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Controller Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:56:42 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:56:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:56:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:56:42 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:56:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:56:42 --> Final output sent to browser
DEBUG - 2014-08-13 10:56:42 --> Total execution time: 0.0865
DEBUG - 2014-08-13 10:56:42 --> Config Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:56:42 --> URI Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Router Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Output Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Security Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Input Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:56:42 --> Language Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Loader Class Initialized
DEBUG - 2014-08-13 10:56:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:56:43 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:56:43 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Session Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:56:43 --> Session routines successfully run
DEBUG - 2014-08-13 10:56:43 --> Upload Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Controller Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:56:43 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 10:56:43 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 10:56:47 --> Config Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:56:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:56:47 --> URI Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Router Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Output Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Security Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Input Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:56:47 --> Language Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Loader Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:56:47 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Session Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:56:47 --> Session routines successfully run
DEBUG - 2014-08-13 10:56:47 --> Upload Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Controller Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:56:47 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:56:47 --> Final output sent to browser
DEBUG - 2014-08-13 10:56:47 --> Total execution time: 0.0795
DEBUG - 2014-08-13 10:56:47 --> Config Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 10:56:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 10:56:47 --> URI Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Router Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Output Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Security Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Input Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 10:56:47 --> Language Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Loader Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: file_helper
DEBUG - 2014-08-13 10:56:47 --> Database Driver Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Session Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 10:56:47 --> Session routines successfully run
DEBUG - 2014-08-13 10:56:47 --> Upload Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Pagination Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Controller Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 10:56:47 --> Form Validation Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Model Class Initialized
DEBUG - 2014-08-13 10:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 10:56:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 10:56:47 --> Final output sent to browser
DEBUG - 2014-08-13 10:56:47 --> Total execution time: 0.1217
DEBUG - 2014-08-13 11:03:02 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:02 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:02 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:02 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:02 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:02 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:03:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:03:02 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:03:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:03:02 --> Final output sent to browser
DEBUG - 2014-08-13 11:03:02 --> Total execution time: 0.0788
DEBUG - 2014-08-13 11:03:02 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:02 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:02 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:02 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:02 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:02 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:03:02 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:03:05 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:05 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:05 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:05 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:05 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:05 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:05 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:05 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:03:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:03:05 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:03:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:03:05 --> Final output sent to browser
DEBUG - 2014-08-13 11:03:05 --> Total execution time: 0.0782
DEBUG - 2014-08-13 11:03:05 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:05 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:05 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:06 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:06 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:06 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:06 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:06 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:06 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:03:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:03:06 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:03:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:03:06 --> Final output sent to browser
DEBUG - 2014-08-13 11:03:06 --> Total execution time: 0.0776
DEBUG - 2014-08-13 11:03:28 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:28 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:28 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:28 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:28 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:28 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:28 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:28 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:03:28 --> Severity: Notice  --> Undefined variable: id F:\wamp\www\hostorks\application\models\superadmin_model.php 259
DEBUG - 2014-08-13 11:03:28 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:28 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:28 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:28 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:28 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:28 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:28 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:03:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:03:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:03:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:03:28 --> Final output sent to browser
DEBUG - 2014-08-13 11:03:28 --> Total execution time: 0.0832
DEBUG - 2014-08-13 11:03:28 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:28 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:28 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:28 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:28 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:28 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:28 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:03:28 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:03:30 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:30 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:30 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:30 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:30 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:30 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:30 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:30 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:03:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:03:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:03:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:03:30 --> Final output sent to browser
DEBUG - 2014-08-13 11:03:30 --> Total execution time: 0.0781
DEBUG - 2014-08-13 11:03:30 --> Config Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:03:30 --> URI Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Router Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Output Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Security Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Input Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:03:30 --> Language Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Loader Class Initialized
DEBUG - 2014-08-13 11:03:30 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:03:30 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:03:31 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Session Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:03:31 --> Session routines successfully run
DEBUG - 2014-08-13 11:03:31 --> Upload Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Controller Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:03:31 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 11:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:03:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:03:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:03:31 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:03:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:03:31 --> Final output sent to browser
DEBUG - 2014-08-13 11:03:31 --> Total execution time: 0.0798
DEBUG - 2014-08-13 11:11:21 --> Config Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:11:21 --> URI Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Router Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Output Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Security Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Input Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:11:21 --> Language Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Loader Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:11:21 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:11:21 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Session Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:11:21 --> Session routines successfully run
DEBUG - 2014-08-13 11:11:21 --> Upload Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Controller Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:11:21 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:11:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:11:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:11:21 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:11:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:11:21 --> Final output sent to browser
DEBUG - 2014-08-13 11:11:21 --> Total execution time: 0.0855
DEBUG - 2014-08-13 11:11:22 --> Config Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:11:22 --> URI Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Router Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Output Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Security Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Input Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:11:22 --> Language Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Loader Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:11:22 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:11:22 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Session Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:11:22 --> Session routines successfully run
DEBUG - 2014-08-13 11:11:22 --> Upload Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Controller Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:11:22 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:11:22 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:11:23 --> Config Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:11:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:11:23 --> URI Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Router Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Output Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Security Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Input Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:11:23 --> Language Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Loader Class Initialized
DEBUG - 2014-08-13 11:11:23 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:11:23 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:11:24 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Session Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:11:24 --> Session routines successfully run
DEBUG - 2014-08-13 11:11:24 --> Upload Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Controller Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:11:24 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:11:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:11:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:11:24 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:11:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:11:24 --> Final output sent to browser
DEBUG - 2014-08-13 11:11:24 --> Total execution time: 0.0813
DEBUG - 2014-08-13 11:11:24 --> Config Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:11:24 --> URI Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Router Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Output Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Security Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Input Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:11:24 --> Language Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Loader Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:11:24 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:11:24 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Session Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:11:24 --> Session routines successfully run
DEBUG - 2014-08-13 11:11:24 --> Upload Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Controller Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:11:24 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:11:24 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:11:26 --> Config Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:11:26 --> URI Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Router Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Output Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Security Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Input Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:11:26 --> Language Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Loader Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:11:26 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Session Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:11:26 --> Session routines successfully run
DEBUG - 2014-08-13 11:11:26 --> Upload Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Controller Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:11:26 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:11:26 --> Final output sent to browser
DEBUG - 2014-08-13 11:11:26 --> Total execution time: 0.0774
DEBUG - 2014-08-13 11:11:26 --> Config Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:11:26 --> URI Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Router Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Output Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Security Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Input Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:11:26 --> Language Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Loader Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:11:26 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Session Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:11:26 --> Session routines successfully run
DEBUG - 2014-08-13 11:11:26 --> Upload Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Controller Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:11:26 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Model Class Initialized
DEBUG - 2014-08-13 11:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:11:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:11:26 --> Final output sent to browser
DEBUG - 2014-08-13 11:11:26 --> Total execution time: 0.0804
DEBUG - 2014-08-13 11:13:14 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:14 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:14 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:14 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:14 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:14 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:14 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:14 --> Total execution time: 0.0947
DEBUG - 2014-08-13 11:13:14 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:14 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:14 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:14 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:14 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:14 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:14 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:13:14 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:13:27 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:27 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:27 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:27 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:27 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:27 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:27 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:27 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:27 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:27 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:27 --> Total execution time: 0.0795
DEBUG - 2014-08-13 11:13:27 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:27 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:27 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:27 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:28 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:28 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:28 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:28 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:28 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:13:28 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:13:29 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:29 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:29 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:29 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:29 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:29 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:29 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:29 --> Total execution time: 0.1078
DEBUG - 2014-08-13 11:13:29 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:29 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:29 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:29 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:29 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:29 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:29 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:29 --> Total execution time: 0.1045
DEBUG - 2014-08-13 11:13:45 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:45 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:45 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:45 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:45 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:45 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:45 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:45 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:45 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:45 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:45 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:45 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:45 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:45 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:45 --> Total execution time: 0.0854
DEBUG - 2014-08-13 11:13:45 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:45 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:45 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:45 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:46 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:46 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:46 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:46 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:13:46 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:13:47 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:47 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:47 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:47 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:47 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:47 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:47 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:47 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:47 --> Total execution time: 0.0805
DEBUG - 2014-08-13 11:13:47 --> Config Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:13:47 --> URI Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Router Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Output Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Security Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Input Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:13:47 --> Language Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Loader Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:13:47 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Session Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:13:47 --> Session routines successfully run
DEBUG - 2014-08-13 11:13:47 --> Upload Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Controller Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:13:47 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:13:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:13:47 --> Final output sent to browser
DEBUG - 2014-08-13 11:13:47 --> Total execution time: 0.0743
DEBUG - 2014-08-13 11:14:23 --> Config Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:14:23 --> URI Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Router Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Output Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Security Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Input Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:14:23 --> Language Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Loader Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:14:23 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Session Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:14:23 --> Session routines successfully run
DEBUG - 2014-08-13 11:14:23 --> Upload Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Controller Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:14:23 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:14:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:14:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:14:23 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:14:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:14:23 --> Final output sent to browser
DEBUG - 2014-08-13 11:14:23 --> Total execution time: 0.0758
DEBUG - 2014-08-13 11:14:23 --> Config Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:14:23 --> URI Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Router Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Output Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Security Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Input Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:14:23 --> Language Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Loader Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:14:23 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Session Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:14:23 --> Session routines successfully run
DEBUG - 2014-08-13 11:14:23 --> Upload Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Controller Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:14:23 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:14:23 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:14:25 --> Config Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:14:25 --> URI Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Router Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Output Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Security Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Input Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:14:25 --> Language Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Loader Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:14:25 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Session Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:14:25 --> Session routines successfully run
DEBUG - 2014-08-13 11:14:25 --> Upload Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Controller Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:14:25 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:14:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:14:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:14:25 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:14:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:14:25 --> Final output sent to browser
DEBUG - 2014-08-13 11:14:25 --> Total execution time: 0.0742
DEBUG - 2014-08-13 11:14:25 --> Config Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:14:25 --> URI Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Router Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Output Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Security Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Input Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:14:25 --> Language Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Loader Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:14:25 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Session Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:14:25 --> Session routines successfully run
DEBUG - 2014-08-13 11:14:25 --> Upload Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Controller Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:14:25 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Model Class Initialized
DEBUG - 2014-08-13 11:14:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:14:25 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:43:43 --> Config Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:43:43 --> URI Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Router Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Output Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Security Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Input Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:43:43 --> Language Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Loader Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:43:43 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:43:43 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Session Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:43:43 --> Session routines successfully run
DEBUG - 2014-08-13 11:43:43 --> Upload Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Controller Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:43:43 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:43:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:43:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:43:43 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:43:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:43:43 --> Final output sent to browser
DEBUG - 2014-08-13 11:43:43 --> Total execution time: 0.0776
DEBUG - 2014-08-13 11:43:43 --> Config Class Initialized
DEBUG - 2014-08-13 11:43:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:43:44 --> URI Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Router Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Output Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Security Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Input Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:43:44 --> Language Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Loader Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:43:44 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:43:44 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Session Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:43:44 --> Session routines successfully run
DEBUG - 2014-08-13 11:43:44 --> Upload Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Controller Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:43:44 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:43:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:43:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:43:44 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:43:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:43:44 --> Final output sent to browser
DEBUG - 2014-08-13 11:43:44 --> Total execution time: 0.0881
DEBUG - 2014-08-13 11:43:46 --> Config Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:43:46 --> URI Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Router Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Output Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Security Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Input Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:43:46 --> Language Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Loader Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:43:46 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Session Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:43:46 --> Session routines successfully run
DEBUG - 2014-08-13 11:43:46 --> Upload Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Controller Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:43:46 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:43:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:43:46 --> Config Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:43:46 --> URI Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Router Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Output Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Security Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Input Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:43:46 --> Language Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Loader Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:43:46 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Session Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:43:46 --> Session routines successfully run
DEBUG - 2014-08-13 11:43:46 --> Upload Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Controller Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:43:46 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:43:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:43:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:43:46 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:43:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:43:46 --> Final output sent to browser
DEBUG - 2014-08-13 11:43:46 --> Total execution time: 0.0798
DEBUG - 2014-08-13 11:43:47 --> Config Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:43:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:43:47 --> URI Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Router Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Output Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Security Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Input Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:43:47 --> Language Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Loader Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:43:47 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:43:47 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Session Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:43:47 --> Session routines successfully run
DEBUG - 2014-08-13 11:43:47 --> Upload Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Controller Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:43:47 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Model Class Initialized
DEBUG - 2014-08-13 11:43:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:43:47 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:50:51 --> Config Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:50:51 --> URI Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Router Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Output Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Security Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Input Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:50:51 --> Language Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Loader Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:50:51 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Session Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:50:51 --> Session routines successfully run
DEBUG - 2014-08-13 11:50:51 --> Upload Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Controller Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:50:51 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:50:51 --> Final output sent to browser
DEBUG - 2014-08-13 11:50:51 --> Total execution time: 0.0807
DEBUG - 2014-08-13 11:50:51 --> Config Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:50:51 --> URI Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Router Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Output Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Security Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Input Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:50:51 --> Language Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Loader Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:50:51 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Session Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:50:51 --> Session routines successfully run
DEBUG - 2014-08-13 11:50:51 --> Upload Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Controller Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:50:51 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:50:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:50:51 --> Final output sent to browser
DEBUG - 2014-08-13 11:50:51 --> Total execution time: 0.0918
DEBUG - 2014-08-13 11:50:59 --> Config Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:50:59 --> URI Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Router Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Output Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Security Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Input Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:50:59 --> Language Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Loader Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:50:59 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Session Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:50:59 --> Session routines successfully run
DEBUG - 2014-08-13 11:50:59 --> Upload Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Controller Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:50:59 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:50:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:50:59 --> Config Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:50:59 --> URI Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Router Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Output Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Security Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Input Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:50:59 --> Language Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Loader Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:50:59 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Session Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:50:59 --> Session routines successfully run
DEBUG - 2014-08-13 11:50:59 --> Upload Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Controller Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:50:59 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Model Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:50:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:50:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:50:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:50:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:50:59 --> Final output sent to browser
DEBUG - 2014-08-13 11:50:59 --> Total execution time: 0.0882
DEBUG - 2014-08-13 11:50:59 --> Config Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:50:59 --> URI Class Initialized
DEBUG - 2014-08-13 11:50:59 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:00 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:00 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:00 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:00 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:00 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:51:00 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:51:02 --> Config Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:51:02 --> URI Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:02 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:02 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:02 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:02 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:51:02 --> Final output sent to browser
DEBUG - 2014-08-13 11:51:02 --> Total execution time: 0.0779
DEBUG - 2014-08-13 11:51:02 --> Config Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:51:02 --> URI Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:02 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:02 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:02 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:02 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:51:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:51:02 --> Final output sent to browser
DEBUG - 2014-08-13 11:51:02 --> Total execution time: 0.0742
DEBUG - 2014-08-13 11:51:48 --> Config Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:51:48 --> URI Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:48 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:48 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:48 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:48 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:48 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:51:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:51:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:51:48 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:51:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:51:48 --> Final output sent to browser
DEBUG - 2014-08-13 11:51:48 --> Total execution time: 0.0785
DEBUG - 2014-08-13 11:51:48 --> Config Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:51:48 --> URI Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:48 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:48 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:48 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:48 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:48 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:51:48 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:51:50 --> Config Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:51:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:51:50 --> URI Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:50 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:50 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:50 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:50 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:51:50 --> Final output sent to browser
DEBUG - 2014-08-13 11:51:50 --> Total execution time: 0.0786
DEBUG - 2014-08-13 11:51:50 --> Config Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:51:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:51:50 --> URI Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Router Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Output Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Security Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Input Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:51:50 --> Language Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Loader Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:51:50 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Session Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:51:50 --> Session routines successfully run
DEBUG - 2014-08-13 11:51:50 --> Upload Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Controller Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:51:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Model Class Initialized
DEBUG - 2014-08-13 11:51:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:51:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:51:50 --> Final output sent to browser
DEBUG - 2014-08-13 11:51:50 --> Total execution time: 0.0928
DEBUG - 2014-08-13 11:53:34 --> Config Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:53:34 --> URI Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Router Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Output Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Security Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Input Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:53:34 --> Language Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Loader Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:53:34 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Session Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:53:34 --> Session routines successfully run
DEBUG - 2014-08-13 11:53:34 --> Upload Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Controller Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:53:34 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:53:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:53:34 --> Config Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:53:34 --> URI Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Router Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Output Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Security Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Input Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:53:34 --> Language Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Loader Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:53:34 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Session Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:53:34 --> Session routines successfully run
DEBUG - 2014-08-13 11:53:34 --> Upload Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Controller Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:53:34 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:53:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:53:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:53:34 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:53:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:53:34 --> Final output sent to browser
DEBUG - 2014-08-13 11:53:34 --> Total execution time: 0.0800
DEBUG - 2014-08-13 11:53:34 --> Config Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:53:34 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:53:34 --> URI Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Router Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Output Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Security Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Input Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:53:35 --> Language Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Loader Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:53:35 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:53:35 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Session Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:53:35 --> Session routines successfully run
DEBUG - 2014-08-13 11:53:35 --> Upload Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Controller Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:53:35 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:53:35 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:53:36 --> Config Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:53:36 --> URI Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Router Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Output Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Security Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Input Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:53:36 --> Language Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Loader Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:53:36 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Session Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:53:36 --> Session routines successfully run
DEBUG - 2014-08-13 11:53:36 --> Upload Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Controller Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:53:36 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:53:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:53:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:53:36 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:53:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:53:36 --> Final output sent to browser
DEBUG - 2014-08-13 11:53:36 --> Total execution time: 0.1366
DEBUG - 2014-08-13 11:53:36 --> Config Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:53:36 --> URI Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Router Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Output Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Security Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Input Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:53:36 --> Language Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Loader Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:53:36 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Session Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:53:36 --> Session routines successfully run
DEBUG - 2014-08-13 11:53:36 --> Upload Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:53:36 --> Controller Class Initialized
DEBUG - 2014-08-13 11:53:37 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:53:37 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:53:37 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:37 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:37 --> Model Class Initialized
DEBUG - 2014-08-13 11:53:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:53:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:53:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:53:37 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:53:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:53:37 --> Final output sent to browser
DEBUG - 2014-08-13 11:53:37 --> Total execution time: 0.0999
DEBUG - 2014-08-13 11:55:05 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:05 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:05 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:05 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:05 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:05 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:05 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:55:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:55:05 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:55:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:55:05 --> Final output sent to browser
DEBUG - 2014-08-13 11:55:05 --> Total execution time: 0.1060
DEBUG - 2014-08-13 11:55:05 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:05 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:05 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:05 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:05 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:05 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:05 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:55:05 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:55:06 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:06 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:06 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:06 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:07 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:07 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:07 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:07 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:55:07 --> Final output sent to browser
DEBUG - 2014-08-13 11:55:07 --> Total execution time: 0.1090
DEBUG - 2014-08-13 11:55:07 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:07 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:07 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:07 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:07 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:07 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:07 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:07 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:55:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:55:07 --> Final output sent to browser
DEBUG - 2014-08-13 11:55:07 --> Total execution time: 0.0839
DEBUG - 2014-08-13 11:55:11 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:11 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:11 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:11 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:11 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:11 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:11 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:11 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:11 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:11 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:11 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:11 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:11 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:11 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:55:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:55:11 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:55:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:55:11 --> Final output sent to browser
DEBUG - 2014-08-13 11:55:11 --> Total execution time: 0.0819
DEBUG - 2014-08-13 11:55:11 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:11 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:11 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:11 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:11 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:11 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:11 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-13 11:55:11 --> 404 Page Not Found --> 
DEBUG - 2014-08-13 11:55:13 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:13 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:13 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:13 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:13 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:13 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:13 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:55:13 --> Final output sent to browser
DEBUG - 2014-08-13 11:55:13 --> Total execution time: 0.0807
DEBUG - 2014-08-13 11:55:13 --> Config Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:55:13 --> URI Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Router Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Output Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Security Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Input Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:55:13 --> Language Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Loader Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:55:13 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Session Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:55:13 --> Session routines successfully run
DEBUG - 2014-08-13 11:55:13 --> Upload Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Controller Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:55:13 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Model Class Initialized
DEBUG - 2014-08-13 11:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:55:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:55:13 --> Final output sent to browser
DEBUG - 2014-08-13 11:55:13 --> Total execution time: 0.0799
DEBUG - 2014-08-13 11:56:09 --> Config Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:56:09 --> URI Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Router Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Output Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Security Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Input Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:56:09 --> Language Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Loader Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:56:09 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Session Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:56:09 --> Session routines successfully run
DEBUG - 2014-08-13 11:56:09 --> Upload Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Controller Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:56:09 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:56:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:56:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:56:09 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:56:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:56:09 --> Final output sent to browser
DEBUG - 2014-08-13 11:56:09 --> Total execution time: 0.0859
DEBUG - 2014-08-13 11:56:09 --> Config Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:56:09 --> URI Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Router Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Output Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Security Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Input Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:56:09 --> Language Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Loader Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:56:09 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Session Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:56:09 --> Session routines successfully run
DEBUG - 2014-08-13 11:56:09 --> Upload Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Controller Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:56:09 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:09 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:10 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:56:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:56:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:56:10 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:56:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:56:10 --> Final output sent to browser
DEBUG - 2014-08-13 11:56:10 --> Total execution time: 0.0812
DEBUG - 2014-08-13 11:56:44 --> Config Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:56:44 --> URI Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Router Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Output Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Security Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Input Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:56:44 --> Language Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Loader Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:56:44 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Session Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:56:44 --> Session routines successfully run
DEBUG - 2014-08-13 11:56:44 --> Upload Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Controller Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:56:44 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:56:44 --> Final output sent to browser
DEBUG - 2014-08-13 11:56:44 --> Total execution time: 0.0818
DEBUG - 2014-08-13 11:56:44 --> Config Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:56:44 --> URI Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Router Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Output Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Security Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Input Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:56:44 --> Language Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Loader Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:56:44 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Session Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:56:44 --> Session routines successfully run
DEBUG - 2014-08-13 11:56:44 --> Upload Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Controller Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:56:44 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:56:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:56:44 --> Final output sent to browser
DEBUG - 2014-08-13 11:56:44 --> Total execution time: 0.0896
DEBUG - 2014-08-13 11:56:58 --> Config Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:56:58 --> URI Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Router Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Output Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Security Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Input Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:56:58 --> Language Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Loader Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:56:58 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Session Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:56:58 --> Session routines successfully run
DEBUG - 2014-08-13 11:56:58 --> Upload Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Controller Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:56:58 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:56:58 --> Final output sent to browser
DEBUG - 2014-08-13 11:56:58 --> Total execution time: 0.0965
DEBUG - 2014-08-13 11:56:58 --> Config Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 11:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 11:56:58 --> URI Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Router Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Output Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Security Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Input Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 11:56:58 --> Language Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Loader Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: file_helper
DEBUG - 2014-08-13 11:56:58 --> Database Driver Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Session Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 11:56:58 --> Session routines successfully run
DEBUG - 2014-08-13 11:56:58 --> Upload Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Pagination Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Controller Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Helper loaded: form_helper
DEBUG - 2014-08-13 11:56:58 --> Form Validation Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Model Class Initialized
DEBUG - 2014-08-13 11:56:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-13 11:56:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-13 11:56:58 --> Final output sent to browser
DEBUG - 2014-08-13 11:56:58 --> Total execution time: 0.1053

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-28 05:58:28 --> Config Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:58:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:58:28 --> URI Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Router Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Output Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Security Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Input Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:58:28 --> Language Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Loader Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:58:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:58:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Session Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:58:28 --> A session cookie was not found.
DEBUG - 2014-07-28 05:58:28 --> Session routines successfully run
DEBUG - 2014-07-28 05:58:28 --> Upload Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Controller Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:58:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:58:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 05:58:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 05:58:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-28 05:58:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 05:58:28 --> Final output sent to browser
DEBUG - 2014-07-28 05:58:28 --> Total execution time: 0.1750
DEBUG - 2014-07-28 05:58:32 --> Config Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:58:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:58:32 --> URI Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Router Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Output Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Security Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Input Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:58:32 --> Language Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Loader Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:58:32 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:58:32 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Session Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:58:32 --> Session routines successfully run
DEBUG - 2014-07-28 05:58:32 --> Upload Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Controller Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:58:32 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:58:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 05:58:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 05:58:32 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 05:58:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 05:58:32 --> Final output sent to browser
DEBUG - 2014-07-28 05:58:32 --> Total execution time: 0.1300
DEBUG - 2014-07-28 05:58:33 --> Config Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:58:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:58:33 --> URI Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Router Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Output Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Security Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Input Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:58:33 --> Language Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Loader Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:58:33 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:58:33 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Session Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:58:33 --> Session routines successfully run
DEBUG - 2014-07-28 05:58:33 --> Upload Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Controller Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:58:33 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Model Class Initialized
DEBUG - 2014-07-28 05:58:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 05:58:33 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 05:59:26 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:26 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:26 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:26 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:26 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:26 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:26 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:26 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:26 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:26 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:26 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:26 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:26 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:26 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:26 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 05:59:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 05:59:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 05:59:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 05:59:27 --> Final output sent to browser
DEBUG - 2014-07-28 05:59:27 --> Total execution time: 0.0809
DEBUG - 2014-07-28 05:59:27 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:27 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:27 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:27 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:27 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:27 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:27 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:27 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 05:59:27 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 05:59:29 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:29 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:29 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:29 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:29 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 05:59:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 05:59:29 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 05:59:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 05:59:29 --> Final output sent to browser
DEBUG - 2014-07-28 05:59:29 --> Total execution time: 0.0814
DEBUG - 2014-07-28 05:59:30 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:30 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:30 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:30 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:30 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:30 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:30 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:30 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 05:59:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 05:59:30 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 05:59:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 05:59:30 --> Final output sent to browser
DEBUG - 2014-07-28 05:59:30 --> Total execution time: 0.0981
DEBUG - 2014-07-28 05:59:34 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:34 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:34 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:34 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:34 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:34 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:34 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:34 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:34 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:34 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:34 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:34 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:34 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:34 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 05:59:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 05:59:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 05:59:34 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 05:59:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 05:59:34 --> Final output sent to browser
DEBUG - 2014-07-28 05:59:34 --> Total execution time: 0.0928
DEBUG - 2014-07-28 05:59:34 --> Config Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Hooks Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Utf8 Class Initialized
DEBUG - 2014-07-28 05:59:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 05:59:34 --> URI Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Router Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Output Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Security Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Input Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 05:59:34 --> Language Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Loader Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: url_helper
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: file_helper
DEBUG - 2014-07-28 05:59:34 --> Database Driver Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Session Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: string_helper
DEBUG - 2014-07-28 05:59:34 --> Session routines successfully run
DEBUG - 2014-07-28 05:59:34 --> Upload Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Pagination Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Controller Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Helper loaded: form_helper
DEBUG - 2014-07-28 05:59:34 --> Form Validation Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Model Class Initialized
DEBUG - 2014-07-28 05:59:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 05:59:34 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:00:04 --> Config Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:00:04 --> URI Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Router Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Output Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Security Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Input Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:00:04 --> Language Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Loader Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:00:04 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:00:04 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Session Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:00:04 --> Session routines successfully run
DEBUG - 2014-07-28 06:00:04 --> Upload Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Controller Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:00:04 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Model Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Model Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Model Class Initialized
DEBUG - 2014-07-28 06:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:00:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:00:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 06:00:04 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 06:00:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:00:04 --> Final output sent to browser
DEBUG - 2014-07-28 06:00:04 --> Total execution time: 0.0957
DEBUG - 2014-07-28 06:00:05 --> Config Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:00:05 --> URI Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Router Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Output Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Security Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Input Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:00:05 --> Language Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Loader Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:00:05 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:00:05 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Session Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:00:05 --> Session routines successfully run
DEBUG - 2014-07-28 06:00:05 --> Upload Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Controller Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:00:05 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Model Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Model Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Model Class Initialized
DEBUG - 2014-07-28 06:00:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:00:05 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:01:12 --> Config Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:01:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:01:12 --> URI Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Router Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Output Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Security Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Input Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:01:12 --> Language Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Loader Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:01:12 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:01:12 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Session Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:01:12 --> Session routines successfully run
DEBUG - 2014-07-28 06:01:12 --> Upload Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Controller Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:01:12 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Model Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Model Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Model Class Initialized
DEBUG - 2014-07-28 06:01:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:01:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:53:17 --> Config Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:53:17 --> URI Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Router Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Output Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Security Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Input Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:53:17 --> Language Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Loader Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:53:17 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:53:17 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Session Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:53:17 --> Session routines successfully run
DEBUG - 2014-07-28 06:53:17 --> Upload Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Controller Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:53:17 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:53:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:53:17 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 6
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_title F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 26
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_title F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 34
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_title F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 43
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_desc F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 55
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_vtext F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 66
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_vlink F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 75
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_stext F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 84
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_slink F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 93
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 104
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 108
ERROR - 2014-07-28 06:53:17 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 115
DEBUG - 2014-07-28 06:53:17 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 06:53:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:53:17 --> Final output sent to browser
DEBUG - 2014-07-28 06:53:17 --> Total execution time: 0.1046
DEBUG - 2014-07-28 06:53:18 --> Config Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:53:18 --> URI Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Router Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Output Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Security Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Input Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:53:18 --> Language Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Loader Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:53:18 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:53:18 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Session Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:53:18 --> Session routines successfully run
DEBUG - 2014-07-28 06:53:18 --> Upload Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Controller Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:53:18 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:53:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:53:58 --> Config Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:53:58 --> URI Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Router Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Output Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Security Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Input Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:53:58 --> Language Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Loader Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:53:58 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:53:58 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Session Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:53:58 --> Session routines successfully run
DEBUG - 2014-07-28 06:53:58 --> Upload Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Controller Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:53:58 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Model Class Initialized
DEBUG - 2014-07-28 06:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:53:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:53:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 06:54:14 --> Config Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:54:14 --> URI Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Router Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Output Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Security Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Input Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:54:14 --> Language Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Loader Class Initialized
DEBUG - 2014-07-28 06:54:14 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:54:14 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:54:14 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Session Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:54:15 --> Session routines successfully run
DEBUG - 2014-07-28 06:54:15 --> Upload Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Controller Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:54:15 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:54:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:54:15 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 06:54:15 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 6
ERROR - 2014-07-28 06:54:15 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 104
ERROR - 2014-07-28 06:54:15 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 108
ERROR - 2014-07-28 06:54:15 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 115
DEBUG - 2014-07-28 06:54:15 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 06:54:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:54:15 --> Final output sent to browser
DEBUG - 2014-07-28 06:54:15 --> Total execution time: 0.1063
DEBUG - 2014-07-28 06:54:15 --> Config Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:54:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:54:15 --> URI Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Router Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Output Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Security Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Input Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:54:15 --> Language Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Loader Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:54:15 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:54:15 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Session Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:54:15 --> Session routines successfully run
DEBUG - 2014-07-28 06:54:15 --> Upload Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Controller Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:54:15 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:54:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:54:15 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:55:14 --> Config Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:55:14 --> URI Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Router Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Output Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Security Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Input Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:55:14 --> Language Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Loader Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:55:14 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:55:14 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Session Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:55:14 --> Session routines successfully run
DEBUG - 2014-07-28 06:55:14 --> Upload Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Controller Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:55:14 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:55:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:55:14 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 06:55:14 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 6
ERROR - 2014-07-28 06:55:14 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 105
ERROR - 2014-07-28 06:55:14 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 109
ERROR - 2014-07-28 06:55:14 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 116
DEBUG - 2014-07-28 06:55:14 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 06:55:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:55:14 --> Final output sent to browser
DEBUG - 2014-07-28 06:55:14 --> Total execution time: 0.0937
DEBUG - 2014-07-28 06:55:15 --> Config Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:55:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:55:15 --> URI Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Router Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Output Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Security Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Input Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:55:15 --> Language Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Loader Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:55:15 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:55:15 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Session Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:55:15 --> Session routines successfully run
DEBUG - 2014-07-28 06:55:15 --> Upload Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Controller Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:55:15 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:55:15 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:55:25 --> Config Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:55:25 --> URI Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Router Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Output Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Security Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Input Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:55:25 --> Language Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Loader Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:55:25 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Session Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:55:25 --> Session routines successfully run
DEBUG - 2014-07-28 06:55:25 --> Upload Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Controller Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:55:25 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:55:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:55:25 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 06:55:25 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 6
ERROR - 2014-07-28 06:55:25 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 105
ERROR - 2014-07-28 06:55:25 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 109
ERROR - 2014-07-28 06:55:25 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 116
DEBUG - 2014-07-28 06:55:25 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 06:55:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:55:25 --> Final output sent to browser
DEBUG - 2014-07-28 06:55:25 --> Total execution time: 0.0925
DEBUG - 2014-07-28 06:55:25 --> Config Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:55:25 --> URI Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Router Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Output Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Security Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Input Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:55:25 --> Language Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Loader Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:55:25 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Session Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:55:25 --> Session routines successfully run
DEBUG - 2014-07-28 06:55:25 --> Upload Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Controller Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:55:25 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Model Class Initialized
DEBUG - 2014-07-28 06:55:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:55:25 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:56:05 --> Config Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:56:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:56:05 --> URI Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Router Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Output Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Security Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Input Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:56:05 --> Language Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Loader Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:56:05 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:56:05 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Session Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:56:05 --> Session routines successfully run
DEBUG - 2014-07-28 06:56:05 --> Upload Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Controller Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:56:05 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:56:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:56:05 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 06:56:05 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 105
ERROR - 2014-07-28 06:56:05 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 109
ERROR - 2014-07-28 06:56:05 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 116
DEBUG - 2014-07-28 06:56:05 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 06:56:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:56:05 --> Final output sent to browser
DEBUG - 2014-07-28 06:56:05 --> Total execution time: 0.1010
DEBUG - 2014-07-28 06:56:06 --> Config Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:56:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:56:06 --> URI Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Router Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Output Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Security Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Input Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:56:06 --> Language Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Loader Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:56:06 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:56:06 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Session Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:56:06 --> Session routines successfully run
DEBUG - 2014-07-28 06:56:06 --> Upload Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Controller Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:56:06 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:56:06 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 06:56:37 --> Config Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:56:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:56:37 --> URI Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Router Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Output Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Security Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Input Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:56:37 --> Language Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Loader Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:56:37 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:56:37 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Session Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:56:37 --> Session routines successfully run
DEBUG - 2014-07-28 06:56:37 --> Upload Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Controller Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:56:37 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 06:56:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 06:56:37 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 06:56:37 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 105
ERROR - 2014-07-28 06:56:37 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 109
ERROR - 2014-07-28 06:56:37 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 116
DEBUG - 2014-07-28 06:56:37 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 06:56:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 06:56:37 --> Final output sent to browser
DEBUG - 2014-07-28 06:56:37 --> Total execution time: 0.1070
DEBUG - 2014-07-28 06:56:37 --> Config Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Hooks Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Utf8 Class Initialized
DEBUG - 2014-07-28 06:56:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 06:56:37 --> URI Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Router Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Output Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Security Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Input Class Initialized
DEBUG - 2014-07-28 06:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 06:56:38 --> Language Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Loader Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Helper loaded: url_helper
DEBUG - 2014-07-28 06:56:38 --> Helper loaded: file_helper
DEBUG - 2014-07-28 06:56:38 --> Database Driver Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Session Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Helper loaded: string_helper
DEBUG - 2014-07-28 06:56:38 --> Session routines successfully run
DEBUG - 2014-07-28 06:56:38 --> Upload Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Pagination Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Controller Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Helper loaded: form_helper
DEBUG - 2014-07-28 06:56:38 --> Form Validation Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Model Class Initialized
DEBUG - 2014-07-28 06:56:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 06:56:38 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:34:15 --> Config Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:34:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:34:15 --> URI Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Router Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Output Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Security Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Input Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:34:15 --> Language Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Loader Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:34:15 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Session Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:34:15 --> Session routines successfully run
DEBUG - 2014-07-28 07:34:15 --> Upload Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Controller Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:34:15 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:34:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:34:15 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 07:34:15 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 120
ERROR - 2014-07-28 07:34:15 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 124
ERROR - 2014-07-28 07:34:15 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 131
DEBUG - 2014-07-28 07:34:15 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:34:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:34:15 --> Final output sent to browser
DEBUG - 2014-07-28 07:34:15 --> Total execution time: 0.0822
DEBUG - 2014-07-28 07:34:15 --> Config Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:34:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:34:15 --> URI Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Router Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Output Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Security Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Input Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:34:15 --> Language Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Loader Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:34:15 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Session Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:34:15 --> Session routines successfully run
DEBUG - 2014-07-28 07:34:15 --> Upload Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Controller Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:34:15 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:34:15 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:34:29 --> Config Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:34:29 --> URI Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Router Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Output Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Security Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Input Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:34:29 --> Language Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Loader Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:34:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:34:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Session Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:34:29 --> Session routines successfully run
DEBUG - 2014-07-28 07:34:29 --> Upload Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Controller Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:34:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:34:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:34:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 07:34:45 --> Config Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:34:45 --> URI Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Router Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Output Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Security Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Input Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:34:45 --> Language Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Loader Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:34:45 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:34:45 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Session Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:34:45 --> Session routines successfully run
DEBUG - 2014-07-28 07:34:45 --> Upload Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Controller Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:34:45 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:34:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:34:45 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 07:34:45 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 118
ERROR - 2014-07-28 07:34:45 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 122
ERROR - 2014-07-28 07:34:45 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 129
DEBUG - 2014-07-28 07:34:45 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:34:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:34:45 --> Final output sent to browser
DEBUG - 2014-07-28 07:34:45 --> Total execution time: 0.0970
DEBUG - 2014-07-28 07:34:46 --> Config Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:34:46 --> URI Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Router Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Output Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Security Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Input Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:34:46 --> Language Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Loader Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:34:46 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:34:46 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Session Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:34:46 --> Session routines successfully run
DEBUG - 2014-07-28 07:34:46 --> Upload Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Controller Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:34:46 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Model Class Initialized
DEBUG - 2014-07-28 07:34:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:34:46 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:40:50 --> Config Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:40:50 --> URI Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Router Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Output Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Security Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Input Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:40:50 --> Language Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Loader Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:40:50 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:40:50 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Session Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:40:50 --> Session routines successfully run
DEBUG - 2014-07-28 07:40:50 --> Upload Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Controller Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:40:50 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Model Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Model Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Model Class Initialized
DEBUG - 2014-07-28 07:40:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:40:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:40:50 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 07:40:50 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 126
ERROR - 2014-07-28 07:40:50 --> Severity: Notice  --> Undefined variable: slide_image F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 130
ERROR - 2014-07-28 07:40:50 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 137
DEBUG - 2014-07-28 07:40:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:40:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:40:50 --> Final output sent to browser
DEBUG - 2014-07-28 07:40:50 --> Total execution time: 0.0926
DEBUG - 2014-07-28 07:40:51 --> Config Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:40:51 --> URI Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Router Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Output Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Security Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Input Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:40:51 --> Language Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Loader Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:40:51 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:40:51 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Session Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:40:51 --> Session routines successfully run
DEBUG - 2014-07-28 07:40:51 --> Upload Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Controller Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:40:51 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Model Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Model Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Model Class Initialized
DEBUG - 2014-07-28 07:40:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:40:51 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:41:35 --> Config Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:41:35 --> URI Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Router Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Output Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Security Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Input Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:41:35 --> Language Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Loader Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:41:35 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Session Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:41:35 --> Session routines successfully run
DEBUG - 2014-07-28 07:41:35 --> Upload Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Controller Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:41:35 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:41:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:41:35 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-28 07:41:35 --> Severity: Notice  --> Undefined variable: edit_slide_id F:\wamp\www\hostorks\application\views\superadmin\home_plans.php 75
DEBUG - 2014-07-28 07:41:35 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:41:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:41:35 --> Final output sent to browser
DEBUG - 2014-07-28 07:41:35 --> Total execution time: 0.0845
DEBUG - 2014-07-28 07:41:35 --> Config Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:41:35 --> URI Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Router Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Output Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Security Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Input Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:41:35 --> Language Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Loader Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:41:35 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Session Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:41:35 --> Session routines successfully run
DEBUG - 2014-07-28 07:41:35 --> Upload Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Controller Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:41:35 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:41:35 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:41:59 --> Config Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:41:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:41:59 --> URI Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Router Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Output Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Security Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Input Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:41:59 --> Language Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Loader Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:41:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Session Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:41:59 --> Session routines successfully run
DEBUG - 2014-07-28 07:41:59 --> Upload Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Controller Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:41:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:41:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:41:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 07:41:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:41:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:41:59 --> Final output sent to browser
DEBUG - 2014-07-28 07:41:59 --> Total execution time: 0.1090
DEBUG - 2014-07-28 07:41:59 --> Config Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:41:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:41:59 --> URI Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Router Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Output Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Security Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Input Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:41:59 --> Language Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Loader Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:41:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Session Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:41:59 --> Session routines successfully run
DEBUG - 2014-07-28 07:41:59 --> Upload Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Controller Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:41:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Model Class Initialized
DEBUG - 2014-07-28 07:41:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:41:59 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:43:25 --> Config Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:43:25 --> URI Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Router Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Output Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Security Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Input Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:43:25 --> Language Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Loader Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:43:25 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Session Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:43:25 --> Session routines successfully run
DEBUG - 2014-07-28 07:43:25 --> Upload Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Controller Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:43:25 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Model Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Model Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Model Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:43:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:43:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 07:43:25 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:43:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:43:25 --> Final output sent to browser
DEBUG - 2014-07-28 07:43:25 --> Total execution time: 0.0789
DEBUG - 2014-07-28 07:43:25 --> Config Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:43:25 --> URI Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Router Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Output Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Security Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Input Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:43:25 --> Language Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Loader Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:43:25 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Session Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:43:25 --> Session routines successfully run
DEBUG - 2014-07-28 07:43:25 --> Upload Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Controller Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:43:25 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Model Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Model Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Model Class Initialized
DEBUG - 2014-07-28 07:43:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:43:25 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:48:23 --> Config Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:48:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:48:23 --> URI Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Router Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Output Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Security Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Input Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:48:23 --> Language Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Loader Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:48:23 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:48:23 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Session Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:48:23 --> Session routines successfully run
DEBUG - 2014-07-28 07:48:23 --> Upload Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Controller Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:48:23 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Model Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Model Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Model Class Initialized
DEBUG - 2014-07-28 07:48:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:48:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:48:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 07:48:24 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:48:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:48:24 --> Final output sent to browser
DEBUG - 2014-07-28 07:48:24 --> Total execution time: 0.0895
DEBUG - 2014-07-28 07:48:24 --> Config Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:48:24 --> URI Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Router Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Output Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Security Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Input Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:48:24 --> Language Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Loader Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:48:24 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:48:24 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Session Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:48:24 --> Session routines successfully run
DEBUG - 2014-07-28 07:48:24 --> Upload Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Controller Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:48:24 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Model Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Model Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Model Class Initialized
DEBUG - 2014-07-28 07:48:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:48:24 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:49:19 --> Config Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:49:19 --> URI Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Router Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Output Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Security Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Input Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:49:19 --> Language Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Loader Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:49:19 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Session Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:49:19 --> Session routines successfully run
DEBUG - 2014-07-28 07:49:19 --> Upload Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Controller Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:49:19 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:49:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:49:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 07:49:19 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:49:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:49:19 --> Final output sent to browser
DEBUG - 2014-07-28 07:49:19 --> Total execution time: 0.0805
DEBUG - 2014-07-28 07:49:19 --> Config Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:49:19 --> URI Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Router Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Output Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Security Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Input Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:49:19 --> Language Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Loader Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:49:19 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Session Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:49:19 --> Session routines successfully run
DEBUG - 2014-07-28 07:49:19 --> Upload Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Controller Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:49:19 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:49:19 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 07:49:34 --> Config Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:49:34 --> URI Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Router Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Output Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Security Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Input Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:49:34 --> Language Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Loader Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:49:34 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:49:34 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Session Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:49:34 --> Session routines successfully run
DEBUG - 2014-07-28 07:49:34 --> Upload Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Controller Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:49:34 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 07:49:34 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 07:49:34 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 07:49:34 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 07:49:34 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 07:49:34 --> Final output sent to browser
DEBUG - 2014-07-28 07:49:34 --> Total execution time: 0.1168
DEBUG - 2014-07-28 07:49:35 --> Config Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Hooks Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Utf8 Class Initialized
DEBUG - 2014-07-28 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 07:49:35 --> URI Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Router Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Output Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Security Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Input Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 07:49:35 --> Language Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Loader Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Helper loaded: url_helper
DEBUG - 2014-07-28 07:49:35 --> Helper loaded: file_helper
DEBUG - 2014-07-28 07:49:35 --> Database Driver Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Session Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Helper loaded: string_helper
DEBUG - 2014-07-28 07:49:35 --> Session routines successfully run
DEBUG - 2014-07-28 07:49:35 --> Upload Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Pagination Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Controller Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Helper loaded: form_helper
DEBUG - 2014-07-28 07:49:35 --> Form Validation Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Model Class Initialized
DEBUG - 2014-07-28 07:49:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 07:49:35 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:04:35 --> Config Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:04:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:04:35 --> URI Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Router Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Output Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Security Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Input Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:04:35 --> Language Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Loader Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:04:35 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Session Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:04:35 --> Session routines successfully run
DEBUG - 2014-07-28 08:04:35 --> Upload Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Controller Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:04:35 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Model Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Model Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Model Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:04:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:04:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:04:35 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:04:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:04:35 --> Final output sent to browser
DEBUG - 2014-07-28 08:04:35 --> Total execution time: 0.0831
DEBUG - 2014-07-28 08:04:35 --> Config Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:04:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:04:35 --> URI Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Router Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Output Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Security Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Input Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:04:35 --> Language Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Loader Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:04:35 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Session Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:04:35 --> Session routines successfully run
DEBUG - 2014-07-28 08:04:35 --> Upload Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Controller Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:04:35 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Model Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Model Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Model Class Initialized
DEBUG - 2014-07-28 08:04:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:04:35 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:09:55 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:55 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:55 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:55 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:55 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:55 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:55 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:55 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:55 --> Total execution time: 0.0865
DEBUG - 2014-07-28 08:09:55 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:55 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:55 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:55 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:55 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:55 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:55 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:09:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:09:55 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:55 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:55 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:55 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:55 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:55 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:55 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:55 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:55 --> Total execution time: 0.0913
DEBUG - 2014-07-28 08:09:55 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:55 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:55 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:55 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:55 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:55 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:55 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:55 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:55 --> Total execution time: 0.0921
DEBUG - 2014-07-28 08:09:56 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:56 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:56 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:56 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:56 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:56 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:56 --> Total execution time: 0.0946
DEBUG - 2014-07-28 08:09:56 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:56 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:56 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:56 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:56 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:56 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:56 --> Total execution time: 0.0791
DEBUG - 2014-07-28 08:09:56 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:56 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:56 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:56 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:56 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:56 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:56 --> Total execution time: 0.1051
DEBUG - 2014-07-28 08:09:56 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:56 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:56 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:56 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:56 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:56 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:56 --> Total execution time: 0.0919
DEBUG - 2014-07-28 08:09:57 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:57 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:57 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:57 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:57 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:57 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:57 --> Total execution time: 0.1010
DEBUG - 2014-07-28 08:09:57 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:57 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:57 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:57 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:57 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:57 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:57 --> Total execution time: 0.0823
DEBUG - 2014-07-28 08:09:57 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:57 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:57 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:57 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:57 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:57 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:57 --> Total execution time: 0.1177
DEBUG - 2014-07-28 08:09:57 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:57 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:57 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:57 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:57 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:57 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:57 --> Total execution time: 0.0777
DEBUG - 2014-07-28 08:09:57 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:57 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:57 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:57 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:57 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:57 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:57 --> Total execution time: 0.0846
DEBUG - 2014-07-28 08:09:58 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:58 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:58 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:58 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:58 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:58 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:58 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:58 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:58 --> Total execution time: 0.1205
DEBUG - 2014-07-28 08:09:58 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:58 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:58 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:58 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:58 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:58 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:58 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:58 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:58 --> Total execution time: 0.0872
DEBUG - 2014-07-28 08:09:58 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:58 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:58 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:58 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:58 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:58 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:58 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:58 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:58 --> Total execution time: 0.1117
DEBUG - 2014-07-28 08:09:58 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:58 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:58 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:58 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:58 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:58 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:58 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:58 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:58 --> Total execution time: 0.0917
DEBUG - 2014-07-28 08:09:58 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:58 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:58 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:59 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:59 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:59 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:59 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:59 --> Total execution time: 0.0931
DEBUG - 2014-07-28 08:09:59 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:59 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:59 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:59 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:59 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:59 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:59 --> Total execution time: 0.1029
DEBUG - 2014-07-28 08:09:59 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:59 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:59 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:59 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:59 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:59 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:59 --> Total execution time: 0.0874
DEBUG - 2014-07-28 08:09:59 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:59 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:59 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:59 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:59 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:59 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:59 --> Total execution time: 0.0772
DEBUG - 2014-07-28 08:09:59 --> Config Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:09:59 --> URI Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Router Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Output Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Security Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Input Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:09:59 --> Language Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Loader Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:09:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:09:59 --> Session routines successfully run
DEBUG - 2014-07-28 08:09:59 --> Upload Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Controller Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:09:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Model Class Initialized
DEBUG - 2014-07-28 08:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:09:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:09:59 --> Final output sent to browser
DEBUG - 2014-07-28 08:09:59 --> Total execution time: 0.1049
DEBUG - 2014-07-28 08:10:00 --> Config Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:10:00 --> URI Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Router Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Output Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Security Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Input Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:10:00 --> Language Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Loader Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:10:00 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:10:00 --> Session routines successfully run
DEBUG - 2014-07-28 08:10:00 --> Upload Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Controller Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:10:00 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:10:00 --> Final output sent to browser
DEBUG - 2014-07-28 08:10:00 --> Total execution time: 0.0993
DEBUG - 2014-07-28 08:10:00 --> Config Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:10:00 --> URI Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Router Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Output Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Security Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Input Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:10:00 --> Language Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Loader Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:10:00 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:10:00 --> Session routines successfully run
DEBUG - 2014-07-28 08:10:00 --> Upload Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Controller Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:10:00 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:10:00 --> Final output sent to browser
DEBUG - 2014-07-28 08:10:00 --> Total execution time: 0.0913
DEBUG - 2014-07-28 08:10:00 --> Config Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:10:00 --> URI Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Router Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Output Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Security Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Input Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:10:00 --> Language Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Loader Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:10:00 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:10:00 --> Session routines successfully run
DEBUG - 2014-07-28 08:10:00 --> Upload Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Controller Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:10:00 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:10:00 --> Final output sent to browser
DEBUG - 2014-07-28 08:10:00 --> Total execution time: 0.0792
DEBUG - 2014-07-28 08:10:00 --> Config Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:10:00 --> URI Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Router Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Output Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Security Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Input Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:10:00 --> Language Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Loader Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:10:00 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:10:00 --> Session routines successfully run
DEBUG - 2014-07-28 08:10:00 --> Upload Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Controller Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:10:00 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:10:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:10:00 --> Final output sent to browser
DEBUG - 2014-07-28 08:10:00 --> Total execution time: 0.1054
DEBUG - 2014-07-28 08:10:00 --> Config Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:10:00 --> URI Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Router Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Output Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Security Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Input Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:10:00 --> Language Class Initialized
DEBUG - 2014-07-28 08:10:00 --> Loader Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:10:01 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:10:01 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Session Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:10:01 --> Session routines successfully run
DEBUG - 2014-07-28 08:10:01 --> Upload Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Controller Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:10:01 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Model Class Initialized
DEBUG - 2014-07-28 08:10:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:10:01 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:11:27 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:27 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:27 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:27 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:27 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:27 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:27 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:27 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:27 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:27 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:27 --> Total execution time: 0.0949
DEBUG - 2014-07-28 08:11:27 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:27 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:28 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:28 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:28 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:28 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:28 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:28 --> Total execution time: 0.1057
DEBUG - 2014-07-28 08:11:28 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:28 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:28 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:28 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:28 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:28 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:28 --> Total execution time: 0.1105
DEBUG - 2014-07-28 08:11:28 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:28 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:28 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:28 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:28 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:28 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:28 --> Total execution time: 0.0991
DEBUG - 2014-07-28 08:11:28 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:28 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:28 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:28 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:28 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:28 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:28 --> Total execution time: 0.1059
DEBUG - 2014-07-28 08:11:28 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:28 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:28 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:28 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:28 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:28 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:28 --> Total execution time: 0.1372
DEBUG - 2014-07-28 08:11:28 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:28 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:28 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:29 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:29 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:29 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:29 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:29 --> Total execution time: 0.0914
DEBUG - 2014-07-28 08:11:29 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:29 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:29 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:29 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:29 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:29 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:29 --> Total execution time: 0.1047
DEBUG - 2014-07-28 08:11:29 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:29 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:29 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:29 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:29 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:29 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:29 --> Total execution time: 0.0870
DEBUG - 2014-07-28 08:11:29 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:29 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:29 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:29 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:29 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:29 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:29 --> Total execution time: 0.0982
DEBUG - 2014-07-28 08:11:29 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:29 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:29 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:29 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:29 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:29 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:29 --> Total execution time: 0.1022
DEBUG - 2014-07-28 08:11:30 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:30 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:30 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:30 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:30 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:30 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:30 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:30 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:30 --> Total execution time: 0.1046
DEBUG - 2014-07-28 08:11:30 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:30 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:30 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:30 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:30 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:30 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:30 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:30 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:30 --> Total execution time: 0.1024
DEBUG - 2014-07-28 08:11:30 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:30 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:30 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:30 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:30 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:30 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:30 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:30 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:30 --> Total execution time: 0.0907
DEBUG - 2014-07-28 08:11:30 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:30 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:30 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:30 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:30 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:30 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:30 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:11:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:11:30 --> Final output sent to browser
DEBUG - 2014-07-28 08:11:30 --> Total execution time: 0.1119
DEBUG - 2014-07-28 08:11:31 --> Config Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:11:31 --> URI Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Router Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Output Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Security Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Input Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:11:31 --> Language Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Loader Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:11:31 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:11:31 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Session Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:11:31 --> Session routines successfully run
DEBUG - 2014-07-28 08:11:31 --> Upload Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Controller Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:11:31 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Model Class Initialized
DEBUG - 2014-07-28 08:11:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:11:31 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:13:51 --> Config Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:13:51 --> URI Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Router Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Output Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Security Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Input Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:13:51 --> Language Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Loader Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:13:51 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Session Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:13:51 --> Session routines successfully run
DEBUG - 2014-07-28 08:13:51 --> Upload Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Controller Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:13:51 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:13:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:13:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:13:51 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-28 08:13:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:13:51 --> Final output sent to browser
DEBUG - 2014-07-28 08:13:51 --> Total execution time: 0.0848
DEBUG - 2014-07-28 08:13:51 --> Config Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:13:51 --> URI Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Router Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Output Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Security Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Input Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:13:51 --> Language Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Loader Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:13:51 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Session Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:13:51 --> Session routines successfully run
DEBUG - 2014-07-28 08:13:51 --> Upload Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Controller Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:13:51 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:13:51 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:13:54 --> Config Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:13:54 --> URI Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Router Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Output Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Security Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Input Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:13:54 --> Language Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Loader Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:13:54 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Session Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:13:54 --> Session routines successfully run
DEBUG - 2014-07-28 08:13:54 --> Upload Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Controller Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:13:54 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:13:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:13:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:13:54 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:13:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:13:54 --> Final output sent to browser
DEBUG - 2014-07-28 08:13:54 --> Total execution time: 0.1184
DEBUG - 2014-07-28 08:13:54 --> Config Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:13:54 --> URI Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Router Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Output Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Security Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Input Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:13:54 --> Language Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Loader Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:13:54 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Session Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:13:54 --> Session routines successfully run
DEBUG - 2014-07-28 08:13:54 --> Upload Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Controller Class Initialized
DEBUG - 2014-07-28 08:13:54 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:13:55 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:13:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:55 --> Model Class Initialized
DEBUG - 2014-07-28 08:13:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:13:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:17:22 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:22 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:22 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:22 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:22 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:22 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:22 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:17:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:17:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:17:22 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:17:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:17:22 --> Final output sent to browser
DEBUG - 2014-07-28 08:17:22 --> Total execution time: 0.0869
DEBUG - 2014-07-28 08:17:22 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:22 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:22 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:22 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:22 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:22 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:22 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:17:22 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:17:23 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:23 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:23 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:23 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:23 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:17:23 --> Final output sent to browser
DEBUG - 2014-07-28 08:17:23 --> Total execution time: 0.1094
DEBUG - 2014-07-28 08:17:23 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:23 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:23 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:23 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:23 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:17:23 --> Final output sent to browser
DEBUG - 2014-07-28 08:17:23 --> Total execution time: 0.1108
DEBUG - 2014-07-28 08:17:24 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:24 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:24 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:24 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:24 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:24 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:24 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:17:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:17:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:17:24 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:17:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:17:24 --> Final output sent to browser
DEBUG - 2014-07-28 08:17:24 --> Total execution time: 0.0925
DEBUG - 2014-07-28 08:17:24 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:24 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:24 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:24 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:24 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:24 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:24 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:17:24 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:17:50 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:50 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:50 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:50 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:50 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:50 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:50 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:17:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:17:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:17:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:17:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:17:50 --> Final output sent to browser
DEBUG - 2014-07-28 08:17:50 --> Total execution time: 0.1092
DEBUG - 2014-07-28 08:17:50 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:50 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:50 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:50 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:50 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:50 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:50 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:17:50 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:17:53 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:53 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:53 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:53 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:53 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:53 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:53 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:53 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:17:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:17:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:17:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:17:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:17:53 --> Final output sent to browser
DEBUG - 2014-07-28 08:17:53 --> Total execution time: 0.0882
DEBUG - 2014-07-28 08:17:54 --> Config Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:17:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:17:54 --> URI Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Router Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Output Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Security Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Input Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:17:54 --> Language Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Loader Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:17:54 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:17:54 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Session Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:17:54 --> Session routines successfully run
DEBUG - 2014-07-28 08:17:54 --> Upload Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Controller Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:17:54 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Model Class Initialized
DEBUG - 2014-07-28 08:17:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:17:54 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:20:16 --> Config Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:20:16 --> URI Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Router Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Output Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Security Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Input Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:20:16 --> Language Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Loader Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:20:16 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:20:16 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Session Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:20:16 --> Session routines successfully run
DEBUG - 2014-07-28 08:20:16 --> Upload Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Controller Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:20:16 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:20:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:20:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:20:16 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:20:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:20:16 --> Final output sent to browser
DEBUG - 2014-07-28 08:20:16 --> Total execution time: 0.0961
DEBUG - 2014-07-28 08:20:16 --> Config Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:20:16 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:20:17 --> URI Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Router Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Output Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Security Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Input Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:20:17 --> Language Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Loader Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:20:17 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:20:17 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Session Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:20:17 --> Session routines successfully run
DEBUG - 2014-07-28 08:20:17 --> Upload Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Controller Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:20:17 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:20:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:20:46 --> Config Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:20:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:20:46 --> URI Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Router Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Output Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Security Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Input Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:20:46 --> Language Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Loader Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:20:46 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Session Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:20:46 --> Session routines successfully run
DEBUG - 2014-07-28 08:20:46 --> Upload Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Controller Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:20:46 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:20:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:20:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:20:46 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:20:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:20:46 --> Final output sent to browser
DEBUG - 2014-07-28 08:20:46 --> Total execution time: 0.0848
DEBUG - 2014-07-28 08:20:46 --> Config Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:20:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:20:46 --> URI Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Router Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Output Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Security Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Input Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:20:46 --> Language Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Loader Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:20:46 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Session Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:20:46 --> Session routines successfully run
DEBUG - 2014-07-28 08:20:46 --> Upload Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Controller Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:20:46 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Model Class Initialized
DEBUG - 2014-07-28 08:20:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:20:46 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:22:23 --> Config Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:22:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:22:23 --> URI Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Router Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Output Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Security Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Input Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:22:23 --> Language Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Loader Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:22:23 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Session Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:22:23 --> Session routines successfully run
DEBUG - 2014-07-28 08:22:23 --> Upload Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Controller Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:22:23 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:22:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:22:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:22:23 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:22:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:22:23 --> Final output sent to browser
DEBUG - 2014-07-28 08:22:23 --> Total execution time: 0.0851
DEBUG - 2014-07-28 08:22:23 --> Config Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:22:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:22:23 --> URI Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Router Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Output Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Security Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Input Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:22:23 --> Language Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Loader Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:22:23 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Session Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:22:23 --> Session routines successfully run
DEBUG - 2014-07-28 08:22:23 --> Upload Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Controller Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:22:23 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:22:23 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 08:22:24 --> Config Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:22:24 --> URI Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Router Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Output Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Security Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Input Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:22:24 --> Language Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Loader Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:22:24 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:22:24 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Session Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:22:24 --> Session routines successfully run
DEBUG - 2014-07-28 08:22:24 --> Upload Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Controller Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:22:24 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 08:22:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 08:22:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 08:22:24 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 08:22:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 08:22:24 --> Final output sent to browser
DEBUG - 2014-07-28 08:22:24 --> Total execution time: 0.0812
DEBUG - 2014-07-28 08:22:24 --> Config Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Hooks Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Utf8 Class Initialized
DEBUG - 2014-07-28 08:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 08:22:24 --> URI Class Initialized
DEBUG - 2014-07-28 08:22:24 --> Router Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Output Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Security Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Input Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 08:22:25 --> Language Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Loader Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Helper loaded: url_helper
DEBUG - 2014-07-28 08:22:25 --> Helper loaded: file_helper
DEBUG - 2014-07-28 08:22:25 --> Database Driver Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Session Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Helper loaded: string_helper
DEBUG - 2014-07-28 08:22:25 --> Session routines successfully run
DEBUG - 2014-07-28 08:22:25 --> Upload Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Pagination Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Controller Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Helper loaded: form_helper
DEBUG - 2014-07-28 08:22:25 --> Form Validation Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Model Class Initialized
DEBUG - 2014-07-28 08:22:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 08:22:25 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 10:57:22 --> Config Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Hooks Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Utf8 Class Initialized
DEBUG - 2014-07-28 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 10:57:22 --> URI Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Router Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Output Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Security Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Input Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 10:57:22 --> Language Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Loader Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: url_helper
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: file_helper
DEBUG - 2014-07-28 10:57:22 --> Database Driver Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Session Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: string_helper
DEBUG - 2014-07-28 10:57:22 --> A session cookie was not found.
DEBUG - 2014-07-28 10:57:22 --> Session routines successfully run
DEBUG - 2014-07-28 10:57:22 --> Upload Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Pagination Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Controller Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: form_helper
DEBUG - 2014-07-28 10:57:22 --> Form Validation Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Model Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Model Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Model Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 10:57:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 10:57:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 10:57:22 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 10:57:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 10:57:22 --> Final output sent to browser
DEBUG - 2014-07-28 10:57:22 --> Total execution time: 0.0904
DEBUG - 2014-07-28 10:57:22 --> Config Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Hooks Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Utf8 Class Initialized
DEBUG - 2014-07-28 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 10:57:22 --> URI Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Router Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Output Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Security Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Input Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 10:57:22 --> Language Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Loader Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: url_helper
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: file_helper
DEBUG - 2014-07-28 10:57:22 --> Database Driver Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Session Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: string_helper
DEBUG - 2014-07-28 10:57:22 --> Session routines successfully run
DEBUG - 2014-07-28 10:57:22 --> Upload Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Pagination Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Controller Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Helper loaded: form_helper
DEBUG - 2014-07-28 10:57:22 --> Form Validation Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Model Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Model Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Model Class Initialized
DEBUG - 2014-07-28 10:57:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 10:57:22 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 10:59:31 --> Config Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Hooks Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Utf8 Class Initialized
DEBUG - 2014-07-28 10:59:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 10:59:31 --> URI Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Router Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Output Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Security Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Input Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 10:59:31 --> Language Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Loader Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Helper loaded: url_helper
DEBUG - 2014-07-28 10:59:31 --> Helper loaded: file_helper
DEBUG - 2014-07-28 10:59:31 --> Database Driver Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Session Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Helper loaded: string_helper
DEBUG - 2014-07-28 10:59:31 --> Session routines successfully run
DEBUG - 2014-07-28 10:59:31 --> Upload Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Pagination Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Controller Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Helper loaded: form_helper
DEBUG - 2014-07-28 10:59:31 --> Form Validation Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Model Class Initialized
DEBUG - 2014-07-28 10:59:31 --> Model Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Config Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:00:28 --> URI Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Router Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Output Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Security Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Input Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:00:28 --> Language Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Loader Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:00:28 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:00:28 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Session Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:00:28 --> Session routines successfully run
DEBUG - 2014-07-28 11:00:28 --> Upload Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Controller Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:00:28 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Model Class Initialized
DEBUG - 2014-07-28 11:00:28 --> Model Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Config Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:00:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:00:50 --> URI Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Router Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Output Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Security Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Input Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:00:50 --> Language Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Loader Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:00:50 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:00:50 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Session Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:00:50 --> Session routines successfully run
DEBUG - 2014-07-28 11:00:50 --> Upload Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Controller Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:00:50 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Model Class Initialized
DEBUG - 2014-07-28 11:00:50 --> Model Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Config Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:00:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:00:56 --> URI Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Router Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Output Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Security Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Input Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:00:56 --> Language Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Loader Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:00:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:00:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Session Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:00:56 --> Session routines successfully run
DEBUG - 2014-07-28 11:00:56 --> Upload Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Controller Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:00:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Model Class Initialized
DEBUG - 2014-07-28 11:00:56 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:19 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:19 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:19 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:19 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:19 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:19 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:19 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:19 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:21 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:21 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:21 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:21 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:21 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:21 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:21 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:21 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:46 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:46 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:46 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:46 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:46 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:46 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:46 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:46 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:48 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:48 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:48 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:48 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:48 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:48 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:48 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:48 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:55 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:55 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:55 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:55 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:55 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:55 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:55 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:55 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:56 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:56 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:56 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:56 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Config Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:01:56 --> URI Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Router Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Output Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Security Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Input Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:01:56 --> Language Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Loader Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:01:56 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Session Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:01:56 --> Session routines successfully run
DEBUG - 2014-07-28 11:01:56 --> Upload Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Controller Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:01:56 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Model Class Initialized
DEBUG - 2014-07-28 11:01:56 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Config Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:02:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:02:48 --> URI Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Router Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Output Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Security Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Input Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:02:48 --> Language Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Loader Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:02:48 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:02:48 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Session Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:02:48 --> Session routines successfully run
DEBUG - 2014-07-28 11:02:48 --> Upload Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Controller Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:02:48 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:02:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:02:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:02:48 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:02:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:02:48 --> Final output sent to browser
DEBUG - 2014-07-28 11:02:48 --> Total execution time: 0.1213
DEBUG - 2014-07-28 11:02:49 --> Config Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:02:49 --> URI Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Router Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Output Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Security Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Input Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:02:49 --> Language Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Loader Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:02:49 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:02:49 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Session Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:02:49 --> Session routines successfully run
DEBUG - 2014-07-28 11:02:49 --> Upload Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Controller Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:02:49 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:02:49 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:02:52 --> Config Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:02:52 --> URI Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Router Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Output Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Security Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Input Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:02:52 --> Language Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Loader Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:02:52 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Session Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:02:52 --> Session routines successfully run
DEBUG - 2014-07-28 11:02:52 --> Upload Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Controller Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:02:52 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:02:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:02:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:02:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:02:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:02:52 --> Final output sent to browser
DEBUG - 2014-07-28 11:02:52 --> Total execution time: 0.0744
DEBUG - 2014-07-28 11:02:52 --> Config Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:02:52 --> URI Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Router Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Output Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Security Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Input Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:02:52 --> Language Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Loader Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:02:52 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Session Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:02:52 --> Session routines successfully run
DEBUG - 2014-07-28 11:02:52 --> Upload Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Controller Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:02:52 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Model Class Initialized
DEBUG - 2014-07-28 11:02:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:02:52 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:03:57 --> Config Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:03:57 --> URI Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Router Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Output Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Security Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Input Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:03:57 --> Language Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Loader Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:03:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Session Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:03:57 --> Session routines successfully run
DEBUG - 2014-07-28 11:03:57 --> Upload Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Controller Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:03:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:03:57 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
ERROR - 2014-07-28 11:03:57 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
ERROR - 2014-07-28 11:03:57 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
DEBUG - 2014-07-28 11:03:57 --> Config Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:03:57 --> URI Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Router Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Output Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Security Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Input Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:03:57 --> Language Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Loader Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:03:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Session Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:03:57 --> Session routines successfully run
DEBUG - 2014-07-28 11:03:57 --> Upload Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Controller Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:03:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:03:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:03:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:03:57 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:03:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:03:57 --> Final output sent to browser
DEBUG - 2014-07-28 11:03:57 --> Total execution time: 0.0880
DEBUG - 2014-07-28 11:03:57 --> Config Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:03:57 --> URI Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Router Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Output Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Security Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Input Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:03:57 --> Language Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Loader Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:03:57 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Session Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:03:57 --> Session routines successfully run
DEBUG - 2014-07-28 11:03:57 --> Upload Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Controller Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:03:57 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Model Class Initialized
DEBUG - 2014-07-28 11:03:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:03:57 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:10:18 --> Config Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:10:18 --> URI Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Router Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Output Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Security Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Input Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:10:18 --> Language Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Loader Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:10:18 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:10:18 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Session Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:10:18 --> Session routines successfully run
DEBUG - 2014-07-28 11:10:18 --> Upload Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Controller Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:10:18 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:10:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:10:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:10:18 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:10:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:10:18 --> Final output sent to browser
DEBUG - 2014-07-28 11:10:18 --> Total execution time: 0.0877
DEBUG - 2014-07-28 11:10:19 --> Config Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:10:19 --> URI Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Router Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Output Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Security Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Input Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:10:19 --> Language Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Loader Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:10:19 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:10:19 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Session Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:10:19 --> Session routines successfully run
DEBUG - 2014-07-28 11:10:19 --> Upload Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Controller Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:10:19 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:10:19 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:10:36 --> Config Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:10:36 --> URI Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Router Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Output Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Security Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Input Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:10:36 --> Language Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Loader Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:10:36 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Session Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:10:36 --> Session routines successfully run
DEBUG - 2014-07-28 11:10:36 --> Upload Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Controller Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:10:36 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:10:36 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
ERROR - 2014-07-28 11:10:36 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
DEBUG - 2014-07-28 11:10:36 --> Config Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:10:36 --> URI Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Router Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Output Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Security Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Input Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:10:36 --> Language Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Loader Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:10:36 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Session Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:10:36 --> Session routines successfully run
DEBUG - 2014-07-28 11:10:36 --> Upload Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Controller Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:10:36 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:10:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:10:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:10:36 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:10:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:10:36 --> Final output sent to browser
DEBUG - 2014-07-28 11:10:36 --> Total execution time: 0.0784
DEBUG - 2014-07-28 11:10:36 --> Config Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:10:36 --> URI Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Router Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Output Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Security Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Input Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:10:36 --> Language Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Loader Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:10:36 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Session Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:10:36 --> Session routines successfully run
DEBUG - 2014-07-28 11:10:36 --> Upload Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Controller Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:10:36 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Model Class Initialized
DEBUG - 2014-07-28 11:10:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:10:36 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:15:29 --> Config Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:15:29 --> URI Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Router Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Output Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Security Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Input Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:15:29 --> Language Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Loader Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:15:29 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:15:29 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Session Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:15:29 --> Session routines successfully run
DEBUG - 2014-07-28 11:15:29 --> Upload Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Controller Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:15:29 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Model Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Model Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Model Class Initialized
DEBUG - 2014-07-28 11:15:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:15:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:15:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:15:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:15:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:15:29 --> Final output sent to browser
DEBUG - 2014-07-28 11:15:29 --> Total execution time: 0.0770
DEBUG - 2014-07-28 11:15:30 --> Config Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:15:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:15:30 --> URI Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Router Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Output Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Security Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Input Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:15:30 --> Language Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Loader Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:15:30 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:15:30 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Session Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:15:30 --> Session routines successfully run
DEBUG - 2014-07-28 11:15:30 --> Upload Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Controller Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:15:30 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Model Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Model Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Model Class Initialized
DEBUG - 2014-07-28 11:15:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:15:30 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:16:02 --> Config Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:16:02 --> URI Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Router Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Output Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Security Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Input Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:16:02 --> Language Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Loader Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:16:02 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Session Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:16:02 --> Session routines successfully run
DEBUG - 2014-07-28 11:16:02 --> Upload Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Controller Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:16:02 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:16:02 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
ERROR - 2014-07-28 11:16:02 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
ERROR - 2014-07-28 11:16:02 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
ERROR - 2014-07-28 11:16:02 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 174
DEBUG - 2014-07-28 11:16:02 --> Config Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:16:02 --> URI Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Router Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Output Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Security Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Input Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:16:02 --> Language Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Loader Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:16:02 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Session Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:16:02 --> Session routines successfully run
DEBUG - 2014-07-28 11:16:02 --> Upload Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Controller Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:16:02 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:16:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:16:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:16:02 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:16:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:16:02 --> Final output sent to browser
DEBUG - 2014-07-28 11:16:02 --> Total execution time: 0.0882
DEBUG - 2014-07-28 11:16:02 --> Config Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:16:02 --> URI Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Router Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Output Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Security Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Input Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:16:02 --> Language Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Loader Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:16:02 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Session Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:16:02 --> Session routines successfully run
DEBUG - 2014-07-28 11:16:02 --> Upload Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Controller Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:16:02 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Model Class Initialized
DEBUG - 2014-07-28 11:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:16:02 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:36:53 --> Config Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:36:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:36:53 --> URI Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Router Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Output Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Security Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Input Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:36:53 --> Language Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Loader Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:36:53 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Session Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:36:53 --> Session routines successfully run
DEBUG - 2014-07-28 11:36:53 --> Upload Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Controller Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:36:53 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:36:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:36:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:36:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:36:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:36:53 --> Final output sent to browser
DEBUG - 2014-07-28 11:36:53 --> Total execution time: 0.0796
DEBUG - 2014-07-28 11:36:53 --> Config Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:36:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:36:53 --> URI Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Router Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Output Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Security Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Input Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:36:53 --> Language Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Loader Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:36:53 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Session Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:36:53 --> Session routines successfully run
DEBUG - 2014-07-28 11:36:53 --> Upload Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Controller Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:36:53 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:36:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:36:53 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:37:38 --> Config Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:37:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:37:38 --> URI Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Router Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Output Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Security Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Input Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:37:38 --> Language Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Loader Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:37:38 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:37:38 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Session Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:37:38 --> Session routines successfully run
DEBUG - 2014-07-28 11:37:38 --> Upload Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Controller Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:37:38 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Model Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Model Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Model Class Initialized
DEBUG - 2014-07-28 11:37:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:37:38 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:37:38 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 180
ERROR - 2014-07-28 11:37:38 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 182
ERROR - 2014-07-28 11:37:38 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 180
ERROR - 2014-07-28 11:37:38 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 182
ERROR - 2014-07-28 11:37:38 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 180
ERROR - 2014-07-28 11:37:38 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 182
DEBUG - 2014-07-28 11:44:16 --> Config Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:44:16 --> URI Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Router Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Output Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Security Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Input Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:44:16 --> Language Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Loader Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:44:16 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:44:16 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Session Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:44:16 --> Session routines successfully run
DEBUG - 2014-07-28 11:44:16 --> Upload Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Controller Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:44:16 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Model Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Model Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Model Class Initialized
DEBUG - 2014-07-28 11:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:44:16 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:44:16 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 181
ERROR - 2014-07-28 11:44:16 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-07-28 11:44:16 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 181
ERROR - 2014-07-28 11:44:16 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-07-28 11:44:16 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 181
ERROR - 2014-07-28 11:44:16 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 183
DEBUG - 2014-07-28 11:46:39 --> Config Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:46:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:46:39 --> URI Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Router Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Output Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Security Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Input Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:46:39 --> Language Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Loader Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:46:39 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:46:39 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Session Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:46:39 --> Session routines successfully run
DEBUG - 2014-07-28 11:46:39 --> Upload Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Controller Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:46:39 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Model Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Model Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Model Class Initialized
DEBUG - 2014-07-28 11:46:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:46:39 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:46:39 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 181
ERROR - 2014-07-28 11:46:39 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-07-28 11:46:39 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 181
ERROR - 2014-07-28 11:46:39 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-07-28 11:46:39 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 181
ERROR - 2014-07-28 11:46:39 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 183
DEBUG - 2014-07-28 11:47:42 --> Config Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:47:42 --> URI Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Router Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Output Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Security Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Input Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:47:42 --> Language Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Loader Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:47:42 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:47:42 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Session Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:47:42 --> Session routines successfully run
DEBUG - 2014-07-28 11:47:42 --> Upload Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Controller Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:47:42 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Model Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Model Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Model Class Initialized
DEBUG - 2014-07-28 11:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:47:42 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:47:42 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 182
ERROR - 2014-07-28 11:47:42 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 184
ERROR - 2014-07-28 11:47:42 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 182
ERROR - 2014-07-28 11:47:42 --> Severity: Notice  --> Undefined index:  F:\wamp\www\hostorks\application\models\superadmin_model.php 184
DEBUG - 2014-07-28 11:48:53 --> Config Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:48:53 --> URI Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Router Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Output Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Security Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Input Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:48:53 --> Language Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Loader Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:48:53 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:48:53 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Session Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:48:53 --> Session routines successfully run
DEBUG - 2014-07-28 11:48:53 --> Upload Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Controller Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:48:53 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Model Class Initialized
DEBUG - 2014-07-28 11:48:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:48:53 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:48:53 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 183
ERROR - 2014-07-28 11:48:53 --> Severity: Notice  --> Undefined variable: tab_image F:\wamp\www\hostorks\application\models\superadmin_model.php 183
DEBUG - 2014-07-28 11:49:12 --> Config Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:49:12 --> URI Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Router Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Output Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Security Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Input Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:49:12 --> Language Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Loader Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:49:12 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:49:12 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Session Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:49:12 --> Session routines successfully run
DEBUG - 2014-07-28 11:49:12 --> Upload Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Controller Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:49:12 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Model Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Model Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Model Class Initialized
DEBUG - 2014-07-28 11:49:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:49:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:50:40 --> Config Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:50:40 --> URI Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Router Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Output Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Security Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Input Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:50:40 --> Language Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Loader Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:50:40 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Session Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:50:40 --> Session routines successfully run
DEBUG - 2014-07-28 11:50:40 --> Upload Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Controller Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:50:40 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:50:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:50:40 --> Config Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:50:40 --> URI Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Router Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Output Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Security Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Input Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:50:40 --> Language Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Loader Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:50:40 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Session Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:50:40 --> Session routines successfully run
DEBUG - 2014-07-28 11:50:40 --> Upload Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Controller Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:50:40 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:50:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:50:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:50:40 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:50:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:50:40 --> Final output sent to browser
DEBUG - 2014-07-28 11:50:40 --> Total execution time: 0.0837
DEBUG - 2014-07-28 11:50:40 --> Config Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:50:40 --> URI Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Router Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Output Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Security Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Input Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:50:40 --> Language Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Loader Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:50:40 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Session Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:50:40 --> Session routines successfully run
DEBUG - 2014-07-28 11:50:40 --> Upload Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Controller Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:50:40 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Model Class Initialized
DEBUG - 2014-07-28 11:50:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:50:40 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:51:59 --> Config Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:51:59 --> URI Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Router Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Output Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Security Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Input Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:51:59 --> Language Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Loader Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:51:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Session Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:51:59 --> Session routines successfully run
DEBUG - 2014-07-28 11:51:59 --> Upload Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Controller Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:51:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Model Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Model Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Model Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:51:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:51:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:51:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:51:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:51:59 --> Final output sent to browser
DEBUG - 2014-07-28 11:51:59 --> Total execution time: 0.0832
DEBUG - 2014-07-28 11:51:59 --> Config Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:51:59 --> URI Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Router Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Output Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Security Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Input Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:51:59 --> Language Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Loader Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:51:59 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Session Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:51:59 --> Session routines successfully run
DEBUG - 2014-07-28 11:51:59 --> Upload Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Controller Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:51:59 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Model Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Model Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Model Class Initialized
DEBUG - 2014-07-28 11:51:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:51:59 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:52:20 --> Config Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:52:20 --> URI Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Router Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Output Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Security Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Input Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:52:20 --> Language Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Loader Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:52:20 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Session Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:52:20 --> Session routines successfully run
DEBUG - 2014-07-28 11:52:20 --> Upload Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Controller Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:52:20 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:52:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:52:20 --> Config Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:52:20 --> URI Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Router Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Output Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Security Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Input Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:52:20 --> Language Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Loader Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:52:20 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Session Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:52:20 --> Session routines successfully run
DEBUG - 2014-07-28 11:52:20 --> Upload Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Controller Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:52:20 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:52:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:52:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:52:20 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:52:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:52:20 --> Final output sent to browser
DEBUG - 2014-07-28 11:52:20 --> Total execution time: 0.0970
DEBUG - 2014-07-28 11:52:20 --> Config Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:52:20 --> URI Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Router Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Output Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Security Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Input Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:52:20 --> Language Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Loader Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:52:20 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Session Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:52:20 --> Session routines successfully run
DEBUG - 2014-07-28 11:52:20 --> Upload Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Controller Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:52:20 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Model Class Initialized
DEBUG - 2014-07-28 11:52:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:52:20 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:57:49 --> Config Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:57:49 --> URI Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Router Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Output Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Security Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Input Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:57:49 --> Language Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Loader Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:57:49 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Session Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:57:49 --> Session routines successfully run
DEBUG - 2014-07-28 11:57:49 --> Upload Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Controller Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:57:49 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:57:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:57:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:57:49 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:57:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:57:49 --> Final output sent to browser
DEBUG - 2014-07-28 11:57:49 --> Total execution time: 0.0775
DEBUG - 2014-07-28 11:57:49 --> Config Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:57:49 --> URI Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Router Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Output Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Security Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Input Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:57:49 --> Language Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Loader Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:57:49 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Session Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:57:49 --> Session routines successfully run
DEBUG - 2014-07-28 11:57:49 --> Upload Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Controller Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:57:49 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Model Class Initialized
DEBUG - 2014-07-28 11:57:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:57:49 --> 404 Page Not Found --> 
DEBUG - 2014-07-28 11:58:04 --> Config Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:58:04 --> URI Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Router Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Output Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Security Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Input Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:58:04 --> Language Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Loader Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:58:04 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:58:04 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Session Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:58:04 --> Session routines successfully run
DEBUG - 2014-07-28 11:58:04 --> Upload Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Controller Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:58:04 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Model Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Model Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Model Class Initialized
DEBUG - 2014-07-28 11:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-28 11:58:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-28 11:58:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-28 11:58:04 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-07-28 11:58:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-28 11:58:04 --> Final output sent to browser
DEBUG - 2014-07-28 11:58:04 --> Total execution time: 0.0813
DEBUG - 2014-07-28 11:58:05 --> Config Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Hooks Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Utf8 Class Initialized
DEBUG - 2014-07-28 11:58:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-28 11:58:05 --> URI Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Router Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Output Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Security Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Input Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-28 11:58:05 --> Language Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Loader Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Helper loaded: url_helper
DEBUG - 2014-07-28 11:58:05 --> Helper loaded: file_helper
DEBUG - 2014-07-28 11:58:05 --> Database Driver Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Session Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Helper loaded: string_helper
DEBUG - 2014-07-28 11:58:05 --> Session routines successfully run
DEBUG - 2014-07-28 11:58:05 --> Upload Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Pagination Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Controller Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Helper loaded: form_helper
DEBUG - 2014-07-28 11:58:05 --> Form Validation Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Model Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Model Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Model Class Initialized
DEBUG - 2014-07-28 11:58:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-28 11:58:05 --> 404 Page Not Found --> 

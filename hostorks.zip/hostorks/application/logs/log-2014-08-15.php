<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-15 01:45:11 --> Config Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Hooks Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Utf8 Class Initialized
DEBUG - 2014-08-15 01:45:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 01:45:11 --> URI Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Router Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Output Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Security Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Input Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 01:45:11 --> Language Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Loader Class Initialized
DEBUG - 2014-08-15 01:45:11 --> Helper loaded: url_helper
DEBUG - 2014-08-15 01:45:11 --> Helper loaded: file_helper
DEBUG - 2014-08-15 01:45:11 --> Database Driver Class Initialized
ERROR - 2014-08-15 01:45:11 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\hostorks\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 01:45:12 --> Session Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 01:45:12 --> A session cookie was not found.
DEBUG - 2014-08-15 01:45:12 --> Session routines successfully run
DEBUG - 2014-08-15 01:45:12 --> Upload Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Controller Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 01:45:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Model Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Model Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Model Class Initialized
DEBUG - 2014-08-15 01:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:46:41 --> Config Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Hooks Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Utf8 Class Initialized
DEBUG - 2014-08-15 01:46:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 01:46:41 --> URI Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Router Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Output Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Security Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Input Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 01:46:41 --> Language Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Loader Class Initialized
DEBUG - 2014-08-15 01:46:41 --> Helper loaded: url_helper
DEBUG - 2014-08-15 01:46:41 --> Helper loaded: file_helper
DEBUG - 2014-08-15 01:46:41 --> Database Driver Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Session Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Helper loaded: string_helper
DEBUG - 2014-08-15 01:46:42 --> Session routines successfully run
DEBUG - 2014-08-15 01:46:42 --> Upload Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Pagination Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Controller Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Helper loaded: form_helper
DEBUG - 2014-08-15 01:46:42 --> Form Validation Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Model Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Model Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Model Class Initialized
DEBUG - 2014-08-15 01:46:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:46:42 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 01:46:42 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\hostorks\application\models\superadmin_model.php 184
DEBUG - 2014-08-15 01:50:08 --> Config Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Hooks Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Utf8 Class Initialized
DEBUG - 2014-08-15 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 01:50:08 --> URI Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Router Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Output Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Security Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Input Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 01:50:08 --> Language Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Loader Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Helper loaded: url_helper
DEBUG - 2014-08-15 01:50:08 --> Helper loaded: file_helper
DEBUG - 2014-08-15 01:50:08 --> Database Driver Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Session Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Helper loaded: string_helper
DEBUG - 2014-08-15 01:50:08 --> Session routines successfully run
DEBUG - 2014-08-15 01:50:08 --> Upload Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Pagination Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Controller Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Helper loaded: form_helper
DEBUG - 2014-08-15 01:50:08 --> Form Validation Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Model Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Model Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Model Class Initialized
DEBUG - 2014-08-15 01:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:50:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:50:25 --> Config Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Hooks Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Utf8 Class Initialized
DEBUG - 2014-08-15 01:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 01:50:25 --> URI Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Router Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Output Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Security Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Input Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 01:50:25 --> Language Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Loader Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Helper loaded: url_helper
DEBUG - 2014-08-15 01:50:25 --> Helper loaded: file_helper
DEBUG - 2014-08-15 01:50:25 --> Database Driver Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Session Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Helper loaded: string_helper
DEBUG - 2014-08-15 01:50:25 --> Session routines successfully run
DEBUG - 2014-08-15 01:50:25 --> Upload Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Pagination Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Controller Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Helper loaded: form_helper
DEBUG - 2014-08-15 01:50:25 --> Form Validation Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Model Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Model Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Model Class Initialized
DEBUG - 2014-08-15 01:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:50:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:52:10 --> Config Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Hooks Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Utf8 Class Initialized
DEBUG - 2014-08-15 01:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 01:52:10 --> URI Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Router Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Output Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Security Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Input Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 01:52:10 --> Language Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Loader Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Helper loaded: url_helper
DEBUG - 2014-08-15 01:52:10 --> Helper loaded: file_helper
DEBUG - 2014-08-15 01:52:10 --> Database Driver Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Session Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Helper loaded: string_helper
DEBUG - 2014-08-15 01:52:10 --> Session routines successfully run
DEBUG - 2014-08-15 01:52:10 --> Upload Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Pagination Class Initialized
DEBUG - 2014-08-15 01:52:10 --> Controller Class Initialized
DEBUG - 2014-08-15 01:52:11 --> Helper loaded: form_helper
DEBUG - 2014-08-15 01:52:11 --> Form Validation Class Initialized
DEBUG - 2014-08-15 01:52:11 --> Model Class Initialized
DEBUG - 2014-08-15 01:52:11 --> Model Class Initialized
DEBUG - 2014-08-15 01:52:11 --> Model Class Initialized
DEBUG - 2014-08-15 01:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:52:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:58:17 --> Config Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Hooks Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Utf8 Class Initialized
DEBUG - 2014-08-15 01:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 01:58:17 --> URI Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Router Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Output Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Security Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Input Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 01:58:17 --> Language Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Loader Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Helper loaded: url_helper
DEBUG - 2014-08-15 01:58:17 --> Helper loaded: file_helper
DEBUG - 2014-08-15 01:58:17 --> Database Driver Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Session Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Helper loaded: string_helper
DEBUG - 2014-08-15 01:58:17 --> Session routines successfully run
DEBUG - 2014-08-15 01:58:17 --> Upload Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Pagination Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Controller Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Helper loaded: form_helper
DEBUG - 2014-08-15 01:58:17 --> Form Validation Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Model Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Model Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Model Class Initialized
DEBUG - 2014-08-15 01:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 01:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:09 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:09 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:09 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:09 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:09 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:03:09 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:03:19 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:19 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:19 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:19 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:19 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:19 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:19 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:19 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:19 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 02:03:19 --> Severity: Notice  --> Undefined variable: tab_title C:\wamp\www\hostorks\application\models\superadmin_model.php 182
ERROR - 2014-08-15 02:03:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\hostorks\application\models\superadmin_model.php 182
DEBUG - 2014-08-15 02:03:28 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:28 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:28 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:28 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:28 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:28 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:28 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:28 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:28 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-08-15 02:03:28 --> Final output sent to browser
DEBUG - 2014-08-15 02:03:28 --> Total execution time: 0.1965
DEBUG - 2014-08-15 02:03:34 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:34 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:34 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:34 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:34 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:35 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:35 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:35 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:35 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:35 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:35 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-15 02:03:35 --> XSS Filtering completed
DEBUG - 2014-08-15 02:03:35 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:35 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:36 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:36 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:36 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:36 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:36 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:36 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 02:03:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 02:03:36 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-15 02:03:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 02:03:36 --> Final output sent to browser
DEBUG - 2014-08-15 02:03:36 --> Total execution time: 0.3092
DEBUG - 2014-08-15 02:03:40 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:40 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:40 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:40 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:40 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:40 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:40 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:40 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:03:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 02:03:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 02:03:40 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 02:03:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 02:03:40 --> Final output sent to browser
DEBUG - 2014-08-15 02:03:40 --> Total execution time: 0.3492
DEBUG - 2014-08-15 02:03:41 --> Config Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:03:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:03:41 --> URI Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Router Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Output Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Security Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Input Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:03:41 --> Language Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Loader Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:03:41 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:03:41 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Session Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:03:41 --> Session routines successfully run
DEBUG - 2014-08-15 02:03:41 --> Upload Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Controller Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:03:41 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Model Class Initialized
DEBUG - 2014-08-15 02:03:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 02:03:41 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 02:04:09 --> Config Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:04:09 --> URI Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Router Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Output Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Security Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Input Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:04:09 --> Language Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Loader Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:04:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:04:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Session Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:04:09 --> Session routines successfully run
DEBUG - 2014-08-15 02:04:09 --> Upload Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Controller Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:04:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Model Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Model Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Model Class Initialized
DEBUG - 2014-08-15 02:04:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:04:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:04:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:04:09 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:31:24 --> Config Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:31:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:31:24 --> URI Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Router Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Output Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Security Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Input Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:31:24 --> Language Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Loader Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:31:24 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:31:24 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Session Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:31:24 --> Session routines successfully run
DEBUG - 2014-08-15 02:31:24 --> Upload Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Controller Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:31:24 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Model Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Model Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Model Class Initialized
DEBUG - 2014-08-15 02:31:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:31:24 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 02:31:24 --> Severity: Notice  --> Undefined variable: files C:\wamp\www\hostorks\application\models\superadmin_model.php 193
ERROR - 2014-08-15 02:31:24 --> Severity: Notice  --> Undefined variable: files C:\wamp\www\hostorks\application\models\superadmin_model.php 194
ERROR - 2014-08-15 02:31:24 --> Severity: Notice  --> Undefined variable: files C:\wamp\www\hostorks\application\models\superadmin_model.php 195
ERROR - 2014-08-15 02:31:24 --> Severity: Notice  --> Undefined variable: files C:\wamp\www\hostorks\application\models\superadmin_model.php 196
ERROR - 2014-08-15 02:31:24 --> Severity: Notice  --> Undefined variable: files C:\wamp\www\hostorks\application\models\superadmin_model.php 197
DEBUG - 2014-08-15 02:31:24 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:31:24 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:32:28 --> Config Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:32:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:32:28 --> URI Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Router Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Output Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Security Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Input Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:32:28 --> Language Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Loader Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:32:28 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:32:28 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Session Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:32:28 --> Session routines successfully run
DEBUG - 2014-08-15 02:32:28 --> Upload Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Controller Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:32:28 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Model Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Model Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Model Class Initialized
DEBUG - 2014-08-15 02:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:32:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:32:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:32:28 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:34:03 --> Config Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:34:03 --> URI Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Router Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Output Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Security Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Input Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:34:03 --> Language Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Loader Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:34:03 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:34:03 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Session Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:34:03 --> Session routines successfully run
DEBUG - 2014-08-15 02:34:03 --> Upload Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Controller Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:34:03 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:03 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:34:03 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:34:08 --> Config Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:34:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:34:08 --> URI Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Router Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Output Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Security Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Input Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:34:08 --> Language Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Loader Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:34:08 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:34:08 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Session Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:34:08 --> Session routines successfully run
DEBUG - 2014-08-15 02:34:08 --> Upload Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Controller Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:34:08 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:08 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-15 02:34:08 --> Final output sent to browser
DEBUG - 2014-08-15 02:34:08 --> Total execution time: 0.1746
DEBUG - 2014-08-15 02:34:16 --> Config Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:34:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:34:16 --> URI Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Router Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Output Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Security Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Input Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:34:16 --> Language Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Loader Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:34:16 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:34:16 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Session Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:34:16 --> Session routines successfully run
DEBUG - 2014-08-15 02:34:16 --> Upload Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Controller Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:34:16 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 02:34:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 02:34:16 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-15 02:34:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 02:34:16 --> Final output sent to browser
DEBUG - 2014-08-15 02:34:16 --> Total execution time: 0.2761
DEBUG - 2014-08-15 02:34:19 --> Config Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:34:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:34:19 --> URI Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Router Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Output Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Security Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Input Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:34:19 --> Language Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Loader Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:34:19 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:34:19 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Session Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:34:19 --> Session routines successfully run
DEBUG - 2014-08-15 02:34:19 --> Upload Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Controller Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:34:19 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 02:34:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 02:34:19 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 02:34:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 02:34:19 --> Final output sent to browser
DEBUG - 2014-08-15 02:34:19 --> Total execution time: 0.1950
DEBUG - 2014-08-15 02:34:20 --> Config Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:34:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:34:20 --> URI Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Router Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Output Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Security Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Input Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:34:20 --> Language Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Loader Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:34:20 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:34:20 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Session Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:34:20 --> Session routines successfully run
DEBUG - 2014-08-15 02:34:20 --> Upload Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Controller Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:34:20 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 02:34:20 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 02:34:49 --> Config Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:34:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:34:49 --> URI Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Router Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Output Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Security Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Input Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:34:49 --> Language Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Loader Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:34:49 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:34:49 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Session Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:34:49 --> Session routines successfully run
DEBUG - 2014-08-15 02:34:49 --> Upload Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Controller Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:34:49 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Model Class Initialized
DEBUG - 2014-08-15 02:34:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:34:49 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:34:49 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:38:13 --> Config Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:38:13 --> URI Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Router Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Output Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Security Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Input Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:38:13 --> Language Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Loader Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:38:13 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:38:13 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Session Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:38:13 --> Session routines successfully run
DEBUG - 2014-08-15 02:38:13 --> Upload Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Controller Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:38:13 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:38:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:38:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:38:13 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:38:40 --> Config Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:38:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:38:40 --> URI Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Router Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Output Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Security Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Input Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:38:40 --> Language Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Loader Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:38:40 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:38:40 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Session Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:38:40 --> Session routines successfully run
DEBUG - 2014-08-15 02:38:40 --> Upload Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Controller Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:38:40 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:38:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:38:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:38:40 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:38:51 --> Config Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:38:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:38:51 --> URI Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Router Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Output Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Security Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Input Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:38:51 --> Language Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Loader Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:38:51 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:38:51 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Session Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:38:51 --> Session routines successfully run
DEBUG - 2014-08-15 02:38:51 --> Upload Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Controller Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:38:51 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Model Class Initialized
DEBUG - 2014-08-15 02:38:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:38:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:38:51 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:38:51 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:39:00 --> Config Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:39:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:39:00 --> URI Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Router Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Output Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Security Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Input Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:39:00 --> Language Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Loader Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:39:00 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:39:00 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Session Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:39:00 --> Session routines successfully run
DEBUG - 2014-08-15 02:39:00 --> Upload Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Controller Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:39:00 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:39:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:39:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:39:00 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:39:13 --> Config Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:39:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:39:13 --> URI Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Router Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Output Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Security Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Input Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:39:13 --> Language Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Loader Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:39:13 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:39:13 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Session Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:39:13 --> Session routines successfully run
DEBUG - 2014-08-15 02:39:13 --> Upload Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Controller Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:39:13 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:39:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:39:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:39:13 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:39:29 --> Config Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:39:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:39:29 --> URI Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Router Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Output Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Security Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Input Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:39:29 --> Language Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Loader Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:39:29 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:39:29 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Session Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:39:29 --> Session routines successfully run
DEBUG - 2014-08-15 02:39:29 --> Upload Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Controller Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:39:29 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Model Class Initialized
DEBUG - 2014-08-15 02:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:39:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:39:29 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:39:29 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:41:50 --> Config Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:41:50 --> URI Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Router Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Output Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Security Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Input Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:41:50 --> Language Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Loader Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:41:50 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:41:50 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Session Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:41:50 --> Session routines successfully run
DEBUG - 2014-08-15 02:41:50 --> Upload Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Controller Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:41:50 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Model Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Model Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Model Class Initialized
DEBUG - 2014-08-15 02:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:41:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:41:50 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:41:50 --> You did not select a file to upload.
DEBUG - 2014-08-15 02:43:03 --> Config Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:43:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:43:03 --> URI Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Router Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Output Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Security Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Input Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:43:03 --> Language Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Loader Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:43:03 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:43:03 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Session Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:43:03 --> Session routines successfully run
DEBUG - 2014-08-15 02:43:03 --> Upload Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Controller Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:43:03 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Model Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Model Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Model Class Initialized
DEBUG - 2014-08-15 02:43:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:43:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:44:02 --> Config Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:44:02 --> URI Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Router Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Output Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Security Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Input Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:44:02 --> Language Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Loader Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:44:02 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:44:02 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Session Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:44:02 --> Session routines successfully run
DEBUG - 2014-08-15 02:44:02 --> Upload Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Controller Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:44:02 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:44:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:44:16 --> Config Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:44:16 --> URI Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Router Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Output Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Security Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Input Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:44:16 --> Language Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Loader Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:44:16 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:44:16 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Session Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:44:16 --> Session routines successfully run
DEBUG - 2014-08-15 02:44:16 --> Upload Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Controller Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:44:16 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:44:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:44:24 --> Config Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:44:24 --> URI Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Router Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Output Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Security Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Input Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:44:24 --> Language Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Loader Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:44:24 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:44:24 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Session Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:44:24 --> Session routines successfully run
DEBUG - 2014-08-15 02:44:24 --> Upload Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Controller Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:44:24 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Model Class Initialized
DEBUG - 2014-08-15 02:44:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:44:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:45:35 --> Config Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Hooks Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Utf8 Class Initialized
DEBUG - 2014-08-15 02:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 02:45:35 --> URI Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Router Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Output Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Security Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Input Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 02:45:35 --> Language Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Loader Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Helper loaded: url_helper
DEBUG - 2014-08-15 02:45:35 --> Helper loaded: file_helper
DEBUG - 2014-08-15 02:45:35 --> Database Driver Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Session Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Helper loaded: string_helper
DEBUG - 2014-08-15 02:45:35 --> Session routines successfully run
DEBUG - 2014-08-15 02:45:35 --> Upload Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Pagination Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Controller Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Helper loaded: form_helper
DEBUG - 2014-08-15 02:45:35 --> Form Validation Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-15 02:45:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:45:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 02:45:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 02:45:35 --> You did not select a file to upload.
DEBUG - 2014-08-15 03:00:39 --> Config Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:00:39 --> URI Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Router Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Output Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Security Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Input Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:00:39 --> Language Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Loader Class Initialized
DEBUG - 2014-08-15 03:00:39 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:00:39 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:00:40 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Session Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:00:40 --> Session routines successfully run
DEBUG - 2014-08-15 03:00:40 --> Upload Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Controller Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:00:40 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Model Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Model Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Model Class Initialized
DEBUG - 2014-08-15 03:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:00:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:00:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:00:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:00:40 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:00:40 --> Severity: Notice  --> Undefined index: file_name C:\wamp\www\hostorks\application\models\superadmin_model.php 220
DEBUG - 2014-08-15 03:00:40 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:00:40 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:00:40 --> Severity: Notice  --> Undefined index: file_name C:\wamp\www\hostorks\application\models\superadmin_model.php 220
ERROR - 2014-08-15 03:00:40 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:00:40 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 251
ERROR - 2014-08-15 03:00:40 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 251
ERROR - 2014-08-15 03:00:40 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 251
ERROR - 2014-08-15 03:00:40 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 251
DEBUG - 2014-08-15 03:02:14 --> Config Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:02:14 --> URI Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Router Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Output Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Security Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Input Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:02:14 --> Language Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Loader Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:02:14 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:02:14 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Session Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:02:14 --> Session routines successfully run
DEBUG - 2014-08-15 03:02:14 --> Upload Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Controller Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:02:14 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Model Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Model Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Model Class Initialized
DEBUG - 2014-08-15 03:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:02:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:02:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:02:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:02:14 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:02:14 --> Severity: Notice  --> Undefined index: file_name C:\wamp\www\hostorks\application\models\superadmin_model.php 221
DEBUG - 2014-08-15 03:02:14 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:02:14 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:02:14 --> Severity: Notice  --> Undefined index: file_name C:\wamp\www\hostorks\application\models\superadmin_model.php 221
ERROR - 2014-08-15 03:02:14 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:02:14 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:02:14 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:02:14 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:02:14 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
DEBUG - 2014-08-15 03:03:30 --> Config Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:03:30 --> URI Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Router Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Output Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Security Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Input Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:03:30 --> Language Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Loader Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:03:30 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:03:30 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Session Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:03:30 --> Session routines successfully run
DEBUG - 2014-08-15 03:03:30 --> Upload Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Controller Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:03:30 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Model Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Model Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Model Class Initialized
DEBUG - 2014-08-15 03:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:03:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:03:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:03:30 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:03:30 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:03:30 --> Severity: Notice  --> Undefined index: file_name C:\wamp\www\hostorks\application\models\superadmin_model.php 221
DEBUG - 2014-08-15 03:03:30 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:03:30 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:03:30 --> Severity: Notice  --> Undefined index: file_name C:\wamp\www\hostorks\application\models\superadmin_model.php 221
ERROR - 2014-08-15 03:03:30 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:03:30 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:03:30 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:03:30 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:03:30 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
DEBUG - 2014-08-15 03:04:24 --> Config Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:04:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:04:24 --> URI Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Router Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Output Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Security Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Input Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:04:24 --> Language Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Loader Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:04:24 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:04:24 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Session Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:04:24 --> Session routines successfully run
DEBUG - 2014-08-15 03:04:24 --> Upload Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Controller Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:04:24 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Model Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Model Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Model Class Initialized
DEBUG - 2014-08-15 03:04:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:04:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:04:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:04:24 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:04:24 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:04:24 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:04:24 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:04:24 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:04:24 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:04:24 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:04:24 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:04:24 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
DEBUG - 2014-08-15 03:05:09 --> Config Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:05:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:05:09 --> URI Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Router Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Output Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Security Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Input Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:05:09 --> Language Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Loader Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:05:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:05:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Session Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:05:09 --> Session routines successfully run
DEBUG - 2014-08-15 03:05:09 --> Upload Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Controller Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:05:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Model Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Model Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Model Class Initialized
DEBUG - 2014-08-15 03:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:05:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:05:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:05:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:05:09 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:05:09 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:05:09 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:05:09 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:05:09 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:05:09 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:05:09 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:05:09 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
DEBUG - 2014-08-15 03:05:39 --> Config Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:05:39 --> URI Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Router Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Output Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Security Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Input Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:05:39 --> Language Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Loader Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:05:39 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:05:39 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Session Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:05:39 --> Session routines successfully run
DEBUG - 2014-08-15 03:05:39 --> Upload Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Controller Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:05:39 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Model Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Model Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Model Class Initialized
DEBUG - 2014-08-15 03:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:05:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:05:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:05:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:05:39 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:05:39 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:05:39 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:05:39 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:05:39 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:05:39 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:05:39 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
ERROR - 2014-08-15 03:05:39 --> Severity: Notice  --> Undefined index: tab_image C:\wamp\www\hostorks\application\models\superadmin_model.php 252
DEBUG - 2014-08-15 03:06:22 --> Config Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:06:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:06:22 --> URI Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Router Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Output Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Security Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Input Class Initialized
DEBUG - 2014-08-15 03:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:06:22 --> Language Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Loader Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:06:23 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:06:23 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Session Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:06:23 --> Session routines successfully run
DEBUG - 2014-08-15 03:06:23 --> Upload Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Controller Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:06:23 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Model Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Model Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Model Class Initialized
DEBUG - 2014-08-15 03:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:06:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:06:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:06:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:06:23 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:06:23 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:06:23 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:06:23 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:07:45 --> Config Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:07:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:07:45 --> URI Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Router Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Output Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Security Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Input Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:07:45 --> Language Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Loader Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:07:45 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:07:45 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Session Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:07:45 --> Session routines successfully run
DEBUG - 2014-08-15 03:07:45 --> Upload Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Controller Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:07:45 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Model Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Model Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Model Class Initialized
DEBUG - 2014-08-15 03:07:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:07:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:07:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:07:45 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:07:45 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:07:45 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:07:45 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:07:45 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:11:36 --> Config Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:11:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:11:36 --> URI Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Router Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Output Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Security Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Input Class Initialized
DEBUG - 2014-08-15 03:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:11:36 --> Language Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Loader Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:11:37 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:11:37 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Session Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:11:37 --> Session routines successfully run
DEBUG - 2014-08-15 03:11:37 --> Upload Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Controller Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:11:37 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Model Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Model Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Model Class Initialized
DEBUG - 2014-08-15 03:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:11:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:11:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:11:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:11:37 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:11:37 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:11:37 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:11:37 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:11:58 --> Config Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:11:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:11:58 --> URI Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Router Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Output Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Security Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Input Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:11:58 --> Language Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Loader Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:11:58 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:11:58 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Session Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:11:58 --> Session routines successfully run
DEBUG - 2014-08-15 03:11:58 --> Upload Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Controller Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:11:58 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Model Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Model Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Model Class Initialized
DEBUG - 2014-08-15 03:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:11:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:11:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:11:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:11:58 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:11:58 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:11:58 --> The upload path does not appear to be valid.
ERROR - 2014-08-15 03:11:58 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:19:45 --> Config Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:19:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:19:45 --> URI Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Router Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Output Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Security Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Input Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:19:45 --> Language Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Loader Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:19:45 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:19:45 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Session Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:19:45 --> Session routines successfully run
DEBUG - 2014-08-15 03:19:45 --> Upload Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Controller Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:19:45 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:19:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:19:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:19:45 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-15 03:19:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:19:45 --> Final output sent to browser
DEBUG - 2014-08-15 03:19:45 --> Total execution time: 0.2771
DEBUG - 2014-08-15 03:19:49 --> Config Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:19:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:19:49 --> URI Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Router Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Output Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Security Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Input Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:19:49 --> Language Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Loader Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:19:49 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:19:49 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Session Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:19:49 --> Session routines successfully run
DEBUG - 2014-08-15 03:19:49 --> Upload Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Controller Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:19:49 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:19:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:19:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:19:49 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 03:19:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:19:49 --> Final output sent to browser
DEBUG - 2014-08-15 03:19:49 --> Total execution time: 0.1978
DEBUG - 2014-08-15 03:19:50 --> Config Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:19:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:19:50 --> URI Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Router Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Output Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Security Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Input Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:19:50 --> Language Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Loader Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:19:50 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:19:50 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Session Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:19:50 --> Session routines successfully run
DEBUG - 2014-08-15 03:19:50 --> Upload Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Controller Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:19:50 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Model Class Initialized
DEBUG - 2014-08-15 03:19:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:19:50 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 03:20:11 --> Config Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:20:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:20:11 --> URI Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Router Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Output Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Security Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Input Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:20:11 --> Language Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Loader Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:20:11 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:20:11 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Session Class Initialized
DEBUG - 2014-08-15 03:20:11 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:20:12 --> Session routines successfully run
DEBUG - 2014-08-15 03:20:12 --> Upload Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Controller Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:20:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:20:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:20:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:20:12 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:20:12 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:20:12 --> The upload path does not appear to be valid.
DEBUG - 2014-08-15 03:20:52 --> Config Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:20:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:20:52 --> URI Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Router Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Output Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Security Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Input Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:20:52 --> Language Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Loader Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:20:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:20:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Session Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:20:52 --> Session routines successfully run
DEBUG - 2014-08-15 03:20:52 --> Upload Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Controller Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:20:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:20:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:20:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:20:52 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-15 03:20:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:20:52 --> Final output sent to browser
DEBUG - 2014-08-15 03:20:52 --> Total execution time: 0.1805
DEBUG - 2014-08-15 03:20:55 --> Config Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:20:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:20:55 --> URI Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Router Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Output Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Security Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Input Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:20:55 --> Language Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Loader Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:20:55 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:20:55 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Session Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:20:55 --> Session routines successfully run
DEBUG - 2014-08-15 03:20:55 --> Upload Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Controller Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:20:55 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:20:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:20:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:20:55 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-08-15 03:20:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:20:55 --> Final output sent to browser
DEBUG - 2014-08-15 03:20:55 --> Total execution time: 0.1846
DEBUG - 2014-08-15 03:20:57 --> Config Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:20:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:20:57 --> URI Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Router Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Output Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Security Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Input Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:20:57 --> Language Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Loader Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:20:57 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:20:57 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Session Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:20:57 --> Session routines successfully run
DEBUG - 2014-08-15 03:20:57 --> Upload Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Controller Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:20:57 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Model Class Initialized
DEBUG - 2014-08-15 03:20:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:20:57 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 03:21:12 --> Config Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:21:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:21:12 --> URI Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Router Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Output Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Security Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Input Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:21:12 --> Language Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Loader Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:21:12 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:21:12 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Session Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:21:12 --> Session routines successfully run
DEBUG - 2014-08-15 03:21:12 --> Upload Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Controller Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:21:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:21:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:21:13 --> Config Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:21:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:21:13 --> URI Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Router Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Output Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Security Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Input Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:21:13 --> Language Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Loader Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:21:13 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:21:13 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Session Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:21:13 --> Session routines successfully run
DEBUG - 2014-08-15 03:21:13 --> Upload Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Controller Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:21:13 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:21:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:21:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:21:13 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-08-15 03:21:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:21:13 --> Final output sent to browser
DEBUG - 2014-08-15 03:21:13 --> Total execution time: 0.2135
DEBUG - 2014-08-15 03:21:14 --> Config Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:21:14 --> URI Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Router Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Output Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Security Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Input Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:21:14 --> Language Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Loader Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:21:14 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:21:14 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Session Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:21:14 --> Session routines successfully run
DEBUG - 2014-08-15 03:21:14 --> Upload Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Controller Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:21:14 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:21:14 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 03:21:19 --> Config Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:21:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:21:19 --> URI Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Router Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Output Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Security Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Input Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:21:19 --> Language Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Loader Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:21:19 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:21:19 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Session Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:21:19 --> Session routines successfully run
DEBUG - 2014-08-15 03:21:19 --> Upload Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Controller Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:21:19 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:21:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:21:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:21:19 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-08-15 03:21:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:21:19 --> Final output sent to browser
DEBUG - 2014-08-15 03:21:19 --> Total execution time: 0.2617
DEBUG - 2014-08-15 03:21:21 --> Config Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:21:21 --> URI Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Router Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Output Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Security Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Input Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:21:21 --> Language Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Loader Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:21:21 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:21:21 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Session Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:21:21 --> Session routines successfully run
DEBUG - 2014-08-15 03:21:21 --> Upload Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Controller Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:21:21 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Model Class Initialized
DEBUG - 2014-08-15 03:21:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:21:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:21:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:21:21 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-08-15 03:21:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:21:21 --> Final output sent to browser
DEBUG - 2014-08-15 03:21:21 --> Total execution time: 0.2463
DEBUG - 2014-08-15 03:22:52 --> Config Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:22:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:22:52 --> URI Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Router Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Output Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Security Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Input Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:22:52 --> Language Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Loader Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:22:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:22:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Session Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:22:52 --> Session routines successfully run
DEBUG - 2014-08-15 03:22:52 --> Upload Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Controller Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:22:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Model Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Model Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Model Class Initialized
DEBUG - 2014-08-15 03:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:22:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 03:22:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 03:22:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 03:22:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 03:22:52 --> Final output sent to browser
DEBUG - 2014-08-15 03:22:52 --> Total execution time: 0.2000
DEBUG - 2014-08-15 03:22:53 --> Config Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:22:53 --> URI Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Router Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Output Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Security Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Input Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:22:53 --> Language Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Loader Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:22:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:22:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Session Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:22:53 --> Session routines successfully run
DEBUG - 2014-08-15 03:22:53 --> Upload Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Controller Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:22:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Model Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Model Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Model Class Initialized
DEBUG - 2014-08-15 03:22:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 03:22:53 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 03:23:06 --> Config Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Hooks Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Utf8 Class Initialized
DEBUG - 2014-08-15 03:23:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 03:23:06 --> URI Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Router Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Output Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Security Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Input Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 03:23:06 --> Language Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Loader Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Helper loaded: url_helper
DEBUG - 2014-08-15 03:23:06 --> Helper loaded: file_helper
DEBUG - 2014-08-15 03:23:06 --> Database Driver Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Session Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Helper loaded: string_helper
DEBUG - 2014-08-15 03:23:06 --> Session routines successfully run
DEBUG - 2014-08-15 03:23:06 --> Upload Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Pagination Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Controller Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Helper loaded: form_helper
DEBUG - 2014-08-15 03:23:06 --> Form Validation Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Model Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Model Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Model Class Initialized
DEBUG - 2014-08-15 03:23:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:23:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 03:23:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-08-15 03:23:06 --> You did not select a file to upload.
DEBUG - 2014-08-15 03:23:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 06:42:53 --> Config Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 06:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 06:42:53 --> URI Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Router Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Output Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Security Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Input Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 06:42:53 --> Language Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Loader Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 06:42:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 06:42:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Session Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 06:42:53 --> A session cookie was not found.
DEBUG - 2014-08-15 06:42:53 --> Session routines successfully run
DEBUG - 2014-08-15 06:42:53 --> Upload Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Controller Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 06:42:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 06:42:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 06:42:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 06:42:53 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-08-15 06:42:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 06:42:53 --> Final output sent to browser
DEBUG - 2014-08-15 06:42:53 --> Total execution time: 0.3447
DEBUG - 2014-08-15 06:42:56 --> Config Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Hooks Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Utf8 Class Initialized
DEBUG - 2014-08-15 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 06:42:56 --> URI Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Router Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Output Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Security Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Input Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 06:42:56 --> Language Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Loader Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: url_helper
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: file_helper
DEBUG - 2014-08-15 06:42:56 --> Database Driver Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Session Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: string_helper
DEBUG - 2014-08-15 06:42:56 --> Session routines successfully run
DEBUG - 2014-08-15 06:42:56 --> Upload Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Pagination Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Controller Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: form_helper
DEBUG - 2014-08-15 06:42:56 --> Form Validation Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 06:42:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 06:42:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 06:42:56 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 06:42:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 06:42:56 --> Final output sent to browser
DEBUG - 2014-08-15 06:42:56 --> Total execution time: 0.1064
DEBUG - 2014-08-15 06:42:56 --> Config Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Hooks Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Utf8 Class Initialized
DEBUG - 2014-08-15 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 06:42:56 --> URI Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Router Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Output Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Security Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Input Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 06:42:56 --> Language Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Loader Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: url_helper
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: file_helper
DEBUG - 2014-08-15 06:42:56 --> Database Driver Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Session Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: string_helper
DEBUG - 2014-08-15 06:42:56 --> Session routines successfully run
DEBUG - 2014-08-15 06:42:56 --> Upload Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Pagination Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Controller Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Helper loaded: form_helper
DEBUG - 2014-08-15 06:42:56 --> Form Validation Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Model Class Initialized
DEBUG - 2014-08-15 06:42:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 06:42:56 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 07:57:09 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:09 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:09 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:09 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:09 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 07:57:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 07:57:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 07:57:09 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 07:57:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 07:57:09 --> Final output sent to browser
DEBUG - 2014-08-15 07:57:09 --> Total execution time: 0.1078
DEBUG - 2014-08-15 07:57:09 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:09 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:09 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:09 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:09 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 07:57:09 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 07:57:12 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:12 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:12 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:12 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:12 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:12 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 07:57:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 07:57:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 07:57:12 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 07:57:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 07:57:12 --> Final output sent to browser
DEBUG - 2014-08-15 07:57:12 --> Total execution time: 0.1222
DEBUG - 2014-08-15 07:57:12 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:12 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:12 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:12 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:12 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:12 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 07:57:12 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 07:57:35 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:35 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:35 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:35 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:35 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:35 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:35 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 07:57:35 --> Severity: Notice  --> Undefined variable: config F:\wamp\www\hostorks\application\controllers\superadmin.php 355
DEBUG - 2014-08-15 07:57:35 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 07:57:35 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\controllers\superadmin.php 363
ERROR - 2014-08-15 07:57:35 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\controllers\superadmin.php 363
ERROR - 2014-08-15 07:57:35 --> Severity: Notice  --> Undefined offset: 4 F:\wamp\www\hostorks\application\controllers\superadmin.php 363
DEBUG - 2014-08-15 07:57:35 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:35 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:35 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:35 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:35 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:35 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:35 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 07:57:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 07:57:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 07:57:35 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 07:57:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 07:57:35 --> Final output sent to browser
DEBUG - 2014-08-15 07:57:35 --> Total execution time: 0.0896
DEBUG - 2014-08-15 07:57:35 --> Config Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Hooks Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Utf8 Class Initialized
DEBUG - 2014-08-15 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 07:57:35 --> URI Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Router Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Output Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Security Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Input Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 07:57:35 --> Language Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Loader Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: url_helper
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: file_helper
DEBUG - 2014-08-15 07:57:35 --> Database Driver Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Session Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: string_helper
DEBUG - 2014-08-15 07:57:35 --> Session routines successfully run
DEBUG - 2014-08-15 07:57:35 --> Upload Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Pagination Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Controller Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Helper loaded: form_helper
DEBUG - 2014-08-15 07:57:35 --> Form Validation Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Model Class Initialized
DEBUG - 2014-08-15 07:57:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 07:57:35 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 09:04:05 --> Config Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:04:05 --> URI Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Router Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Output Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Security Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Input Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:04:05 --> Language Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Loader Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:04:05 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Session Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:04:05 --> Session routines successfully run
DEBUG - 2014-08-15 09:04:05 --> Upload Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Controller Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:04:05 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Model Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Model Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Model Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:04:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:04:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:04:05 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:04:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:04:05 --> Final output sent to browser
DEBUG - 2014-08-15 09:04:05 --> Total execution time: 0.2510
DEBUG - 2014-08-15 09:04:05 --> Config Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:04:05 --> URI Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Router Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Output Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Security Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Input Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:04:05 --> Language Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Loader Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:04:05 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Session Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:04:05 --> Session routines successfully run
DEBUG - 2014-08-15 09:04:05 --> Upload Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:04:05 --> Controller Class Initialized
ERROR - 2014-08-15 09:04:05 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 09:04:06 --> Config Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:04:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:04:06 --> URI Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Router Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Output Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Security Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Input Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:04:06 --> Language Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Loader Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:04:06 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:04:06 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Session Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:04:06 --> Session routines successfully run
DEBUG - 2014-08-15 09:04:06 --> Upload Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Controller Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:04:06 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Model Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Model Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Model Class Initialized
DEBUG - 2014-08-15 09:04:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:04:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:04:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:04:06 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:04:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:04:06 --> Final output sent to browser
DEBUG - 2014-08-15 09:04:06 --> Total execution time: 0.1028
DEBUG - 2014-08-15 09:40:26 --> Config Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:40:26 --> URI Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Router Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Output Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Security Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Input Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:40:26 --> Language Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Loader Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:40:26 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Session Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:40:26 --> Session routines successfully run
DEBUG - 2014-08-15 09:40:26 --> Upload Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Controller Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:40:26 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:40:26 --> Config Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:40:26 --> URI Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Router Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Output Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Security Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Input Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:40:26 --> Language Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Loader Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:40:26 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Session Class Initialized
DEBUG - 2014-08-15 09:40:26 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:40:26 --> Session routines successfully run
DEBUG - 2014-08-15 09:40:27 --> Upload Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Controller Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:40:27 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:40:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:40:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:40:27 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:40:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:40:27 --> Final output sent to browser
DEBUG - 2014-08-15 09:40:27 --> Total execution time: 0.1050
DEBUG - 2014-08-15 09:40:27 --> Config Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:40:27 --> URI Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Router Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Output Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Security Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Input Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:40:27 --> Language Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Loader Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:40:27 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:40:27 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Session Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:40:27 --> Session routines successfully run
DEBUG - 2014-08-15 09:40:27 --> Upload Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Controller Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:40:27 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 09:40:27 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 09:40:31 --> Config Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:40:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:40:31 --> URI Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Router Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Output Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Security Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Input Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:40:31 --> Language Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Loader Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:40:31 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:40:31 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Session Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:40:31 --> Session routines successfully run
DEBUG - 2014-08-15 09:40:31 --> Upload Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Controller Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:40:31 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:40:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:40:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:40:31 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:40:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:40:31 --> Final output sent to browser
DEBUG - 2014-08-15 09:40:31 --> Total execution time: 0.1063
DEBUG - 2014-08-15 09:40:32 --> Config Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:40:32 --> URI Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Router Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Output Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Security Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Input Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:40:32 --> Language Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Loader Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:40:32 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:40:32 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Session Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:40:32 --> Session routines successfully run
DEBUG - 2014-08-15 09:40:32 --> Upload Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Controller Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:40:32 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Model Class Initialized
DEBUG - 2014-08-15 09:40:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 09:40:32 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 09:41:12 --> Config Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:41:12 --> URI Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Router Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Output Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Security Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Input Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:41:12 --> Language Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Loader Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:41:12 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Session Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:41:12 --> Session routines successfully run
DEBUG - 2014-08-15 09:41:12 --> Upload Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Controller Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:41:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 09:41:12 --> Severity: Notice  --> Undefined variable: config F:\wamp\www\hostorks\application\controllers\superadmin.php 355
DEBUG - 2014-08-15 09:41:12 --> Upload class already loaded. Second attempt ignored.
ERROR - 2014-08-15 09:41:12 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\controllers\superadmin.php 363
ERROR - 2014-08-15 09:41:12 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\controllers\superadmin.php 363
ERROR - 2014-08-15 09:41:12 --> Severity: Notice  --> Undefined offset: 4 F:\wamp\www\hostorks\application\controllers\superadmin.php 363
DEBUG - 2014-08-15 09:41:12 --> Config Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:41:12 --> URI Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Router Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Output Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Security Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Input Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:41:12 --> Language Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Loader Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:41:12 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Session Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:41:12 --> Session routines successfully run
DEBUG - 2014-08-15 09:41:12 --> Upload Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Controller Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:41:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:41:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:41:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:41:13 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:41:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:41:13 --> Final output sent to browser
DEBUG - 2014-08-15 09:41:13 --> Total execution time: 0.1266
DEBUG - 2014-08-15 09:41:13 --> Config Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:41:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:41:13 --> URI Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Router Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Output Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Security Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Input Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:41:13 --> Language Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Loader Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:41:13 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:41:13 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Session Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:41:13 --> Session routines successfully run
DEBUG - 2014-08-15 09:41:13 --> Upload Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Controller Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:41:13 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 09:41:13 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 09:41:15 --> Config Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:41:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:41:15 --> URI Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Router Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Output Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Security Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Input Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:41:15 --> Language Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Loader Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:41:15 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:41:15 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Session Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:41:15 --> Session routines successfully run
DEBUG - 2014-08-15 09:41:15 --> Upload Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Controller Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:41:15 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:41:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:41:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:41:15 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:41:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:41:15 --> Final output sent to browser
DEBUG - 2014-08-15 09:41:15 --> Total execution time: 0.1006
DEBUG - 2014-08-15 09:41:16 --> Config Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:41:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:41:16 --> URI Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Router Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Output Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Security Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Input Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:41:16 --> Language Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Loader Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:41:16 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:41:16 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Session Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:41:16 --> Session routines successfully run
DEBUG - 2014-08-15 09:41:16 --> Upload Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Controller Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:41:16 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Model Class Initialized
DEBUG - 2014-08-15 09:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:41:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:41:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:41:16 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:41:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:41:16 --> Final output sent to browser
DEBUG - 2014-08-15 09:41:16 --> Total execution time: 0.1080
DEBUG - 2014-08-15 09:42:38 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:38 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:38 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:38 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:38 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:38 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:38 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:38 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:42:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:42:38 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:42:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:42:38 --> Final output sent to browser
DEBUG - 2014-08-15 09:42:38 --> Total execution time: 0.0894
DEBUG - 2014-08-15 09:42:39 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:39 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:39 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:39 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:39 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:39 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:39 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:39 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:42:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:42:39 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:42:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:42:39 --> Final output sent to browser
DEBUG - 2014-08-15 09:42:39 --> Total execution time: 0.1309
DEBUG - 2014-08-15 09:42:51 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:51 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:51 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:51 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:51 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:51 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:51 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:51 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:51 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:51 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:51 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:51 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:51 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:51 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:42:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:42:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:42:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:42:51 --> Final output sent to browser
DEBUG - 2014-08-15 09:42:51 --> Total execution time: 0.0967
DEBUG - 2014-08-15 09:42:51 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:51 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:51 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:51 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:51 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:51 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:51 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 09:42:51 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 09:42:53 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:53 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:53 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:53 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:53 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:42:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:42:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:42:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:42:53 --> Final output sent to browser
DEBUG - 2014-08-15 09:42:53 --> Total execution time: 0.0979
DEBUG - 2014-08-15 09:42:53 --> Config Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:42:53 --> URI Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Router Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Output Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Security Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Input Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:42:53 --> Language Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Loader Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:42:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Session Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:42:53 --> Session routines successfully run
DEBUG - 2014-08-15 09:42:53 --> Upload Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:42:53 --> Controller Class Initialized
DEBUG - 2014-08-15 09:42:54 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:42:54 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:42:54 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:54 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:54 --> Model Class Initialized
DEBUG - 2014-08-15 09:42:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:42:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:42:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:42:54 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:42:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:42:54 --> Final output sent to browser
DEBUG - 2014-08-15 09:42:54 --> Total execution time: 0.1057
DEBUG - 2014-08-15 09:51:51 --> Config Class Initialized
DEBUG - 2014-08-15 09:51:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:51:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:51:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:51:52 --> URI Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Router Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Output Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Security Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Input Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:51:52 --> Language Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Loader Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:51:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Session Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:51:52 --> Session routines successfully run
DEBUG - 2014-08-15 09:51:52 --> Upload Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Controller Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:51:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Model Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Model Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Model Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:51:52 --> Final output sent to browser
DEBUG - 2014-08-15 09:51:52 --> Total execution time: 0.1098
DEBUG - 2014-08-15 09:51:52 --> Config Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Hooks Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Utf8 Class Initialized
DEBUG - 2014-08-15 09:51:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 09:51:52 --> URI Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Router Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Output Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Security Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Input Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 09:51:52 --> Language Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Loader Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 09:51:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Session Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 09:51:52 --> Session routines successfully run
DEBUG - 2014-08-15 09:51:52 --> Upload Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Controller Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 09:51:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Model Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Model Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Model Class Initialized
DEBUG - 2014-08-15 09:51:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 09:51:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 09:51:52 --> Final output sent to browser
DEBUG - 2014-08-15 09:51:52 --> Total execution time: 0.1071
DEBUG - 2014-08-15 10:20:35 --> Config Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:20:35 --> URI Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Router Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Output Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Security Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Input Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:20:35 --> Language Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Loader Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:20:35 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:20:35 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Session Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:20:35 --> Session routines successfully run
DEBUG - 2014-08-15 10:20:35 --> Upload Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Controller Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:20:35 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Model Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Model Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Model Class Initialized
DEBUG - 2014-08-15 10:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:20:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:20:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:20:35 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:20:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:20:35 --> Final output sent to browser
DEBUG - 2014-08-15 10:20:35 --> Total execution time: 0.1093
DEBUG - 2014-08-15 10:20:36 --> Config Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:20:36 --> URI Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Router Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Output Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Security Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Input Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:20:36 --> Language Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Loader Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:20:36 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:20:36 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Session Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:20:36 --> Session routines successfully run
DEBUG - 2014-08-15 10:20:36 --> Upload Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Controller Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:20:36 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Model Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Model Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Model Class Initialized
DEBUG - 2014-08-15 10:20:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:20:36 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:22:24 --> Config Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:22:24 --> URI Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Router Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Output Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Security Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Input Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:22:24 --> Language Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Loader Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:22:24 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Session Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:22:24 --> Session routines successfully run
DEBUG - 2014-08-15 10:22:24 --> Upload Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Controller Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:22:24 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:22:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:22:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:22:24 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:22:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:22:24 --> Final output sent to browser
DEBUG - 2014-08-15 10:22:24 --> Total execution time: 0.1301
DEBUG - 2014-08-15 10:22:24 --> Config Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:22:24 --> URI Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Router Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Output Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Security Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Input Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:22:24 --> Language Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Loader Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:22:24 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Session Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:22:24 --> Session routines successfully run
DEBUG - 2014-08-15 10:22:24 --> Upload Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:22:24 --> Controller Class Initialized
DEBUG - 2014-08-15 10:22:25 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:22:25 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:22:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:22:25 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:22:32 --> Config Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:22:32 --> URI Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Router Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Output Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Security Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Input Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:22:32 --> Language Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Loader Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:22:32 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Session Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:22:32 --> Session routines successfully run
DEBUG - 2014-08-15 10:22:32 --> Upload Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Controller Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:22:32 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:22:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:22:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:22:32 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:22:32 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:22:32 --> Final output sent to browser
DEBUG - 2014-08-15 10:22:32 --> Total execution time: 0.0887
DEBUG - 2014-08-15 10:22:32 --> Config Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:22:32 --> URI Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Router Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Output Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Security Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Input Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:22:32 --> Language Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Loader Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:22:32 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Session Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:22:32 --> Session routines successfully run
DEBUG - 2014-08-15 10:22:32 --> Upload Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Controller Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:22:32 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Model Class Initialized
DEBUG - 2014-08-15 10:22:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:22:32 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:31:44 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:44 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:44 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:44 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:44 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:44 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:44 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:44 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:31:44 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:31:44 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:31:44 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:31:44 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:31:44 --> Final output sent to browser
DEBUG - 2014-08-15 10:31:44 --> Total execution time: 0.1379
DEBUG - 2014-08-15 10:31:45 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:45 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:45 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:45 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:45 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:45 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:45 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:45 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:31:45 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:31:46 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:46 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:46 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:46 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:46 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:46 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:46 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:46 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:31:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:31:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:31:46 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:31:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:31:46 --> Final output sent to browser
DEBUG - 2014-08-15 10:31:46 --> Total execution time: 0.1056
DEBUG - 2014-08-15 10:31:47 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:47 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:47 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:47 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:47 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:47 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:47 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:47 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:31:47 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:31:48 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:48 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:48 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:48 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:48 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:48 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:48 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:48 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:31:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:31:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:31:48 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:31:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:31:48 --> Final output sent to browser
DEBUG - 2014-08-15 10:31:48 --> Total execution time: 0.1200
DEBUG - 2014-08-15 10:31:48 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:48 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:48 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:48 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:48 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:48 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:49 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:49 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:49 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:31:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:31:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:31:49 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:31:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:31:49 --> Final output sent to browser
DEBUG - 2014-08-15 10:31:49 --> Total execution time: 0.1125
DEBUG - 2014-08-15 10:31:59 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:59 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:59 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:59 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:59 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:59 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:59 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:31:59 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:31:59 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:31:59 --> Severity: Notice  --> Undefined offset: 4 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
DEBUG - 2014-08-15 10:31:59 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:59 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:59 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:59 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:59 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:59 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:59 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:31:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:31:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:31:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:31:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:31:59 --> Final output sent to browser
DEBUG - 2014-08-15 10:31:59 --> Total execution time: 0.1137
DEBUG - 2014-08-15 10:31:59 --> Config Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:31:59 --> URI Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Router Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Output Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Security Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Input Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:31:59 --> Language Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Loader Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:31:59 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Session Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:31:59 --> Session routines successfully run
DEBUG - 2014-08-15 10:31:59 --> Upload Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Controller Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:31:59 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:31:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:31:59 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:32:01 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:01 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:01 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:01 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:01 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:01 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:01 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:01 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:01 --> Total execution time: 0.0916
DEBUG - 2014-08-15 10:32:01 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:01 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:01 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:01 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:01 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:01 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:01 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:01 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:01 --> Total execution time: 0.1208
DEBUG - 2014-08-15 10:32:07 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:07 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:07 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:07 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:07 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:07 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:07 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:07 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:07 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:07 --> Severity: Notice  --> Undefined offset: 4 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:07 --> Severity: Notice  --> Undefined variable: delete_photo F:\wamp\www\hostorks\application\models\superadmin_model.php 215
DEBUG - 2014-08-15 10:32:07 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:07 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:07 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:07 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:07 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:07 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:07 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:07 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:07 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:07 --> Total execution time: 0.0944
DEBUG - 2014-08-15 10:32:07 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:07 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:07 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:07 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:07 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:07 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:07 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:07 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:32:10 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:10 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:10 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:10 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:10 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:10 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:10 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:10 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:10 --> Total execution time: 0.1016
DEBUG - 2014-08-15 10:32:10 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:10 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:10 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:10 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:10 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:10 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:10 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:10 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:10 --> Total execution time: 0.1090
DEBUG - 2014-08-15 10:32:17 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:17 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:17 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:17 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:17 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:17 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:17 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:17 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:17 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:17 --> Severity: Notice  --> Undefined offset: 4 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
DEBUG - 2014-08-15 10:32:17 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:17 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:17 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:17 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:17 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:17 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:17 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:17 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:17 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:17 --> Total execution time: 0.1047
DEBUG - 2014-08-15 10:32:18 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:18 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:18 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:18 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:18 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:18 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:18 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:18 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:18 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:32:19 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:19 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:19 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:19 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:19 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:19 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:19 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:19 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:19 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:19 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:19 --> Total execution time: 0.1090
DEBUG - 2014-08-15 10:32:20 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:20 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:20 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:20 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:20 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:20 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:20 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:20 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:20 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:20 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:20 --> Total execution time: 0.1145
DEBUG - 2014-08-15 10:32:27 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:27 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:27 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:27 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:27 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:27 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:27 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:27 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:27 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
ERROR - 2014-08-15 10:32:27 --> Severity: Notice  --> Undefined offset: 4 F:\wamp\www\hostorks\application\controllers\superadmin.php 427
DEBUG - 2014-08-15 10:32:27 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:27 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:27 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:27 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:27 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:27 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:27 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:27 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:27 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:27 --> Total execution time: 0.1020
DEBUG - 2014-08-15 10:32:27 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:27 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:27 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:27 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:27 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:27 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:27 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:27 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:32:29 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:29 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:29 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:29 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:29 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:29 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:29 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:29 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:29 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:29 --> Total execution time: 0.1021
DEBUG - 2014-08-15 10:32:30 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:30 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:30 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:30 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:30 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:30 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:30 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:30 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:30 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:30 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:30 --> Total execution time: 0.1050
DEBUG - 2014-08-15 10:32:37 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:37 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:37 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:37 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:37 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:38 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:38 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:38 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:38 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:38 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:38 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:38 --> Total execution time: 0.1008
DEBUG - 2014-08-15 10:32:38 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:38 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:38 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:38 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:38 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:38 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:38 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:38 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:38 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:32:51 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:51 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:51 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:51 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:51 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:51 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:51 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:51 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:51 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:51 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:51 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:51 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:51 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:51 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:51 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:51 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:51 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:51 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:51 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:51 --> Total execution time: 0.0995
DEBUG - 2014-08-15 10:32:52 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:52 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:52 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:52 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:52 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:32:52 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:32:53 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:53 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:53 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:53 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:53 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:53 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:53 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:53 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:53 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:53 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:53 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:53 --> Total execution time: 0.1087
DEBUG - 2014-08-15 10:32:56 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:56 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:56 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:56 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:56 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:56 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:56 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:56 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:56 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:56 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:56 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:56 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:56 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:56 --> Total execution time: 0.0928
DEBUG - 2014-08-15 10:32:59 --> Config Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:32:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:32:59 --> URI Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Router Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Output Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Security Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Input Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:32:59 --> Language Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Loader Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:32:59 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:32:59 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Session Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:32:59 --> Session routines successfully run
DEBUG - 2014-08-15 10:32:59 --> Upload Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Controller Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:32:59 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Model Class Initialized
DEBUG - 2014-08-15 10:32:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:32:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:32:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:32:59 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:32:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:32:59 --> Final output sent to browser
DEBUG - 2014-08-15 10:32:59 --> Total execution time: 0.0924
DEBUG - 2014-08-15 10:33:11 --> Config Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:33:11 --> URI Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Router Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Output Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Security Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Input Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:33:11 --> Language Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Loader Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:33:11 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:33:11 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Session Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:33:11 --> Session routines successfully run
DEBUG - 2014-08-15 10:33:11 --> Upload Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Controller Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:33:11 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Model Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Model Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Model Class Initialized
DEBUG - 2014-08-15 10:33:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:33:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:33:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:33:11 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:33:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:33:11 --> Final output sent to browser
DEBUG - 2014-08-15 10:33:11 --> Total execution time: 0.0916
DEBUG - 2014-08-15 10:36:07 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:07 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:07 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:07 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:07 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:07 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:07 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:36:07 --> Severity: Notice  --> Undefined variable: config F:\wamp\www\hostorks\application\controllers\superadmin.php 355
DEBUG - 2014-08-15 10:36:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:07 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:07 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:07 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:07 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:07 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:07 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:07 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:36:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:36:07 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:36:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:36:07 --> Final output sent to browser
DEBUG - 2014-08-15 10:36:07 --> Total execution time: 0.0905
DEBUG - 2014-08-15 10:36:07 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:07 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:07 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:07 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:07 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:07 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:07 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:36:07 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:36:09 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:09 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:09 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:09 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:09 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:36:09 --> Final output sent to browser
DEBUG - 2014-08-15 10:36:09 --> Total execution time: 0.1029
DEBUG - 2014-08-15 10:36:09 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:09 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:09 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:09 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:09 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:09 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:09 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:36:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:36:09 --> Final output sent to browser
DEBUG - 2014-08-15 10:36:10 --> Total execution time: 0.1152
DEBUG - 2014-08-15 10:36:49 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:49 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:49 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:49 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:49 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:49 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:50 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:50 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:50 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:50 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:50 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:36:50 --> Severity: Notice  --> Undefined variable: delete_photo F:\wamp\www\hostorks\application\models\superadmin_model.php 215
ERROR - 2014-08-15 10:36:50 --> Severity: Notice  --> Undefined variable: delete_photo F:\wamp\www\hostorks\application\models\superadmin_model.php 215
DEBUG - 2014-08-15 10:36:50 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:50 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:50 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:50 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:50 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:50 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:50 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:36:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:36:50 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:36:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:36:50 --> Final output sent to browser
DEBUG - 2014-08-15 10:36:50 --> Total execution time: 0.1056
DEBUG - 2014-08-15 10:36:50 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:50 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:50 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:50 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:50 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:50 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:50 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:36:50 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:36:52 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:52 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:52 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:52 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:52 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:36:52 --> Final output sent to browser
DEBUG - 2014-08-15 10:36:52 --> Total execution time: 0.0991
DEBUG - 2014-08-15 10:36:52 --> Config Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:36:52 --> URI Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Router Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Output Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Security Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Input Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:36:52 --> Language Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Loader Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:36:52 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Session Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:36:52 --> Session routines successfully run
DEBUG - 2014-08-15 10:36:52 --> Upload Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Controller Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:36:52 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Model Class Initialized
DEBUG - 2014-08-15 10:36:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:36:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:36:52 --> Final output sent to browser
DEBUG - 2014-08-15 10:36:52 --> Total execution time: 0.1131
DEBUG - 2014-08-15 10:37:03 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:03 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:03 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:03 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:03 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:03 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:03 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:37:03 --> Severity: Notice  --> Undefined offset: 1 F:\wamp\www\hostorks\application\models\superadmin_model.php 215
ERROR - 2014-08-15 10:37:03 --> Severity: Notice  --> Undefined offset: 2 F:\wamp\www\hostorks\application\models\superadmin_model.php 215
DEBUG - 2014-08-15 10:37:03 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:03 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:03 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:03 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:03 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:03 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:03 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:37:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:37:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:37:03 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:37:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:37:03 --> Final output sent to browser
DEBUG - 2014-08-15 10:37:03 --> Total execution time: 0.0982
DEBUG - 2014-08-15 10:37:03 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:03 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:03 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:03 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:03 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:03 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:03 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:37:03 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:37:05 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:05 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:05 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:05 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:05 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:05 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:05 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:37:05 --> Final output sent to browser
DEBUG - 2014-08-15 10:37:05 --> Total execution time: 0.0984
DEBUG - 2014-08-15 10:37:05 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:05 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:05 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:05 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:05 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:05 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:05 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:37:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:37:05 --> Final output sent to browser
DEBUG - 2014-08-15 10:37:05 --> Total execution time: 0.1441
DEBUG - 2014-08-15 10:37:22 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:22 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:22 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:22 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:22 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:22 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:22 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:37:22 --> Severity: Notice  --> Undefined offset: 3 F:\wamp\www\hostorks\application\models\superadmin_model.php 215
DEBUG - 2014-08-15 10:37:22 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:22 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:22 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:22 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:22 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:22 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:22 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:37:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:37:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:37:22 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:37:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:37:22 --> Final output sent to browser
DEBUG - 2014-08-15 10:37:22 --> Total execution time: 0.0935
DEBUG - 2014-08-15 10:37:22 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:22 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:22 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:22 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:22 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:22 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:22 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:37:22 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:37:25 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:25 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:25 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:25 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:25 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:25 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:25 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:37:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:37:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:37:25 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:37:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:37:25 --> Final output sent to browser
DEBUG - 2014-08-15 10:37:25 --> Total execution time: 0.0967
DEBUG - 2014-08-15 10:37:25 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:25 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:25 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:25 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:25 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:25 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:25 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:37:25 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:37:29 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:29 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:29 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:29 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:29 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:29 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:29 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:37:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:37:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:37:29 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:37:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:37:29 --> Final output sent to browser
DEBUG - 2014-08-15 10:37:29 --> Total execution time: 0.0960
DEBUG - 2014-08-15 10:37:29 --> Config Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:37:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:37:29 --> URI Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Router Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Output Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Security Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Input Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:37:29 --> Language Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Loader Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:37:29 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Session Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:37:29 --> Session routines successfully run
DEBUG - 2014-08-15 10:37:29 --> Upload Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:37:29 --> Controller Class Initialized
DEBUG - 2014-08-15 10:37:30 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:37:30 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:37:30 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:30 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:30 --> Model Class Initialized
DEBUG - 2014-08-15 10:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:37:30 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:48:41 --> Config Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:48:41 --> URI Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Router Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Output Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Security Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Input Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:48:41 --> Language Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Loader Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:48:41 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Session Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:48:41 --> Session routines successfully run
DEBUG - 2014-08-15 10:48:41 --> Upload Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Controller Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:48:41 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:48:41 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:48:41 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:48:41 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:48:41 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:48:41 --> Final output sent to browser
DEBUG - 2014-08-15 10:48:41 --> Total execution time: 0.0882
DEBUG - 2014-08-15 10:48:41 --> Config Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:48:41 --> URI Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Router Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Output Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Security Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Input Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:48:41 --> Language Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Loader Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:48:41 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Session Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:48:41 --> Session routines successfully run
DEBUG - 2014-08-15 10:48:41 --> Upload Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Controller Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:48:41 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:48:41 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:48:43 --> Config Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:48:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:48:43 --> URI Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Router Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Output Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Security Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Input Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:48:43 --> Language Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Loader Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:48:43 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Session Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:48:43 --> Session routines successfully run
DEBUG - 2014-08-15 10:48:43 --> Upload Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Controller Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:48:43 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:48:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:48:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:48:43 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:48:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:48:43 --> Final output sent to browser
DEBUG - 2014-08-15 10:48:43 --> Total execution time: 0.1082
DEBUG - 2014-08-15 10:48:43 --> Config Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:48:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:48:43 --> URI Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Router Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Output Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Security Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Input Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:48:43 --> Language Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Loader Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:48:43 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Session Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:48:43 --> Session routines successfully run
DEBUG - 2014-08-15 10:48:43 --> Upload Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Controller Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:48:43 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Model Class Initialized
DEBUG - 2014-08-15 10:48:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:48:43 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:50:53 --> Config Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:50:53 --> URI Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Router Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Output Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Security Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Input Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:50:53 --> Language Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Loader Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:50:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Session Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:50:53 --> Session routines successfully run
DEBUG - 2014-08-15 10:50:53 --> Upload Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Controller Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:50:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:50:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:50:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:50:53 --> File loaded: application/views/superadmin/home_plans.php
DEBUG - 2014-08-15 10:50:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:50:53 --> Final output sent to browser
DEBUG - 2014-08-15 10:50:53 --> Total execution time: 0.0982
DEBUG - 2014-08-15 10:50:53 --> Config Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:50:53 --> URI Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Router Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Output Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Security Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Input Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:50:53 --> Language Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Loader Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:50:53 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Session Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:50:53 --> Session routines successfully run
DEBUG - 2014-08-15 10:50:53 --> Upload Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Controller Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:50:53 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Model Class Initialized
DEBUG - 2014-08-15 10:50:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 10:50:53 --> 404 Page Not Found --> 
DEBUG - 2014-08-15 10:52:01 --> Config Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:52:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:52:01 --> URI Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Router Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Output Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Security Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Input Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:52:01 --> Language Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Loader Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:52:01 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:52:01 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Session Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:52:01 --> Session routines successfully run
DEBUG - 2014-08-15 10:52:01 --> Upload Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Controller Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:52:01 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:52:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:52:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:52:01 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-08-15 10:52:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:52:01 --> Final output sent to browser
DEBUG - 2014-08-15 10:52:01 --> Total execution time: 0.1390
DEBUG - 2014-08-15 10:52:12 --> Config Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:52:12 --> URI Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Router Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Output Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Security Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Input Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:52:12 --> Language Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Loader Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:52:12 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:52:12 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Session Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:52:12 --> Session routines successfully run
DEBUG - 2014-08-15 10:52:12 --> Upload Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Controller Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:52:12 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:52:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:52:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:52:13 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-08-15 10:52:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:52:13 --> Final output sent to browser
DEBUG - 2014-08-15 10:52:13 --> Total execution time: 0.1621
DEBUG - 2014-08-15 10:52:50 --> Config Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Hooks Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Utf8 Class Initialized
DEBUG - 2014-08-15 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 10:52:50 --> URI Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Router Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Output Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Security Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Input Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 10:52:50 --> Language Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Loader Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 10:52:50 --> Helper loaded: file_helper
DEBUG - 2014-08-15 10:52:50 --> Database Driver Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Session Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 10:52:50 --> Session routines successfully run
DEBUG - 2014-08-15 10:52:50 --> Upload Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Pagination Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Controller Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 10:52:50 --> Form Validation Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Model Class Initialized
DEBUG - 2014-08-15 10:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 10:52:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 10:52:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 10:52:50 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-08-15 10:52:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 10:52:50 --> Final output sent to browser
DEBUG - 2014-08-15 10:52:50 --> Total execution time: 0.0944
DEBUG - 2014-08-15 11:29:47 --> Config Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Hooks Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Utf8 Class Initialized
DEBUG - 2014-08-15 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 11:29:47 --> URI Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Router Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Output Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Security Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Input Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 11:29:47 --> Language Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Loader Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Helper loaded: url_helper
DEBUG - 2014-08-15 11:29:47 --> Helper loaded: file_helper
DEBUG - 2014-08-15 11:29:47 --> Database Driver Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Session Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Helper loaded: string_helper
DEBUG - 2014-08-15 11:29:47 --> Session routines successfully run
DEBUG - 2014-08-15 11:29:47 --> Upload Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Pagination Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Controller Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Helper loaded: form_helper
DEBUG - 2014-08-15 11:29:47 --> Form Validation Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Model Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Model Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Model Class Initialized
DEBUG - 2014-08-15 11:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-15 11:29:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-08-15 11:29:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-08-15 11:29:47 --> File loaded: application/views/superadmin/home_custom_order.php
DEBUG - 2014-08-15 11:29:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-08-15 11:29:47 --> Final output sent to browser
DEBUG - 2014-08-15 11:29:47 --> Total execution time: 0.0916
DEBUG - 2014-08-15 11:29:48 --> Config Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Hooks Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Utf8 Class Initialized
DEBUG - 2014-08-15 11:29:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 11:29:48 --> URI Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Router Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Output Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Security Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Input Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 11:29:48 --> Language Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Loader Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Helper loaded: url_helper
DEBUG - 2014-08-15 11:29:48 --> Helper loaded: file_helper
DEBUG - 2014-08-15 11:29:48 --> Database Driver Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Session Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Helper loaded: string_helper
DEBUG - 2014-08-15 11:29:48 --> Session routines successfully run
DEBUG - 2014-08-15 11:29:48 --> Upload Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Pagination Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Controller Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Helper loaded: form_helper
DEBUG - 2014-08-15 11:29:48 --> Form Validation Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Model Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Model Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Model Class Initialized
DEBUG - 2014-08-15 11:29:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-08-15 11:29:48 --> 404 Page Not Found --> 

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-26 05:02:38 --> Config Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Hooks Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Utf8 Class Initialized
DEBUG - 2014-07-26 05:02:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 05:02:38 --> URI Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Router Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Output Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Security Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Input Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 05:02:38 --> Language Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Loader Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Helper loaded: url_helper
DEBUG - 2014-07-26 05:02:38 --> Helper loaded: file_helper
DEBUG - 2014-07-26 05:02:38 --> Database Driver Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Session Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Helper loaded: string_helper
DEBUG - 2014-07-26 05:02:38 --> A session cookie was not found.
DEBUG - 2014-07-26 05:02:38 --> Session routines successfully run
DEBUG - 2014-07-26 05:02:38 --> Upload Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Pagination Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Controller Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Helper loaded: form_helper
DEBUG - 2014-07-26 05:02:38 --> Form Validation Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Model Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Model Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Model Class Initialized
DEBUG - 2014-07-26 05:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 05:02:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 05:02:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 05:02:39 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-26 05:02:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 05:02:39 --> Final output sent to browser
DEBUG - 2014-07-26 05:02:39 --> Total execution time: 0.9413
DEBUG - 2014-07-26 05:02:43 --> Config Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Hooks Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Utf8 Class Initialized
DEBUG - 2014-07-26 05:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 05:02:43 --> URI Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Router Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Output Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Security Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Input Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 05:02:43 --> Language Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Loader Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Helper loaded: url_helper
DEBUG - 2014-07-26 05:02:43 --> Helper loaded: file_helper
DEBUG - 2014-07-26 05:02:43 --> Database Driver Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Session Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Helper loaded: string_helper
DEBUG - 2014-07-26 05:02:43 --> Session routines successfully run
DEBUG - 2014-07-26 05:02:43 --> Upload Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Pagination Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Controller Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Helper loaded: form_helper
DEBUG - 2014-07-26 05:02:43 --> Form Validation Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Model Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Model Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Model Class Initialized
DEBUG - 2014-07-26 05:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 05:02:43 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 05:02:43 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 05:02:43 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 05:02:43 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 05:02:43 --> Final output sent to browser
DEBUG - 2014-07-26 05:02:43 --> Total execution time: 0.2035
DEBUG - 2014-07-26 06:07:05 --> Config Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:07:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:07:05 --> URI Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Router Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Output Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Security Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Input Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:07:05 --> Language Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Loader Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:07:05 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:07:05 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Session Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:07:05 --> Session routines successfully run
DEBUG - 2014-07-26 06:07:05 --> Upload Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Controller Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:07:05 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Model Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Model Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Model Class Initialized
DEBUG - 2014-07-26 06:07:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:07:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:07:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:07:05 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:07:05 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:07:05 --> Final output sent to browser
DEBUG - 2014-07-26 06:07:05 --> Total execution time: 0.5590
DEBUG - 2014-07-26 06:08:33 --> Config Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:08:33 --> URI Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Router Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Output Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Security Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Input Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:08:33 --> Language Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Loader Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:08:33 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Session Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:08:33 --> Session routines successfully run
DEBUG - 2014-07-26 06:08:33 --> Upload Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Controller Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:08:33 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:08:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:08:33 --> Config Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:08:33 --> URI Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Router Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Output Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Security Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Input Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:08:33 --> Language Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Loader Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:08:33 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Session Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:08:33 --> Session routines successfully run
DEBUG - 2014-07-26 06:08:33 --> Upload Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Controller Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:08:33 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:08:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:08:33 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:08:33 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:08:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:08:33 --> Final output sent to browser
DEBUG - 2014-07-26 06:08:33 --> Total execution time: 0.2062
DEBUG - 2014-07-26 06:11:37 --> Config Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:11:37 --> URI Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Router Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Output Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Security Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Input Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:11:37 --> Language Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Loader Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:11:37 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Session Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:11:37 --> Session routines successfully run
DEBUG - 2014-07-26 06:11:37 --> Upload Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Controller Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:11:37 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:11:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:11:37 --> Config Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:11:37 --> URI Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Router Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Output Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Security Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Input Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:11:37 --> Language Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Loader Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:11:37 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Session Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:11:37 --> Session routines successfully run
DEBUG - 2014-07-26 06:11:37 --> Upload Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Controller Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:11:37 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:11:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:11:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:11:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:11:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:11:37 --> Final output sent to browser
DEBUG - 2014-07-26 06:11:37 --> Total execution time: 0.1647
DEBUG - 2014-07-26 06:19:07 --> Config Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:19:07 --> URI Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Router Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Output Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Security Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Input Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:19:07 --> Language Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Loader Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:19:07 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:19:07 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Session Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:19:07 --> Session routines successfully run
DEBUG - 2014-07-26 06:19:07 --> Upload Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Controller Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:19:07 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:19:07 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:19:14 --> Config Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:19:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:19:14 --> URI Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Router Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Output Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Security Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Input Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:19:14 --> Language Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Loader Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:19:14 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:19:14 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Session Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:19:14 --> Session routines successfully run
DEBUG - 2014-07-26 06:19:14 --> Upload Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Controller Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:19:14 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:19:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:19:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:19:14 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:19:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:19:14 --> Final output sent to browser
DEBUG - 2014-07-26 06:19:14 --> Total execution time: 0.1693
DEBUG - 2014-07-26 06:19:14 --> Config Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:19:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:19:14 --> URI Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Router Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Output Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Security Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Input Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:19:14 --> Language Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Loader Class Initialized
DEBUG - 2014-07-26 06:19:14 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:19:14 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:19:15 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Session Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:19:15 --> Session routines successfully run
DEBUG - 2014-07-26 06:19:15 --> Upload Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Controller Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:19:15 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:19:15 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:19:15 --> Config Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:19:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:19:15 --> URI Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Config Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Router Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Output Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Security Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Input Class Initialized
DEBUG - 2014-07-26 06:19:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:19:15 --> URI Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Router Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:19:15 --> Language Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Output Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Security Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Loader Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Input Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:19:15 --> Language Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:19:15 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Session Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:19:15 --> Session routines successfully run
DEBUG - 2014-07-26 06:19:15 --> Upload Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Controller Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:19:15 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:19:15 --> Loader Class Initialized
ERROR - 2014-07-26 06:19:15 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:19:15 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Session Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:19:15 --> Session routines successfully run
DEBUG - 2014-07-26 06:19:15 --> Upload Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Controller Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:19:15 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Model Class Initialized
DEBUG - 2014-07-26 06:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:19:15 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:28:36 --> Config Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:28:36 --> URI Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Router Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Output Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Security Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Input Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:28:36 --> Language Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Loader Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:28:36 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:28:36 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Session Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:28:36 --> Session routines successfully run
DEBUG - 2014-07-26 06:28:36 --> Upload Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Controller Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:28:36 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:28:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:28:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:28:36 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:28:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:28:36 --> Final output sent to browser
DEBUG - 2014-07-26 06:28:36 --> Total execution time: 0.1551
DEBUG - 2014-07-26 06:28:37 --> Config Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:28:37 --> URI Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Router Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Output Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Security Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Input Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:28:37 --> Language Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Loader Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:28:37 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:28:37 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Session Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:28:37 --> Session routines successfully run
DEBUG - 2014-07-26 06:28:37 --> Upload Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Controller Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:28:37 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:28:37 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:28:37 --> Config Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:28:37 --> URI Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Router Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Output Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Security Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Input Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:28:37 --> Language Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Loader Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:28:37 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:28:37 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:28:37 --> Session Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:28:38 --> Session routines successfully run
DEBUG - 2014-07-26 06:28:38 --> Upload Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Controller Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:28:38 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Model Class Initialized
DEBUG - 2014-07-26 06:28:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:28:38 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:31:45 --> Config Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:31:45 --> URI Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Router Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Output Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Security Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Input Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:31:45 --> Language Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Loader Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:31:45 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:31:45 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Session Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:31:45 --> Session routines successfully run
DEBUG - 2014-07-26 06:31:45 --> Upload Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Controller Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:31:45 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:31:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:31:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:31:45 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:31:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:31:45 --> Final output sent to browser
DEBUG - 2014-07-26 06:31:45 --> Total execution time: 0.1732
DEBUG - 2014-07-26 06:31:46 --> Config Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:31:46 --> URI Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Router Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Output Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Security Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Input Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:31:46 --> Language Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Loader Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:31:46 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:31:46 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Session Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:31:46 --> Session routines successfully run
DEBUG - 2014-07-26 06:31:46 --> Upload Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Controller Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:31:46 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:31:46 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:31:47 --> Config Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:31:47 --> URI Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Router Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Output Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Security Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Input Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:31:47 --> Language Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Loader Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:31:47 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Session Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:31:47 --> Session routines successfully run
DEBUG - 2014-07-26 06:31:47 --> Upload Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Controller Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:31:47 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:31:47 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:31:47 --> Config Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:31:47 --> URI Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Router Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Output Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Security Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Input Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:31:47 --> Language Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Loader Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:31:47 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Session Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:31:47 --> Session routines successfully run
DEBUG - 2014-07-26 06:31:47 --> Upload Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Controller Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:31:47 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:31:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:31:47 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:44:33 --> Config Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:44:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:44:33 --> URI Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Router Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Output Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Security Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Input Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:44:33 --> Language Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Loader Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:44:33 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:44:33 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Session Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:44:33 --> Session routines successfully run
DEBUG - 2014-07-26 06:44:33 --> Upload Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Controller Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:44:33 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Model Class Initialized
DEBUG - 2014-07-26 06:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:44:33 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:44:33 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-26 06:44:33 --> Severity: Warning  --> explode() expects parameter 2 to be string, object given C:\wamp\www\hostorks\application\views\superadmin\home_slider.php 119
ERROR - 2014-07-26 06:44:33 --> Severity: Warning  --> explode() expects parameter 2 to be string, object given C:\wamp\www\hostorks\application\views\superadmin\home_slider.php 119
DEBUG - 2014-07-26 06:44:33 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:44:33 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:44:33 --> Final output sent to browser
DEBUG - 2014-07-26 06:44:33 --> Total execution time: 0.1684
DEBUG - 2014-07-26 06:44:34 --> Config Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:44:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:44:34 --> URI Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Router Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Output Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Security Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Input Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:44:34 --> Language Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Loader Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:44:34 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:44:34 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Session Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:44:34 --> Session routines successfully run
DEBUG - 2014-07-26 06:44:34 --> Upload Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Controller Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:44:34 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Model Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Model Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Model Class Initialized
DEBUG - 2014-07-26 06:44:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:44:34 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:48:03 --> Config Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:48:03 --> URI Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Router Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Output Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Security Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Input Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:48:03 --> Language Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Loader Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:48:03 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:48:03 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Session Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:48:03 --> Session routines successfully run
DEBUG - 2014-07-26 06:48:03 --> Upload Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Controller Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:48:03 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:48:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:48:03 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-26 06:48:03 --> Severity: Warning  --> explode() expects parameter 2 to be string, object given C:\wamp\www\hostorks\application\views\superadmin\home_slider.php 119
DEBUG - 2014-07-26 06:48:03 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:48:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:48:03 --> Final output sent to browser
DEBUG - 2014-07-26 06:48:03 --> Total execution time: 0.1704
DEBUG - 2014-07-26 06:48:04 --> Config Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:48:04 --> URI Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Router Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Output Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Security Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Input Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:48:04 --> Language Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Loader Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:48:04 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:48:04 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Session Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:48:04 --> Session routines successfully run
DEBUG - 2014-07-26 06:48:04 --> Upload Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Controller Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:48:04 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:48:04 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:48:31 --> Config Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:48:31 --> URI Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Router Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Output Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Security Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Input Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:48:31 --> Language Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Loader Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Session Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:48:31 --> Session routines successfully run
DEBUG - 2014-07-26 06:48:31 --> Upload Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Controller Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:48:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:48:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:48:31 --> Config Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:48:31 --> URI Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Router Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Output Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Security Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Input Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:48:31 --> Language Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Loader Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:48:31 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Session Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:48:31 --> Session routines successfully run
DEBUG - 2014-07-26 06:48:31 --> Upload Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Controller Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:48:31 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:48:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:48:31 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:49:12 --> Config Class Initialized
DEBUG - 2014-07-26 06:49:12 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:49:12 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:49:12 --> URI Class Initialized
DEBUG - 2014-07-26 06:49:12 --> Router Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Output Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Security Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Input Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:49:13 --> Language Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Loader Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:49:13 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Session Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:49:13 --> Session routines successfully run
DEBUG - 2014-07-26 06:49:13 --> Upload Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Controller Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:49:13 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:49:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:49:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:49:13 --> Config Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:49:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:49:13 --> URI Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Router Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Output Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Security Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Input Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:49:13 --> Language Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Loader Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:49:13 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Session Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:49:13 --> Session routines successfully run
DEBUG - 2014-07-26 06:49:13 --> Upload Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Controller Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:49:13 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:49:13 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:49:39 --> Config Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:49:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:49:39 --> URI Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Router Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Output Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Security Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Input Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:49:39 --> Language Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Loader Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:49:39 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:49:39 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Session Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:49:39 --> Session routines successfully run
DEBUG - 2014-07-26 06:49:39 --> Upload Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Controller Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:49:39 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:49:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:49:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:49:40 --> Config Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:49:40 --> URI Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Router Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Output Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Security Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Input Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:49:40 --> Language Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Loader Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:49:40 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:49:40 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Session Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:49:40 --> Session routines successfully run
DEBUG - 2014-07-26 06:49:40 --> Upload Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Controller Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:49:40 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Model Class Initialized
DEBUG - 2014-07-26 06:49:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:49:40 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:50:06 --> Config Class Initialized
DEBUG - 2014-07-26 06:50:06 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:50:06 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:50:06 --> URI Class Initialized
DEBUG - 2014-07-26 06:50:06 --> Router Class Initialized
DEBUG - 2014-07-26 06:50:06 --> Output Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Security Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Input Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:50:07 --> Language Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Loader Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:50:07 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:50:07 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Session Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:50:07 --> Session routines successfully run
DEBUG - 2014-07-26 06:50:07 --> Upload Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Controller Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:50:07 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Model Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Model Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Model Class Initialized
DEBUG - 2014-07-26 06:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:50:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:50:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:50:07 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:50:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:50:07 --> Final output sent to browser
DEBUG - 2014-07-26 06:50:07 --> Total execution time: 0.1809
DEBUG - 2014-07-26 06:50:08 --> Config Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:50:08 --> URI Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Router Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Output Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Security Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Input Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:50:08 --> Language Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Loader Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:50:08 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:50:08 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Session Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:50:08 --> Session routines successfully run
DEBUG - 2014-07-26 06:50:08 --> Upload Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Controller Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:50:08 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Model Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Model Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Model Class Initialized
DEBUG - 2014-07-26 06:50:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:50:08 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:51:02 --> Config Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:51:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:51:02 --> URI Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Router Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Output Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Security Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Input Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:51:02 --> Language Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Loader Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:51:02 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:51:02 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Session Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:51:02 --> Session routines successfully run
DEBUG - 2014-07-26 06:51:02 --> Upload Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Controller Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:51:02 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:51:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:51:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:51:02 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:51:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:51:02 --> Final output sent to browser
DEBUG - 2014-07-26 06:51:02 --> Total execution time: 0.1947
DEBUG - 2014-07-26 06:51:03 --> Config Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:51:03 --> URI Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Router Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Output Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Security Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Input Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:51:03 --> Language Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Loader Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:51:03 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:51:03 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Session Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:51:03 --> Session routines successfully run
DEBUG - 2014-07-26 06:51:03 --> Upload Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Controller Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:51:03 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:51:03 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:51:42 --> Config Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:51:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:51:42 --> URI Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Router Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Output Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Security Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Input Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:51:42 --> Language Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Loader Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:51:42 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:51:42 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Session Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:51:42 --> Session routines successfully run
DEBUG - 2014-07-26 06:51:42 --> Upload Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Controller Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:51:42 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:51:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:51:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:51:42 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:51:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:51:42 --> Final output sent to browser
DEBUG - 2014-07-26 06:51:42 --> Total execution time: 0.1694
DEBUG - 2014-07-26 06:51:43 --> Config Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:51:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:51:43 --> URI Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Router Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Output Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Security Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Input Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:51:43 --> Language Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Loader Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:51:43 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:51:43 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Session Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:51:43 --> Session routines successfully run
DEBUG - 2014-07-26 06:51:43 --> Upload Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Controller Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:51:43 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Model Class Initialized
DEBUG - 2014-07-26 06:51:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:51:43 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:52:09 --> Config Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:52:09 --> URI Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Router Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Output Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Security Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Input Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:52:09 --> Language Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Loader Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:52:09 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:52:09 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Session Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:52:09 --> Session routines successfully run
DEBUG - 2014-07-26 06:52:09 --> Upload Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Controller Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:52:09 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:52:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:52:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:52:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:52:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:52:09 --> Final output sent to browser
DEBUG - 2014-07-26 06:52:09 --> Total execution time: 0.2099
DEBUG - 2014-07-26 06:52:10 --> Config Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:52:10 --> URI Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Router Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Output Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Security Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Input Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:52:10 --> Language Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Loader Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:52:10 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:52:10 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Session Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:52:10 --> Session routines successfully run
DEBUG - 2014-07-26 06:52:10 --> Upload Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Controller Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:52:10 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:52:10 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:52:30 --> Config Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:52:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:52:30 --> URI Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Router Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Output Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Security Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Input Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:52:30 --> Language Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Loader Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:52:30 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:52:30 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Session Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:52:30 --> Session routines successfully run
DEBUG - 2014-07-26 06:52:30 --> Upload Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Controller Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:52:30 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:52:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:52:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:52:30 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:52:30 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:52:30 --> Final output sent to browser
DEBUG - 2014-07-26 06:52:30 --> Total execution time: 0.1825
DEBUG - 2014-07-26 06:52:31 --> Config Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:52:31 --> URI Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Router Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Output Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Security Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Input Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:52:31 --> Language Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Loader Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:52:31 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:52:31 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Session Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:52:31 --> Session routines successfully run
DEBUG - 2014-07-26 06:52:31 --> Upload Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Controller Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:52:31 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Model Class Initialized
DEBUG - 2014-07-26 06:52:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:52:31 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:52:59 --> Config Class Initialized
DEBUG - 2014-07-26 06:52:59 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:52:59 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:52:59 --> URI Class Initialized
DEBUG - 2014-07-26 06:52:59 --> Router Class Initialized
DEBUG - 2014-07-26 06:52:59 --> Output Class Initialized
DEBUG - 2014-07-26 06:52:59 --> Security Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Input Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:53:00 --> Language Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Loader Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:53:00 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:53:00 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Session Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:53:00 --> Session routines successfully run
DEBUG - 2014-07-26 06:53:00 --> Upload Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Controller Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:53:00 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Model Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Model Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Model Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:53:00 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:53:00 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:53:00 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:53:00 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:53:00 --> Final output sent to browser
DEBUG - 2014-07-26 06:53:00 --> Total execution time: 0.1659
DEBUG - 2014-07-26 06:53:00 --> Config Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:53:00 --> URI Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Router Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Output Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Security Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Input Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:53:00 --> Language Class Initialized
DEBUG - 2014-07-26 06:53:00 --> Loader Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:53:01 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:53:01 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Session Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:53:01 --> Session routines successfully run
DEBUG - 2014-07-26 06:53:01 --> Upload Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Controller Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:53:01 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Model Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Model Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Model Class Initialized
DEBUG - 2014-07-26 06:53:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:53:01 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:58:26 --> Config Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:58:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:58:26 --> URI Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Router Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Output Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Security Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Input Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:58:26 --> Language Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Loader Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:58:26 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:58:26 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Session Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:58:26 --> Session routines successfully run
DEBUG - 2014-07-26 06:58:26 --> Upload Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Controller Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:58:26 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:58:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:58:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:58:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:58:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:58:26 --> Final output sent to browser
DEBUG - 2014-07-26 06:58:26 --> Total execution time: 0.1762
DEBUG - 2014-07-26 06:58:28 --> Config Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:58:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:58:28 --> URI Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Router Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Output Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Security Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Input Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:58:28 --> Language Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Loader Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:58:28 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:58:28 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Session Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:58:28 --> Session routines successfully run
DEBUG - 2014-07-26 06:58:28 --> Upload Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Controller Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:58:28 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:58:28 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:58:52 --> Config Class Initialized
DEBUG - 2014-07-26 06:58:52 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:58:52 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:58:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:58:52 --> URI Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Router Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Output Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Security Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Input Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:58:53 --> Language Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Loader Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:58:53 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:58:53 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Session Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:58:53 --> Session routines successfully run
DEBUG - 2014-07-26 06:58:53 --> Upload Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Controller Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:58:53 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:58:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:58:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:58:53 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:58:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:58:53 --> Final output sent to browser
DEBUG - 2014-07-26 06:58:53 --> Total execution time: 0.1785
DEBUG - 2014-07-26 06:58:54 --> Config Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:58:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:58:54 --> URI Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Router Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Output Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Security Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Input Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:58:54 --> Language Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Loader Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:58:54 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:58:54 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Session Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:58:54 --> Session routines successfully run
DEBUG - 2014-07-26 06:58:54 --> Upload Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Controller Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:58:54 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Model Class Initialized
DEBUG - 2014-07-26 06:58:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:58:54 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:59:18 --> Config Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:59:18 --> URI Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Router Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Output Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Security Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Input Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:59:18 --> Language Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Loader Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:59:18 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:59:18 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Session Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:59:18 --> Session routines successfully run
DEBUG - 2014-07-26 06:59:18 --> Upload Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Controller Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:59:18 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:59:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:59:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:59:18 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:59:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:59:18 --> Final output sent to browser
DEBUG - 2014-07-26 06:59:18 --> Total execution time: 0.1822
DEBUG - 2014-07-26 06:59:20 --> Config Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:59:20 --> URI Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Router Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Output Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Security Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Input Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:59:20 --> Language Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Loader Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:59:20 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:59:20 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Session Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:59:20 --> Session routines successfully run
DEBUG - 2014-07-26 06:59:20 --> Upload Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Controller Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:59:20 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:59:20 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 06:59:46 --> Config Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:59:46 --> URI Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Router Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Output Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Security Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Input Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:59:46 --> Language Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Loader Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:59:46 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:59:46 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Session Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:59:46 --> Session routines successfully run
DEBUG - 2014-07-26 06:59:46 --> Upload Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Controller Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:59:46 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 06:59:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 06:59:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 06:59:46 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 06:59:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 06:59:46 --> Final output sent to browser
DEBUG - 2014-07-26 06:59:46 --> Total execution time: 0.1713
DEBUG - 2014-07-26 06:59:47 --> Config Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Hooks Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Utf8 Class Initialized
DEBUG - 2014-07-26 06:59:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 06:59:47 --> URI Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Router Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Output Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Security Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Input Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 06:59:47 --> Language Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Loader Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Helper loaded: url_helper
DEBUG - 2014-07-26 06:59:47 --> Helper loaded: file_helper
DEBUG - 2014-07-26 06:59:47 --> Database Driver Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Session Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Helper loaded: string_helper
DEBUG - 2014-07-26 06:59:47 --> Session routines successfully run
DEBUG - 2014-07-26 06:59:47 --> Upload Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Pagination Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Controller Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Helper loaded: form_helper
DEBUG - 2014-07-26 06:59:47 --> Form Validation Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Model Class Initialized
DEBUG - 2014-07-26 06:59:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 06:59:47 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 07:16:22 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:22 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:22 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:22 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:22 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:22 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:22 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:22 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:22 --> Total execution time: 0.1907
DEBUG - 2014-07-26 07:16:22 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:22 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:22 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:22 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:22 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:22 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:22 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:22 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:22 --> Total execution time: 0.1734
DEBUG - 2014-07-26 07:16:23 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:23 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:23 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:23 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:23 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:23 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:23 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:23 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:23 --> Total execution time: 0.1543
DEBUG - 2014-07-26 07:16:23 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:23 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:23 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:23 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:23 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:23 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:23 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:23 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:23 --> Total execution time: 0.2375
DEBUG - 2014-07-26 07:16:23 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:23 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:23 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:23 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:23 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:23 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:23 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:23 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:23 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:23 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:23 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:23 --> Total execution time: 0.2474
DEBUG - 2014-07-26 07:16:23 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:23 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:23 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:23 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:23 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:23 --> Total execution time: 0.1806
DEBUG - 2014-07-26 07:16:24 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:24 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:24 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:24 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:24 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:24 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:24 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:24 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:24 --> Total execution time: 0.1459
DEBUG - 2014-07-26 07:16:24 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:24 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:24 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:24 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:24 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:24 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:24 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:24 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:24 --> Total execution time: 0.1466
DEBUG - 2014-07-26 07:16:24 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:24 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:24 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:24 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:24 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:24 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:24 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:24 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:24 --> Total execution time: 0.1564
DEBUG - 2014-07-26 07:16:24 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:24 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:24 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:24 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:24 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:24 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:24 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:24 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:24 --> Total execution time: 0.2061
DEBUG - 2014-07-26 07:16:25 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:25 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:25 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:25 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:25 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:25 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:25 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:25 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:25 --> Total execution time: 0.1913
DEBUG - 2014-07-26 07:16:25 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:25 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:25 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:25 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:25 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:25 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:25 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:25 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:25 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:25 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:25 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:25 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:25 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:25 --> Total execution time: 0.3258
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:25 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:25 --> Total execution time: 0.1763
DEBUG - 2014-07-26 07:16:25 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:25 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:25 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:25 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:25 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:25 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:25 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:16:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:16:25 --> Final output sent to browser
DEBUG - 2014-07-26 07:16:25 --> Total execution time: 0.1734
DEBUG - 2014-07-26 07:16:27 --> Config Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:16:27 --> URI Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Router Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Output Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Security Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Input Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:16:27 --> Language Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Loader Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:16:27 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:16:27 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Session Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:16:27 --> Session routines successfully run
DEBUG - 2014-07-26 07:16:27 --> Upload Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Controller Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:16:27 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Model Class Initialized
DEBUG - 2014-07-26 07:16:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 07:16:27 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 07:28:26 --> Config Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:28:26 --> URI Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Router Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Output Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Security Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Input Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:28:26 --> Language Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Loader Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:28:26 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:28:26 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Session Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:28:26 --> Session routines successfully run
DEBUG - 2014-07-26 07:28:26 --> Upload Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Controller Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:28:26 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Model Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Model Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Model Class Initialized
DEBUG - 2014-07-26 07:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:28:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:28:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:28:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:28:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:28:26 --> Final output sent to browser
DEBUG - 2014-07-26 07:28:26 --> Total execution time: 0.1910
DEBUG - 2014-07-26 07:28:28 --> Config Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:28:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:28:28 --> URI Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Router Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Output Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Security Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Input Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:28:28 --> Language Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Loader Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:28:28 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:28:28 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Session Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:28:28 --> Session routines successfully run
DEBUG - 2014-07-26 07:28:28 --> Upload Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Controller Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:28:28 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Model Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Model Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Model Class Initialized
DEBUG - 2014-07-26 07:28:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 07:28:28 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 07:32:25 --> Config Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:32:25 --> URI Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Router Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Output Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Security Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Input Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:32:25 --> Language Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Loader Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:32:25 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:32:25 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Session Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:32:25 --> Session routines successfully run
DEBUG - 2014-07-26 07:32:25 --> Upload Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Controller Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:32:25 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:32:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:32:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:32:25 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:32:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:32:25 --> Final output sent to browser
DEBUG - 2014-07-26 07:32:25 --> Total execution time: 0.1946
DEBUG - 2014-07-26 07:32:26 --> Config Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:32:26 --> URI Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Router Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Output Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Security Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Input Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:32:26 --> Language Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Loader Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:32:26 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:32:26 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Session Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:32:26 --> Session routines successfully run
DEBUG - 2014-07-26 07:32:26 --> Upload Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Controller Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:32:26 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 07:32:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 07:32:29 --> Config Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:32:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:32:29 --> URI Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Router Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Output Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Security Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Input Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:32:29 --> Language Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Loader Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:32:29 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:32:29 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Session Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:32:29 --> Session routines successfully run
DEBUG - 2014-07-26 07:32:29 --> Upload Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Controller Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:32:29 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:32:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:32:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:32:29 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:32:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:32:29 --> Final output sent to browser
DEBUG - 2014-07-26 07:32:29 --> Total execution time: 0.1603
DEBUG - 2014-07-26 07:32:31 --> Config Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:32:31 --> URI Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Router Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Output Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Security Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Input Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:32:31 --> Language Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Loader Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:32:31 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:32:31 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Session Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:32:31 --> Session routines successfully run
DEBUG - 2014-07-26 07:32:31 --> Upload Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Controller Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:32:31 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Model Class Initialized
DEBUG - 2014-07-26 07:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:32:31 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:32:31 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:32:31 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:32:31 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:32:31 --> Final output sent to browser
DEBUG - 2014-07-26 07:32:31 --> Total execution time: 0.1859
DEBUG - 2014-07-26 07:58:30 --> Config Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:58:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:58:30 --> URI Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Router Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Output Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Security Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Input Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:58:30 --> Language Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Loader Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:58:30 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:58:30 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Session Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:58:30 --> Session routines successfully run
DEBUG - 2014-07-26 07:58:30 --> Upload Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Controller Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:58:30 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Model Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Model Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Model Class Initialized
DEBUG - 2014-07-26 07:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:58:30 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:58:30 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:58:59 --> Config Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:58:59 --> URI Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Router Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Output Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Security Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Input Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:58:59 --> Language Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Loader Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:58:59 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:58:59 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Session Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:58:59 --> Session routines successfully run
DEBUG - 2014-07-26 07:58:59 --> Upload Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Controller Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:58:59 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-26 07:58:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:58:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:58:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:58:59 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:58:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:58:59 --> Final output sent to browser
DEBUG - 2014-07-26 07:58:59 --> Total execution time: 0.1807
DEBUG - 2014-07-26 07:59:00 --> Config Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:59:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:59:00 --> URI Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Router Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Output Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Security Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Input Class Initialized
DEBUG - 2014-07-26 07:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:59:00 --> Language Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Loader Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:59:01 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:59:01 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Session Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:59:01 --> Session routines successfully run
DEBUG - 2014-07-26 07:59:01 --> Upload Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Controller Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:59:01 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-26 07:59:01 --> 404 Page Not Found --> 
DEBUG - 2014-07-26 07:59:05 --> Config Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:59:05 --> URI Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Router Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Output Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Security Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Input Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:59:05 --> Language Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Loader Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:59:05 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:59:05 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Session Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:59:05 --> Session routines successfully run
DEBUG - 2014-07-26 07:59:05 --> Upload Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Controller Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:59:05 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:59:05 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:59:05 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:59:28 --> Config Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:59:28 --> URI Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Router Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Output Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Security Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Input Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:59:28 --> Language Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Loader Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:59:28 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:59:28 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Session Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:59:28 --> Session routines successfully run
DEBUG - 2014-07-26 07:59:28 --> Upload Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Controller Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:59:28 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:59:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:59:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:59:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:59:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:59:28 --> Final output sent to browser
DEBUG - 2014-07-26 07:59:28 --> Total execution time: 0.1676
DEBUG - 2014-07-26 07:59:29 --> Config Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Hooks Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Utf8 Class Initialized
DEBUG - 2014-07-26 07:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 07:59:29 --> URI Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Router Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Output Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Security Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Input Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 07:59:29 --> Language Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Loader Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Helper loaded: url_helper
DEBUG - 2014-07-26 07:59:29 --> Helper loaded: file_helper
DEBUG - 2014-07-26 07:59:29 --> Database Driver Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Session Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Helper loaded: string_helper
DEBUG - 2014-07-26 07:59:29 --> Session routines successfully run
DEBUG - 2014-07-26 07:59:29 --> Upload Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Pagination Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Controller Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Helper loaded: form_helper
DEBUG - 2014-07-26 07:59:29 --> Form Validation Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Model Class Initialized
DEBUG - 2014-07-26 07:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 07:59:29 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 07:59:29 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 07:59:29 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 07:59:29 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 07:59:29 --> Final output sent to browser
DEBUG - 2014-07-26 07:59:29 --> Total execution time: 0.2181
DEBUG - 2014-07-26 08:01:57 --> Config Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Hooks Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Utf8 Class Initialized
DEBUG - 2014-07-26 08:01:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 08:01:57 --> URI Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Router Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Output Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Security Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Input Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 08:01:57 --> Language Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Loader Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Helper loaded: url_helper
DEBUG - 2014-07-26 08:01:57 --> Helper loaded: file_helper
DEBUG - 2014-07-26 08:01:57 --> Database Driver Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Session Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Helper loaded: string_helper
DEBUG - 2014-07-26 08:01:57 --> Session routines successfully run
DEBUG - 2014-07-26 08:01:57 --> Upload Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Pagination Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Controller Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Helper loaded: form_helper
DEBUG - 2014-07-26 08:01:57 --> Form Validation Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Model Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Model Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Model Class Initialized
DEBUG - 2014-07-26 08:01:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 08:01:57 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 08:01:57 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 08:01:57 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 08:01:57 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 08:01:57 --> Final output sent to browser
DEBUG - 2014-07-26 08:01:57 --> Total execution time: 0.1842
DEBUG - 2014-07-26 08:01:59 --> Config Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Hooks Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Utf8 Class Initialized
DEBUG - 2014-07-26 08:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 08:01:59 --> URI Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Router Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Output Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Security Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Input Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 08:01:59 --> Language Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Loader Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Helper loaded: url_helper
DEBUG - 2014-07-26 08:01:59 --> Helper loaded: file_helper
DEBUG - 2014-07-26 08:01:59 --> Database Driver Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Session Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Helper loaded: string_helper
DEBUG - 2014-07-26 08:01:59 --> Session routines successfully run
DEBUG - 2014-07-26 08:01:59 --> Upload Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Pagination Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Controller Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Helper loaded: form_helper
DEBUG - 2014-07-26 08:01:59 --> Form Validation Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Model Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Model Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Model Class Initialized
DEBUG - 2014-07-26 08:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 08:01:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 08:01:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 08:01:59 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 08:01:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 08:01:59 --> Final output sent to browser
DEBUG - 2014-07-26 08:01:59 --> Total execution time: 0.2084
DEBUG - 2014-07-26 08:02:07 --> Config Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Hooks Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Utf8 Class Initialized
DEBUG - 2014-07-26 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 08:02:07 --> URI Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Router Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Output Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Security Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Input Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 08:02:07 --> Language Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Loader Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Helper loaded: url_helper
DEBUG - 2014-07-26 08:02:07 --> Helper loaded: file_helper
DEBUG - 2014-07-26 08:02:07 --> Database Driver Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Session Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Helper loaded: string_helper
DEBUG - 2014-07-26 08:02:07 --> Session routines successfully run
DEBUG - 2014-07-26 08:02:07 --> Upload Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Pagination Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Controller Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Helper loaded: form_helper
DEBUG - 2014-07-26 08:02:07 --> Form Validation Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Model Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Model Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Model Class Initialized
DEBUG - 2014-07-26 08:02:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 08:02:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 08:02:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 08:02:07 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 08:02:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 08:02:07 --> Final output sent to browser
DEBUG - 2014-07-26 08:02:07 --> Total execution time: 0.1709
DEBUG - 2014-07-26 08:02:08 --> Config Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Hooks Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Utf8 Class Initialized
DEBUG - 2014-07-26 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 08:02:08 --> URI Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Router Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Output Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Security Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Input Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 08:02:08 --> Language Class Initialized
DEBUG - 2014-07-26 08:02:08 --> Loader Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Helper loaded: url_helper
DEBUG - 2014-07-26 08:02:09 --> Helper loaded: file_helper
DEBUG - 2014-07-26 08:02:09 --> Database Driver Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Session Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Helper loaded: string_helper
DEBUG - 2014-07-26 08:02:09 --> Session routines successfully run
DEBUG - 2014-07-26 08:02:09 --> Upload Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Pagination Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Controller Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Helper loaded: form_helper
DEBUG - 2014-07-26 08:02:09 --> Form Validation Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Model Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Model Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Model Class Initialized
DEBUG - 2014-07-26 08:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 08:02:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 08:02:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 08:02:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 08:02:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 08:02:09 --> Final output sent to browser
DEBUG - 2014-07-26 08:02:09 --> Total execution time: 0.1898
DEBUG - 2014-07-26 08:04:26 --> Config Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Hooks Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Utf8 Class Initialized
DEBUG - 2014-07-26 08:04:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 08:04:26 --> URI Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Router Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Output Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Security Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Input Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 08:04:26 --> Language Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Loader Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Helper loaded: url_helper
DEBUG - 2014-07-26 08:04:26 --> Helper loaded: file_helper
DEBUG - 2014-07-26 08:04:26 --> Database Driver Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Session Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Helper loaded: string_helper
DEBUG - 2014-07-26 08:04:26 --> Session routines successfully run
DEBUG - 2014-07-26 08:04:26 --> Upload Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Pagination Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Controller Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Helper loaded: form_helper
DEBUG - 2014-07-26 08:04:26 --> Form Validation Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Model Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Model Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Model Class Initialized
DEBUG - 2014-07-26 08:04:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 08:04:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 08:04:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 08:04:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 08:04:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 08:04:26 --> Final output sent to browser
DEBUG - 2014-07-26 08:04:26 --> Total execution time: 0.1883
DEBUG - 2014-07-26 08:04:28 --> Config Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Hooks Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Utf8 Class Initialized
DEBUG - 2014-07-26 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-26 08:04:28 --> URI Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Router Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Output Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Security Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Input Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-26 08:04:28 --> Language Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Loader Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Helper loaded: url_helper
DEBUG - 2014-07-26 08:04:28 --> Helper loaded: file_helper
DEBUG - 2014-07-26 08:04:28 --> Database Driver Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Session Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Helper loaded: string_helper
DEBUG - 2014-07-26 08:04:28 --> Session routines successfully run
DEBUG - 2014-07-26 08:04:28 --> Upload Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Pagination Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Controller Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Helper loaded: form_helper
DEBUG - 2014-07-26 08:04:28 --> Form Validation Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Model Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Model Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Model Class Initialized
DEBUG - 2014-07-26 08:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-26 08:04:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-26 08:04:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-26 08:04:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-26 08:04:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-26 08:04:28 --> Final output sent to browser
DEBUG - 2014-07-26 08:04:28 --> Total execution time: 0.2115

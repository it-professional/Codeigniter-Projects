<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-05 05:21:37 --> Config Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:21:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:21:37 --> URI Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Router Class Initialized
DEBUG - 2014-07-05 05:21:37 --> No URI present. Default controller set.
DEBUG - 2014-07-05 05:21:37 --> Output Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Security Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Input Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:21:37 --> Language Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Loader Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:21:37 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:21:37 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Session Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:21:37 --> A session cookie was not found.
DEBUG - 2014-07-05 05:21:37 --> Session routines successfully run
DEBUG - 2014-07-05 05:21:37 --> Upload Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:21:37 --> Controller Class Initialized
DEBUG - 2014-07-05 05:21:37 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-05 05:21:37 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-05 05:21:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-05 05:21:37 --> Final output sent to browser
DEBUG - 2014-07-05 05:21:37 --> Total execution time: 0.3709
DEBUG - 2014-07-05 05:25:40 --> Config Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:25:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:25:40 --> URI Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Router Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Output Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Security Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Input Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:25:40 --> Language Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Loader Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:25:40 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:25:40 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Session Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:25:40 --> Session routines successfully run
DEBUG - 2014-07-05 05:25:40 --> Upload Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Controller Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Helper loaded: form_helper
DEBUG - 2014-07-05 05:25:40 --> Form Validation Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Model Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Model Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Model Class Initialized
DEBUG - 2014-07-05 05:25:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 05:25:40 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-05 05:25:40 --> Final output sent to browser
DEBUG - 2014-07-05 05:25:40 --> Total execution time: 0.2418
DEBUG - 2014-07-05 05:50:49 --> Config Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:50:49 --> URI Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Router Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Output Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Security Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Input Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:50:49 --> Language Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Loader Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:50:49 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Session Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:50:49 --> Session routines successfully run
DEBUG - 2014-07-05 05:50:49 --> Upload Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Controller Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: form_helper
DEBUG - 2014-07-05 05:50:49 --> Form Validation Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Model Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Model Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Model Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 05:50:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-05 05:50:49 --> XSS Filtering completed
DEBUG - 2014-07-05 05:50:49 --> Config Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:50:49 --> URI Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Router Class Initialized
DEBUG - 2014-07-05 05:50:49 --> No URI present. Default controller set.
DEBUG - 2014-07-05 05:50:49 --> Output Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Security Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Input Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:50:49 --> Language Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Loader Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:50:49 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Session Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:50:49 --> Session routines successfully run
DEBUG - 2014-07-05 05:50:49 --> Upload Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:50:49 --> Controller Class Initialized
DEBUG - 2014-07-05 05:50:49 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-05 05:50:49 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-05 05:50:49 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-05 05:50:49 --> Final output sent to browser
DEBUG - 2014-07-05 05:50:49 --> Total execution time: 0.1397
DEBUG - 2014-07-05 05:51:03 --> Config Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:51:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:51:03 --> URI Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Router Class Initialized
DEBUG - 2014-07-05 05:51:03 --> No URI present. Default controller set.
DEBUG - 2014-07-05 05:51:03 --> Output Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Security Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Input Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:51:03 --> Language Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Loader Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:51:03 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:51:03 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Session Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:51:03 --> Session routines successfully run
DEBUG - 2014-07-05 05:51:03 --> Upload Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:51:03 --> Controller Class Initialized
DEBUG - 2014-07-05 05:51:03 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-05 05:51:03 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-05 05:51:03 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-05 05:51:03 --> Final output sent to browser
DEBUG - 2014-07-05 05:51:03 --> Total execution time: 0.1455
DEBUG - 2014-07-05 05:51:10 --> Config Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:51:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:51:10 --> URI Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Router Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Output Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Security Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Input Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:51:10 --> Language Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Loader Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:51:10 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:51:10 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Session Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:51:10 --> Session routines successfully run
DEBUG - 2014-07-05 05:51:10 --> Upload Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Controller Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Helper loaded: form_helper
DEBUG - 2014-07-05 05:51:10 --> Form Validation Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Model Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Model Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Model Class Initialized
DEBUG - 2014-07-05 05:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 05:51:10 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-05 05:51:10 --> Final output sent to browser
DEBUG - 2014-07-05 05:51:10 --> Total execution time: 0.1717
DEBUG - 2014-07-05 05:51:18 --> Config Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Hooks Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Utf8 Class Initialized
DEBUG - 2014-07-05 05:51:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 05:51:18 --> URI Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Router Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Output Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Security Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Input Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 05:51:18 --> Language Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Loader Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Helper loaded: url_helper
DEBUG - 2014-07-05 05:51:18 --> Helper loaded: file_helper
DEBUG - 2014-07-05 05:51:18 --> Database Driver Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Session Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Helper loaded: string_helper
DEBUG - 2014-07-05 05:51:18 --> Session routines successfully run
DEBUG - 2014-07-05 05:51:18 --> Upload Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Pagination Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Controller Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Helper loaded: form_helper
DEBUG - 2014-07-05 05:51:18 --> Form Validation Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Model Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Model Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Model Class Initialized
DEBUG - 2014-07-05 05:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 05:51:18 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-05 05:51:18 --> Final output sent to browser
DEBUG - 2014-07-05 05:51:18 --> Total execution time: 0.1928
DEBUG - 2014-07-05 06:01:16 --> Config Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:01:16 --> URI Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Router Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Output Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Security Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Input Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:01:16 --> Language Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Loader Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:01:16 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:01:16 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Session Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:01:16 --> Session routines successfully run
DEBUG - 2014-07-05 06:01:16 --> Upload Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Controller Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:01:16 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Model Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Model Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Model Class Initialized
DEBUG - 2014-07-05 06:01:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 06:01:16 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-05 06:01:16 --> Final output sent to browser
DEBUG - 2014-07-05 06:01:16 --> Total execution time: 0.1898
DEBUG - 2014-07-05 06:13:36 --> Config Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:13:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:13:36 --> URI Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Router Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Output Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Security Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Input Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:13:36 --> Language Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Loader Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:13:36 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:13:36 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Session Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:13:36 --> Session routines successfully run
DEBUG - 2014-07-05 06:13:36 --> Upload Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Controller Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:13:36 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Model Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Model Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Model Class Initialized
DEBUG - 2014-07-05 06:13:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:13:36 --> 404 Page Not Found --> 
DEBUG - 2014-07-05 06:15:03 --> Config Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:15:03 --> URI Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Router Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Output Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Security Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Input Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:15:03 --> Language Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Loader Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:15:03 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:15:03 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Session Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:15:03 --> Session routines successfully run
DEBUG - 2014-07-05 06:15:03 --> Upload Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Controller Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:15:03 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:15:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:15:03 --> 404 Page Not Found --> 
DEBUG - 2014-07-05 06:15:31 --> Config Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:15:31 --> URI Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Router Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Output Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Security Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Input Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:15:31 --> Language Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Loader Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:15:31 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:15:31 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Session Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:15:31 --> Session routines successfully run
DEBUG - 2014-07-05 06:15:31 --> Upload Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Controller Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:15:31 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Model Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Model Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Model Class Initialized
DEBUG - 2014-07-05 06:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 06:15:31 --> DB Transaction Failure
ERROR - 2014-07-05 06:15:31 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:15:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:16:47 --> Config Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:16:47 --> URI Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Router Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Output Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Security Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Input Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:16:47 --> Language Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Loader Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:16:47 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:16:47 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Session Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:16:47 --> Session routines successfully run
DEBUG - 2014-07-05 06:16:47 --> Upload Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Controller Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:16:47 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Model Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Model Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Model Class Initialized
DEBUG - 2014-07-05 06:16:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 06:16:47 --> DB Transaction Failure
ERROR - 2014-07-05 06:16:47 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:16:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:17:27 --> Config Class Initialized
DEBUG - 2014-07-05 06:17:27 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:17:27 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:17:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:17:27 --> URI Class Initialized
DEBUG - 2014-07-05 06:17:27 --> Router Class Initialized
DEBUG - 2014-07-05 06:17:27 --> Output Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Security Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Input Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:17:28 --> Language Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Loader Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:17:28 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:17:28 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Session Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:17:28 --> Session routines successfully run
DEBUG - 2014-07-05 06:17:28 --> Upload Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Controller Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:17:28 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Model Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Model Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Model Class Initialized
DEBUG - 2014-07-05 06:17:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:17:28 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:17:28 --> DB Transaction Failure
ERROR - 2014-07-05 06:17:28 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:17:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:17:59 --> Config Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:17:59 --> URI Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Router Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Output Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Security Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Input Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:17:59 --> Language Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Loader Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:17:59 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:17:59 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Session Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:17:59 --> Session routines successfully run
DEBUG - 2014-07-05 06:17:59 --> Upload Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Controller Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:17:59 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Model Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Model Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Model Class Initialized
DEBUG - 2014-07-05 06:17:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:17:59 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:17:59 --> DB Transaction Failure
ERROR - 2014-07-05 06:17:59 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:17:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:18:03 --> Config Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:18:03 --> URI Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Router Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Output Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Security Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Input Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:18:03 --> Language Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Loader Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:18:03 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:18:03 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Session Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:18:03 --> Session routines successfully run
DEBUG - 2014-07-05 06:18:03 --> Upload Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Controller Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:18:03 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:18:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:18:03 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:18:03 --> DB Transaction Failure
ERROR - 2014-07-05 06:18:03 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:18:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:18:20 --> Config Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:18:20 --> URI Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Router Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Output Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Security Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Input Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:18:20 --> Language Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Loader Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:18:20 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:18:20 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Session Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:18:20 --> Session routines successfully run
DEBUG - 2014-07-05 06:18:20 --> Upload Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Controller Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:18:20 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Model Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Model Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Model Class Initialized
DEBUG - 2014-07-05 06:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 06:18:20 --> DB Transaction Failure
ERROR - 2014-07-05 06:18:20 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:18:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:20:09 --> Config Class Initialized
DEBUG - 2014-07-05 06:20:09 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:20:09 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:20:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:20:09 --> URI Class Initialized
DEBUG - 2014-07-05 06:20:09 --> Router Class Initialized
DEBUG - 2014-07-05 06:20:09 --> Output Class Initialized
DEBUG - 2014-07-05 06:20:09 --> Security Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Input Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:20:10 --> Language Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Loader Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:20:10 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:20:10 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Session Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:20:10 --> Session routines successfully run
DEBUG - 2014-07-05 06:20:10 --> Upload Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Controller Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:20:10 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Model Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Model Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Model Class Initialized
DEBUG - 2014-07-05 06:20:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:20:10 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:20:10 --> DB Transaction Failure
ERROR - 2014-07-05 06:20:10 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:20:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:20:43 --> Config Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:20:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:20:43 --> URI Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Router Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Output Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Security Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Input Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:20:43 --> Language Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Loader Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:20:43 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:20:43 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Session Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:20:43 --> Session routines successfully run
DEBUG - 2014-07-05 06:20:43 --> Upload Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Controller Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:20:43 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Model Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Model Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Model Class Initialized
DEBUG - 2014-07-05 06:20:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:20:43 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:20:43 --> DB Transaction Failure
ERROR - 2014-07-05 06:20:43 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:20:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:21:03 --> Config Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:21:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:21:03 --> URI Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Router Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Output Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Security Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Input Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:21:03 --> Language Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Loader Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:21:03 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:21:03 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Session Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:21:03 --> Session routines successfully run
DEBUG - 2014-07-05 06:21:03 --> Upload Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Controller Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:21:03 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Model Class Initialized
DEBUG - 2014-07-05 06:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-05 06:21:03 --> DB Transaction Failure
ERROR - 2014-07-05 06:21:03 --> Query error: Table 'hostorks.tbl_links' doesn't exist
DEBUG - 2014-07-05 06:21:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:24:54 --> Config Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:24:54 --> URI Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Router Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Output Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Security Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Input Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:24:54 --> Language Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Loader Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:24:54 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:24:54 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Session Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:24:54 --> Session routines successfully run
DEBUG - 2014-07-05 06:24:54 --> Upload Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Controller Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:24:54 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Model Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Model Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Model Class Initialized
DEBUG - 2014-07-05 06:24:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:24:54 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:24:54 --> DB Transaction Failure
ERROR - 2014-07-05 06:24:54 --> Query error: Unknown column 'tbl_links.link_type' in 'where clause'
DEBUG - 2014-07-05 06:24:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-05 06:25:45 --> Config Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Hooks Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Utf8 Class Initialized
DEBUG - 2014-07-05 06:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-05 06:25:45 --> URI Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Router Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Output Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Security Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Input Class Initialized
DEBUG - 2014-07-05 06:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-05 06:25:45 --> Language Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Loader Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Helper loaded: url_helper
DEBUG - 2014-07-05 06:25:46 --> Helper loaded: file_helper
DEBUG - 2014-07-05 06:25:46 --> Database Driver Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Session Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Helper loaded: string_helper
DEBUG - 2014-07-05 06:25:46 --> Session routines successfully run
DEBUG - 2014-07-05 06:25:46 --> Upload Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Pagination Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Controller Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Helper loaded: form_helper
DEBUG - 2014-07-05 06:25:46 --> Form Validation Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Model Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Model Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Model Class Initialized
DEBUG - 2014-07-05 06:25:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-05 06:25:46 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-05 06:25:46 --> File loaded: application/views/templates/header.php

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-14 06:36:23 --> Config Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 06:36:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 06:36:23 --> URI Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Router Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Output Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Security Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Input Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 06:36:23 --> Language Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Loader Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 06:36:23 --> Helper loaded: file_helper
DEBUG - 2014-07-14 06:36:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Session Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 06:36:23 --> A session cookie was not found.
DEBUG - 2014-07-14 06:36:23 --> Session routines successfully run
DEBUG - 2014-07-14 06:36:23 --> Upload Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Controller Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 06:36:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Model Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Model Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Model Class Initialized
DEBUG - 2014-07-14 06:36:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 06:36:23 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-14 06:36:23 --> Final output sent to browser
DEBUG - 2014-07-14 06:36:23 --> Total execution time: 0.1412
DEBUG - 2014-07-14 06:37:12 --> Config Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Hooks Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Utf8 Class Initialized
DEBUG - 2014-07-14 06:37:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 06:37:12 --> URI Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Router Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Output Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Security Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Input Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 06:37:12 --> Language Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Loader Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Helper loaded: url_helper
DEBUG - 2014-07-14 06:37:12 --> Helper loaded: file_helper
DEBUG - 2014-07-14 06:37:12 --> Database Driver Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Session Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Helper loaded: string_helper
DEBUG - 2014-07-14 06:37:12 --> Session routines successfully run
DEBUG - 2014-07-14 06:37:12 --> Upload Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Pagination Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Controller Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Helper loaded: form_helper
DEBUG - 2014-07-14 06:37:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 06:37:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 06:37:12 --> XSS Filtering completed
DEBUG - 2014-07-14 06:37:13 --> Config Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 06:37:13 --> URI Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Router Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Output Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Security Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Input Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 06:37:13 --> Language Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Loader Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 06:37:13 --> Helper loaded: file_helper
DEBUG - 2014-07-14 06:37:13 --> Database Driver Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Session Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 06:37:13 --> Session routines successfully run
DEBUG - 2014-07-14 06:37:13 --> Upload Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Pagination Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Controller Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 06:37:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 06:37:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 06:37:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 06:37:13 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 06:37:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 06:37:13 --> Final output sent to browser
DEBUG - 2014-07-14 06:37:13 --> Total execution time: 0.1322
DEBUG - 2014-07-14 06:37:49 --> Config Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 06:37:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 06:37:49 --> URI Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Router Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Output Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Security Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Input Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 06:37:49 --> Language Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Loader Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 06:37:49 --> Helper loaded: file_helper
DEBUG - 2014-07-14 06:37:49 --> Database Driver Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Session Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 06:37:49 --> Session routines successfully run
DEBUG - 2014-07-14 06:37:49 --> Upload Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Pagination Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Controller Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Helper loaded: form_helper
DEBUG - 2014-07-14 06:37:49 --> Form Validation Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Model Class Initialized
DEBUG - 2014-07-14 06:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 06:37:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 06:37:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 06:37:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 06:37:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 06:37:49 --> Final output sent to browser
DEBUG - 2014-07-14 06:37:49 --> Total execution time: 0.0873
DEBUG - 2014-07-14 08:19:35 --> Config Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 08:19:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 08:19:35 --> URI Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Router Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Output Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Security Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Input Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 08:19:35 --> Language Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Loader Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 08:19:35 --> Helper loaded: file_helper
DEBUG - 2014-07-14 08:19:35 --> Database Driver Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Session Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 08:19:35 --> Session routines successfully run
DEBUG - 2014-07-14 08:19:35 --> Upload Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Pagination Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Controller Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 08:19:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Model Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Model Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Model Class Initialized
DEBUG - 2014-07-14 08:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 08:19:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 08:19:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 08:19:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 08:19:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 08:19:35 --> Final output sent to browser
DEBUG - 2014-07-14 08:19:35 --> Total execution time: 0.0861
DEBUG - 2014-07-14 09:19:23 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:23 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:23 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:23 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:23 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:23 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:23 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:23 --> Total execution time: 0.1022
DEBUG - 2014-07-14 09:19:25 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:25 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:25 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:25 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:25 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:25 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:25 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:25 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:25 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:25 --> Total execution time: 0.0950
DEBUG - 2014-07-14 09:19:26 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:26 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:26 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:26 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:26 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:26 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:26 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:26 --> Total execution time: 0.1257
DEBUG - 2014-07-14 09:19:26 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:26 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:26 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:26 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:26 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:26 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:26 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:26 --> Total execution time: 0.1206
DEBUG - 2014-07-14 09:19:26 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:26 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:26 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:26 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:26 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:26 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:26 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:26 --> Total execution time: 0.1139
DEBUG - 2014-07-14 09:19:26 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:26 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:26 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:26 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:26 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:26 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:26 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:26 --> Total execution time: 0.0949
DEBUG - 2014-07-14 09:19:26 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:26 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:27 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:27 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:27 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:27 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:27 --> Total execution time: 0.0983
DEBUG - 2014-07-14 09:19:27 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:27 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:27 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:27 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:27 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:27 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:27 --> Total execution time: 0.0961
DEBUG - 2014-07-14 09:19:27 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:27 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:27 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:27 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:27 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:27 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:27 --> Total execution time: 0.0924
DEBUG - 2014-07-14 09:19:27 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:27 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:27 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:27 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:27 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:27 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:27 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:27 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:27 --> Total execution time: 0.1243
DEBUG - 2014-07-14 09:19:27 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:27 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:27 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:27 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:27 --> Total execution time: 0.1227
DEBUG - 2014-07-14 09:19:28 --> Config Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:19:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:19:28 --> URI Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Router Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Output Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Security Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Input Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:19:28 --> Language Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Loader Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:19:28 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:19:28 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Session Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:19:28 --> Session routines successfully run
DEBUG - 2014-07-14 09:19:28 --> Upload Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Controller Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:19:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Model Class Initialized
DEBUG - 2014-07-14 09:19:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:19:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:19:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:19:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:19:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:19:28 --> Final output sent to browser
DEBUG - 2014-07-14 09:19:28 --> Total execution time: 0.1141
DEBUG - 2014-07-14 09:20:15 --> Config Class Initialized
DEBUG - 2014-07-14 09:20:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:20:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:20:16 --> URI Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Router Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Output Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Security Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Input Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:20:16 --> Language Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Loader Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:20:16 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:20:16 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Session Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:20:16 --> Session routines successfully run
DEBUG - 2014-07-14 09:20:16 --> Upload Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Controller Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:20:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Model Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Model Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Model Class Initialized
DEBUG - 2014-07-14 09:20:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-14 09:20:16 --> Severity: Notice  --> Undefined variable: data F:\wamp\www\hostorks\application\controllers\superadmin.php 166
DEBUG - 2014-07-14 09:20:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:20:16 --> Final output sent to browser
DEBUG - 2014-07-14 09:20:16 --> Total execution time: 0.2519
DEBUG - 2014-07-14 09:20:32 --> Config Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:20:32 --> URI Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Router Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Output Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Security Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Input Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:20:32 --> Language Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Loader Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:20:32 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:20:32 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Session Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:20:32 --> Session routines successfully run
DEBUG - 2014-07-14 09:20:32 --> Upload Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Controller Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:20:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Model Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Model Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Model Class Initialized
DEBUG - 2014-07-14 09:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:20:32 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:20:32 --> Final output sent to browser
DEBUG - 2014-07-14 09:20:32 --> Total execution time: 0.2278
DEBUG - 2014-07-14 09:24:59 --> Config Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:24:59 --> URI Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Router Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Output Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Security Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Input Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:24:59 --> Language Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Loader Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:24:59 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:24:59 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Session Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:24:59 --> Session routines successfully run
DEBUG - 2014-07-14 09:24:59 --> Upload Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Controller Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:24:59 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Model Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Model Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Model Class Initialized
DEBUG - 2014-07-14 09:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:24:59 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 09:24:59 --> Final output sent to browser
DEBUG - 2014-07-14 09:24:59 --> Total execution time: 0.0915
DEBUG - 2014-07-14 09:25:05 --> Config Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:25:05 --> URI Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Router Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Output Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Security Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Input Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:25:05 --> Language Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Loader Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:25:05 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:25:05 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Session Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:25:05 --> Session routines successfully run
DEBUG - 2014-07-14 09:25:05 --> Upload Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Controller Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:25:05 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:25:05 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 09:25:05 --> Final output sent to browser
DEBUG - 2014-07-14 09:25:05 --> Total execution time: 0.0885
DEBUG - 2014-07-14 09:25:12 --> Config Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:25:12 --> URI Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Router Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Output Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Security Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Input Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:25:12 --> Language Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Loader Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:25:12 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:25:12 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Session Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:25:12 --> Session routines successfully run
DEBUG - 2014-07-14 09:25:12 --> Upload Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Controller Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:25:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:25:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:25:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:25:12 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 09:25:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:25:12 --> Final output sent to browser
DEBUG - 2014-07-14 09:25:12 --> Total execution time: 0.1022
DEBUG - 2014-07-14 09:25:14 --> Config Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 09:25:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 09:25:14 --> URI Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Router Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Output Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Security Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Input Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 09:25:14 --> Language Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Loader Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 09:25:14 --> Helper loaded: file_helper
DEBUG - 2014-07-14 09:25:14 --> Database Driver Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Session Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 09:25:14 --> Session routines successfully run
DEBUG - 2014-07-14 09:25:14 --> Upload Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Pagination Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Controller Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 09:25:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 09:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 09:25:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 09:25:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 09:25:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 09:25:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 09:25:14 --> Final output sent to browser
DEBUG - 2014-07-14 09:25:14 --> Total execution time: 0.0766
DEBUG - 2014-07-14 10:03:15 --> Config Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 10:03:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 10:03:15 --> URI Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Router Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Output Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Security Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Input Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 10:03:15 --> Language Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Loader Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 10:03:15 --> Helper loaded: file_helper
DEBUG - 2014-07-14 10:03:15 --> Database Driver Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Session Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Helper loaded: string_helper
DEBUG - 2014-07-14 10:03:15 --> Session routines successfully run
DEBUG - 2014-07-14 10:03:15 --> Upload Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Pagination Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Controller Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Helper loaded: form_helper
DEBUG - 2014-07-14 10:03:15 --> Form Validation Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 10:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 10:03:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 10:03:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 10:03:15 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 10:03:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 10:03:15 --> Final output sent to browser
DEBUG - 2014-07-14 10:03:15 --> Total execution time: 0.0754
DEBUG - 2014-07-14 10:03:34 --> Config Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Hooks Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Utf8 Class Initialized
DEBUG - 2014-07-14 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 10:03:34 --> URI Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Router Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Output Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Security Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Input Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 10:03:34 --> Language Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Loader Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Helper loaded: url_helper
DEBUG - 2014-07-14 10:03:34 --> Helper loaded: file_helper
DEBUG - 2014-07-14 10:03:34 --> Database Driver Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Session Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Helper loaded: string_helper
DEBUG - 2014-07-14 10:03:34 --> Session routines successfully run
DEBUG - 2014-07-14 10:03:34 --> Upload Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Pagination Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Controller Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Helper loaded: form_helper
DEBUG - 2014-07-14 10:03:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Model Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Model Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Model Class Initialized
DEBUG - 2014-07-14 10:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 10:03:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 10:03:34 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 10:03:34 --> Final output sent to browser
DEBUG - 2014-07-14 10:03:34 --> Total execution time: 0.1439
DEBUG - 2014-07-14 10:07:25 --> Config Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Hooks Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Utf8 Class Initialized
DEBUG - 2014-07-14 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 10:07:25 --> URI Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Router Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Output Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Security Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Input Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 10:07:25 --> Language Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Loader Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Helper loaded: url_helper
DEBUG - 2014-07-14 10:07:25 --> Helper loaded: file_helper
DEBUG - 2014-07-14 10:07:25 --> Database Driver Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Session Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Helper loaded: string_helper
DEBUG - 2014-07-14 10:07:25 --> Session routines successfully run
DEBUG - 2014-07-14 10:07:25 --> Upload Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Pagination Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Controller Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Helper loaded: form_helper
DEBUG - 2014-07-14 10:07:25 --> Form Validation Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Model Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Model Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Model Class Initialized
DEBUG - 2014-07-14 10:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 10:07:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 10:07:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 10:07:25 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 10:07:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 10:07:25 --> Final output sent to browser
DEBUG - 2014-07-14 10:07:25 --> Total execution time: 0.0911
DEBUG - 2014-07-14 10:07:27 --> Config Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 10:07:27 --> URI Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Router Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Output Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Security Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Input Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 10:07:27 --> Language Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Loader Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 10:07:27 --> Helper loaded: file_helper
DEBUG - 2014-07-14 10:07:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Session Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 10:07:27 --> Session routines successfully run
DEBUG - 2014-07-14 10:07:27 --> Upload Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Controller Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 10:07:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Model Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Model Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Model Class Initialized
DEBUG - 2014-07-14 10:07:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 10:07:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 10:07:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 10:07:27 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 10:07:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 10:07:27 --> Final output sent to browser
DEBUG - 2014-07-14 10:07:27 --> Total execution time: 0.0805
DEBUG - 2014-07-14 10:29:48 --> Config Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Hooks Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Utf8 Class Initialized
DEBUG - 2014-07-14 10:29:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 10:29:48 --> URI Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Router Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Output Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Security Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Input Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 10:29:48 --> Language Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Loader Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Helper loaded: url_helper
DEBUG - 2014-07-14 10:29:48 --> Helper loaded: file_helper
DEBUG - 2014-07-14 10:29:48 --> Database Driver Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Session Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Helper loaded: string_helper
DEBUG - 2014-07-14 10:29:48 --> Session routines successfully run
DEBUG - 2014-07-14 10:29:48 --> Upload Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Pagination Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Controller Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Helper loaded: form_helper
DEBUG - 2014-07-14 10:29:48 --> Form Validation Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Model Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Model Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Model Class Initialized
DEBUG - 2014-07-14 10:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 10:29:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 10:29:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 10:29:48 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 10:29:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 10:29:48 --> Final output sent to browser
DEBUG - 2014-07-14 10:29:48 --> Total execution time: 0.1154
DEBUG - 2014-07-14 11:04:46 --> Config Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:04:46 --> URI Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Router Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Output Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Security Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Input Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:04:46 --> Language Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Loader Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:04:46 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:04:46 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Session Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:04:46 --> Session routines successfully run
DEBUG - 2014-07-14 11:04:46 --> Upload Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Controller Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:04:46 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Model Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Model Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Model Class Initialized
DEBUG - 2014-07-14 11:04:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:04:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:04:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:04:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:04:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:04:46 --> Final output sent to browser
DEBUG - 2014-07-14 11:04:46 --> Total execution time: 0.0948
DEBUG - 2014-07-14 11:09:35 --> Config Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:09:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:09:35 --> URI Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Router Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Output Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Security Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Input Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:09:35 --> Language Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Loader Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:09:35 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:09:35 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Session Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:09:35 --> Session routines successfully run
DEBUG - 2014-07-14 11:09:35 --> Upload Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Controller Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:09:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Model Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Model Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Model Class Initialized
DEBUG - 2014-07-14 11:09:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:09:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:09:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:09:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:09:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:09:35 --> Final output sent to browser
DEBUG - 2014-07-14 11:09:35 --> Total execution time: 0.1102
DEBUG - 2014-07-14 11:10:07 --> Config Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:10:07 --> URI Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Router Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Output Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Security Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Input Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:10:07 --> Language Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Loader Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:10:07 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Session Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:10:07 --> Session routines successfully run
DEBUG - 2014-07-14 11:10:07 --> Upload Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Controller Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:10:07 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Model Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Model Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Model Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:10:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 11:10:07 --> Config Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:10:07 --> URI Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Router Class Initialized
DEBUG - 2014-07-14 11:10:07 --> No URI present. Default controller set.
DEBUG - 2014-07-14 11:10:07 --> Output Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Security Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Input Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:10:07 --> Language Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Loader Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:10:07 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Session Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:10:07 --> Session routines successfully run
DEBUG - 2014-07-14 11:10:07 --> Upload Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:10:07 --> Controller Class Initialized
DEBUG - 2014-07-14 11:10:07 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-14 11:10:07 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-14 11:10:07 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-14 11:10:07 --> Final output sent to browser
DEBUG - 2014-07-14 11:10:07 --> Total execution time: 0.0668
DEBUG - 2014-07-14 11:10:15 --> Config Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:10:15 --> URI Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Router Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Output Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Security Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Input Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:10:15 --> Language Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Loader Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:10:15 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:10:15 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Session Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:10:15 --> Session routines successfully run
DEBUG - 2014-07-14 11:10:15 --> Upload Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Controller Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:10:15 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Model Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Model Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Model Class Initialized
DEBUG - 2014-07-14 11:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:10:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:10:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:10:15 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:10:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:10:15 --> Final output sent to browser
DEBUG - 2014-07-14 11:10:15 --> Total execution time: 0.0845
DEBUG - 2014-07-14 11:11:08 --> Config Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:11:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:11:08 --> URI Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Router Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Output Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Security Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Input Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:11:08 --> Language Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Loader Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:11:08 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:11:08 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Session Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:11:08 --> Session routines successfully run
DEBUG - 2014-07-14 11:11:08 --> Upload Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Controller Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:11:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:11:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:11:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:11:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:11:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:11:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:11:08 --> Final output sent to browser
DEBUG - 2014-07-14 11:11:08 --> Total execution time: 0.1353
DEBUG - 2014-07-14 11:12:58 --> Config Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:12:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:12:58 --> URI Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Router Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Output Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Security Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Input Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:12:58 --> Language Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Loader Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:12:58 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:12:58 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Session Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:12:58 --> Session routines successfully run
DEBUG - 2014-07-14 11:12:58 --> Upload Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Controller Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:12:58 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Model Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Model Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Model Class Initialized
DEBUG - 2014-07-14 11:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:12:58 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 11:12:58 --> Final output sent to browser
DEBUG - 2014-07-14 11:12:58 --> Total execution time: 0.1383
DEBUG - 2014-07-14 11:13:08 --> Config Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:13:08 --> URI Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Router Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Output Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Security Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Input Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:13:08 --> Language Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Loader Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:13:08 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:13:08 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Session Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:13:08 --> Session routines successfully run
DEBUG - 2014-07-14 11:13:08 --> Upload Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Controller Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:13:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:13:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:13:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:13:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:13:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:13:08 --> Final output sent to browser
DEBUG - 2014-07-14 11:13:08 --> Total execution time: 0.1125
DEBUG - 2014-07-14 11:15:46 --> Config Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:15:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:15:46 --> URI Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Router Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Output Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Security Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Input Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:15:46 --> Language Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Loader Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:15:46 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:15:46 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Session Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:15:46 --> Session routines successfully run
DEBUG - 2014-07-14 11:15:46 --> Upload Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Controller Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:15:46 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:15:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:15:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:15:46 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:15:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:15:46 --> Final output sent to browser
DEBUG - 2014-07-14 11:15:46 --> Total execution time: 0.1449
DEBUG - 2014-07-14 11:15:50 --> Config Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:15:50 --> URI Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Router Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Output Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Security Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Input Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:15:50 --> Language Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Loader Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:15:50 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:15:50 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Session Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:15:50 --> Session routines successfully run
DEBUG - 2014-07-14 11:15:50 --> Upload Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Controller Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:15:50 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:15:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:15:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:15:50 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:15:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:15:50 --> Final output sent to browser
DEBUG - 2014-07-14 11:15:50 --> Total execution time: 0.0748
DEBUG - 2014-07-14 11:15:52 --> Config Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:15:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:15:52 --> URI Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Router Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Output Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Security Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Input Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:15:52 --> Language Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Loader Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:15:52 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:15:52 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Session Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:15:52 --> Session routines successfully run
DEBUG - 2014-07-14 11:15:52 --> Upload Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Controller Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:15:52 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:15:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:15:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:15:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:15:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:15:52 --> Final output sent to browser
DEBUG - 2014-07-14 11:15:52 --> Total execution time: 0.0815
DEBUG - 2014-07-14 11:15:53 --> Config Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:15:53 --> URI Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Router Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Output Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Security Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Input Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:15:53 --> Language Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Loader Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:15:53 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:15:53 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Session Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:15:53 --> Session routines successfully run
DEBUG - 2014-07-14 11:15:53 --> Upload Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Controller Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:15:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Model Class Initialized
DEBUG - 2014-07-14 11:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:15:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:15:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:15:53 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:15:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:15:53 --> Final output sent to browser
DEBUG - 2014-07-14 11:15:53 --> Total execution time: 0.1073
DEBUG - 2014-07-14 11:16:03 --> Config Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:16:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:16:03 --> URI Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Router Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Output Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Security Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Input Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:16:03 --> Language Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Loader Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:16:03 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:16:03 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Session Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:16:03 --> Session routines successfully run
DEBUG - 2014-07-14 11:16:03 --> Upload Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Controller Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:16:03 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Model Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Model Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Model Class Initialized
DEBUG - 2014-07-14 11:16:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:16:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:16:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:16:03 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:16:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:16:03 --> Final output sent to browser
DEBUG - 2014-07-14 11:16:03 --> Total execution time: 0.0947
DEBUG - 2014-07-14 11:17:17 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:17 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:17 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:17 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:17 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:17 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:17 --> Total execution time: 0.0833
DEBUG - 2014-07-14 11:17:20 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:20 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:20 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:20 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:20 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:20 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:20 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:20 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:20 --> Total execution time: 0.0914
DEBUG - 2014-07-14 11:17:21 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:21 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:21 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:21 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:21 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:21 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:21 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:21 --> Total execution time: 0.0930
DEBUG - 2014-07-14 11:17:21 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:21 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:21 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:21 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:21 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:21 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:21 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:21 --> Total execution time: 0.0790
DEBUG - 2014-07-14 11:17:21 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:21 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:21 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:21 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:21 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:21 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:21 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:21 --> Total execution time: 0.0878
DEBUG - 2014-07-14 11:17:21 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:21 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:21 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:21 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:21 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:21 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:21 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:21 --> Total execution time: 0.0923
DEBUG - 2014-07-14 11:17:21 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:21 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:21 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:21 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:21 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:21 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:21 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:21 --> Total execution time: 0.0819
DEBUG - 2014-07-14 11:17:22 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:22 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:22 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:22 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:22 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:22 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:22 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:22 --> Total execution time: 0.0839
DEBUG - 2014-07-14 11:17:22 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:22 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:22 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:22 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:22 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:22 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:22 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:22 --> Total execution time: 0.0843
DEBUG - 2014-07-14 11:17:22 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:22 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:22 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:22 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:22 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:22 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:22 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:22 --> Total execution time: 0.0898
DEBUG - 2014-07-14 11:17:22 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:22 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:22 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:22 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:22 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:22 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:22 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:22 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:22 --> Total execution time: 0.0808
DEBUG - 2014-07-14 11:17:22 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:22 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:22 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:22 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:23 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:23 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:23 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:23 --> Total execution time: 0.0762
DEBUG - 2014-07-14 11:17:23 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:23 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:23 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:23 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:23 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:23 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:23 --> Total execution time: 0.0977
DEBUG - 2014-07-14 11:17:23 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:23 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:23 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:23 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:23 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:23 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:23 --> Total execution time: 0.0868
DEBUG - 2014-07-14 11:17:23 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:23 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:23 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:23 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:23 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:23 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:23 --> Total execution time: 0.0907
DEBUG - 2014-07-14 11:17:23 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:23 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:23 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:23 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:23 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:23 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:23 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:23 --> Total execution time: 0.0936
DEBUG - 2014-07-14 11:17:24 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:24 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:24 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:24 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:24 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:24 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:24 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:24 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:24 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:24 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:24 --> Total execution time: 0.2266
DEBUG - 2014-07-14 11:17:24 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:24 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:24 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:24 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:24 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:24 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:24 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:24 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:24 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:24 --> Total execution time: 0.0847
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:24 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:24 --> Total execution time: 0.3164
DEBUG - 2014-07-14 11:17:24 --> Config Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:17:24 --> URI Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Router Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Output Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Security Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Input Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:17:24 --> Language Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Loader Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:17:24 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:17:24 --> Session routines successfully run
DEBUG - 2014-07-14 11:17:24 --> Upload Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Controller Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:17:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Model Class Initialized
DEBUG - 2014-07-14 11:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:17:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:17:24 --> Final output sent to browser
DEBUG - 2014-07-14 11:17:24 --> Total execution time: 0.1135
DEBUG - 2014-07-14 11:18:16 --> Config Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:18:16 --> URI Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Router Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Output Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Security Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Input Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:18:16 --> Language Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Loader Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:18:16 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:18:16 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Session Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:18:16 --> Session routines successfully run
DEBUG - 2014-07-14 11:18:16 --> Upload Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Controller Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:18:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Model Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Model Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Model Class Initialized
DEBUG - 2014-07-14 11:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:18:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:18:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:18:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:18:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:18:16 --> Final output sent to browser
DEBUG - 2014-07-14 11:18:16 --> Total execution time: 0.1111
DEBUG - 2014-07-14 11:18:48 --> Config Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:18:48 --> URI Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Router Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Output Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Security Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Input Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:18:48 --> Language Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Loader Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:18:48 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:18:48 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Session Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:18:48 --> Session routines successfully run
DEBUG - 2014-07-14 11:18:48 --> Upload Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Controller Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:18:48 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Model Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Model Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Model Class Initialized
DEBUG - 2014-07-14 11:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:18:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:18:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:18:48 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:18:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:18:48 --> Final output sent to browser
DEBUG - 2014-07-14 11:18:48 --> Total execution time: 0.0800
DEBUG - 2014-07-14 11:28:08 --> Config Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:28:08 --> URI Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Router Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Output Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Security Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Input Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:28:08 --> Language Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Loader Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:28:08 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:28:08 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Session Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:28:08 --> Session routines successfully run
DEBUG - 2014-07-14 11:28:08 --> Upload Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Controller Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:28:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Model Class Initialized
DEBUG - 2014-07-14 11:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:28:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:28:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:28:08 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:28:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:28:08 --> Final output sent to browser
DEBUG - 2014-07-14 11:28:08 --> Total execution time: 0.0889
DEBUG - 2014-07-14 11:29:06 --> Config Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:29:06 --> URI Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Router Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Output Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Security Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Input Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:29:06 --> Language Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Loader Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:29:06 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:29:06 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Session Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:29:06 --> Session routines successfully run
DEBUG - 2014-07-14 11:29:06 --> Upload Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Controller Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:29:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 11:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:29:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:29:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:29:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:29:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:29:06 --> Final output sent to browser
DEBUG - 2014-07-14 11:29:06 --> Total execution time: 0.0865
DEBUG - 2014-07-14 11:30:32 --> Config Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:30:32 --> URI Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Router Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Output Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Security Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Input Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:30:32 --> Language Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Loader Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:30:32 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:30:32 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Session Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:30:32 --> Session routines successfully run
DEBUG - 2014-07-14 11:30:32 --> Upload Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Controller Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:30:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 11:30:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:30:32 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:30:32 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:30:32 --> DB Transaction Failure
ERROR - 2014-07-14 11:30:32 --> Query error: Unknown column 'tbl_links.sstr_type' in 'where clause'
DEBUG - 2014-07-14 11:30:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 11:31:28 --> Config Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:31:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:31:28 --> URI Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Router Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Output Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Security Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Input Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:31:28 --> Language Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Loader Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:31:28 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:31:28 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Session Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:31:28 --> Session routines successfully run
DEBUG - 2014-07-14 11:31:28 --> Upload Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Controller Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:31:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Model Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Model Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Model Class Initialized
DEBUG - 2014-07-14 11:31:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:31:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:31:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:31:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:31:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:31:28 --> Final output sent to browser
DEBUG - 2014-07-14 11:31:28 --> Total execution time: 0.0919
DEBUG - 2014-07-14 11:56:13 --> Config Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:56:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:56:13 --> URI Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Router Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Output Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Security Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Input Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:56:13 --> Language Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Loader Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:56:13 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:56:13 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Session Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:56:13 --> Session routines successfully run
DEBUG - 2014-07-14 11:56:13 --> Upload Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Controller Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:56:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:56:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:56:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:56:13 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:56:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:56:13 --> Final output sent to browser
DEBUG - 2014-07-14 11:56:13 --> Total execution time: 0.0916
DEBUG - 2014-07-14 11:56:19 --> Config Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:56:19 --> URI Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Router Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Output Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Security Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Input Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:56:19 --> Language Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Loader Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:56:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:56:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Session Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:56:19 --> Session routines successfully run
DEBUG - 2014-07-14 11:56:19 --> Upload Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Controller Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:56:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:56:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:56:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:56:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:56:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:56:19 --> Final output sent to browser
DEBUG - 2014-07-14 11:56:19 --> Total execution time: 0.0872
DEBUG - 2014-07-14 11:56:21 --> Config Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:56:21 --> URI Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Router Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Output Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Security Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Input Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:56:21 --> Language Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Loader Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:56:21 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:56:21 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Session Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:56:21 --> Session routines successfully run
DEBUG - 2014-07-14 11:56:21 --> Upload Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Controller Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:56:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Model Class Initialized
DEBUG - 2014-07-14 11:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:56:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:56:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:56:21 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:56:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:56:21 --> Final output sent to browser
DEBUG - 2014-07-14 11:56:21 --> Total execution time: 0.0816
DEBUG - 2014-07-14 11:57:06 --> Config Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:57:06 --> URI Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Router Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Output Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Security Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Input Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:57:06 --> Language Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Loader Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:57:06 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:57:06 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Session Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:57:06 --> Session routines successfully run
DEBUG - 2014-07-14 11:57:06 --> Upload Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Controller Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:57:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Model Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Model Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Model Class Initialized
DEBUG - 2014-07-14 11:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:57:06 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 11:57:06 --> Final output sent to browser
DEBUG - 2014-07-14 11:57:06 --> Total execution time: 0.3868
DEBUG - 2014-07-14 11:57:12 --> Config Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:57:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:57:12 --> URI Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Router Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Output Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Security Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Input Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:57:12 --> Language Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Loader Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:57:12 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:57:12 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Session Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:57:12 --> Session routines successfully run
DEBUG - 2014-07-14 11:57:12 --> Upload Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Controller Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:57:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Model Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Model Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Model Class Initialized
DEBUG - 2014-07-14 11:57:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:57:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:57:12 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:57:12 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:57:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:57:12 --> Final output sent to browser
DEBUG - 2014-07-14 11:57:12 --> Total execution time: 0.0857
DEBUG - 2014-07-14 11:59:19 --> Config Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:59:19 --> URI Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Router Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Output Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Security Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Input Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:59:19 --> Language Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Loader Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:59:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:59:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Session Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:59:19 --> Session routines successfully run
DEBUG - 2014-07-14 11:59:19 --> Upload Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Controller Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:59:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:59:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:59:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:59:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:59:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:59:19 --> Final output sent to browser
DEBUG - 2014-07-14 11:59:19 --> Total execution time: 0.0916
DEBUG - 2014-07-14 11:59:29 --> Config Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:59:29 --> URI Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Router Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Output Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Security Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Input Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:59:29 --> Language Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Loader Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:59:29 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:59:29 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Session Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:59:29 --> Session routines successfully run
DEBUG - 2014-07-14 11:59:29 --> Upload Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Controller Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:59:29 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:59:30 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-14 11:59:30 --> Final output sent to browser
DEBUG - 2014-07-14 11:59:30 --> Total execution time: 0.2880
DEBUG - 2014-07-14 11:59:35 --> Config Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 11:59:35 --> URI Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Router Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Output Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Security Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Input Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 11:59:35 --> Language Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Loader Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 11:59:35 --> Helper loaded: file_helper
DEBUG - 2014-07-14 11:59:35 --> Database Driver Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Session Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 11:59:35 --> Session routines successfully run
DEBUG - 2014-07-14 11:59:35 --> Upload Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Pagination Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Controller Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 11:59:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Model Class Initialized
DEBUG - 2014-07-14 11:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 11:59:35 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 11:59:35 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 11:59:35 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 11:59:35 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 11:59:35 --> Final output sent to browser
DEBUG - 2014-07-14 11:59:35 --> Total execution time: 0.0833
DEBUG - 2014-07-14 12:00:01 --> Config Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:00:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:00:01 --> URI Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Router Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Output Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Security Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Input Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:00:01 --> Language Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Loader Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:00:01 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:00:01 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Session Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:00:01 --> Session routines successfully run
DEBUG - 2014-07-14 12:00:01 --> Upload Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Controller Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:00:01 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:00:01 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:00:01 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:00:01 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:00:01 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:00:01 --> Final output sent to browser
DEBUG - 2014-07-14 12:00:01 --> Total execution time: 0.0965
DEBUG - 2014-07-14 12:00:04 --> Config Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:00:04 --> URI Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Router Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Output Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Security Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Input Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:00:04 --> Language Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Loader Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:00:04 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Session Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:00:04 --> Session routines successfully run
DEBUG - 2014-07-14 12:00:04 --> Upload Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Controller Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:00:04 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:00:04 --> Config Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:00:04 --> URI Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Router Class Initialized
DEBUG - 2014-07-14 12:00:04 --> No URI present. Default controller set.
DEBUG - 2014-07-14 12:00:04 --> Output Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Security Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Input Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:00:04 --> Language Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Loader Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:00:04 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Session Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:00:04 --> Session routines successfully run
DEBUG - 2014-07-14 12:00:04 --> Upload Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:00:04 --> Controller Class Initialized
DEBUG - 2014-07-14 12:00:04 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-14 12:00:04 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-14 12:00:04 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-14 12:00:04 --> Final output sent to browser
DEBUG - 2014-07-14 12:00:04 --> Total execution time: 0.0628
DEBUG - 2014-07-14 12:00:49 --> Config Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:00:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:00:49 --> URI Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Router Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Output Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Security Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Input Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:00:49 --> Language Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Loader Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:00:49 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:00:49 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Session Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:00:49 --> Session routines successfully run
DEBUG - 2014-07-14 12:00:49 --> Upload Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Controller Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:00:49 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:00:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:00:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:00:49 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:00:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:00:49 --> Final output sent to browser
DEBUG - 2014-07-14 12:00:49 --> Total execution time: 0.0883
DEBUG - 2014-07-14 12:00:53 --> Config Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:00:53 --> URI Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Router Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Output Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Security Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Input Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:00:53 --> Language Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Loader Class Initialized
DEBUG - 2014-07-14 12:00:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:00:53 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:00:54 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Session Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:00:54 --> Session routines successfully run
DEBUG - 2014-07-14 12:00:54 --> Upload Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Controller Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:00:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:00:54 --> Config Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:00:54 --> URI Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Router Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Output Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Security Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Input Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:00:54 --> Language Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Loader Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:00:54 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:00:54 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Session Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:00:54 --> Session routines successfully run
DEBUG - 2014-07-14 12:00:54 --> Upload Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Controller Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:00:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Model Class Initialized
DEBUG - 2014-07-14 12:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:00:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:00:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:00:54 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:00:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:00:54 --> Final output sent to browser
DEBUG - 2014-07-14 12:00:54 --> Total execution time: 0.0881
DEBUG - 2014-07-14 12:04:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:04:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:04:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:04:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:04:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:04:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:04:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:04:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:04:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:04:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:04:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:04:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:04:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:04:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:04:18 --> Total execution time: 0.0750
DEBUG - 2014-07-14 12:09:42 --> Config Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:09:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:09:42 --> URI Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Router Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Output Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Security Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Input Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:09:42 --> Language Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Loader Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:09:42 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:09:42 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Session Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:09:42 --> Session routines successfully run
DEBUG - 2014-07-14 12:09:42 --> Upload Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Controller Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:09:42 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Model Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Model Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Model Class Initialized
DEBUG - 2014-07-14 12:09:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:09:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:09:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:09:42 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:09:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:09:42 --> Final output sent to browser
DEBUG - 2014-07-14 12:09:42 --> Total execution time: 0.0829
DEBUG - 2014-07-14 12:09:47 --> Config Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:09:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:09:47 --> URI Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Router Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Output Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Security Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Input Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:09:47 --> Language Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Loader Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:09:47 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:09:47 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Session Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:09:47 --> Session routines successfully run
DEBUG - 2014-07-14 12:09:47 --> Upload Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Controller Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:09:47 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Model Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Model Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Model Class Initialized
DEBUG - 2014-07-14 12:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:09:47 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:09:47 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:09:47 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:09:47 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:09:47 --> Final output sent to browser
DEBUG - 2014-07-14 12:09:47 --> Total execution time: 0.0876
DEBUG - 2014-07-14 12:43:28 --> Config Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:43:28 --> URI Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Router Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Output Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Security Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Input Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:43:28 --> Language Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Loader Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:43:28 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:43:28 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Session Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:43:28 --> Session routines successfully run
DEBUG - 2014-07-14 12:43:28 --> Upload Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Controller Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:43:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:43:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:43:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:43:28 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:43:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:43:28 --> Final output sent to browser
DEBUG - 2014-07-14 12:43:28 --> Total execution time: 0.0828
DEBUG - 2014-07-14 12:43:35 --> Config Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:43:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:43:35 --> URI Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Router Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Output Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Security Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Input Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:43:35 --> Language Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Loader Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:43:35 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:43:35 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Session Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:43:35 --> Session routines successfully run
DEBUG - 2014-07-14 12:43:35 --> Upload Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Controller Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:43:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:43:36 --> Config Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:43:36 --> URI Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Router Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Output Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Security Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Input Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:43:36 --> Language Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Loader Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:43:36 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:43:36 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Session Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:43:36 --> Session routines successfully run
DEBUG - 2014-07-14 12:43:36 --> Upload Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Controller Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:43:36 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Model Class Initialized
DEBUG - 2014-07-14 12:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:43:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:43:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:43:36 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:43:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:43:36 --> Final output sent to browser
DEBUG - 2014-07-14 12:43:36 --> Total execution time: 0.0906
DEBUG - 2014-07-14 12:44:25 --> Config Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:44:25 --> URI Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Router Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Output Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Security Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Input Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:44:25 --> Language Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Loader Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:44:25 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:44:25 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Session Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:44:25 --> Session routines successfully run
DEBUG - 2014-07-14 12:44:25 --> Upload Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Controller Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:44:25 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Model Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Model Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Model Class Initialized
DEBUG - 2014-07-14 12:44:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:44:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:44:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:44:25 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:44:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:44:25 --> Final output sent to browser
DEBUG - 2014-07-14 12:44:25 --> Total execution time: 0.0927
DEBUG - 2014-07-14 12:48:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:48:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:48:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:48:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:48:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:48:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:48:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:48:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:48:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:48:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:48:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:48:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:48:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:48:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:48:19 --> Total execution time: 0.0800
DEBUG - 2014-07-14 12:56:52 --> Config Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:56:52 --> URI Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Router Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Output Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Security Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Input Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:56:52 --> Language Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Loader Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:56:52 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Session Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:56:52 --> Session routines successfully run
DEBUG - 2014-07-14 12:56:52 --> Upload Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Controller Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:56:52 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Model Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Model Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Model Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:56:52 --> Config Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:56:52 --> URI Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Router Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Output Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Security Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Input Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:56:52 --> Language Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Loader Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:56:52 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Session Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:56:52 --> Session routines successfully run
DEBUG - 2014-07-14 12:56:52 --> Upload Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Controller Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:56:52 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Model Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Model Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Model Class Initialized
DEBUG - 2014-07-14 12:56:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:56:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:56:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:56:52 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:56:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:56:52 --> Final output sent to browser
DEBUG - 2014-07-14 12:56:52 --> Total execution time: 0.0895
DEBUG - 2014-07-14 12:57:14 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:14 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:14 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:14 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:14 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:14 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:14 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:14 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:14 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:14 --> Total execution time: 0.1205
DEBUG - 2014-07-14 12:57:15 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:15 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:15 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:15 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:15 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:16 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:16 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:16 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:16 --> Total execution time: 0.1080
DEBUG - 2014-07-14 12:57:16 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:16 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:16 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:16 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:16 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:16 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:16 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:16 --> Total execution time: 0.1261
DEBUG - 2014-07-14 12:57:16 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:16 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:16 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:16 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:16 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:16 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:16 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:16 --> Total execution time: 0.0896
DEBUG - 2014-07-14 12:57:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:17 --> Total execution time: 0.1122
DEBUG - 2014-07-14 12:57:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:17 --> Total execution time: 0.0838
DEBUG - 2014-07-14 12:57:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:17 --> Total execution time: 0.1043
DEBUG - 2014-07-14 12:57:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:17 --> Total execution time: 0.1049
DEBUG - 2014-07-14 12:57:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:17 --> Total execution time: 0.0968
DEBUG - 2014-07-14 12:57:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:18 --> Total execution time: 0.0954
DEBUG - 2014-07-14 12:57:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:18 --> Total execution time: 0.0901
DEBUG - 2014-07-14 12:57:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:18 --> Total execution time: 0.0842
DEBUG - 2014-07-14 12:57:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:18 --> Total execution time: 0.1140
DEBUG - 2014-07-14 12:57:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:18 --> Total execution time: 0.0908
DEBUG - 2014-07-14 12:57:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:19 --> Total execution time: 0.0946
DEBUG - 2014-07-14 12:57:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:19 --> Total execution time: 0.1148
DEBUG - 2014-07-14 12:57:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:19 --> Total execution time: 0.0941
DEBUG - 2014-07-14 12:57:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:19 --> Total execution time: 0.1032
DEBUG - 2014-07-14 12:57:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:57:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:57:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:57:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:57:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:57:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:57:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:57:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:57:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:57:19 --> Total execution time: 0.0927
DEBUG - 2014-07-14 12:58:16 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:16 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:16 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:16 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:16 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:16 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:16 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:16 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:16 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:16 --> Total execution time: 0.0984
DEBUG - 2014-07-14 12:58:16 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:17 --> Total execution time: 0.1277
DEBUG - 2014-07-14 12:58:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:17 --> Total execution time: 0.1162
DEBUG - 2014-07-14 12:58:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:17 --> Total execution time: 0.0939
DEBUG - 2014-07-14 12:58:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:17 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:17 --> Total execution time: 0.0884
DEBUG - 2014-07-14 12:58:17 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:17 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:17 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:17 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:17 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:17 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:18 --> Total execution time: 0.0945
DEBUG - 2014-07-14 12:58:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:18 --> Total execution time: 0.0965
DEBUG - 2014-07-14 12:58:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:18 --> Total execution time: 0.1014
DEBUG - 2014-07-14 12:58:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:18 --> Total execution time: 0.0911
DEBUG - 2014-07-14 12:58:18 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:18 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:18 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:18 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:18 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:18 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:18 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:18 --> Total execution time: 0.1096
DEBUG - 2014-07-14 12:58:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:19 --> Total execution time: 0.1111
DEBUG - 2014-07-14 12:58:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:19 --> Total execution time: 0.0971
DEBUG - 2014-07-14 12:58:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:19 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:19 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:19 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:19 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:19 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:19 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:19 --> Total execution time: 0.1136
DEBUG - 2014-07-14 12:58:19 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:19 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:20 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:20 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:20 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:20 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:20 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:20 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:20 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:20 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:20 --> Total execution time: 0.1365
DEBUG - 2014-07-14 12:58:20 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:20 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:20 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:20 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:20 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:20 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:20 --> Total execution time: 0.0973
DEBUG - 2014-07-14 12:58:20 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:20 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:20 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:20 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:20 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:20 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:20 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:20 --> Total execution time: 0.0946
DEBUG - 2014-07-14 12:58:20 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:20 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:20 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:20 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:20 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:20 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:20 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:20 --> Total execution time: 0.1027
DEBUG - 2014-07-14 12:58:20 --> Config Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 12:58:20 --> URI Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Router Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Output Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Security Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Input Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 12:58:20 --> Language Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Loader Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: file_helper
DEBUG - 2014-07-14 12:58:20 --> Database Driver Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 12:58:20 --> Session routines successfully run
DEBUG - 2014-07-14 12:58:20 --> Upload Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Pagination Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Controller Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 12:58:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Model Class Initialized
DEBUG - 2014-07-14 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-14 12:58:20 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-14 12:58:20 --> Final output sent to browser
DEBUG - 2014-07-14 12:58:20 --> Total execution time: 0.0846

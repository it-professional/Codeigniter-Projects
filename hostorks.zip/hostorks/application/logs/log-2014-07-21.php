<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-21 05:55:03 --> Config Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:55:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:55:03 --> URI Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Router Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Output Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Security Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Input Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:55:03 --> Language Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Loader Class Initialized
DEBUG - 2014-07-21 05:55:03 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:55:03 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:55:03 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Session Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:55:04 --> A session cookie was not found.
DEBUG - 2014-07-21 05:55:04 --> Session routines successfully run
DEBUG - 2014-07-21 05:55:04 --> Upload Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Controller Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:55:04 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:55:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 05:55:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 05:55:04 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-21 05:55:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 05:55:04 --> Final output sent to browser
DEBUG - 2014-07-21 05:55:04 --> Total execution time: 0.3018
DEBUG - 2014-07-21 05:55:07 --> Config Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:55:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:55:07 --> URI Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Router Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Output Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Security Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Input Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:55:07 --> Language Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Loader Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:55:07 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:55:07 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Session Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:55:07 --> Session routines successfully run
DEBUG - 2014-07-21 05:55:07 --> Upload Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Controller Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:55:07 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:55:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 05:55:07 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 05:55:07 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 05:55:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 05:55:07 --> Final output sent to browser
DEBUG - 2014-07-21 05:55:07 --> Total execution time: 0.1268
DEBUG - 2014-07-21 05:55:55 --> Config Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:55:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:55:55 --> URI Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Router Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Output Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Security Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Input Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:55:55 --> Language Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Loader Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:55:55 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Session Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:55:55 --> Session routines successfully run
DEBUG - 2014-07-21 05:55:55 --> Upload Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Controller Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:55:55 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:55:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:55:55 --> Config Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:55:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:55:55 --> URI Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Router Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Output Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Security Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Input Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:55:55 --> Language Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Loader Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:55:55 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Session Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:55:55 --> Session routines successfully run
DEBUG - 2014-07-21 05:55:55 --> Upload Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Controller Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:55:55 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Model Class Initialized
DEBUG - 2014-07-21 05:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:55:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 05:55:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 05:55:55 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 05:55:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 05:55:55 --> Final output sent to browser
DEBUG - 2014-07-21 05:55:55 --> Total execution time: 0.0900
DEBUG - 2014-07-21 05:56:01 --> Config Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:56:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:56:01 --> URI Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Router Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Output Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Security Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Input Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:56:01 --> Language Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Loader Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:56:01 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:56:01 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Session Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:56:01 --> Session routines successfully run
DEBUG - 2014-07-21 05:56:01 --> Upload Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Controller Class Initialized
DEBUG - 2014-07-21 05:56:01 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:56:02 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:02 --> Config Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:56:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:56:02 --> URI Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Router Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Output Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Security Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Input Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:56:02 --> Language Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Loader Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:56:02 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:56:02 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Session Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:56:02 --> Session routines successfully run
DEBUG - 2014-07-21 05:56:02 --> Upload Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Controller Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:56:02 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:02 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 05:56:02 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 05:56:02 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 05:56:02 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 05:56:02 --> Final output sent to browser
DEBUG - 2014-07-21 05:56:02 --> Total execution time: 0.0949
DEBUG - 2014-07-21 05:56:08 --> Config Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:56:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:56:08 --> URI Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Router Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Output Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Security Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Input Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:56:08 --> Language Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Loader Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:56:08 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:56:08 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Session Class Initialized
DEBUG - 2014-07-21 05:56:08 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:56:08 --> Session routines successfully run
DEBUG - 2014-07-21 05:56:09 --> Upload Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Controller Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:56:09 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:09 --> Config Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:56:09 --> URI Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Router Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Output Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Security Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Input Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:56:09 --> Language Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Loader Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:56:09 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:56:09 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Session Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:56:09 --> Session routines successfully run
DEBUG - 2014-07-21 05:56:09 --> Upload Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Controller Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:56:09 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 05:56:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 05:56:09 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 05:56:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 05:56:09 --> Final output sent to browser
DEBUG - 2014-07-21 05:56:09 --> Total execution time: 0.0865
DEBUG - 2014-07-21 05:56:13 --> Config Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:56:13 --> URI Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Router Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Output Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Security Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Input Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:56:13 --> Language Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Loader Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:56:13 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Session Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:56:13 --> Session routines successfully run
DEBUG - 2014-07-21 05:56:13 --> Upload Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Controller Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:56:13 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:13 --> Config Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Hooks Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Utf8 Class Initialized
DEBUG - 2014-07-21 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 05:56:13 --> URI Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Router Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Output Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Security Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Input Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 05:56:13 --> Language Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Loader Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: url_helper
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: file_helper
DEBUG - 2014-07-21 05:56:13 --> Database Driver Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Session Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: string_helper
DEBUG - 2014-07-21 05:56:13 --> Session routines successfully run
DEBUG - 2014-07-21 05:56:13 --> Upload Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Pagination Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Controller Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Helper loaded: form_helper
DEBUG - 2014-07-21 05:56:13 --> Form Validation Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Model Class Initialized
DEBUG - 2014-07-21 05:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 05:56:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 05:56:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 05:56:13 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 05:56:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 05:56:13 --> Final output sent to browser
DEBUG - 2014-07-21 05:56:13 --> Total execution time: 0.0799
DEBUG - 2014-07-21 06:23:15 --> Config Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Hooks Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Utf8 Class Initialized
DEBUG - 2014-07-21 06:23:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 06:23:15 --> URI Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Router Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Output Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Security Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Input Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 06:23:15 --> Language Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Loader Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Helper loaded: url_helper
DEBUG - 2014-07-21 06:23:15 --> Helper loaded: file_helper
DEBUG - 2014-07-21 06:23:15 --> Database Driver Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Session Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Helper loaded: string_helper
DEBUG - 2014-07-21 06:23:15 --> Session routines successfully run
DEBUG - 2014-07-21 06:23:15 --> Upload Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Pagination Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Controller Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Helper loaded: form_helper
DEBUG - 2014-07-21 06:23:15 --> Form Validation Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Model Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Model Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Model Class Initialized
DEBUG - 2014-07-21 06:23:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 06:23:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 06:23:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 06:23:15 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 06:23:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 06:23:15 --> Final output sent to browser
DEBUG - 2014-07-21 06:23:15 --> Total execution time: 0.0874
DEBUG - 2014-07-21 07:05:42 --> Config Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:05:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:05:42 --> URI Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Router Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Output Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Security Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Input Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:05:42 --> Language Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Loader Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:05:42 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:05:42 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Session Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:05:42 --> Session routines successfully run
DEBUG - 2014-07-21 07:05:42 --> Upload Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Controller Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:05:42 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Model Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Model Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Model Class Initialized
DEBUG - 2014-07-21 07:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:05:42 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:05:42 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:05:42 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 07:05:42 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:05:42 --> Final output sent to browser
DEBUG - 2014-07-21 07:05:42 --> Total execution time: 0.1138
DEBUG - 2014-07-21 07:06:10 --> Config Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:06:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:06:10 --> URI Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Router Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Output Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Security Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Input Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:06:10 --> Language Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Loader Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:06:10 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Session Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:06:10 --> Session routines successfully run
DEBUG - 2014-07-21 07:06:10 --> Upload Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Controller Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:06:10 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:06:10 --> Config Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:06:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:06:10 --> URI Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Router Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Output Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Security Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Input Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:06:10 --> Language Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Loader Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:06:10 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Session Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:06:10 --> Session routines successfully run
DEBUG - 2014-07-21 07:06:10 --> Upload Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Controller Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:06:10 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:06:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:06:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:06:10 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 07:06:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:06:10 --> Final output sent to browser
DEBUG - 2014-07-21 07:06:10 --> Total execution time: 0.1271
DEBUG - 2014-07-21 07:06:37 --> Config Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:06:37 --> URI Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Router Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Output Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Security Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Input Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:06:37 --> Language Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Loader Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:06:37 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Session Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:06:37 --> Session routines successfully run
DEBUG - 2014-07-21 07:06:37 --> Upload Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Controller Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:06:37 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:06:37 --> Config Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:06:37 --> URI Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Router Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Output Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Security Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Input Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:06:37 --> Language Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Loader Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:06:37 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Session Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:06:37 --> Session routines successfully run
DEBUG - 2014-07-21 07:06:37 --> Upload Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Controller Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:06:37 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:06:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:06:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:06:37 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 07:06:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:06:37 --> Final output sent to browser
DEBUG - 2014-07-21 07:06:37 --> Total execution time: 0.1093
DEBUG - 2014-07-21 07:06:58 --> Config Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:06:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:06:58 --> URI Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Router Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Output Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Security Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Input Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:06:58 --> Language Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Loader Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:06:58 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:06:58 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Session Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:06:58 --> Session routines successfully run
DEBUG - 2014-07-21 07:06:58 --> Upload Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Controller Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:06:58 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:06:59 --> Config Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:06:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:06:59 --> URI Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Router Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Output Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Security Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Input Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:06:59 --> Language Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Loader Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:06:59 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:06:59 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Session Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:06:59 --> Session routines successfully run
DEBUG - 2014-07-21 07:06:59 --> Upload Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Controller Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:06:59 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Model Class Initialized
DEBUG - 2014-07-21 07:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:06:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:06:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:06:59 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 07:06:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:06:59 --> Final output sent to browser
DEBUG - 2014-07-21 07:06:59 --> Total execution time: 0.1045
DEBUG - 2014-07-21 07:08:06 --> Config Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:08:06 --> URI Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Router Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Output Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Security Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Input Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:08:06 --> Language Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Loader Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:08:06 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Session Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:08:06 --> Session routines successfully run
DEBUG - 2014-07-21 07:08:06 --> Upload Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Controller Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:08:06 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:08:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-21 07:08:06 --> Config Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:08:06 --> URI Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Router Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Output Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Security Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Input Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:08:06 --> Language Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Loader Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:08:06 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Session Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:08:06 --> Session routines successfully run
DEBUG - 2014-07-21 07:08:06 --> Upload Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Controller Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:08:06 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:08:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:08:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:08:06 --> File loaded: application/views/superadmin/header_manage.php
DEBUG - 2014-07-21 07:08:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:08:06 --> Final output sent to browser
DEBUG - 2014-07-21 07:08:06 --> Total execution time: 0.0998
DEBUG - 2014-07-21 07:08:10 --> Config Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:08:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:08:10 --> URI Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Router Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Output Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Security Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Input Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:08:10 --> Language Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Loader Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:08:10 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:08:10 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Session Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:08:10 --> Session routines successfully run
DEBUG - 2014-07-21 07:08:10 --> Upload Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Controller Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:08:10 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Model Class Initialized
DEBUG - 2014-07-21 07:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:08:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:08:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:08:10 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 07:08:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:08:10 --> Final output sent to browser
DEBUG - 2014-07-21 07:08:10 --> Total execution time: 0.1187
DEBUG - 2014-07-21 07:42:23 --> Config Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Hooks Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Utf8 Class Initialized
DEBUG - 2014-07-21 07:42:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 07:42:23 --> URI Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Router Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Output Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Security Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Input Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 07:42:23 --> Language Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Loader Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Helper loaded: url_helper
DEBUG - 2014-07-21 07:42:23 --> Helper loaded: file_helper
DEBUG - 2014-07-21 07:42:23 --> Database Driver Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Session Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Helper loaded: string_helper
DEBUG - 2014-07-21 07:42:23 --> Session routines successfully run
DEBUG - 2014-07-21 07:42:23 --> Upload Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Pagination Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Controller Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Helper loaded: form_helper
DEBUG - 2014-07-21 07:42:23 --> Form Validation Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Model Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Model Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Model Class Initialized
DEBUG - 2014-07-21 07:42:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 07:42:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 07:42:23 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 07:42:23 --> File loaded: application/views/superadmin/footer_manage.php
DEBUG - 2014-07-21 07:42:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 07:42:23 --> Final output sent to browser
DEBUG - 2014-07-21 07:42:23 --> Total execution time: 0.0908
DEBUG - 2014-07-21 11:53:20 --> Config Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Hooks Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Utf8 Class Initialized
DEBUG - 2014-07-21 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 11:53:20 --> URI Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Router Class Initialized
DEBUG - 2014-07-21 11:53:20 --> No URI present. Default controller set.
DEBUG - 2014-07-21 11:53:20 --> Output Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Security Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Input Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 11:53:20 --> Language Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Loader Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Helper loaded: url_helper
DEBUG - 2014-07-21 11:53:20 --> Helper loaded: file_helper
DEBUG - 2014-07-21 11:53:20 --> Database Driver Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Session Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Helper loaded: string_helper
DEBUG - 2014-07-21 11:53:20 --> A session cookie was not found.
DEBUG - 2014-07-21 11:53:20 --> Session routines successfully run
DEBUG - 2014-07-21 11:53:20 --> Upload Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Pagination Class Initialized
DEBUG - 2014-07-21 11:53:20 --> Controller Class Initialized
DEBUG - 2014-07-21 11:53:20 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-21 11:53:20 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-21 11:53:20 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-21 11:53:20 --> Final output sent to browser
DEBUG - 2014-07-21 11:53:20 --> Total execution time: 0.1235
DEBUG - 2014-07-21 11:53:24 --> Config Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Hooks Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Utf8 Class Initialized
DEBUG - 2014-07-21 11:53:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 11:53:24 --> URI Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Router Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Output Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Security Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Input Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 11:53:24 --> Language Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Loader Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Helper loaded: url_helper
DEBUG - 2014-07-21 11:53:24 --> Helper loaded: file_helper
DEBUG - 2014-07-21 11:53:24 --> Database Driver Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Session Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Helper loaded: string_helper
DEBUG - 2014-07-21 11:53:24 --> Session routines successfully run
DEBUG - 2014-07-21 11:53:24 --> Upload Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Pagination Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Controller Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Helper loaded: form_helper
DEBUG - 2014-07-21 11:53:24 --> Form Validation Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 11:53:24 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-21 11:53:24 --> Final output sent to browser
DEBUG - 2014-07-21 11:53:24 --> Total execution time: 0.1007
DEBUG - 2014-07-21 11:53:28 --> Config Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Hooks Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Utf8 Class Initialized
DEBUG - 2014-07-21 11:53:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 11:53:28 --> URI Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Router Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Output Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Security Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Input Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 11:53:28 --> Language Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Loader Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Helper loaded: url_helper
DEBUG - 2014-07-21 11:53:28 --> Helper loaded: file_helper
DEBUG - 2014-07-21 11:53:28 --> Database Driver Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Session Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Helper loaded: string_helper
DEBUG - 2014-07-21 11:53:28 --> Session routines successfully run
DEBUG - 2014-07-21 11:53:28 --> Upload Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Pagination Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Controller Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Helper loaded: form_helper
DEBUG - 2014-07-21 11:53:28 --> Form Validation Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 11:53:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 11:53:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 11:53:28 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-21 11:53:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 11:53:28 --> Final output sent to browser
DEBUG - 2014-07-21 11:53:28 --> Total execution time: 0.1024
DEBUG - 2014-07-21 11:53:38 --> Config Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Hooks Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Utf8 Class Initialized
DEBUG - 2014-07-21 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 11:53:38 --> URI Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Router Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Output Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Security Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Input Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 11:53:38 --> Language Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Loader Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Helper loaded: url_helper
DEBUG - 2014-07-21 11:53:38 --> Helper loaded: file_helper
DEBUG - 2014-07-21 11:53:38 --> Database Driver Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Session Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Helper loaded: string_helper
DEBUG - 2014-07-21 11:53:38 --> Session routines successfully run
DEBUG - 2014-07-21 11:53:38 --> Upload Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Pagination Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Controller Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Helper loaded: form_helper
DEBUG - 2014-07-21 11:53:38 --> Form Validation Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Model Class Initialized
DEBUG - 2014-07-21 11:53:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-21 11:53:38 --> 404 Page Not Found --> 
DEBUG - 2014-07-21 12:50:45 --> Config Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Hooks Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Utf8 Class Initialized
DEBUG - 2014-07-21 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-21 12:50:45 --> URI Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Router Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Output Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Security Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Input Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-21 12:50:45 --> Language Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Loader Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Helper loaded: url_helper
DEBUG - 2014-07-21 12:50:45 --> Helper loaded: file_helper
DEBUG - 2014-07-21 12:50:45 --> Database Driver Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Session Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Helper loaded: string_helper
DEBUG - 2014-07-21 12:50:45 --> Session routines successfully run
DEBUG - 2014-07-21 12:50:45 --> Upload Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Pagination Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Controller Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Helper loaded: form_helper
DEBUG - 2014-07-21 12:50:45 --> Form Validation Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Model Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Model Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Model Class Initialized
DEBUG - 2014-07-21 12:50:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-21 12:50:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-21 12:50:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-21 12:50:45 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-21 12:50:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-21 12:50:45 --> Final output sent to browser
DEBUG - 2014-07-21 12:50:45 --> Total execution time: 0.1030

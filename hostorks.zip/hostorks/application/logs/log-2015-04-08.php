<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-08 14:15:52 --> Config Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Hooks Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Utf8 Class Initialized
DEBUG - 2015-04-08 14:15:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 14:15:52 --> URI Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Router Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Output Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Security Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Input Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 14:15:52 --> Language Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Loader Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Helper loaded: url_helper
DEBUG - 2015-04-08 14:15:52 --> Helper loaded: file_helper
DEBUG - 2015-04-08 14:15:52 --> Database Driver Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Session Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Helper loaded: string_helper
DEBUG - 2015-04-08 14:15:52 --> A session cookie was not found.
DEBUG - 2015-04-08 14:15:52 --> Session routines successfully run
DEBUG - 2015-04-08 14:15:52 --> Upload Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Pagination Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Controller Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Helper loaded: form_helper
DEBUG - 2015-04-08 14:15:52 --> Form Validation Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Model Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Model Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Model Class Initialized
DEBUG - 2015-04-08 14:15:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2015-04-08 14:15:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2015-04-08 14:15:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2015-04-08 14:15:52 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2015-04-08 14:15:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2015-04-08 14:15:52 --> Final output sent to browser
DEBUG - 2015-04-08 14:15:52 --> Total execution time: 0.2921
DEBUG - 2015-04-08 14:19:29 --> Config Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Hooks Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Utf8 Class Initialized
DEBUG - 2015-04-08 14:19:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 14:19:29 --> URI Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Router Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Output Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Security Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Input Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 14:19:29 --> Language Class Initialized
DEBUG - 2015-04-08 14:19:29 --> Loader Class Initialized
DEBUG - 2015-04-08 14:19:30 --> Helper loaded: url_helper
DEBUG - 2015-04-08 14:19:30 --> Helper loaded: file_helper
DEBUG - 2015-04-08 14:19:30 --> Database Driver Class Initialized
DEBUG - 2015-04-08 14:19:30 --> Session Class Initialized
DEBUG - 2015-04-08 14:19:30 --> Helper loaded: string_helper
DEBUG - 2015-04-08 14:19:30 --> Session routines successfully run
DEBUG - 2015-04-08 14:19:30 --> Upload Class Initialized
DEBUG - 2015-04-08 14:19:30 --> Pagination Class Initialized
DEBUG - 2015-04-08 14:19:30 --> Controller Class Initialized
ERROR - 2015-04-08 14:19:30 --> 404 Page Not Found --> 

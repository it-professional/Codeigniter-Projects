<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-22 05:39:59 --> Config Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Hooks Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Utf8 Class Initialized
DEBUG - 2014-07-22 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 05:39:59 --> URI Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Router Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Output Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Security Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Input Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 05:39:59 --> Language Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Loader Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Helper loaded: url_helper
DEBUG - 2014-07-22 05:39:59 --> Helper loaded: file_helper
DEBUG - 2014-07-22 05:39:59 --> Database Driver Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Session Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Helper loaded: string_helper
DEBUG - 2014-07-22 05:39:59 --> A session cookie was not found.
DEBUG - 2014-07-22 05:39:59 --> Session routines successfully run
DEBUG - 2014-07-22 05:39:59 --> Upload Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Pagination Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Controller Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Helper loaded: form_helper
DEBUG - 2014-07-22 05:39:59 --> Form Validation Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Model Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Model Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Model Class Initialized
DEBUG - 2014-07-22 05:39:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 05:39:59 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 05:39:59 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 05:39:59 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-22 05:39:59 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 05:39:59 --> Final output sent to browser
DEBUG - 2014-07-22 05:39:59 --> Total execution time: 0.2671
DEBUG - 2014-07-22 05:48:06 --> Config Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Hooks Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Utf8 Class Initialized
DEBUG - 2014-07-22 05:48:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 05:48:06 --> URI Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Router Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Output Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Security Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Input Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 05:48:06 --> Language Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Loader Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Helper loaded: url_helper
DEBUG - 2014-07-22 05:48:06 --> Helper loaded: file_helper
DEBUG - 2014-07-22 05:48:06 --> Database Driver Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Session Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Helper loaded: string_helper
DEBUG - 2014-07-22 05:48:06 --> Session routines successfully run
DEBUG - 2014-07-22 05:48:06 --> Upload Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Pagination Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Controller Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Helper loaded: form_helper
DEBUG - 2014-07-22 05:48:06 --> Form Validation Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Model Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Model Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Model Class Initialized
DEBUG - 2014-07-22 05:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 05:48:06 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 05:48:06 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 05:48:06 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 05:48:06 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 05:48:06 --> Final output sent to browser
DEBUG - 2014-07-22 05:48:06 --> Total execution time: 0.1200
DEBUG - 2014-07-22 06:01:23 --> Config Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:01:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:01:23 --> URI Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Router Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Output Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Security Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Input Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:01:23 --> Language Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Loader Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:01:23 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:01:23 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Session Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:01:23 --> Session routines successfully run
DEBUG - 2014-07-22 06:01:23 --> Upload Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Controller Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:01:23 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Model Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Model Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Model Class Initialized
DEBUG - 2014-07-22 06:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:01:23 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:01:23 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:01:23 --> Severity: Notice  --> Undefined variable: bigtitle F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 23
ERROR - 2014-07-22 06:01:23 --> Severity: Notice  --> Undefined variable: option_heading F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 32
DEBUG - 2014-07-22 06:01:23 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:01:23 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:01:23 --> Final output sent to browser
DEBUG - 2014-07-22 06:01:23 --> Total execution time: 0.1080
DEBUG - 2014-07-22 06:01:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:01:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:01:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:01:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:01:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:01:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:01:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:01:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:01:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:01:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:01:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:01:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:01:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:01:37 --> Total execution time: 0.0837
DEBUG - 2014-07-22 06:19:07 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:07 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:07 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:07 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:07 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:07 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:07 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:07 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:07 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:07 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:07 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:07 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:07 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:07 --> Total execution time: 0.0984
DEBUG - 2014-07-22 06:19:07 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:07 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:07 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:07 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:07 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:07 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:07 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:07 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:09 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:09 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:09 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:09 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:09 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:09 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:09 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:09 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:09 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:09 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:09 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:09 --> Total execution time: 0.0870
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:10 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
ERROR - 2014-07-22 06:19:10 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:10 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:10 --> Total execution time: 0.1455
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:10 --> Total execution time: 0.1996
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:10 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:10 --> Total execution time: 0.0979
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
ERROR - 2014-07-22 06:19:10 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:10 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:10 --> Total execution time: 0.0992
DEBUG - 2014-07-22 06:19:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
ERROR - 2014-07-22 06:19:11 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:11 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:11 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:11 --> Total execution time: 0.1346
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:11 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:11 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:11 --> Total execution time: 0.0766
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:11 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:11 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:11 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:11 --> Total execution time: 0.1006
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:11 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:11 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:11 --> Total execution time: 0.0842
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:11 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:11 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:11 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:12 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:12 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:12 --> Total execution time: 0.1102
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:12 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:12 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:12 --> Total execution time: 0.0897
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
ERROR - 2014-07-22 06:19:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:12 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:12 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:12 --> Total execution time: 0.0917
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:12 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:12 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:12 --> Total execution time: 0.1190
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:12 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:12 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:12 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:12 --> Total execution time: 0.0838
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:12 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:12 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:12 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:12 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:12 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:12 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:19:12 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:12 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:12 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:13 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:13 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:13 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:13 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:13 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:19:13 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:13 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Security Class Initialized
ERROR - 2014-07-22 06:19:13 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:13 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:13 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:13 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Total execution time: 0.1408
DEBUG - 2014-07-22 06:19:13 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:13 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:13 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:13 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:13 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/includes/header.php
ERROR - 2014-07-22 06:19:13 --> Severity: Notice  --> Undefined variable: base_url F:\wamp\www\hostorks\application\views\superadmin\home_slider.php 14
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:19:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:19:13 --> Final output sent to browser
DEBUG - 2014-07-22 06:19:13 --> Total execution time: 0.0902
DEBUG - 2014-07-22 06:19:13 --> Config Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:19:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:19:13 --> URI Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Router Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Output Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Security Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Input Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:19:13 --> Language Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Loader Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:19:13 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Session Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:19:13 --> Session routines successfully run
DEBUG - 2014-07-22 06:19:13 --> Upload Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Controller Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:19:13 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Model Class Initialized
DEBUG - 2014-07-22 06:19:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:19:13 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:24 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:24 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:24 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:24 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:24 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:24 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:24 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:24 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:24 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:24 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:24 --> Total execution time: 0.0648
DEBUG - 2014-07-22 06:20:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:36 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:36 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:36 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:36 --> Total execution time: 0.0781
DEBUG - 2014-07-22 06:20:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:36 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:36 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:36 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:36 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Total execution time: 0.1312
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:37 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:37 --> Total execution time: 0.0861
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:37 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:37 --> Total execution time: 0.1234
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:37 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:37 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:37 --> Total execution time: 0.0847
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:37 --> Total execution time: 0.0980
DEBUG - 2014-07-22 06:20:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:37 --> Total execution time: 0.0863
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:38 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:38 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:38 --> Total execution time: 0.2119
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:38 --> Total execution time: 0.0860
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:38 --> Total execution time: 0.0872
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:38 --> Total execution time: 0.0786
DEBUG - 2014-07-22 06:20:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:38 --> Total execution time: 0.0849
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:20:39 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Model Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:20:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:20:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:20:39 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:20:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:20:39 --> Final output sent to browser
DEBUG - 2014-07-22 06:20:39 --> Total execution time: 0.0769
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:20:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:20:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:20:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:20:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:20:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:20:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:20:39 --> Controller Class Initialized
ERROR - 2014-07-22 06:20:39 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:24 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:24 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:24 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:24 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:24 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:24 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:24 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Controller Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:21:24 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Model Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Model Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Model Class Initialized
DEBUG - 2014-07-22 06:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:21:24 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:21:24 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:21:24 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:21:24 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:21:24 --> Final output sent to browser
DEBUG - 2014-07-22 06:21:24 --> Total execution time: 0.1632
DEBUG - 2014-07-22 06:21:25 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:25 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:25 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:25 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:25 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:25 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:25 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Config Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> URI Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Router Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Output Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Security Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Input Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Language Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Loader Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:21:26 --> Session Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:21:26 --> Session routines successfully run
DEBUG - 2014-07-22 06:21:26 --> Upload Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:21:26 --> Controller Class Initialized
ERROR - 2014-07-22 06:21:26 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:54 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:54 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:54 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:54 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:29:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:29:54 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:29:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:29:54 --> Final output sent to browser
DEBUG - 2014-07-22 06:29:54 --> Total execution time: 0.1027
DEBUG - 2014-07-22 06:29:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:55 --> Security Class Initialized
ERROR - 2014-07-22 06:29:55 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: string_helper
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:56 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:56 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Controller Class Initialized
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:56 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:56 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:56 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:56 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Config Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:29:57 --> URI Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Router Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:57 --> Output Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Security Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Input Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Language Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Loader Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:29:57 --> Database Driver Class Initialized
ERROR - 2014-07-22 06:29:57 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:57 --> Controller Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:29:57 --> Session routines successfully run
DEBUG - 2014-07-22 06:29:57 --> Upload Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:57 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:29:57 --> Controller Class Initialized
ERROR - 2014-07-22 06:29:57 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:29:57 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:29:57 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Model Class Initialized
DEBUG - 2014-07-22 06:29:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:29:57 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:08 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:08 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:08 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:08 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:08 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:08 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:08 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:08 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:08 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:08 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:08 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:08 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:08 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:08 --> Total execution time: 0.1361
DEBUG - 2014-07-22 06:33:09 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:09 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:09 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:09 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:09 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:09 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:09 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:09 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:09 --> Total execution time: 0.0999
DEBUG - 2014-07-22 06:33:09 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:09 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:09 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:09 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:09 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:09 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:09 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:09 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:09 --> Total execution time: 0.1048
DEBUG - 2014-07-22 06:33:09 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:09 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:09 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:09 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:09 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:09 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:09 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:09 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:09 --> Total execution time: 0.1100
DEBUG - 2014-07-22 06:33:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:10 --> Total execution time: 0.0956
DEBUG - 2014-07-22 06:33:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:10 --> Total execution time: 0.1045
DEBUG - 2014-07-22 06:33:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:10 --> Total execution time: 0.0922
DEBUG - 2014-07-22 06:33:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:10 --> Total execution time: 0.1134
DEBUG - 2014-07-22 06:33:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:10 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:10 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:10 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:10 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:10 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:10 --> Total execution time: 0.0915
DEBUG - 2014-07-22 06:33:10 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:10 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:11 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:11 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:11 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:33:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:33:11 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:33:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:33:11 --> Final output sent to browser
DEBUG - 2014-07-22 06:33:11 --> Total execution time: 0.0944
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:16 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:16 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:16 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:16 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:16 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:16 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:16 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:16 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:16 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Pagination Class Initialized
ERROR - 2014-07-22 06:33:16 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:16 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Utf8 Class Initialized
ERROR - 2014-07-22 06:33:16 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
ERROR - 2014-07-22 06:33:16 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:16 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:16 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:16 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:16 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:17 --> UTF-8 Support Enabled
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:17 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:17 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:17 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:17 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Config Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> URI Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Router Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Output Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Security Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Input Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Language Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Loader Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Session Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:33:18 --> Session routines successfully run
DEBUG - 2014-07-22 06:33:18 --> Upload Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Controller Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:33:18 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:33:18 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Model Class Initialized
DEBUG - 2014-07-22 06:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-22 06:33:18 --> 404 Page Not Found --> 
DEBUG - 2014-07-22 06:34:04 --> Config Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:34:04 --> URI Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Router Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Output Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Security Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Input Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:34:04 --> Language Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Loader Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:34:04 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:34:04 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Session Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:34:04 --> Session routines successfully run
DEBUG - 2014-07-22 06:34:04 --> Upload Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Controller Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:34:04 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Model Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Model Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Model Class Initialized
DEBUG - 2014-07-22 06:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:34:04 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:34:04 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:34:04 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:34:04 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:34:04 --> Final output sent to browser
DEBUG - 2014-07-22 06:34:04 --> Total execution time: 0.0882
DEBUG - 2014-07-22 06:34:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:34:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:34:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:34:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:34:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:34:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:34:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:34:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:34:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:34:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:34:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:34:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:34:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:34:37 --> Total execution time: 0.0820
DEBUG - 2014-07-22 06:36:27 --> Config Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:36:27 --> URI Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Router Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Output Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Security Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Input Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:36:27 --> Language Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Loader Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:36:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:36:27 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Session Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:36:27 --> Session routines successfully run
DEBUG - 2014-07-22 06:36:27 --> Upload Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Controller Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:36:27 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Model Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Model Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Model Class Initialized
DEBUG - 2014-07-22 06:36:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:36:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:36:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:36:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:36:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:36:27 --> Final output sent to browser
DEBUG - 2014-07-22 06:36:27 --> Total execution time: 0.1129
DEBUG - 2014-07-22 06:37:49 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:49 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:49 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:49 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:49 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:49 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:49 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:49 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:49 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:49 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:49 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:49 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:49 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:49 --> Total execution time: 0.0849
DEBUG - 2014-07-22 06:37:53 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:53 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:53 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:53 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:53 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:53 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:53 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:53 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:53 --> Total execution time: 0.0876
DEBUG - 2014-07-22 06:37:53 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:53 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:53 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:53 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:53 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:53 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:53 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:53 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:53 --> Total execution time: 0.1005
DEBUG - 2014-07-22 06:37:53 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:53 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:53 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:53 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:53 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:53 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:53 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:53 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:53 --> Total execution time: 0.0821
DEBUG - 2014-07-22 06:37:53 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:53 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:53 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:53 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:53 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:53 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:53 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:53 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:53 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:53 --> Total execution time: 0.1115
DEBUG - 2014-07-22 06:37:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:54 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:54 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:54 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:54 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:54 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:54 --> Total execution time: 0.0881
DEBUG - 2014-07-22 06:37:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:54 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:54 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:54 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:54 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:54 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:54 --> Total execution time: 0.0886
DEBUG - 2014-07-22 06:37:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:54 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:54 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:54 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:54 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:54 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:54 --> Total execution time: 0.0877
DEBUG - 2014-07-22 06:37:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:54 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:54 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:54 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:54 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:54 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:54 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:54 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:54 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:54 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:54 --> Total execution time: 0.2039
DEBUG - 2014-07-22 06:37:54 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:54 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:54 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:54 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:54 --> Total execution time: 0.1168
DEBUG - 2014-07-22 06:37:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:55 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:55 --> Total execution time: 0.0908
DEBUG - 2014-07-22 06:37:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:55 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:55 --> Total execution time: 0.1069
DEBUG - 2014-07-22 06:37:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:55 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:55 --> Total execution time: 0.0827
DEBUG - 2014-07-22 06:37:55 --> Config Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:37:55 --> URI Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Router Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Output Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Security Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Input Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:37:55 --> Language Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Loader Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:37:55 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:37:55 --> Session routines successfully run
DEBUG - 2014-07-22 06:37:55 --> Upload Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Controller Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:37:55 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Model Class Initialized
DEBUG - 2014-07-22 06:37:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:37:55 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:37:55 --> Final output sent to browser
DEBUG - 2014-07-22 06:37:55 --> Total execution time: 0.0753
DEBUG - 2014-07-22 06:39:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:36 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:36 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:36 --> Total execution time: 0.0869
DEBUG - 2014-07-22 06:39:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:36 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:36 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:36 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:36 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Total execution time: 0.1553
DEBUG - 2014-07-22 06:39:36 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:36 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:36 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:36 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:36 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:36 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:36 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:36 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:36 --> Total execution time: 0.1037
DEBUG - 2014-07-22 06:39:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:37 --> Total execution time: 0.0859
DEBUG - 2014-07-22 06:39:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:37 --> Total execution time: 0.1119
DEBUG - 2014-07-22 06:39:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:37 --> Total execution time: 0.0812
DEBUG - 2014-07-22 06:39:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:37 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:37 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:37 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:37 --> Total execution time: 0.0860
DEBUG - 2014-07-22 06:39:37 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:37 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:37 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:38 --> Total execution time: 0.1060
DEBUG - 2014-07-22 06:39:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:38 --> Total execution time: 0.0998
DEBUG - 2014-07-22 06:39:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:38 --> Total execution time: 0.0771
DEBUG - 2014-07-22 06:39:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:38 --> Total execution time: 0.0803
DEBUG - 2014-07-22 06:39:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:38 --> Total execution time: 0.1060
DEBUG - 2014-07-22 06:39:38 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:38 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:38 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:38 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:38 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:38 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:38 --> Total execution time: 0.0892
DEBUG - 2014-07-22 06:39:39 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:39 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:39 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:39 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:39 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:39 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:39 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:39 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:39 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:39 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:39 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:39 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:39 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:39 --> Total execution time: 0.0783
DEBUG - 2014-07-22 06:39:52 --> Config Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Hooks Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Utf8 Class Initialized
DEBUG - 2014-07-22 06:39:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 06:39:52 --> URI Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Router Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Output Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Security Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Input Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 06:39:52 --> Language Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Loader Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Helper loaded: url_helper
DEBUG - 2014-07-22 06:39:52 --> Helper loaded: file_helper
DEBUG - 2014-07-22 06:39:52 --> Database Driver Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Session Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Helper loaded: string_helper
DEBUG - 2014-07-22 06:39:52 --> Session routines successfully run
DEBUG - 2014-07-22 06:39:52 --> Upload Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Pagination Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Controller Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Helper loaded: form_helper
DEBUG - 2014-07-22 06:39:52 --> Form Validation Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Model Class Initialized
DEBUG - 2014-07-22 06:39:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 06:39:52 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 06:39:52 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 06:39:52 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 06:39:52 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 06:39:52 --> Final output sent to browser
DEBUG - 2014-07-22 06:39:52 --> Total execution time: 0.0765
DEBUG - 2014-07-22 08:28:09 --> Config Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Hooks Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Utf8 Class Initialized
DEBUG - 2014-07-22 08:28:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 08:28:09 --> URI Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Router Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Output Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Security Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Input Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 08:28:09 --> Language Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Loader Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Helper loaded: url_helper
DEBUG - 2014-07-22 08:28:09 --> Helper loaded: file_helper
DEBUG - 2014-07-22 08:28:09 --> Database Driver Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Session Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Helper loaded: string_helper
DEBUG - 2014-07-22 08:28:09 --> Session routines successfully run
DEBUG - 2014-07-22 08:28:09 --> Upload Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Pagination Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Controller Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Helper loaded: form_helper
DEBUG - 2014-07-22 08:28:09 --> Form Validation Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Model Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Model Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Model Class Initialized
DEBUG - 2014-07-22 08:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 08:28:09 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 08:28:09 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 08:28:09 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 08:28:09 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 08:28:09 --> Final output sent to browser
DEBUG - 2014-07-22 08:28:09 --> Total execution time: 0.1228
DEBUG - 2014-07-22 08:28:27 --> Config Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 08:28:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 08:28:27 --> URI Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Router Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Output Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Security Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Input Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 08:28:27 --> Language Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Loader Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 08:28:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 08:28:27 --> Database Driver Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Session Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Helper loaded: string_helper
DEBUG - 2014-07-22 08:28:27 --> Session routines successfully run
DEBUG - 2014-07-22 08:28:27 --> Upload Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Pagination Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Controller Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Helper loaded: form_helper
DEBUG - 2014-07-22 08:28:27 --> Form Validation Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Model Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Model Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Model Class Initialized
DEBUG - 2014-07-22 08:28:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 08:28:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 08:28:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 08:28:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 08:28:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 08:28:27 --> Final output sent to browser
DEBUG - 2014-07-22 08:28:27 --> Total execution time: 0.1114
DEBUG - 2014-07-22 09:05:11 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:11 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:11 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:11 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:11 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:11 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:11 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:11 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:11 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:11 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:11 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:11 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:11 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:11 --> Total execution time: 0.1258
DEBUG - 2014-07-22 09:05:13 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:13 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:13 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:13 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:13 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:13 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:13 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:13 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:13 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:13 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:13 --> Total execution time: 0.0826
DEBUG - 2014-07-22 09:05:14 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:14 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:14 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:14 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:14 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:14 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:14 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:14 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:14 --> Total execution time: 0.1272
DEBUG - 2014-07-22 09:05:14 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:14 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:14 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:14 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:14 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:14 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:14 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:14 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:14 --> Total execution time: 0.0911
DEBUG - 2014-07-22 09:05:14 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:14 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:14 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:14 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:14 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:14 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:14 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:14 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:14 --> Total execution time: 0.1399
DEBUG - 2014-07-22 09:05:14 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:14 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:14 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:14 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:14 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:14 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:14 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:14 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:14 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:14 --> Total execution time: 0.0733
DEBUG - 2014-07-22 09:05:15 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:15 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:15 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:15 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:15 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:15 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:15 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:15 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:15 --> Total execution time: 0.0882
DEBUG - 2014-07-22 09:05:15 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:15 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:15 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:15 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:15 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:15 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:15 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:15 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:15 --> Total execution time: 0.1088
DEBUG - 2014-07-22 09:05:15 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:15 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:15 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:15 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:15 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:15 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:15 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:15 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:15 --> Total execution time: 0.0834
DEBUG - 2014-07-22 09:05:15 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:15 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:15 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:15 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:15 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:15 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:15 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:15 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:15 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:15 --> Total execution time: 0.0874
DEBUG - 2014-07-22 09:05:16 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:16 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:16 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:16 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:16 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:16 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:16 --> Total execution time: 0.1235
DEBUG - 2014-07-22 09:05:16 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:16 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:16 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:16 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:16 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:16 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:16 --> Total execution time: 0.0866
DEBUG - 2014-07-22 09:05:16 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:16 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:16 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:16 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:16 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:16 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:16 --> Total execution time: 0.1184
DEBUG - 2014-07-22 09:05:16 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:16 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:16 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:16 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:16 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:16 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:16 --> Total execution time: 0.0832
DEBUG - 2014-07-22 09:05:16 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:16 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:16 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:16 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:17 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:17 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:17 --> Config Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:05:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:05:17 --> URI Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Router Class Initialized
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:17 --> Output Class Initialized
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:17 --> Security Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:17 --> Total execution time: 0.1614
DEBUG - 2014-07-22 09:05:17 --> Input Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:05:17 --> Language Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Loader Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:05:17 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Session Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:05:17 --> Session routines successfully run
DEBUG - 2014-07-22 09:05:17 --> Upload Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Controller Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:05:17 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Model Class Initialized
DEBUG - 2014-07-22 09:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:05:17 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:05:17 --> Final output sent to browser
DEBUG - 2014-07-22 09:05:17 --> Total execution time: 0.0938
DEBUG - 2014-07-22 09:14:45 --> Config Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:14:45 --> URI Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Router Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Output Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Security Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Input Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:14:45 --> Language Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Loader Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:14:45 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:14:45 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Session Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:14:45 --> Session routines successfully run
DEBUG - 2014-07-22 09:14:45 --> Upload Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Controller Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:14:45 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Model Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Model Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Model Class Initialized
DEBUG - 2014-07-22 09:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:14:45 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:14:45 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:14:45 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:14:45 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:14:45 --> Final output sent to browser
DEBUG - 2014-07-22 09:14:45 --> Total execution time: 0.0865
DEBUG - 2014-07-22 09:15:38 --> Config Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:15:38 --> URI Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Router Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Output Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Security Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Input Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:15:38 --> Language Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Loader Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:15:38 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:15:38 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Session Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:15:38 --> Session routines successfully run
DEBUG - 2014-07-22 09:15:38 --> Upload Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Controller Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:15:38 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Model Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Model Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Model Class Initialized
DEBUG - 2014-07-22 09:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:15:38 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:15:38 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:15:38 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:15:38 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:15:38 --> Final output sent to browser
DEBUG - 2014-07-22 09:15:38 --> Total execution time: 0.0836
DEBUG - 2014-07-22 09:43:21 --> Config Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:43:21 --> URI Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Router Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Output Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Security Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Input Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:43:21 --> Language Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Loader Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:43:21 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:43:21 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Session Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:43:21 --> Session routines successfully run
DEBUG - 2014-07-22 09:43:21 --> Upload Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Controller Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:43:21 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:43:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:43:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:43:21 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:43:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:43:21 --> Final output sent to browser
DEBUG - 2014-07-22 09:43:21 --> Total execution time: 0.0799
DEBUG - 2014-07-22 09:43:40 --> Config Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:43:40 --> URI Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Router Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Output Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Security Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Input Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:43:40 --> Language Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Loader Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:43:40 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:43:40 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Session Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:43:40 --> Session routines successfully run
DEBUG - 2014-07-22 09:43:40 --> Upload Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Controller Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:43:40 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:43:40 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:43:40 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:43:40 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:43:40 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:43:40 --> Final output sent to browser
DEBUG - 2014-07-22 09:43:40 --> Total execution time: 0.0835
DEBUG - 2014-07-22 09:43:46 --> Config Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:43:46 --> URI Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Router Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Output Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Security Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Input Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:43:46 --> Language Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Loader Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:43:46 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:43:46 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Session Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:43:46 --> Session routines successfully run
DEBUG - 2014-07-22 09:43:46 --> Upload Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Controller Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:43:46 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Model Class Initialized
DEBUG - 2014-07-22 09:43:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:43:46 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:43:46 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:43:46 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:43:46 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:43:46 --> Final output sent to browser
DEBUG - 2014-07-22 09:43:46 --> Total execution time: 0.0781
DEBUG - 2014-07-22 09:44:03 --> Config Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:44:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:44:03 --> URI Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Router Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Output Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Security Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Input Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:44:03 --> Language Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Loader Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:44:03 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:44:03 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Session Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:44:03 --> Session routines successfully run
DEBUG - 2014-07-22 09:44:03 --> Upload Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Controller Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:44:03 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Model Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Model Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Model Class Initialized
DEBUG - 2014-07-22 09:44:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:44:03 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:44:03 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:44:03 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:44:03 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:44:03 --> Final output sent to browser
DEBUG - 2014-07-22 09:44:03 --> Total execution time: 0.1032
DEBUG - 2014-07-22 09:44:26 --> Config Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:44:26 --> URI Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Router Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Output Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Security Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Input Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:44:26 --> Language Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Loader Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:44:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:44:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Session Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:44:26 --> Session routines successfully run
DEBUG - 2014-07-22 09:44:26 --> Upload Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Controller Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:44:26 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:44:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:44:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:44:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:44:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:44:26 --> Final output sent to browser
DEBUG - 2014-07-22 09:44:26 --> Total execution time: 0.0828
DEBUG - 2014-07-22 09:47:13 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:13 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:13 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:13 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:13 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:13 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:13 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:13 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:13 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:13 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:13 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:13 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:13 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:13 --> Total execution time: 0.0829
DEBUG - 2014-07-22 09:47:16 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:16 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:16 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:16 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:16 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:16 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:16 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:16 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:16 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:16 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:16 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:16 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:16 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:16 --> Total execution time: 0.0834
DEBUG - 2014-07-22 09:47:21 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:21 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:21 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:21 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:21 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:21 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:21 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:21 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:21 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:21 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:21 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:21 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:21 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:21 --> Total execution time: 0.0919
DEBUG - 2014-07-22 09:47:25 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:25 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:25 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:25 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:25 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:25 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:25 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:25 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:25 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:25 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:25 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:25 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:25 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:25 --> Total execution time: 0.0816
DEBUG - 2014-07-22 09:47:26 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:26 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:26 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:26 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:26 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:26 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:26 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:26 --> Total execution time: 0.0776
DEBUG - 2014-07-22 09:47:26 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:26 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:26 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:26 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:26 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:26 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:26 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:26 --> Total execution time: 0.0820
DEBUG - 2014-07-22 09:47:26 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:26 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:26 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:26 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:26 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:26 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:26 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:26 --> Total execution time: 0.0919
DEBUG - 2014-07-22 09:47:26 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:26 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:26 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:26 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:26 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:26 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:26 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:26 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:26 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:26 --> Total execution time: 0.0849
DEBUG - 2014-07-22 09:47:27 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:27 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:27 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:27 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:27 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:27 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:27 --> Total execution time: 0.1174
DEBUG - 2014-07-22 09:47:27 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:27 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:27 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:27 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:27 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:27 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:27 --> Total execution time: 0.0921
DEBUG - 2014-07-22 09:47:27 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:27 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:27 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:27 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:27 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:27 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:27 --> Total execution time: 0.1162
DEBUG - 2014-07-22 09:47:27 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:27 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:27 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:27 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:27 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:27 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:27 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:27 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:27 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:27 --> Total execution time: 0.0876
DEBUG - 2014-07-22 09:47:27 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:27 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:27 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:27 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:28 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:28 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:28 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:28 --> Total execution time: 0.1174
DEBUG - 2014-07-22 09:47:28 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:28 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:28 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:28 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:28 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:28 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:28 --> Total execution time: 0.0788
DEBUG - 2014-07-22 09:47:28 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:28 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:28 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:28 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:28 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:28 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:28 --> Total execution time: 0.1073
DEBUG - 2014-07-22 09:47:28 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:28 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:28 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:28 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:28 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:28 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:28 --> Total execution time: 0.0863
DEBUG - 2014-07-22 09:47:28 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:28 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:28 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:28 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:28 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:28 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:28 --> Total execution time: 0.0888
DEBUG - 2014-07-22 09:47:28 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:28 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:28 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:28 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:28 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:28 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:28 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:28 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:28 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:28 --> Total execution time: 0.0732
DEBUG - 2014-07-22 09:47:58 --> Config Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:47:58 --> URI Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Router Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Output Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Security Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Input Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:47:58 --> Language Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Loader Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:47:58 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:47:58 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Session Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:47:58 --> Session routines successfully run
DEBUG - 2014-07-22 09:47:58 --> Upload Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Controller Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:47:58 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Model Class Initialized
DEBUG - 2014-07-22 09:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:47:58 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:47:58 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:47:58 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:47:58 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:47:58 --> Final output sent to browser
DEBUG - 2014-07-22 09:47:58 --> Total execution time: 0.0808
DEBUG - 2014-07-22 09:48:37 --> Config Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:48:37 --> URI Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Router Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Output Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Security Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Input Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:48:37 --> Language Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Loader Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:48:37 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:48:37 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Session Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:48:37 --> Session routines successfully run
DEBUG - 2014-07-22 09:48:37 --> Upload Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Controller Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:48:37 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Model Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Model Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Model Class Initialized
DEBUG - 2014-07-22 09:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:48:37 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:48:37 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:48:37 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:48:37 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:48:37 --> Final output sent to browser
DEBUG - 2014-07-22 09:48:37 --> Total execution time: 0.0913
DEBUG - 2014-07-22 09:49:48 --> Config Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:49:48 --> URI Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Router Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Output Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Security Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Input Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:49:48 --> Language Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Loader Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:49:48 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:49:48 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Session Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:49:48 --> Session routines successfully run
DEBUG - 2014-07-22 09:49:48 --> Upload Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Controller Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:49:48 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Model Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Model Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Model Class Initialized
DEBUG - 2014-07-22 09:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:49:48 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:49:48 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:49:48 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:49:48 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:49:48 --> Final output sent to browser
DEBUG - 2014-07-22 09:49:48 --> Total execution time: 0.0765
DEBUG - 2014-07-22 09:49:50 --> Config Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Hooks Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Utf8 Class Initialized
DEBUG - 2014-07-22 09:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-22 09:49:50 --> URI Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Router Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Output Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Security Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Input Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-22 09:49:50 --> Language Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Loader Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Helper loaded: url_helper
DEBUG - 2014-07-22 09:49:50 --> Helper loaded: file_helper
DEBUG - 2014-07-22 09:49:50 --> Database Driver Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Session Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Helper loaded: string_helper
DEBUG - 2014-07-22 09:49:50 --> Session routines successfully run
DEBUG - 2014-07-22 09:49:50 --> Upload Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Pagination Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Controller Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Helper loaded: form_helper
DEBUG - 2014-07-22 09:49:50 --> Form Validation Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Model Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Model Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Model Class Initialized
DEBUG - 2014-07-22 09:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-22 09:49:50 --> File loaded: application/views/superadmin/includes/menu.php
DEBUG - 2014-07-22 09:49:50 --> File loaded: application/views/superadmin/includes/header.php
DEBUG - 2014-07-22 09:49:50 --> File loaded: application/views/superadmin/home_slider.php
DEBUG - 2014-07-22 09:49:50 --> File loaded: application/views/superadmin/includes/footer.php
DEBUG - 2014-07-22 09:49:50 --> Final output sent to browser
DEBUG - 2014-07-22 09:49:50 --> Total execution time: 0.0850

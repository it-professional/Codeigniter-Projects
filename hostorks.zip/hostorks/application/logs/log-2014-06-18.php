<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-18 08:18:35 --> Config Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:18:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:18:35 --> URI Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Router Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Output Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Security Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Input Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:18:35 --> Language Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Loader Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:18:35 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:18:35 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:18:35 --> Session Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:18:36 --> A session cookie was not found.
DEBUG - 2014-06-18 08:18:36 --> Session routines successfully run
DEBUG - 2014-06-18 08:18:36 --> Upload Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Controller Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:18:36 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Model Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Model Class Initialized
DEBUG - 2014-06-18 08:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:18:36 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:18:36 --> Final output sent to browser
DEBUG - 2014-06-18 08:18:36 --> Total execution time: 0.5088
DEBUG - 2014-06-18 08:18:44 --> Config Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:18:44 --> URI Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Router Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Output Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Security Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Input Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:18:44 --> Language Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Loader Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:18:44 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:18:44 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Session Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:18:44 --> Session routines successfully run
DEBUG - 2014-06-18 08:18:44 --> Upload Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Controller Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:18:44 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Model Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Model Class Initialized
DEBUG - 2014-06-18 08:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:18:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-18 08:18:44 --> XSS Filtering completed
DEBUG - 2014-06-18 08:18:44 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:18:44 --> Final output sent to browser
DEBUG - 2014-06-18 08:18:44 --> Total execution time: 0.1260
DEBUG - 2014-06-18 08:18:55 --> Config Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:18:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:18:55 --> URI Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Router Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Output Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Security Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Input Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:18:55 --> Language Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Loader Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:18:55 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Session Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:18:55 --> Session routines successfully run
DEBUG - 2014-06-18 08:18:55 --> Upload Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Controller Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:18:55 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Model Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Model Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:18:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-18 08:18:55 --> XSS Filtering completed
DEBUG - 2014-06-18 08:18:55 --> Config Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:18:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:18:55 --> URI Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Router Class Initialized
DEBUG - 2014-06-18 08:18:55 --> No URI present. Default controller set.
DEBUG - 2014-06-18 08:18:55 --> Output Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Security Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Input Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:18:55 --> Language Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Loader Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:18:55 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Session Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:18:55 --> Session routines successfully run
DEBUG - 2014-06-18 08:18:55 --> Upload Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Controller Class Initialized
DEBUG - 2014-06-18 08:18:55 --> Final output sent to browser
DEBUG - 2014-06-18 08:18:55 --> Total execution time: 0.0932
DEBUG - 2014-06-18 08:19:41 --> Config Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:19:41 --> URI Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Router Class Initialized
DEBUG - 2014-06-18 08:19:41 --> No URI present. Default controller set.
DEBUG - 2014-06-18 08:19:41 --> Output Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Security Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Input Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:19:41 --> Language Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Loader Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:19:41 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:19:41 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Session Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:19:41 --> Session routines successfully run
DEBUG - 2014-06-18 08:19:41 --> Upload Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:19:41 --> Controller Class Initialized
DEBUG - 2014-06-18 08:19:41 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:19:41 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 08:19:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:19:41 --> Final output sent to browser
DEBUG - 2014-06-18 08:19:41 --> Total execution time: 0.0731
DEBUG - 2014-06-18 08:20:06 --> Config Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:20:06 --> URI Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Router Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Output Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Security Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Input Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:20:06 --> Language Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Loader Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:20:06 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:20:06 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Session Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:20:06 --> Session routines successfully run
DEBUG - 2014-06-18 08:20:06 --> Upload Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Controller Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:20:06 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Model Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Model Class Initialized
DEBUG - 2014-06-18 08:20:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-18 08:20:06 --> 404 Page Not Found --> superadmin/dashboard
DEBUG - 2014-06-18 08:20:58 --> Config Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:20:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:20:58 --> URI Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Router Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Output Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Security Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Input Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:20:58 --> Language Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Loader Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:20:58 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:20:58 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Session Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:20:58 --> Session routines successfully run
DEBUG - 2014-06-18 08:20:58 --> Upload Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Controller Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:20:58 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Model Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Model Class Initialized
DEBUG - 2014-06-18 08:20:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-18 08:20:58 --> 404 Page Not Found --> superadmin/dashboard
DEBUG - 2014-06-18 08:24:19 --> Config Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:24:19 --> URI Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Router Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Output Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Security Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Input Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:24:19 --> Language Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Loader Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:24:19 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:24:19 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Session Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:24:19 --> Session routines successfully run
DEBUG - 2014-06-18 08:24:19 --> Upload Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Controller Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:24:19 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Model Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Model Class Initialized
DEBUG - 2014-06-18 08:24:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-18 08:24:19 --> 404 Page Not Found --> superadmin/dashboard
DEBUG - 2014-06-18 08:25:08 --> Config Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:25:08 --> URI Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Router Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Output Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Security Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Input Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:25:08 --> Language Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Loader Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:25:08 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:25:08 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Session Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:25:08 --> Session routines successfully run
DEBUG - 2014-06-18 08:25:08 --> Upload Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Controller Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:25:08 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Model Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Model Class Initialized
DEBUG - 2014-06-18 08:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:25:08 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:25:32 --> Config Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:25:32 --> URI Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Router Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Output Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Security Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Input Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:25:32 --> Language Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Loader Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:25:32 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:25:32 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Session Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:25:32 --> Session routines successfully run
DEBUG - 2014-06-18 08:25:32 --> Upload Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Controller Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:25:32 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Model Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Model Class Initialized
DEBUG - 2014-06-18 08:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:25:32 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:25:32 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 08:25:32 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:25:32 --> Final output sent to browser
DEBUG - 2014-06-18 08:25:32 --> Total execution time: 0.0776
DEBUG - 2014-06-18 08:26:23 --> Config Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:26:23 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:26:23 --> URI Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Router Class Initialized
DEBUG - 2014-06-18 08:26:23 --> No URI present. Default controller set.
DEBUG - 2014-06-18 08:26:23 --> Output Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Security Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Input Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:26:23 --> Language Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Loader Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:26:23 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:26:23 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Session Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:26:23 --> Session routines successfully run
DEBUG - 2014-06-18 08:26:23 --> Upload Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:26:23 --> Controller Class Initialized
DEBUG - 2014-06-18 08:26:23 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:26:23 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 08:26:23 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:26:23 --> Final output sent to browser
DEBUG - 2014-06-18 08:26:23 --> Total execution time: 0.0789
DEBUG - 2014-06-18 08:26:28 --> Config Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:26:28 --> URI Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Router Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Output Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Security Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Input Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:26:28 --> Language Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Loader Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:26:28 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:26:28 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Session Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:26:28 --> Session routines successfully run
DEBUG - 2014-06-18 08:26:28 --> Upload Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Controller Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:26:28 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Model Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Model Class Initialized
DEBUG - 2014-06-18 08:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:26:28 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:26:28 --> Final output sent to browser
DEBUG - 2014-06-18 08:26:28 --> Total execution time: 0.0926
DEBUG - 2014-06-18 08:26:57 --> Config Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:26:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:26:57 --> URI Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Router Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Output Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Security Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Input Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:26:57 --> Language Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Loader Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:26:57 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:26:57 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Session Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:26:57 --> Session routines successfully run
DEBUG - 2014-06-18 08:26:57 --> Upload Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Controller Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:26:57 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Model Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Model Class Initialized
DEBUG - 2014-06-18 08:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:26:57 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:26:57 --> Final output sent to browser
DEBUG - 2014-06-18 08:26:57 --> Total execution time: 0.0712
DEBUG - 2014-06-18 08:26:59 --> Config Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:26:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:26:59 --> URI Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Router Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Output Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Security Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Input Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:26:59 --> Language Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Loader Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:26:59 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:26:59 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Session Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:26:59 --> Session routines successfully run
DEBUG - 2014-06-18 08:26:59 --> Upload Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Controller Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:26:59 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Model Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Model Class Initialized
DEBUG - 2014-06-18 08:26:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:26:59 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:26:59 --> Final output sent to browser
DEBUG - 2014-06-18 08:26:59 --> Total execution time: 0.0712
DEBUG - 2014-06-18 08:27:08 --> Config Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:27:08 --> URI Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Router Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Output Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Security Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Input Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:27:08 --> Language Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Loader Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:27:08 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:27:08 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Session Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:27:08 --> Session routines successfully run
DEBUG - 2014-06-18 08:27:08 --> Upload Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Controller Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:27:08 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:27:08 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:27:08 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:27:08 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:27:08 --> Final output sent to browser
DEBUG - 2014-06-18 08:27:08 --> Total execution time: 0.1012
DEBUG - 2014-06-18 08:27:30 --> Config Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:27:30 --> URI Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Router Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Output Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Security Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Input Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:27:30 --> Language Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Loader Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:27:30 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:27:30 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Session Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:27:30 --> Session routines successfully run
DEBUG - 2014-06-18 08:27:30 --> Upload Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Controller Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:27:30 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:27:30 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:27:30 --> Final output sent to browser
DEBUG - 2014-06-18 08:27:30 --> Total execution time: 0.0808
DEBUG - 2014-06-18 08:27:33 --> Config Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:27:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:27:33 --> URI Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Router Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Output Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Security Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Input Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:27:33 --> Language Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Loader Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:27:33 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:27:33 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Session Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:27:33 --> Session routines successfully run
DEBUG - 2014-06-18 08:27:33 --> Upload Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Controller Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:27:33 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:27:33 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:27:33 --> Final output sent to browser
DEBUG - 2014-06-18 08:27:33 --> Total execution time: 0.0650
DEBUG - 2014-06-18 08:27:52 --> Config Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:27:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:27:52 --> URI Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Router Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Output Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Security Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Input Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:27:52 --> Language Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Loader Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:27:52 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:27:52 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Session Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:27:52 --> Session routines successfully run
DEBUG - 2014-06-18 08:27:52 --> Upload Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Controller Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:27:52 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:27:52 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:27:52 --> Final output sent to browser
DEBUG - 2014-06-18 08:27:52 --> Total execution time: 0.0726
DEBUG - 2014-06-18 08:27:54 --> Config Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:27:54 --> URI Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Router Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Output Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Security Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Input Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:27:54 --> Language Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Loader Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:27:54 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:27:54 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Session Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:27:54 --> Session routines successfully run
DEBUG - 2014-06-18 08:27:54 --> Upload Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Controller Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:27:54 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Model Class Initialized
DEBUG - 2014-06-18 08:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:27:54 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:27:54 --> Final output sent to browser
DEBUG - 2014-06-18 08:27:54 --> Total execution time: 0.0747
DEBUG - 2014-06-18 08:28:00 --> Config Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:28:00 --> URI Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Router Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Output Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Security Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Input Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:28:00 --> Language Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Loader Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:28:00 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:28:00 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Session Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:28:00 --> Session routines successfully run
DEBUG - 2014-06-18 08:28:00 --> Upload Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Controller Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:28:00 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Model Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Model Class Initialized
DEBUG - 2014-06-18 08:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:28:00 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:28:00 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:28:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:28:00 --> Final output sent to browser
DEBUG - 2014-06-18 08:28:00 --> Total execution time: 0.1059
DEBUG - 2014-06-18 08:28:58 --> Config Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:28:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:28:58 --> URI Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Router Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Output Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Security Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Input Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:28:58 --> Language Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Loader Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:28:58 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:28:58 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Session Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:28:58 --> Session routines successfully run
DEBUG - 2014-06-18 08:28:58 --> Upload Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Controller Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:28:58 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Model Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Model Class Initialized
DEBUG - 2014-06-18 08:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:28:58 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:28:58 --> Final output sent to browser
DEBUG - 2014-06-18 08:28:58 --> Total execution time: 0.0917
DEBUG - 2014-06-18 08:29:00 --> Config Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:29:00 --> URI Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Router Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Output Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Security Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Input Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:29:00 --> Language Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Loader Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:29:00 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:29:00 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Session Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:29:00 --> Session routines successfully run
DEBUG - 2014-06-18 08:29:00 --> Upload Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Controller Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:29:00 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Model Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Model Class Initialized
DEBUG - 2014-06-18 08:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:29:00 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:29:00 --> Final output sent to browser
DEBUG - 2014-06-18 08:29:00 --> Total execution time: 0.0653
DEBUG - 2014-06-18 08:29:59 --> Config Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:29:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:29:59 --> URI Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Router Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Output Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Security Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Input Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:29:59 --> Language Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Loader Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:29:59 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:29:59 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Session Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:29:59 --> Session routines successfully run
DEBUG - 2014-06-18 08:29:59 --> Upload Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Controller Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:29:59 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Model Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Model Class Initialized
DEBUG - 2014-06-18 08:29:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:29:59 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:29:59 --> Final output sent to browser
DEBUG - 2014-06-18 08:29:59 --> Total execution time: 0.0681
DEBUG - 2014-06-18 08:30:15 --> Config Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:30:15 --> URI Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Router Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Output Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Security Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Input Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:30:15 --> Language Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Loader Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:30:15 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:30:15 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Session Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:30:15 --> Session routines successfully run
DEBUG - 2014-06-18 08:30:15 --> Upload Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Controller Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:30:15 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Model Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Model Class Initialized
DEBUG - 2014-06-18 08:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:30:15 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:30:15 --> Final output sent to browser
DEBUG - 2014-06-18 08:30:15 --> Total execution time: 0.0717
DEBUG - 2014-06-18 08:30:44 --> Config Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:30:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:30:44 --> URI Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Router Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Output Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Security Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Input Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:30:44 --> Language Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Loader Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:30:44 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:30:44 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Session Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:30:44 --> Session routines successfully run
DEBUG - 2014-06-18 08:30:44 --> Upload Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Controller Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:30:44 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Model Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Model Class Initialized
DEBUG - 2014-06-18 08:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:30:44 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:30:44 --> Final output sent to browser
DEBUG - 2014-06-18 08:30:44 --> Total execution time: 0.0651
DEBUG - 2014-06-18 08:30:50 --> Config Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:30:50 --> URI Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Router Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Output Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Security Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Input Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:30:50 --> Language Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Loader Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:30:50 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:30:50 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Session Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:30:50 --> Session routines successfully run
DEBUG - 2014-06-18 08:30:50 --> Upload Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Controller Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:30:50 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Model Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Model Class Initialized
DEBUG - 2014-06-18 08:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:30:50 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:30:50 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:30:50 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:30:50 --> Final output sent to browser
DEBUG - 2014-06-18 08:30:50 --> Total execution time: 0.1019
DEBUG - 2014-06-18 08:41:12 --> Config Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:41:12 --> URI Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Router Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Output Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Security Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Input Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:41:12 --> Language Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Loader Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:41:12 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:41:12 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Session Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:41:12 --> Session routines successfully run
DEBUG - 2014-06-18 08:41:12 --> Upload Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Controller Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:41:12 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Model Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Model Class Initialized
DEBUG - 2014-06-18 08:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:41:12 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:41:12 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 08:41:12 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:41:12 --> Final output sent to browser
DEBUG - 2014-06-18 08:41:12 --> Total execution time: 0.0799
DEBUG - 2014-06-18 08:41:18 --> Config Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:41:18 --> URI Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Router Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Output Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Security Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Input Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:41:18 --> Language Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Loader Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:41:18 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:41:18 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Session Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:41:18 --> Session routines successfully run
DEBUG - 2014-06-18 08:41:18 --> Upload Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Controller Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:41:18 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Model Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Model Class Initialized
DEBUG - 2014-06-18 08:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 08:41:18 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 08:41:18 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 08:41:18 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 08:41:18 --> Final output sent to browser
DEBUG - 2014-06-18 08:41:18 --> Total execution time: 0.0832
DEBUG - 2014-06-18 08:44:24 --> Config Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Hooks Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Utf8 Class Initialized
DEBUG - 2014-06-18 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 08:44:24 --> URI Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Router Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Output Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Security Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Input Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 08:44:24 --> Language Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Loader Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Helper loaded: url_helper
DEBUG - 2014-06-18 08:44:24 --> Helper loaded: file_helper
DEBUG - 2014-06-18 08:44:24 --> Database Driver Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Session Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Helper loaded: string_helper
DEBUG - 2014-06-18 08:44:24 --> Session routines successfully run
DEBUG - 2014-06-18 08:44:24 --> Upload Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Pagination Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Controller Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Helper loaded: form_helper
DEBUG - 2014-06-18 08:44:24 --> Form Validation Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Model Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Model Class Initialized
DEBUG - 2014-06-18 08:44:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-18 08:44:24 --> 404 Page Not Found --> 
DEBUG - 2014-06-18 09:23:01 --> Config Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:23:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:23:01 --> URI Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Router Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Output Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Security Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Input Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:23:01 --> Language Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Loader Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:23:01 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:23:01 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Session Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:23:01 --> Session routines successfully run
DEBUG - 2014-06-18 09:23:01 --> Upload Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Controller Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:23:01 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Model Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Model Class Initialized
DEBUG - 2014-06-18 09:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:23:01 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 09:23:01 --> Final output sent to browser
DEBUG - 2014-06-18 09:23:01 --> Total execution time: 0.0741
DEBUG - 2014-06-18 09:25:35 --> Config Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:25:35 --> URI Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Router Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Output Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Security Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Input Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:25:35 --> Language Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Loader Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:25:35 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:25:35 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Session Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:25:35 --> Session routines successfully run
DEBUG - 2014-06-18 09:25:35 --> Upload Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Controller Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:25:35 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Model Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Model Class Initialized
DEBUG - 2014-06-18 09:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:25:35 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 09:25:35 --> Final output sent to browser
DEBUG - 2014-06-18 09:25:35 --> Total execution time: 0.0625
DEBUG - 2014-06-18 09:25:42 --> Config Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:25:42 --> URI Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Router Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Output Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Security Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Input Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:25:42 --> Language Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Loader Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:25:42 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Session Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:25:42 --> Session routines successfully run
DEBUG - 2014-06-18 09:25:42 --> Upload Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Controller Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:25:42 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Model Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Model Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:25:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-18 09:25:42 --> XSS Filtering completed
DEBUG - 2014-06-18 09:25:42 --> Config Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:25:42 --> URI Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Router Class Initialized
DEBUG - 2014-06-18 09:25:42 --> No URI present. Default controller set.
DEBUG - 2014-06-18 09:25:42 --> Output Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Security Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Input Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:25:42 --> Language Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Loader Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:25:42 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Session Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:25:42 --> Session routines successfully run
DEBUG - 2014-06-18 09:25:42 --> Upload Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:25:42 --> Controller Class Initialized
DEBUG - 2014-06-18 09:25:42 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:25:42 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 09:25:42 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:25:42 --> Final output sent to browser
DEBUG - 2014-06-18 09:25:42 --> Total execution time: 0.0691
DEBUG - 2014-06-18 09:25:52 --> Config Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:25:52 --> URI Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Router Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Output Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Security Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Input Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:25:52 --> Language Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Loader Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:25:52 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:25:52 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Session Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:25:52 --> Session routines successfully run
DEBUG - 2014-06-18 09:25:52 --> Upload Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Controller Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:25:52 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Model Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Model Class Initialized
DEBUG - 2014-06-18 09:25:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:25:52 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:25:52 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 09:25:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:25:52 --> Final output sent to browser
DEBUG - 2014-06-18 09:25:52 --> Total execution time: 0.0723
DEBUG - 2014-06-18 09:28:29 --> Config Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:28:29 --> URI Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Router Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Output Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Security Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Input Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:28:29 --> Language Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Loader Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:28:29 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:28:29 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Session Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:28:29 --> Session routines successfully run
DEBUG - 2014-06-18 09:28:29 --> Upload Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Controller Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:28:29 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Model Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Model Class Initialized
DEBUG - 2014-06-18 09:28:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-18 09:28:29 --> Severity: Notice  --> Undefined variable: data F:\wamp\www\hostorks\application\controllers\superadmin.php 17
DEBUG - 2014-06-18 09:28:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 09:28:29 --> Final output sent to browser
DEBUG - 2014-06-18 09:28:29 --> Total execution time: 0.0777
DEBUG - 2014-06-18 09:31:08 --> Config Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:31:08 --> URI Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Router Class Initialized
DEBUG - 2014-06-18 09:31:08 --> No URI present. Default controller set.
DEBUG - 2014-06-18 09:31:08 --> Output Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Security Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Input Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:31:08 --> Language Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Loader Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:31:08 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:31:08 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Session Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:31:08 --> Session routines successfully run
DEBUG - 2014-06-18 09:31:08 --> Upload Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:31:08 --> Controller Class Initialized
DEBUG - 2014-06-18 09:31:08 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:31:08 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 09:31:08 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:31:08 --> Final output sent to browser
DEBUG - 2014-06-18 09:31:08 --> Total execution time: 0.0777
DEBUG - 2014-06-18 09:37:04 --> Config Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:37:04 --> URI Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Router Class Initialized
DEBUG - 2014-06-18 09:37:04 --> No URI present. Default controller set.
DEBUG - 2014-06-18 09:37:04 --> Output Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Security Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Input Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:37:04 --> Language Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Loader Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:37:04 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:37:04 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Session Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:37:04 --> Session routines successfully run
DEBUG - 2014-06-18 09:37:04 --> Upload Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:37:04 --> Controller Class Initialized
DEBUG - 2014-06-18 09:37:04 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:37:04 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 09:37:04 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:37:04 --> Final output sent to browser
DEBUG - 2014-06-18 09:37:04 --> Total execution time: 0.0774
DEBUG - 2014-06-18 09:37:27 --> Config Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:37:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:37:27 --> URI Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Router Class Initialized
DEBUG - 2014-06-18 09:37:27 --> No URI present. Default controller set.
DEBUG - 2014-06-18 09:37:27 --> Output Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Security Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Input Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:37:27 --> Language Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Loader Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:37:27 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:37:27 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Session Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:37:27 --> Session routines successfully run
DEBUG - 2014-06-18 09:37:27 --> Upload Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:37:27 --> Controller Class Initialized
DEBUG - 2014-06-18 09:37:27 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:37:27 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 09:37:27 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:37:27 --> Final output sent to browser
DEBUG - 2014-06-18 09:37:27 --> Total execution time: 0.0742
DEBUG - 2014-06-18 09:37:42 --> Config Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:37:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:37:42 --> URI Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Router Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Output Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Security Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Input Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:37:42 --> Language Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Loader Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:37:42 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:37:42 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Session Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:37:42 --> Session routines successfully run
DEBUG - 2014-06-18 09:37:42 --> Upload Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Controller Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:37:42 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Model Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Model Class Initialized
DEBUG - 2014-06-18 09:37:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:37:42 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 09:37:42 --> Final output sent to browser
DEBUG - 2014-06-18 09:37:42 --> Total execution time: 0.0716
DEBUG - 2014-06-18 09:37:54 --> Config Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:37:54 --> URI Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Router Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Output Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Security Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Input Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:37:54 --> Language Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Loader Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:37:54 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:37:54 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Session Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:37:54 --> Session routines successfully run
DEBUG - 2014-06-18 09:37:54 --> Upload Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Controller Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:37:54 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Model Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Model Class Initialized
DEBUG - 2014-06-18 09:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:37:54 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 09:37:54 --> Final output sent to browser
DEBUG - 2014-06-18 09:37:54 --> Total execution time: 0.0684
DEBUG - 2014-06-18 09:56:19 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:19 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:19 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:19 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:19 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:19 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:19 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:19 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:19 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 09:56:19 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:19 --> Total execution time: 0.0695
DEBUG - 2014-06-18 09:56:25 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:25 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:25 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:25 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:25 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:25 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:25 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:25 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:25 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:56:25 --> File loaded: application/views/superadmin/logout.php
DEBUG - 2014-06-18 09:56:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:56:25 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:25 --> Total execution time: 0.0906
DEBUG - 2014-06-18 09:56:30 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:30 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:30 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:30 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:30 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:30 --> A session cookie was not found.
DEBUG - 2014-06-18 09:56:30 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:30 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:30 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:30 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 09:56:30 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:30 --> Total execution time: 0.0799
DEBUG - 2014-06-18 09:56:33 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:33 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:33 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:33 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:33 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:33 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:33 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:33 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:33 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 09:56:33 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:33 --> Total execution time: 0.0623
DEBUG - 2014-06-18 09:56:37 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:37 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:37 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:37 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:37 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:37 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:37 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:37 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:37 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:37 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 09:56:37 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:37 --> Total execution time: 0.0749
DEBUG - 2014-06-18 09:56:40 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:40 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:40 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:40 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:40 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:40 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:40 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:40 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-18 09:56:40 --> XSS Filtering completed
DEBUG - 2014-06-18 09:56:40 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-06-18 09:56:40 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:40 --> Total execution time: 0.0727
DEBUG - 2014-06-18 09:56:46 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:46 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:46 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:46 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:46 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:46 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:46 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-06-18 09:56:46 --> XSS Filtering completed
DEBUG - 2014-06-18 09:56:46 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:46 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:46 --> No URI present. Default controller set.
DEBUG - 2014-06-18 09:56:46 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:46 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:46 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:46 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:46 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:46 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:46 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:56:46 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-18 09:56:46 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:56:46 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:46 --> Total execution time: 0.0812
DEBUG - 2014-06-18 09:56:59 --> Config Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Hooks Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Utf8 Class Initialized
DEBUG - 2014-06-18 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 09:56:59 --> URI Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Router Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Output Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Security Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Input Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 09:56:59 --> Language Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Loader Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Helper loaded: url_helper
DEBUG - 2014-06-18 09:56:59 --> Helper loaded: file_helper
DEBUG - 2014-06-18 09:56:59 --> Database Driver Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Session Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Helper loaded: string_helper
DEBUG - 2014-06-18 09:56:59 --> Session routines successfully run
DEBUG - 2014-06-18 09:56:59 --> Upload Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Pagination Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Controller Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Helper loaded: form_helper
DEBUG - 2014-06-18 09:56:59 --> Form Validation Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Model Class Initialized
DEBUG - 2014-06-18 09:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 09:56:59 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 09:56:59 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 09:56:59 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 09:56:59 --> Final output sent to browser
DEBUG - 2014-06-18 09:56:59 --> Total execution time: 0.0774
DEBUG - 2014-06-18 10:00:22 --> Config Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Hooks Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Utf8 Class Initialized
DEBUG - 2014-06-18 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 10:00:22 --> URI Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Router Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Output Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Security Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Input Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 10:00:22 --> Language Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Loader Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Helper loaded: url_helper
DEBUG - 2014-06-18 10:00:22 --> Helper loaded: file_helper
DEBUG - 2014-06-18 10:00:22 --> Database Driver Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Session Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Helper loaded: string_helper
DEBUG - 2014-06-18 10:00:22 --> Session routines successfully run
DEBUG - 2014-06-18 10:00:22 --> Upload Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Pagination Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Controller Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Helper loaded: form_helper
DEBUG - 2014-06-18 10:00:22 --> Form Validation Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Model Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Model Class Initialized
DEBUG - 2014-06-18 10:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 10:00:22 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 10:00:22 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 10:00:22 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 10:00:22 --> Final output sent to browser
DEBUG - 2014-06-18 10:00:22 --> Total execution time: 0.0753
DEBUG - 2014-06-18 10:13:14 --> Config Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Hooks Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Utf8 Class Initialized
DEBUG - 2014-06-18 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-18 10:13:14 --> URI Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Router Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Output Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Security Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Input Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-18 10:13:14 --> Language Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Loader Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Helper loaded: url_helper
DEBUG - 2014-06-18 10:13:14 --> Helper loaded: file_helper
DEBUG - 2014-06-18 10:13:14 --> Database Driver Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Session Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Helper loaded: string_helper
DEBUG - 2014-06-18 10:13:14 --> Session routines successfully run
DEBUG - 2014-06-18 10:13:14 --> Upload Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Pagination Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Controller Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Helper loaded: form_helper
DEBUG - 2014-06-18 10:13:14 --> Form Validation Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Model Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Model Class Initialized
DEBUG - 2014-06-18 10:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-18 10:13:14 --> File loaded: application/views/templates/header.php
DEBUG - 2014-06-18 10:13:14 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-06-18 10:13:14 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-06-18 10:13:14 --> Final output sent to browser
DEBUG - 2014-06-18 10:13:14 --> Total execution time: 0.0993

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-06 06:04:59 --> Config Class Initialized
DEBUG - 2014-07-06 06:04:59 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:04:59 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:05:00 --> URI Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Router Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Output Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Security Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Input Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:05:00 --> Language Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Loader Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:05:00 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:05:00 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Session Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:05:00 --> A session cookie was not found.
DEBUG - 2014-07-06 06:05:00 --> Session routines successfully run
DEBUG - 2014-07-06 06:05:00 --> Upload Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Controller Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:05:00 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:05:00 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-06 06:05:00 --> Final output sent to browser
DEBUG - 2014-07-06 06:05:00 --> Total execution time: 0.6789
DEBUG - 2014-07-06 06:05:10 --> Config Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:05:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:05:10 --> URI Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Router Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Output Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Security Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Input Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:05:10 --> Language Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Loader Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:05:10 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:05:10 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Session Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:05:10 --> Session routines successfully run
DEBUG - 2014-07-06 06:05:10 --> Upload Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Controller Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:05:10 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:05:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 06:05:10 --> XSS Filtering completed
DEBUG - 2014-07-06 06:05:11 --> Config Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:05:11 --> URI Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Router Class Initialized
DEBUG - 2014-07-06 06:05:11 --> No URI present. Default controller set.
DEBUG - 2014-07-06 06:05:11 --> Output Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Security Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Input Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:05:11 --> Language Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Loader Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:05:11 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:05:11 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Session Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:05:11 --> Session routines successfully run
DEBUG - 2014-07-06 06:05:11 --> Upload Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:05:11 --> Controller Class Initialized
DEBUG - 2014-07-06 06:05:11 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:05:11 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-06 06:05:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:05:11 --> Final output sent to browser
DEBUG - 2014-07-06 06:05:11 --> Total execution time: 0.1418
DEBUG - 2014-07-06 06:05:42 --> Config Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:05:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:05:42 --> URI Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Router Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Output Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Security Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Input Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:05:42 --> Language Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Loader Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:05:42 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:05:42 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Session Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:05:42 --> Session routines successfully run
DEBUG - 2014-07-06 06:05:42 --> Upload Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Controller Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:05:42 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Model Class Initialized
DEBUG - 2014-07-06 06:05:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:05:42 --> Severity: Notice  --> Undefined property: Superadmin::$dashboard C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-06 06:05:42 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:05:42 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 06:05:42 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:05:42 --> Final output sent to browser
DEBUG - 2014-07-06 06:05:42 --> Total execution time: 0.2990
DEBUG - 2014-07-06 06:11:43 --> Config Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:11:43 --> URI Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Router Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Output Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Security Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Input Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:11:43 --> Language Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Loader Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:11:43 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:11:43 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Session Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:11:43 --> A session cookie was not found.
DEBUG - 2014-07-06 06:11:43 --> Session routines successfully run
DEBUG - 2014-07-06 06:11:43 --> Upload Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Controller Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:11:43 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Model Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Model Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Model Class Initialized
DEBUG - 2014-07-06 06:11:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:11:43 --> Severity: Notice  --> Undefined property: Superadmin::$dashboard C:\wamp\www\hostorks\application\controllers\superadmin.php 66
DEBUG - 2014-07-06 06:11:43 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:11:43 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 06:11:43 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:11:43 --> Final output sent to browser
DEBUG - 2014-07-06 06:11:43 --> Total execution time: 0.4962
DEBUG - 2014-07-06 06:11:52 --> Config Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:11:52 --> URI Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Router Class Initialized
DEBUG - 2014-07-06 06:11:52 --> No URI present. Default controller set.
DEBUG - 2014-07-06 06:11:52 --> Output Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Security Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Input Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:11:52 --> Language Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Loader Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:11:52 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:11:52 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Session Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:11:52 --> Session routines successfully run
DEBUG - 2014-07-06 06:11:52 --> Upload Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:11:52 --> Controller Class Initialized
DEBUG - 2014-07-06 06:11:52 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:11:52 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-06 06:11:52 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:11:52 --> Final output sent to browser
DEBUG - 2014-07-06 06:11:52 --> Total execution time: 0.1208
DEBUG - 2014-07-06 06:12:04 --> Config Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:12:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:12:04 --> URI Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Router Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Output Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Security Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Input Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:12:04 --> Language Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Loader Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:12:04 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:12:04 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Session Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:12:04 --> Session routines successfully run
DEBUG - 2014-07-06 06:12:04 --> Upload Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Controller Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:12:04 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Model Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Model Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Model Class Initialized
DEBUG - 2014-07-06 06:12:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:12:04 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-06 06:12:04 --> Final output sent to browser
DEBUG - 2014-07-06 06:12:04 --> Total execution time: 0.1591
DEBUG - 2014-07-06 06:12:37 --> Config Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:12:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:12:37 --> URI Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Router Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Output Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Security Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Input Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:12:37 --> Language Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Loader Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:12:37 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:12:37 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Session Class Initialized
DEBUG - 2014-07-06 06:12:37 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:12:37 --> Session routines successfully run
DEBUG - 2014-07-06 06:12:37 --> Upload Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Controller Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:12:38 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Model Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Model Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Model Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:12:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 06:12:38 --> XSS Filtering completed
DEBUG - 2014-07-06 06:12:38 --> Config Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:12:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:12:38 --> URI Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Router Class Initialized
DEBUG - 2014-07-06 06:12:38 --> No URI present. Default controller set.
DEBUG - 2014-07-06 06:12:38 --> Output Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Security Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Input Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:12:38 --> Language Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Loader Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:12:38 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:12:38 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Session Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:12:38 --> Session routines successfully run
DEBUG - 2014-07-06 06:12:38 --> Upload Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:12:38 --> Controller Class Initialized
DEBUG - 2014-07-06 06:12:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:12:38 --> File loaded: application/views/pages/home.php
DEBUG - 2014-07-06 06:12:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:12:38 --> Final output sent to browser
DEBUG - 2014-07-06 06:12:38 --> Total execution time: 0.0996
DEBUG - 2014-07-06 06:14:25 --> Config Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:14:25 --> URI Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Router Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Output Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Security Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Input Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:14:25 --> Language Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Loader Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:14:25 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:14:25 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Session Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:14:25 --> Session routines successfully run
DEBUG - 2014-07-06 06:14:25 --> Upload Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Controller Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:14:25 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Model Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Model Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Model Class Initialized
DEBUG - 2014-07-06 06:14:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:14:25 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 06:14:25 --> Final output sent to browser
DEBUG - 2014-07-06 06:14:25 --> Total execution time: 0.1424
DEBUG - 2014-07-06 06:15:57 --> Config Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:15:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:15:57 --> URI Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Router Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Output Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Security Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Input Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:15:57 --> Language Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Loader Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:15:57 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:15:57 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Session Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:15:57 --> Session routines successfully run
DEBUG - 2014-07-06 06:15:57 --> Upload Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Controller Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:15:57 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Model Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Model Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Model Class Initialized
DEBUG - 2014-07-06 06:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:15:57 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 06:15:57 --> Final output sent to browser
DEBUG - 2014-07-06 06:15:57 --> Total execution time: 0.1299
DEBUG - 2014-07-06 06:20:41 --> Config Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:20:41 --> URI Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Router Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Output Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Security Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Input Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:20:41 --> Language Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Loader Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:20:41 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:20:41 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Session Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:20:41 --> Session routines successfully run
DEBUG - 2014-07-06 06:20:41 --> Upload Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Controller Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:20:41 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Model Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Model Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Model Class Initialized
DEBUG - 2014-07-06 06:20:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:20:41 --> Severity: Notice  --> Undefined property: Superadmin::$logout C:\wamp\www\hostorks\application\controllers\superadmin.php 75
DEBUG - 2014-07-06 06:20:41 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:20:41 --> File loaded: application/views/superadmin/logout.php
DEBUG - 2014-07-06 06:20:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:20:41 --> Final output sent to browser
DEBUG - 2014-07-06 06:20:41 --> Total execution time: 0.1798
DEBUG - 2014-07-06 06:20:49 --> Config Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:20:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:20:49 --> URI Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Router Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Output Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Security Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Input Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:20:49 --> Language Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Loader Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:20:49 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:20:49 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Session Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:20:49 --> A session cookie was not found.
DEBUG - 2014-07-06 06:20:49 --> Session routines successfully run
DEBUG - 2014-07-06 06:20:49 --> Upload Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Controller Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:20:49 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Model Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Model Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Model Class Initialized
DEBUG - 2014-07-06 06:20:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:20:49 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-06 06:20:49 --> Final output sent to browser
DEBUG - 2014-07-06 06:20:49 --> Total execution time: 0.1683
DEBUG - 2014-07-06 06:26:05 --> Config Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:26:05 --> URI Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Router Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Output Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Security Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Input Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:26:05 --> Language Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Loader Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:26:05 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Session Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:26:05 --> Session routines successfully run
DEBUG - 2014-07-06 06:26:05 --> Upload Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Controller Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:26:05 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:26:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 06:26:05 --> XSS Filtering completed
DEBUG - 2014-07-06 06:26:05 --> Config Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:26:05 --> URI Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Router Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Output Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Security Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Input Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:26:05 --> Language Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Loader Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:26:05 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Session Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:26:05 --> Session routines successfully run
DEBUG - 2014-07-06 06:26:05 --> Upload Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Controller Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:26:05 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:26:05 --> Severity: Notice  --> Undefined property: Superadmin::$dashboard C:\wamp\www\hostorks\application\controllers\superadmin.php 75
DEBUG - 2014-07-06 06:26:05 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:26:05 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 06:26:05 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:26:05 --> Final output sent to browser
DEBUG - 2014-07-06 06:26:05 --> Total execution time: 0.1655
DEBUG - 2014-07-06 06:26:32 --> Config Class Initialized
DEBUG - 2014-07-06 06:26:32 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:26:32 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:26:32 --> URI Class Initialized
DEBUG - 2014-07-06 06:26:32 --> Router Class Initialized
DEBUG - 2014-07-06 06:26:32 --> Output Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Security Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Input Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:26:33 --> Language Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Loader Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:26:33 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:26:33 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Session Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:26:33 --> Session routines successfully run
DEBUG - 2014-07-06 06:26:33 --> Upload Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Controller Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:26:33 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:26:33 --> Severity: Notice  --> Undefined property: Superadmin::$logout C:\wamp\www\hostorks\application\controllers\superadmin.php 75
DEBUG - 2014-07-06 06:26:33 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:26:33 --> File loaded: application/views/superadmin/logout.php
DEBUG - 2014-07-06 06:26:33 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:26:33 --> Final output sent to browser
DEBUG - 2014-07-06 06:26:33 --> Total execution time: 0.2655
DEBUG - 2014-07-06 06:26:37 --> Config Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:26:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:26:37 --> URI Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Router Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Output Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Security Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Input Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:26:37 --> Language Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Loader Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:26:37 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:26:37 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Session Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:26:37 --> A session cookie was not found.
DEBUG - 2014-07-06 06:26:37 --> Session routines successfully run
DEBUG - 2014-07-06 06:26:37 --> Upload Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Controller Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:26:37 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:26:37 --> File loaded: application/views/superadmin/login.php
DEBUG - 2014-07-06 06:26:37 --> Final output sent to browser
DEBUG - 2014-07-06 06:26:37 --> Total execution time: 0.1580
DEBUG - 2014-07-06 06:26:45 --> Config Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:26:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:26:45 --> URI Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Router Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Output Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Security Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Input Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:26:45 --> Language Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Loader Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:26:45 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:26:45 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Session Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:26:45 --> Session routines successfully run
DEBUG - 2014-07-06 06:26:45 --> Upload Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Controller Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:26:45 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Model Class Initialized
DEBUG - 2014-07-06 06:26:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:26:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 06:26:45 --> XSS Filtering completed
DEBUG - 2014-07-06 06:27:51 --> Config Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:27:51 --> URI Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Router Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Output Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Security Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Input Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:27:51 --> Language Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Loader Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:27:51 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Session Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:27:51 --> Session routines successfully run
DEBUG - 2014-07-06 06:27:51 --> Upload Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Controller Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:27:51 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:27:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 06:27:51 --> XSS Filtering completed
DEBUG - 2014-07-06 06:27:51 --> Config Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:27:51 --> URI Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Router Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Output Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Security Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Input Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:27:51 --> Language Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Loader Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:27:51 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Session Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:27:51 --> Session routines successfully run
DEBUG - 2014-07-06 06:27:51 --> Upload Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Controller Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:27:51 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:27:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:27:51 --> Severity: Notice  --> Undefined property: Superadmin::$dashboard C:\wamp\www\hostorks\application\controllers\superadmin.php 75
DEBUG - 2014-07-06 06:27:51 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:27:51 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 06:27:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 06:27:51 --> Final output sent to browser
DEBUG - 2014-07-06 06:27:51 --> Total execution time: 0.1717
DEBUG - 2014-07-06 06:48:51 --> Config Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:48:51 --> URI Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Router Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Output Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Security Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Input Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:48:51 --> Language Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Loader Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:48:51 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:48:51 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Session Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:48:51 --> Session routines successfully run
DEBUG - 2014-07-06 06:48:51 --> Upload Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Controller Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:48:51 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Model Class Initialized
DEBUG - 2014-07-06 06:48:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:48:51 --> Severity: Notice  --> Use of undefined constant self - assumed 'self' C:\wamp\www\hostorks\application\controllers\superadmin.php 75
ERROR - 2014-07-06 06:48:51 --> Severity: Notice  --> Undefined property: Superadmin::$test C:\wamp\www\hostorks\application\controllers\superadmin.php 75
DEBUG - 2014-07-06 06:48:51 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:54:38 --> Config Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:54:38 --> URI Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Router Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Output Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Security Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Input Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:54:38 --> Language Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Loader Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:54:38 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:54:38 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Session Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:54:38 --> Session routines successfully run
DEBUG - 2014-07-06 06:54:38 --> Upload Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Controller Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:54:38 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Model Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Model Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Model Class Initialized
DEBUG - 2014-07-06 06:54:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 06:54:38 --> Severity: Notice  --> Use of undefined constant self - assumed 'self' C:\wamp\www\hostorks\application\controllers\superadmin.php 75
DEBUG - 2014-07-06 06:54:38 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 06:57:25 --> Config Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:57:25 --> URI Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Router Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Output Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Security Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Input Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:57:25 --> Language Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Loader Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:57:25 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:57:25 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Session Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:57:25 --> Session routines successfully run
DEBUG - 2014-07-06 06:57:25 --> Upload Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Controller Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:57:25 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Model Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Model Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Model Class Initialized
DEBUG - 2014-07-06 06:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:57:25 --> Final output sent to browser
DEBUG - 2014-07-06 06:57:25 --> Total execution time: 0.1804
DEBUG - 2014-07-06 06:58:22 --> Config Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Hooks Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Utf8 Class Initialized
DEBUG - 2014-07-06 06:58:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 06:58:22 --> URI Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Router Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Output Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Security Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Input Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 06:58:22 --> Language Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Loader Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Helper loaded: url_helper
DEBUG - 2014-07-06 06:58:22 --> Helper loaded: file_helper
DEBUG - 2014-07-06 06:58:22 --> Database Driver Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Session Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Helper loaded: string_helper
DEBUG - 2014-07-06 06:58:22 --> Session routines successfully run
DEBUG - 2014-07-06 06:58:22 --> Upload Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Pagination Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Controller Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Helper loaded: form_helper
DEBUG - 2014-07-06 06:58:22 --> Form Validation Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Model Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Model Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Model Class Initialized
DEBUG - 2014-07-06 06:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 06:58:22 --> Final output sent to browser
DEBUG - 2014-07-06 06:58:22 --> Total execution time: 0.1335
DEBUG - 2014-07-06 07:40:49 --> Config Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Hooks Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Utf8 Class Initialized
DEBUG - 2014-07-06 07:40:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 07:40:49 --> URI Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Router Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Output Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Security Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Input Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 07:40:49 --> Language Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Loader Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Helper loaded: url_helper
DEBUG - 2014-07-06 07:40:49 --> Helper loaded: file_helper
DEBUG - 2014-07-06 07:40:49 --> Database Driver Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Session Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Helper loaded: string_helper
DEBUG - 2014-07-06 07:40:49 --> Session routines successfully run
DEBUG - 2014-07-06 07:40:49 --> Upload Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Pagination Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Controller Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Helper loaded: form_helper
DEBUG - 2014-07-06 07:40:49 --> Form Validation Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Model Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Model Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Model Class Initialized
DEBUG - 2014-07-06 07:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 07:40:49 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 07:40:49 --> Final output sent to browser
DEBUG - 2014-07-06 07:40:49 --> Total execution time: 0.2097
DEBUG - 2014-07-06 09:34:00 --> Config Class Initialized
DEBUG - 2014-07-06 09:34:00 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:34:00 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:34:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:34:01 --> URI Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Router Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Output Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Security Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Input Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:34:01 --> Language Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Loader Class Initialized
DEBUG - 2014-07-06 09:34:01 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:34:01 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:34:01 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Session Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:34:02 --> Session routines successfully run
DEBUG - 2014-07-06 09:34:02 --> Upload Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Controller Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:34:02 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Model Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Model Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Model Class Initialized
DEBUG - 2014-07-06 09:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:34:02 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:34:02 --> Final output sent to browser
DEBUG - 2014-07-06 09:34:02 --> Total execution time: 1.5490
DEBUG - 2014-07-06 09:34:18 --> Config Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:34:18 --> URI Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Router Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Output Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Security Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Input Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:34:18 --> Language Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Loader Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:34:18 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:34:18 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Session Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:34:18 --> Session routines successfully run
DEBUG - 2014-07-06 09:34:18 --> Upload Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Controller Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:34:18 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Model Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Model Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Model Class Initialized
DEBUG - 2014-07-06 09:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:34:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 09:34:19 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:34:19 --> Final output sent to browser
DEBUG - 2014-07-06 09:34:19 --> Total execution time: 0.8624
DEBUG - 2014-07-06 09:35:39 --> Config Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:35:39 --> URI Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Router Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Output Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Security Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Input Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:35:39 --> Language Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Loader Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:35:39 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:35:39 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Session Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:35:39 --> Session routines successfully run
DEBUG - 2014-07-06 09:35:39 --> Upload Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Controller Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:35:39 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Model Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Model Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Model Class Initialized
DEBUG - 2014-07-06 09:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:35:39 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:35:39 --> Final output sent to browser
DEBUG - 2014-07-06 09:35:39 --> Total execution time: 0.1770
DEBUG - 2014-07-06 09:36:29 --> Config Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:36:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:36:29 --> URI Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Router Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Output Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Security Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Input Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:36:29 --> Language Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Loader Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:36:29 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:36:29 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Session Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:36:29 --> Session routines successfully run
DEBUG - 2014-07-06 09:36:29 --> Upload Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Controller Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:36:29 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Model Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Model Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Model Class Initialized
DEBUG - 2014-07-06 09:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:36:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:36:29 --> Final output sent to browser
DEBUG - 2014-07-06 09:36:29 --> Total execution time: 0.1461
DEBUG - 2014-07-06 09:36:45 --> Config Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:36:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:36:45 --> URI Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Router Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Output Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Security Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Input Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:36:45 --> Language Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Loader Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:36:45 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:36:45 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Session Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:36:45 --> Session routines successfully run
DEBUG - 2014-07-06 09:36:45 --> Upload Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Controller Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:36:45 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Model Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Model Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Model Class Initialized
DEBUG - 2014-07-06 09:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:36:45 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 09:36:45 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:36:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 09:36:45 --> Final output sent to browser
DEBUG - 2014-07-06 09:36:45 --> Total execution time: 0.1583
DEBUG - 2014-07-06 09:37:41 --> Config Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:37:41 --> URI Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Router Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Output Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Security Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Input Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:37:41 --> Language Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Loader Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:37:41 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:37:41 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Session Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:37:41 --> Session routines successfully run
DEBUG - 2014-07-06 09:37:41 --> Upload Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Controller Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:37:41 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Model Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Model Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Model Class Initialized
DEBUG - 2014-07-06 09:37:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:37:41 --> DB Transaction Failure
ERROR - 2014-07-06 09:37:41 --> Query error: Unknown column 'tbl_links.str_type2' in 'where clause'
DEBUG - 2014-07-06 09:37:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-06 09:39:03 --> Config Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:39:03 --> URI Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Router Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Output Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Security Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Input Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:39:03 --> Language Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Loader Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:39:03 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:39:03 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Session Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:39:03 --> Session routines successfully run
DEBUG - 2014-07-06 09:39:03 --> Upload Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Controller Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:39:03 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Model Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Model Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Model Class Initialized
DEBUG - 2014-07-06 09:39:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:39:36 --> Config Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:39:36 --> URI Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Router Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Output Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Security Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Input Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:39:36 --> Language Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Loader Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:39:36 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:39:36 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Session Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:39:36 --> Session routines successfully run
DEBUG - 2014-07-06 09:39:36 --> Upload Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Controller Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:39:36 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Model Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Model Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Model Class Initialized
DEBUG - 2014-07-06 09:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:40:49 --> Config Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:40:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:40:49 --> URI Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Router Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Output Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Security Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Input Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:40:49 --> Language Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Loader Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:40:49 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:40:49 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Session Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:40:49 --> Session routines successfully run
DEBUG - 2014-07-06 09:40:49 --> Upload Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Controller Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:40:49 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Model Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Model Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Model Class Initialized
DEBUG - 2014-07-06 09:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:40:49 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 09:40:49 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:40:49 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 09:40:49 --> Final output sent to browser
DEBUG - 2014-07-06 09:40:49 --> Total execution time: 0.1760
DEBUG - 2014-07-06 09:41:51 --> Config Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:41:51 --> URI Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Router Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Output Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Security Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Input Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:41:51 --> Language Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Loader Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:41:51 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:41:51 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Session Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:41:51 --> Session routines successfully run
DEBUG - 2014-07-06 09:41:51 --> Upload Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Controller Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:41:51 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Model Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Model Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Model Class Initialized
DEBUG - 2014-07-06 09:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:41:51 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 09:41:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 09:41:51 --> Final output sent to browser
DEBUG - 2014-07-06 09:41:51 --> Total execution time: 0.1590
DEBUG - 2014-07-06 09:43:21 --> Config Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:43:21 --> URI Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Router Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Output Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Security Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Input Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:43:21 --> Language Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Loader Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:43:21 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:43:21 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Session Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:43:21 --> Session routines successfully run
DEBUG - 2014-07-06 09:43:21 --> Upload Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Controller Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:43:21 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Model Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Model Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Model Class Initialized
DEBUG - 2014-07-06 09:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:43:21 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 09:43:54 --> Config Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:43:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:43:54 --> URI Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Router Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Output Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Security Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Input Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:43:54 --> Language Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Loader Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:43:54 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:43:54 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Session Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:43:54 --> Session routines successfully run
DEBUG - 2014-07-06 09:43:54 --> Upload Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Controller Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:43:54 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Model Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Model Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Model Class Initialized
DEBUG - 2014-07-06 09:43:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:43:54 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 09:44:34 --> Config Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Hooks Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Utf8 Class Initialized
DEBUG - 2014-07-06 09:44:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 09:44:34 --> URI Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Router Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Output Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Security Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Input Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 09:44:34 --> Language Class Initialized
DEBUG - 2014-07-06 09:44:34 --> Loader Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Helper loaded: url_helper
DEBUG - 2014-07-06 09:44:35 --> Helper loaded: file_helper
DEBUG - 2014-07-06 09:44:35 --> Database Driver Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Session Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Helper loaded: string_helper
DEBUG - 2014-07-06 09:44:35 --> Session routines successfully run
DEBUG - 2014-07-06 09:44:35 --> Upload Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Pagination Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Controller Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Helper loaded: form_helper
DEBUG - 2014-07-06 09:44:35 --> Form Validation Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Model Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Model Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Model Class Initialized
DEBUG - 2014-07-06 09:44:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 09:44:35 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 09:44:35 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 09:44:35 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 09:44:35 --> Final output sent to browser
DEBUG - 2014-07-06 09:44:35 --> Total execution time: 0.1727
DEBUG - 2014-07-06 10:49:43 --> Config Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:49:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:49:43 --> URI Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Router Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Output Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Security Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Input Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:49:43 --> Language Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Loader Class Initialized
DEBUG - 2014-07-06 10:49:43 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:49:43 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:49:44 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Session Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:49:44 --> Session routines successfully run
DEBUG - 2014-07-06 10:49:44 --> Upload Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Controller Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:49:44 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Model Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Model Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Model Class Initialized
DEBUG - 2014-07-06 10:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:49:44 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 10:49:44 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:49:44 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 10:49:44 --> Final output sent to browser
DEBUG - 2014-07-06 10:49:44 --> Total execution time: 0.5174
DEBUG - 2014-07-06 10:50:24 --> Config Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:50:24 --> URI Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Router Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Output Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Security Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Input Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:50:24 --> Language Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Loader Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:50:24 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:50:24 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Session Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:50:24 --> Session routines successfully run
DEBUG - 2014-07-06 10:50:24 --> Upload Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Controller Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:50:24 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:50:24 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 10:50:24 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:50:24 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 10:50:24 --> Final output sent to browser
DEBUG - 2014-07-06 10:50:24 --> Total execution time: 0.1829
DEBUG - 2014-07-06 10:50:41 --> Config Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:50:41 --> URI Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Router Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Output Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Security Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Input Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:50:41 --> Language Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Loader Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:50:41 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:50:41 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Session Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:50:41 --> Session routines successfully run
DEBUG - 2014-07-06 10:50:41 --> Upload Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Controller Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:50:41 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:50:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 10:50:41 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:50:41 --> Final output sent to browser
DEBUG - 2014-07-06 10:50:41 --> Total execution time: 0.1459
DEBUG - 2014-07-06 10:50:49 --> Config Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:50:49 --> URI Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Router Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Output Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Security Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Input Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:50:49 --> Language Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Loader Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:50:49 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:50:49 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Session Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:50:49 --> Session routines successfully run
DEBUG - 2014-07-06 10:50:49 --> Upload Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Controller Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:50:49 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Model Class Initialized
DEBUG - 2014-07-06 10:50:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:50:49 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 10:50:49 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:50:49 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 10:50:49 --> Final output sent to browser
DEBUG - 2014-07-06 10:50:49 --> Total execution time: 0.1840
DEBUG - 2014-07-06 10:51:08 --> Config Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:51:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:51:08 --> URI Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Router Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Output Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Security Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Input Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:51:08 --> Language Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Loader Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:51:08 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:51:08 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Session Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:51:08 --> Session routines successfully run
DEBUG - 2014-07-06 10:51:08 --> Upload Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Controller Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:51:08 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:51:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 10:51:08 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:51:08 --> Final output sent to browser
DEBUG - 2014-07-06 10:51:08 --> Total execution time: 0.1652
DEBUG - 2014-07-06 10:51:26 --> Config Class Initialized
DEBUG - 2014-07-06 10:51:26 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:51:26 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:51:27 --> URI Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Router Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Output Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Security Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Input Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:51:27 --> Language Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Loader Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:51:27 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:51:27 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Session Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:51:27 --> Session routines successfully run
DEBUG - 2014-07-06 10:51:27 --> Upload Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Controller Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:51:27 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:51:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 10:51:27 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:51:27 --> Final output sent to browser
DEBUG - 2014-07-06 10:51:27 --> Total execution time: 0.2727
DEBUG - 2014-07-06 10:51:37 --> Config Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:51:37 --> URI Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Router Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Output Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Security Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Input Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:51:37 --> Language Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Loader Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:51:37 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:51:37 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Session Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:51:37 --> Session routines successfully run
DEBUG - 2014-07-06 10:51:37 --> Upload Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Controller Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:51:37 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:51:37 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:51:37 --> Final output sent to browser
DEBUG - 2014-07-06 10:51:37 --> Total execution time: 0.1408
DEBUG - 2014-07-06 10:51:42 --> Config Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:51:42 --> URI Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Router Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Output Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Security Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Input Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:51:42 --> Language Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Loader Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:51:42 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:51:42 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Session Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:51:42 --> Session routines successfully run
DEBUG - 2014-07-06 10:51:42 --> Upload Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Controller Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:51:42 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:51:42 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 10:51:42 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:51:42 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 10:51:42 --> Final output sent to browser
DEBUG - 2014-07-06 10:51:42 --> Total execution time: 0.1802
DEBUG - 2014-07-06 10:51:59 --> Config Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:51:59 --> URI Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Router Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Output Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Security Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Input Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:51:59 --> Language Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Loader Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:51:59 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:51:59 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Session Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:51:59 --> Session routines successfully run
DEBUG - 2014-07-06 10:51:59 --> Upload Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Controller Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:51:59 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Model Class Initialized
DEBUG - 2014-07-06 10:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:51:59 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:51:59 --> Final output sent to browser
DEBUG - 2014-07-06 10:51:59 --> Total execution time: 0.4039
DEBUG - 2014-07-06 10:59:05 --> Config Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:59:05 --> URI Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Router Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Output Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Security Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Input Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:59:05 --> Language Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Loader Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:59:05 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:59:05 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Session Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:59:05 --> Session routines successfully run
DEBUG - 2014-07-06 10:59:05 --> Upload Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:59:05 --> Controller Class Initialized
DEBUG - 2014-07-06 10:59:06 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:59:06 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:59:06 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:06 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:06 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:59:06 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 10:59:06 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:59:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 10:59:06 --> Final output sent to browser
DEBUG - 2014-07-06 10:59:06 --> Total execution time: 0.1688
DEBUG - 2014-07-06 10:59:29 --> Config Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:59:29 --> URI Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Router Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Output Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Security Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Input Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:59:29 --> Language Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Loader Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:59:29 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:59:29 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Session Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:59:29 --> Session routines successfully run
DEBUG - 2014-07-06 10:59:29 --> Upload Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Controller Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:59:29 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:59:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-06 10:59:29 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:59:29 --> Final output sent to browser
DEBUG - 2014-07-06 10:59:29 --> Total execution time: 0.2000
DEBUG - 2014-07-06 10:59:41 --> Config Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:59:41 --> URI Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Router Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Output Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Security Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Input Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:59:41 --> Language Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Loader Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:59:41 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:59:41 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Session Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:59:41 --> Session routines successfully run
DEBUG - 2014-07-06 10:59:41 --> Upload Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Controller Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:59:41 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:59:41 --> File loaded: application/views/templates/header.php
DEBUG - 2014-07-06 10:59:41 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:59:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2014-07-06 10:59:41 --> Final output sent to browser
DEBUG - 2014-07-06 10:59:41 --> Total execution time: 0.1521
DEBUG - 2014-07-06 10:59:50 --> Config Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:59:50 --> URI Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Router Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Output Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Security Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Input Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:59:50 --> Language Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Loader Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:59:50 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:59:50 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Session Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:59:50 --> Session routines successfully run
DEBUG - 2014-07-06 10:59:50 --> Upload Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Controller Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:59:50 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-06 10:59:50 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:59:50 --> Final output sent to browser
DEBUG - 2014-07-06 10:59:50 --> Total execution time: 0.3372
DEBUG - 2014-07-06 10:59:57 --> Config Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Hooks Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Utf8 Class Initialized
DEBUG - 2014-07-06 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-06 10:59:57 --> URI Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Router Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Output Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Security Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Input Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-06 10:59:57 --> Language Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Loader Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Helper loaded: url_helper
DEBUG - 2014-07-06 10:59:57 --> Helper loaded: file_helper
DEBUG - 2014-07-06 10:59:57 --> Database Driver Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Session Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Helper loaded: string_helper
DEBUG - 2014-07-06 10:59:57 --> Session routines successfully run
DEBUG - 2014-07-06 10:59:57 --> Upload Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Pagination Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Controller Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Helper loaded: form_helper
DEBUG - 2014-07-06 10:59:57 --> Form Validation Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Model Class Initialized
DEBUG - 2014-07-06 10:59:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-06 10:59:57 --> Severity: Notice  --> Undefined variable: menuid C:\wamp\www\hostorks\application\models\superadmin_model.php 58
ERROR - 2014-07-06 10:59:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\hostorks\application\models\superadmin_model.php 58
DEBUG - 2014-07-06 10:59:57 --> File loaded: application/views/superadmin/dashboard.php
DEBUG - 2014-07-06 10:59:57 --> Final output sent to browser
DEBUG - 2014-07-06 10:59:57 --> Total execution time: 0.1937

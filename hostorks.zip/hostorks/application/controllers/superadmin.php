<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Superadmin extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('login_model');
		$this->load->model('superadmin_model');
		$this->load->library("session");
	}
	
	public function index()
	{
		if($this->session->userdata('user_logged_in'))
		{
			$this->load->view('superadmin/dashboard');	
		}
		else
		{
			$this->load->view('superadmin/login');
		}
	}
	
	public function login()
	{		
		$data['enterusername'] = $this->input->post('loginusername') ;
		$data['enterpassword'] = $this->input->post('loginpassword') ;
		
		$this->form_validation->set_rules('loginusername', 'Email', 'trim|required|max_length[80]');
		$this->form_validation->set_rules('loginpassword', 'Password', 'trim|required|min_length[1]|max_length[64]|xss_clean');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['error'] = validation_errors();			
			$this->load->view('superadmin/login', $data);
		}
		else
		{				
			$password = base64_encode($this->input->post('loginpassword')) ;
			$result = intval($this->login_model->validate_login( $this->input->post('loginusername'), $password)) ;
			
			if($result == "0")
			{
				$data['error'] = 'Login failed, invalid user name or password';				
				$this->load->view('superadmin/login', $data);	
			}
			else
			{	
				$sessiondata = array('testusername'=> $this->input->post('loginusername'),'user_logged_in' => TRUE);
				$this->session->set_userdata($sessiondata);
				
				redirect(base_url().'superadmin/dashboard');
			}
		}
	}
	
	
	function logout()
	{
		$sessiondata = array('testusername'=> '','user_logged_in' => FALSE);
		$this->session->unset_userdata($sessiondata);
		redirect(base_url().'superadmin');
	}
	
	
	public function pages($page = 'home')
	{
		if(method_exists($this,$page))
		{
			$this->$page(); 
		}
		else
		{
			if(!file_exists(APPPATH.'/views/superadmin/'.$page.'.php'))
			{
				show_404();
			}
			else
			{
				$data['title'] = ucfirst($page); // Capitalize the first letter
				$data['header_links'] = $this->superadmin_model->get_links('main_menu') ; 
				
				$this->load->view('superadmin/includes/header', $data);
				$this->load->view('superadmin/'.$page, $data);
				$this->load->view('superadmin/includes/footer', $data);
			}
		}
	}
	
	public function save_links()
	{	
		$this->form_validation->set_rules('menu_name', 'Menu Name', 'trim|required|max_length[200]');
		$this->form_validation->set_rules('menu_link', 'Menu Link', 'trim|required|max_length[250]');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['error'] = validation_errors();			
			$this->load->view('superadmin/dashboard', $data);
		}
		else
		{				
			$result = intval($this->superadmin_model->save_menu_item($this->input->post('menu_name'), $this->input->post('menu_link'), $this->input->post('menu_order'), $this->input->post('link_type'), $this->input->post('menu_parent'))) ;
			if($result == 0)
			{
				$data['error'] = 'Failed to add Menu Item.';
			}
			else
			{
				$data['success'] = 'Menu added successfully.';
			}
			redirect(base_url().'superadmin/header_manage');
		}
	}
	
	public function update_links()
	{					
		$result = intval($this->superadmin_model->update_menu_item($_POST)) ;
		if($result == 0)
		{
			$data['error'] = 'All Menu Items not Updated.';
		}
		else
		{
			$data['success'] = 'Menu updated successfully.';
		}
		
		$data['header_links'] = $this->superadmin_model->get_links('main_menu') ; 
		redirect(base_url().'superadmin/header_manage');
	}
	
	function delete_menu()
	{
		$result = intval($this->superadmin_model->delete_menu_item($this->uri->segment(3))) ;
		if($result == 0)
		{
			$data['error'] = 'Menu item can not be deleted.';
		}
		else
		{
			$data['success'] = 'Menu Deleted successfully.';
		}
		redirect(base_url().'superadmin/header_manage');
	}
	
	function manage_contact_info()
	{
		$entered_info_names = array();
		$entered_info_values = array(); 				
		
		$entered_info_names[] = $this->input->post('info_name_phone') ;
		$entered_info_names[] = $this->input->post('info_name_email') ;
		$entered_info_names[] = $this->input->post('info_name_support') ;
		
		$entered_info_values[] = $this->input->post('header_phone') ;
		$entered_info_values[] = $this->input->post('header_email') ;
		$entered_info_values[] = $this->input->post('support_link') ;
						
		$this->superadmin_model->save_info($entered_info_names,$entered_info_values) ;		
		redirect(base_url().'superadmin/header_manage');
	}
	
	function upload_logo()
	{
		$config['upload_path'] = 'includes/superadmin/uploads/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_size']	= '100';
		$config['max_width']  = '115';
		$config['max_height']  = '80';

		$this->upload->initialize($config);
		$this->load->library('upload', $config);
		
		if (!$this->upload->do_upload('upload_footer_logo'))
		{
			$error = array('error' => $this->upload->display_errors());
			$this->load->view('superadmin/footer_manage', $error);
		}
		else
		{
			$upload_data = $this->upload->data();
			$result = intval($this->superadmin_model->save_logos($upload_data['file_name'])) ;
			if($result == 0)
			{
				$data['error'] = 'Logo can not be added.';
			}
			else
			{
				$data['success'] = 'Logo Added successfully.';
			}
			redirect(base_url().'superadmin/footer_manage');
		}
	}
	
	function delete_logo()
	{
		$result = intval($this->superadmin_model->delete_logo($this->uri->segment(3))) ;
		if($result == 0)
		{
			$data['error'] = 'Logo can not be deleted.';
		}
		else
		{
			$data['success'] = 'Logo Deleted successfully.';
		}
		redirect(base_url().'superadmin/footer_manage');
	}
	
	function manage_footer_info()
	{
		$entered_info_names = array();
		$entered_info_values = array(); 				
		
		$entered_info_names[] = $this->input->post('contact_email') ;
		$entered_info_names[] = $this->input->post('facebook_link_name') ;
		$entered_info_names[] = $this->input->post('twitter_link_name') ;
		$entered_info_names[] = $this->input->post('linkedin_link_name') ;
		$entered_info_names[] = $this->input->post('rss_link_name') ;
		$entered_info_names[] = $this->input->post('copyright_name') ;
		
		$entered_info_values[] = $this->input->post('contact_email_address') ;
		$entered_info_values[] = $this->input->post('facebook_link') ;
		$entered_info_values[] = $this->input->post('twitter_link') ;
		$entered_info_values[] = $this->input->post('linkedin_link') ;
		$entered_info_values[] = $this->input->post('rss_link') ;
		$entered_info_values[] = $this->input->post('copyright') ;
						
		$this->superadmin_model->save_info($entered_info_names,$entered_info_values) ;		
		redirect(base_url().'superadmin/footer_manage');
	}
	
	function manage_slides()
	{
		$slide_title = $this->input->post('slide_title') ;
		$slide_short_desc = $this->input->post('slide_short_desc') ;
		$slide_view_text = $this->input->post('slide_view_text') ;
		$slide_view_link = $this->input->post('slide_view_link') ;
		$slide_signup_text = $this->input->post('slide_signup_text') ;
		$slide_signup_link = $this->input->post('slide_signup_link') ;
		$slide_image = $this->input->post('slide_image') ;
		
		$config['upload_path'] = 'includes/superadmin/uploads/home_slides';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		
		$this->upload->initialize($config);
		$this->load->library('upload', $config);
		
		if (!$this->upload->do_upload('slide_image'))
		{
			$error = array('error' => $this->upload->display_errors());
			$this->load->view('superadmin/home_slider', $error);
		}
		else
		{
			$upload_data = $this->upload->data();
			$uploaded_file_name = $upload_data['file_name'] ; 
			$result = intval($this->superadmin_model->save_slides($slide_title, $slide_short_desc, $slide_view_text, $slide_view_link, $slide_signup_text, $slide_signup_link, $uploaded_file_name)) ;
			if($result == 0)
			{
				$data['error'] = 'Slide can not be added.';
			}
			else
			{
				$data['success'] = 'Slide Added successfully.';
			}
			redirect(base_url().'superadmin/home_slider');
		}
	}
	
	function update_slides()
	{
		$slide_id = $this->input->post('hdneditid') ;
		$slide_title = $this->input->post('slide_title') ;
		$slide_short_desc = $this->input->post('slide_short_desc') ;
		$slide_view_text = $this->input->post('slide_view_text') ;
		$slide_view_link = $this->input->post('slide_view_link') ;
		$slide_signup_text = $this->input->post('slide_signup_text') ;
		$slide_signup_link = $this->input->post('slide_signup_link') ;
		$slide_image = $this->input->post('slide_image') ; 
		$delete_photo = $this->input->post('delete_photo') ;
		
		$config['upload_path'] = 'includes/superadmin/uploads/home_slides';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		
		$this->upload->initialize($config);
		$this->load->library('upload', $config);
		
		if ($_FILES["slide_image"]["name"])
		{
			if (!$this->upload->do_upload('slide_image'))
			{
				$error = array('error' => $this->upload->display_errors());
				$this->load->view('superadmin/home_slider', $error);
			}
			else
			{
				$upload_data = $this->upload->data();
				$uploaded_file_name = $upload_data['file_name'] ; 
				$result = intval($this->superadmin_model->update_slides($slide_id, $slide_title, $slide_short_desc, $slide_view_text, $slide_view_link, $slide_signup_text, $slide_signup_link, $uploaded_file_name)) ;
				if($result == 0)
				{
					$data['error'] = 'Slide can not be added.';
				}
				else
				{
					$data['success'] = 'Slide Added successfully.';
				}
				redirect(base_url().'superadmin/home_slider');
			}
		}
		else
		{
			if($delete_photo == "on"){
				$uploaded_file_name = "" ;
			}else{
				$uploaded_file_name = $this->input->post('hdn_slide_image') ;
			}
			$result = intval($this->superadmin_model->update_slides($slide_id, $slide_title, $slide_short_desc, $slide_view_text, $slide_view_link, $slide_signup_text, $slide_signup_link, $uploaded_file_name)) ;
			if($result == 0)
			{
				$data['error'] = 'Slide can not be updated.';
			}
			else
			{
				$data['success'] = 'Slide Updated successfully.';
			}
			redirect(base_url().'superadmin/home_slider');
		}
	}
	
	function delete_slide()
	{
		$result = intval($this->superadmin_model->delete_content($this->uri->segment(3))) ;
		if($result == 0)
		{
			$data['error'] = 'Slide can not be deleted.';
		}
		else
		{
			$data['success'] = 'Slide Deleted successfully.';
		}
		redirect(base_url().'superadmin/footer_manage');
	}
	
	
	function manage_plans()
	{
		$special_plan = $this->input->post('special_plan') ;
		$plan_name = $this->input->post('plan_name') ;
		$plan_link = $this->input->post('plan_link') ;
		$plan_price = $this->input->post('plan_price') ;
		$plan_type = $this->input->post('plan_type') ;
		
		$this->load->library('upload', $config);
		
		$tab_images_names = array(); 
		$count = count($_FILES['tab_image']); 
		foreach($_FILES as $key=>$value) 
		{
			for($s=0; $s<=$count-1; $s++)
			{
				if($value['name'][$s])
				{
					$_FILES['userfile']['name']= $value['name'][$s];
					$_FILES['userfile']['type'] = $value['type'][$s];
					$_FILES['userfile']['tmp_name'] = $value['tmp_name'][$s];
					$_FILES['userfile']['error'] = $value['error'][$s]; 
					$_FILES['userfile']['size'] = $value['size'][$s]; 
					
					$config['upload_path'] = 'includes/superadmin/uploads/home_plans';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					
					$this->upload->initialize($config);
					
					if(!$this->upload->do_upload())
					{
						//$error = array('error' => $this->upload->display_errors());
						//redirect(base_url().'superadmin/home_plans'); 
						$tab_images_names[] = "" ; 
					}
					else
					{
						$upload_data = $this->upload->data();
						$tab_images_names[] = $upload_data['file_name'] ; 
					} 
				}
				else
				{
					$tab_images_names[] = "" ; 
				}
			}
		}
		
		$result = intval($this->superadmin_model->manage_plans($special_plan, $plan_name,$plan_link, $plan_price ,$plan_type ,$_POST, $tab_images_names)) ;
		if($result == 0)
		{
			$data['error'] = 'All Menu Items not Updated.';
		}
		else
		{
			$data['success'] = 'Menu updated successfully.';
		}
		
		$data['header_links'] = $this->superadmin_model->get_links('main_menu') ; 
		redirect(base_url().'superadmin/home_plans');
	}
	
	function update_plans()
	{
		$special_plan = $this->input->post('special_plan') ;
		$plan_name = $this->input->post('plan_name') ;
		$plan_link = $this->input->post('plan_link') ;
		$plan_price = $this->input->post('plan_price') ;
		$plan_type = $this->input->post('plan_month_year') ;
		$update_plan_id = $this->input->post('hdneditid') ;
		
		
		
		
		$tab_images_names = array(); 
		$count = count($_FILES['tab_image']); 
		foreach($_FILES as $key=>$value) 
		{
			for($s=0; $s<=$count-1; $s++)
			{
				if($value['name'][$s])
				{
					$_FILES['userfile']['name']= $value['name'][$s];
					$_FILES['userfile']['type'] = $value['type'][$s];
					$_FILES['userfile']['tmp_name'] = $value['tmp_name'][$s];
					$_FILES['userfile']['error'] = $value['error'][$s]; 
					$_FILES['userfile']['size'] = $value['size'][$s]; 
					
					$config['upload_path'] = 'includes/superadmin/uploads/home_plans';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					
					$this->upload->initialize($config);
					
					if(!$this->upload->do_upload())
					{
						$tab_images_names[] = "" ; 
					}
					else
					{
						$upload_data = $this->upload->data();
						$tab_images_names[] = $upload_data['file_name'] ; 
					} 
				}
				else
				{
					$tab_images_names[] = "" ; 
				}
			}
		}
		
		$result = intval($this->superadmin_model->update_plans($update_plan_id, $special_plan, $plan_name,$plan_link, $plan_price ,$plan_type ,$_POST, $tab_images_names)) ;
		if($result == 0)
		{
			$data['error'] = 'All Menu Items not Updated.';
		}
		else
		{
			$data['success'] = 'Menu updated successfully.';
		}
		
		$data['header_links'] = $this->superadmin_model->get_links('main_menu') ; 
		redirect(base_url().'superadmin/home_plans');
	}
	
	function delete_plan()
	{
		$result = intval($this->superadmin_model->delete_content($this->uri->segment(3))) ;
		if($result == 0)
		{
			$data['error'] = 'Plan can not be deleted.';
		}
		else
		{
			$data['success'] = 'Plan Deleted successfully.';
		}
		redirect(base_url().'superadmin/home_plans');
	}
}
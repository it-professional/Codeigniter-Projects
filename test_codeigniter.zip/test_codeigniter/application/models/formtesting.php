<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php class Formtesting extends CI_Model{
	  	
		public function test_form_insertion($getusername,$getemail,$getpass){
			$result = $this->db->insert('users', array('name' => "$getusername", 'email' => "$getemail", 'password' => "$getpass" ));
			if($result){
				return 1;
			}else{
				return 0;
			}
		}
}
?>
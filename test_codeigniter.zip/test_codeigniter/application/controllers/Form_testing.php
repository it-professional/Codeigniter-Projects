<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_testing extends CI_Controller {
	public function __construct(){
		parent::__construct();	
		$this->load->helper(array('form','url'));
		$this->load->library(array('form_validation'));
		$this->load->model('formtesting');
	}
	
	public function index(){
		$this->load->view('test_form');
	}
	
	public function form_submit(){
		$this->form_validation->set_rules('user_name','User Name','required|trim|is_unique[users.name]');
		$this->form_validation->set_rules('user_email','Email','required|valid_email');
		$this->form_validation->set_rules('user_pass','Password','required');
		$this->form_validation->set_rules('user_conf_pass','Confirm Password','required|matches[user_pass]');
		
		if($this->form_validation->run() == FALSE){
			$this->load->view('test_form');
		}else{
			$getresult = $this->formtesting->test_form_insertion($this->input->post('user_name'),$this->input->post('user_email'),$this->input->post('user_pass'));
			
			if($getresult == 1){
				//echo "Everything is Okay";
				redirect('/account/login', 'refresh');
			}else{
				echo "There is error to insert the record. <br>get result value is: ".$getresult;
			}
		}
	}
	
	public function page(){
		
	}
}
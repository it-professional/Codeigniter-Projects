<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php  $attributes = array('class' => 'test form class', 'id' => 'testform');
       echo form_open('form_testing/form_submit', $attributes); ?>
       
	<?php //echo validation_errors(); ?>
    
	<?php echo form_error('user_name','<div class="error">','</div>'); ?>
    <input type="text" name="user_name" placeholder="User Name" value="<?php echo set_value('user_name'); ?>">
    
    <?php echo form_error('user_email','<div class="error">','</div>'); ?>
    <input type="email" name="user_email" placeholder="User Email" value="<?php echo set_value('user_email'); ?>">
    
    <?php echo form_error('user_pass','<div class="error">','</div>'); ?>
    <input type="password" name="user_pass" placeholder="User Password" value="<?php echo set_value('user_pass'); ?>">
    
    <?php echo form_error('user_conf_pass','<div class="error">','</div>'); ?>
    <input type="password" name="user_conf_pass" placeholder="Confirm Password" value="<?php echo set_value('user_conf_pass'); ?>">
    
    <input type="submit" value="Register" name="register" >
<?php echo form_close();?>